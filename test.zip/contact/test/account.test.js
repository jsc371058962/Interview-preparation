/* global jest, describe, it, expect, shallow, mount, render, toJson */
import accountManger, { accountStore } from 'account/account_manager';

describe('Account', () => {
  it('accountStore should be ready', () => {
    return accountStore.whenReady.then(result => {
      expect(result).toBeTruthy();
    });
  });

  it('accountStore CRUD ok', () => {
    const mockId = 'mockId';
    const mockAccount = {
      accountId: mockId,
      store: { _shouldShowContacts: true },
    };
    const updatedAccount = {
      accountId: mockId,
      updated: true,
      store: { _shouldShowContacts: true },
    };

    accountStore.set(mockAccount);
    expect(accountStore.getAccountById(mockId)).toEqual(mockAccount);

    accountStore.set(updatedAccount);
    expect(accountStore.getAccountById(mockId)).toEqual(updatedAccount);

    accountStore.remove(mockId);
    expect(accountStore.getAccountById(mockId)).toEqual({});
  });
});
