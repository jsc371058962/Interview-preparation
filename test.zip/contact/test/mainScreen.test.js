/* global jest, describe, it, expect, shallow, mount, render, toJson */
import React from 'react';
import ContactListView from '../src/list';
import ICEListView from '../src/ice_list_view';
import FavoriteView from '../src/favorite_view';

describe('Main Screen', () => {
  it('list.js render ok', () => {
    const wrapper = render(<ContactListView />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  it('ice_list_view render ok', () => {
    const wrapper = render(<ICEListView />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  it('favorite_view render ok', () => {
    const wrapper = render(<FavoriteView />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });
});
