/* global jest, describe, it, expect, shallow, mount, render, toJson */
import React from 'react';
import { mount } from 'enzyme';
import ContactListView from '../src/list';
import ContactStore from '../src/contact_store';
import Search from '../src/search';

jest.useFakeTimers();

describe('Contact Picker', () => {
  const spyContactStoreSearch = jest.spyOn(ContactStore, 'search');

  it('pick tel render ok', () => {
    const wrapper = render(<ContactListView target="tel" />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  it('should invoke ContactStore.search', () => {
    const wrapper = mount(<Search />);
    wrapper.find('input#search').simulate('change');
    wrapper.instance().doSearch('eeeee');
    expect(spyContactStoreSearch).toHaveBeenCalled();
    expect(spyContactStoreSearch).toHaveBeenCalledTimes(1);
  });
});
