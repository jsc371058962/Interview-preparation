/* global jest, describe, it, expect, shallow, mount, render, toJson */
import React from 'react';
import Search from '../src/search';

describe('Search', () => {
  it('search render ok', () => {
    const wrapper = render(<Search />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });
});
