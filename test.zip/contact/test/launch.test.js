/* global jest, describe, it, expect, shallow, mount, render, toJson */
import React from 'react';
import App from '../src/app';

// to skip ReactDOM.render in app.js
jest.mock('react-dom', () => {
  return {
    render: jest.fn(),
  };
});

describe('Launch', () => {
  it('app.js render ok', () => {
    navigator.getFeature = jest.fn().mockResolvedValue(256);
    App.load = jest.fn().mockImplementation(() => {
      const wrapper = shallow(<App />);
      expect(toJson(wrapper)).toMatchSnapshot();
      expect(App.isLowMemoryDevice).toBeTruthy();
    });

    // need to manually invoke DOMContentLoaded event for jsdom
    document.dispatchEvent(
      new Event('DOMContentLoaded', {
        bubbles: true,
        cancelable: true,
      })
    );
  });
});
