// global jest
import Enzyme, { shallow, render, mount } from 'enzyme';
import Adapter from 'enzyme-adapter-react-15.4';
import toJson from 'enzyme-to-json';
// global mocks

import './mocks/localStorage';
import './mocks/mozContact';
import './mocks/performance';
import './mocks/BroadcastChannel';
import './mocks/sharedLib';
import './mocks/navigator/accountManager';
import './mocks/navigator/getDataStores';
import './mocks/navigator/getDeviceStorage';
import './mocks/navigator/getDeviceStorages';
import './mocks/navigator/getFeature';
import './mocks/navigator/contacts';
import './mocks/navigator/l10n';
import './mocks/navigator/setMessageHandler';
import './mocks/navigator/settings';
import './mocks/navigator/apps';
import './mocks/navigator/connection';
import './mocks/navigator/serviceWorker';

const define = require('amdefine');

Enzyme.configure({ adapter: new Adapter() });

global.shallow = shallow;
global.render = render;
global.mount = mount;
global.toJson = toJson;
global.define = define;

// let jsdom works for pre-rendering
// should be the same as body of index.html
document.body.innerHTML = `
  <div id="root"></div>
  <div id="ssr">
      <div class="statusbar-placeholder"></div>
      <div class="header h1" data-l10n-id="contacts">Contacts</div>
      <div class="content-placeholder">
      </div>
      <div class="softkey-placeholder">
          <button id="fake-new-button"></button>
          <button id="fake-settings-button" data-l10n-id="settings" class="hidden"></button>
      </div>
  </div>
`;
