/* global jest */
global.SimSettingsHelper = {
  observe: jest.fn(),
  getCardIndexFrom: jest.fn().mockResolvedValue(''),
};
global.AppOrigin = {
  getManifestURL: jest.fn(),
  getOrigin: jest.fn(),
};
