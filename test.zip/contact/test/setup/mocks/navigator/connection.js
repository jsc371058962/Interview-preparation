global.navigator.connection = {
  type: 'wifi',
};
