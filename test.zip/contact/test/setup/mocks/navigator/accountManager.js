/* global jest */
global.navigator.accountManager = {
  getAccounts: jest.fn().mockResolvedValue([]),
  getCredential: jest.fn().mockResolvedValue([]),
  logout: jest.fn().mockResolvedValue(true),
  showLoginPage: jest.fn().mockResolvedValue(true),
};

global.AccountManager = {
  observe: jest.fn(),
};
