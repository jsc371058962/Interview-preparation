/* global jest */
class DOMRequest {
  result = [];
  onsuccess = () => {};
  onerror = () => {};

  static create({ result = null }) {
    const request = new DOMRequest();
    setTimeout(() => {
      expect(typeof request.onsuccess).toBe('function');
      request.result = result;
      request.onsuccess({
        target: request,
      });
    }, 100);
    return request;
  }
}

global.AppsManager = {
  getApp: jest.fn().mockResolvedValue(''),
};
