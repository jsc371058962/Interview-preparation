/* global jest */
global.navigator.getFeature = jest.fn().mockImplementation(name => {
  let value = '';
  if ('hardware.memory' === name) {
    value = 512;
  }
  return Promise.resolve(value);
});
