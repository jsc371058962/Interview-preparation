/* global jest */

class DOMRequest {
  result = null;
  onsuccess = () => {};
  onerror = () => {};

  static create({ result = null }) {
    const request = new DOMRequest();
    setTimeout(() => {
      expect(typeof request.onsuccess).toBe('function');
      request.result = result;
      request.onsuccess({
        target: request,
      });
    }, 100);
    return request;
  }
}

class DOMCursor {
  _result = [];
  result = null;
  done = false;
  onsuccess = () => {};
  then = () => {};
  onerror = () => {};
  continue = () => {
    this.result = this._result.pop();
    if (0 === this._result.length) {
      this.done = true;
    }
    this.onsuccess({
      target: this,
    });
  };

  static create({ result = [] }) {
    const request = new DOMCursor();
    request._result = result;
    setTimeout(() => {
      expect(typeof request.onsuccess).toBe('function');
      request.continue();
    }, 100);
    return request;
  }
}

global.ContactsManager = {
  addEventListener: jest.fn(),
  getSpeedDials: jest.fn().mockResolvedValue([]),
  find: jest.fn().mockImplementation(() => {
    // XXX: manipulate some mock results

    const request = DOMRequest.create({
      result: [],
    });
    return request;
  }),
  findWithCursor: jest.fn().mockImplementation(() => {
    const request = DOMCursor.create({
      result: [],
    });
    return request;
  }),
  getAll: jest.fn().mockImplementation(() => {
    const request = DOMCursor.create({
      result: [],
    });
    return request;
  }),
  getAllBlockedNumbers: jest.fn().mockImplementation(() => {
    const request = DOMCursor.create({
      result: [],
    });
    return request;
  }),
  getAllGroups: jest.fn().mockImplementation(() => {
    const request = DOMCursor.create({
      result: [{}],
    });
    return request;
  }),
  save: jest.fn().mockImplementation(aMozContact => {
    expect(aMozContact instanceof global.mozContact).toBeTruthy();

    const request = DOMRequest.create({
      result: null,
    });
    return request;
  }),
  getAllICE: jest.fn().mockResolvedValue([]),
  removeICE: jest.fn().mockImplementation(id => {
    expect('string' === typeof id).toBeTruthy();
    return Promise.resolve();
  }),
  setICE: jest.fn().mockImplementation((id, position) => {
    expect('string' === typeof id).toBeTruthy();
    expect('number' === typeof position).toBeTruthy();
    return Promise.resolve();
  }),
};

const ChangeReason = {
  CREATE: 0,
  UPDATE: 1,
  REMOVE: 2,
};

const FilterByOption = {
  NAME: 0,
  GIVEN_NAME: 1,
  FAMILY_NAME: 2,
  TEL: 3,
  EMAIL: 4,
  CATEGORY: 5,
};

const FilterOption = {
  EQUALS: 0,
  CONTAINS: 1,
  MATCH: 2,
  STARTS_WITH: 3,
  FUZZY_MATCH: 4,
};

const Order = {
  ASCENDING: 0,
  DESCENDING: 1,
};

const SortOption = {
  GIVEN_NAME: 0,
  FAMILY_NAME: 1,
  NAME: 2,
};

const EventMap = {
  BLOCKED_NUMBER_CHANGE: 'blockChange',
  CONTACT_CHANGE: 'contactChange',
  GROUP_CHANGE: 'groupChange',
  SPEED_DIAL_CHANGE: 'speedDialChange',
};

Object.assign(global.ContactsManager, {
  SortOption,
  Order,
  FilterOption,
  FilterByOption,
  ChangeReason,
  EventMap,
});
