/* global jest */
global.api = global.api || {};
global.api.l10n = {
  get: jest.fn(),
  ready: jest.fn(),
  DateTimeFormat: jest.fn(),
};
