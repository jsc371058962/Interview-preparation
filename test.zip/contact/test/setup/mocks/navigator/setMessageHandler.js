/* global jest */
global.navigator.mozSetMessageHandler = jest.fn();
