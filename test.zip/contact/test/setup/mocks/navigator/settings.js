/* global jest */
global.navigator.mozSettings = {
  addObserver: jest.fn(),
  createLock: () => {
    return {
      get: () => {
        return {
          addEventListener: jest.fn(),
        };
      },
    };
  },
};

global.navigator.SettingsObserver = {
  addObserver: jest.fn(),
  getValue: () => ({
    then: jest.fn(),
  }),
  setValue: () => ({
    then: jest.fn(),
  }),
};

global.SettingsObserver = {
  addObserver: jest.fn(),
  observe: () => ({
    then: jest.fn(),
  }),
  getValue: () => ({
    then: jest.fn(),
  }),
  setValue: () => ({
    then: jest.fn(),
  }),
};
