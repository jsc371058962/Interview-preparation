global._SWObserver = {
  on: jest.fn(),
  emit: jest.fn(),
};
