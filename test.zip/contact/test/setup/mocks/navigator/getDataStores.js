/* global jest */
const mockDataStore = {
  get: jest.fn(),
  add: jest.fn(),
  put: jest.fn().mockImplementation((obj, id) => {
    return Promise.resolve(id);
  }),
  remove: jest.fn(),
  clear: jest.fn(),
};
global.navigator.getDataStores = jest.fn().mockResolvedValue([mockDataStore]);
