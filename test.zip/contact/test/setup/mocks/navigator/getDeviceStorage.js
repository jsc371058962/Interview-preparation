/* global jest */
global.navigator.getDeviceStorage = jest.fn().mockResolvedValue([]);

global.navigator.getDeviceStorage().isDiskFull = jest
  .fn()
  .mockImplementation(value => {
    return Promise.resolve(value);
  });

global.navigator.b2g = global.navigator.b2g || {};
global.navigator.b2g.getDeviceStorage = jest.fn().mockResolvedValue([]);
global.navigator.b2g.getDeviceStorage().isDiskFull = jest
  .fn()
  .mockImplementation(value => {
    return Promise.resolve(value);
  });
