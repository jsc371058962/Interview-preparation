/* global jest */
global.navigator.getDeviceStorages = jest.fn().mockReturnValue([]);
global.navigator.b2g = global.navigator.b2g || {};
global.navigator.b2g.getDeviceStorages = jest.fn().mockReturnValue([]);
