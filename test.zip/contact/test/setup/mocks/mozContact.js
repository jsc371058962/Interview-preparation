/* global jest */
class mozContact {
  constructor(config) {
    this.id = Math.random()
      .toString(36)
      .substr(2);
    [
      'adr',
      'bday',
      'category',
      'email',
      'familyName',
      'givenName',
      'jobTitle',
      'name',
      'nickname',
      'note',
      'org',
      'photo',
      'ringtone',
      'tel',
      'url',
    ].forEach(key => {
      if (config[key]) {
        if ('bday' === key) {
          expect(config[key]).toBeInstanceOf(Date);
          this[key] = config[key];
        } else if ('ringtone' === key) {
          expect(typeof config[key]).toBe('string');
          this[key] = config[key];
        } else {
          expect(Array.isArray(config[key])).toBeTruthy();
          this[key] = [].concat(config[key]);
        }
      } else {
        this[key] = null;
      }
    });
  }
}
global.mozContact = mozContact;
