/* global jest */
class BroadcastChannel {
  constructor(name) {}
  onmessage() {}
  postMessage() {}
}
global.BroadcastChannel = BroadcastChannel;
