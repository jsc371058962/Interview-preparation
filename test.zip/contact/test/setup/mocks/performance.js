/* global jest */
global.performance = {
  mark: jest.fn(),
  measure: jest.fn(),
};
