/* global jest, describe, it, expect, shallow, mount, render, toJson */
import React from 'react';
import EditView from '../src/edit_view';
import ContactEditor from '../src/contact_editor';
import SimContactEditor from '../src/sim_contact_editor';
import ContactStore from '../src/contact_store';

describe('New Contact', () => {
  it('edit_view render ok without data', () => {
    const wrapper = render(<EditView />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  it('contact_editor render ok with wrapped contact', () => {
    return ContactStore.getWrappedContact('new').then(contact => {
      const wrapper = render(<ContactEditor contact={contact} />);
      expect(toJson(wrapper)).toMatchSnapshot();
    });
  });

  it('sim_contact_editor render ok with wrapped contact', () => {
    return ContactStore.getWrappedContact('new').then(contact => {
      const wrapper = render(<SimContactEditor contact={contact} />);
      expect(toJson(wrapper)).toMatchSnapshot();
    });
  });
});
