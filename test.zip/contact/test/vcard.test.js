/* global jest, describe, it, expect, shallow, mount, render, toJson */
import React from 'react';
import ImportVcardView from 'activity/import_vcard_view';
import VcardUtils from 'vcard_utils';

// Read more about the specification:
// [vCard 3.0 (RFC 2426)](https://tools.ietf.org/html/rfc2426)
describe('vCard functionalities', () => {
  // keep no indent as it to have correct VCARD format blob
  const mockVcardStr = `BEGIN:VCARD
VERSION:3.0
N:;kai-contact;;;
FN:kai-contact
CATEGORIES:DEVICE,KAICONTACT
TEL;TYPE=CELL:111
END:VCARD
`;

  const mockVcardBlob = new Blob([mockVcardStr], {
    type: 'text/vcard',
  });

  const mockContact = new mozContact({
    name: ['kai-contact'],
    givenName: ['kai-contact'],
    category: ['DEVICE', 'KAICONTACT'],
    tel: [
      {
        type: ['mobile'],
        value: '111',
      },
    ],
  });

  it('import_vcard_view render ok', () => {
    const wrapper = mount(<ImportVcardView blob={mockVcardBlob} />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  it('convert a mozContact to vCard blob ok', () => {
    return VcardUtils.ContactToVcardBlob([mockContact])
      .then(blob => {
        expect(blob.type).toEqual(mockVcardBlob.type);
        return new Promise(resolve => {
          const reader = new FileReader();
          reader.onload = e => resolve(e.target.result);
          reader.readAsText(blob);
        });
      })
      .then(mockContactStr => {
        expect(mockContactStr.replace(/\r/g, '')).toBe(
          mockVcardStr.replace(/\r/g, '')
        );
      });
  });
});
