/* global jest, describe, it, expect, shallow, mount, render, toJson */
import React from 'react';
import { _mergeContacts } from 'modules/merge_helper';

describe('Merge contact', () => {
  const rawContact = {
    name: ['contactB Kai'],
    givenName: ['contactB'],
    familyName: ['Kai'],
    tel: [
      {
        type: ['mobile'],
        value: '1',
      },
    ],
    email: [
      {
        type: ['personal'],
        value: 'b@b.com',
      },
    ],
    photo: [new File([''], 'filename')],
    bday: new Date('2018-01-01'),
    ringtone: 'ringtone_uri',
    note: ['noteB'],
  };

  it('merge ok with no conflict', () => {
    const fromContact = new mozContact({
      name: [''],
      tel: [
        {
          type: ['mobile'],
          value: '1',
        },
        {
          type: ['mobile'],
          value: '2',
        },
      ],
      email: [
        {
          type: ['personal'],
          value: 'a@a.com',
        },
      ],
    });
    const toContact = new mozContact(rawContact);

    const mergedContact = _mergeContacts(fromContact, toContact);
    expect(mergedContact.tel.length).toBe(2);
    expect(mergedContact.email.length).toBe(2);
  });

  it('merge ok with conflicts', () => {
    const fromContact = new mozContact({
      name: ['contactA'],
      givenName: [''],
      familyName: [''],
      tel: [
        {
          type: ['mobile'],
          value: '1',
        },
      ],
      bday: new Date('2018-01-02'),
      note: ['noteA'],
    });
    const toContact = new mozContact(rawContact);

    const mergedContact = _mergeContacts(fromContact, toContact);
    expect(mergedContact.name).toEqual(rawContact.name);
    expect(mergedContact.givenName).toEqual(rawContact.givenName);
    expect(mergedContact.familyName).toEqual(rawContact.familyName);
    expect(mergedContact.photo).toEqual(rawContact.photo);
    expect(mergedContact.bday).toEqual(rawContact.bday);
    expect(mergedContact.ringtone).toEqual(rawContact.ringtone);
    expect(mergedContact.note).toEqual(rawContact.note);
  });

  it('merge to empty name ok', () => {
    const fromContact = new mozContact({
      name: ['contactA'],
      tel: [
        {
          type: ['mobile'],
          value: '1',
        },
      ],
    });
    const toContact = new mozContact(rawContact);
    toContact.name = [''];

    const mergedContact = _mergeContacts(fromContact, toContact);
    expect(mergedContact.name).toEqual(fromContact.name);
  });
});
