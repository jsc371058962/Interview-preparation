/* global jest, describe, it, expect, shallow, mount, render, toJson */
import React from 'react';
import SettingView from '../src/setting_view';
import SpeedDialView from '../src/speed_dial_view';
import ICEView from '../src/ice_editor_view';
import ImportView from '../src/import_view';
import ExportView from '../src/export_view';

describe('Settings', () => {
  it('setting_view render ok', () => {
    const wrapper = render(<SettingView />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  it('speed_dial_view render ok', () => {
    const wrapper = render(<SpeedDialView />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  it('ice_editor_view render ok', () => {
    const wrapper = render(<ICEView />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  it('import_view render ok', () => {
    const wrapper = render(<ImportView />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  it('export_view render ok', () => {
    const wrapper = render(<ExportView />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });
});
