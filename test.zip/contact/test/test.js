/* global jest, describe, it, expect, shallow, mount, render, toJson */

/**
 * Guideline to create test files:
 * Ideally there should an one on one matching between the SPEC and the test.
 * Do your best to structure and describe the tests following the SPEC items.
 *
 * Consideration:
 * Is it good to name *.spec.js for SPEC item testing, *.test.js for other testing?
 */
describe('Test framework', () => {
  it('Jest ok', () => {
    expect(1).toBe(1);
  });
});
