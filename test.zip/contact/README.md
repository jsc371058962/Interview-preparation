# Contact
KaiOS core app for contacts management.

## Technical overview

Keywords: webpack, react, jest, enzyme, code spliting

## Development

```
# in this root
yarn install
make watch

# in gaia root
NO_NETWORK=1 DEVICE_DEBUG=1 NO_BUNDLE=1 make install-gaia APP=contact
```
