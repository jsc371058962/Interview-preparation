const ASYMMETRIC_ALGORITHM_NAME = 'RSA-OAEP';
let theKeyPair;

/**
 * Generate Asymmetric Key
 * To prevent account info leak, the caller app should/must post the activity with a public key created by the RSA-OAEP algorithm, this key will be used on encryption.
 */

function exportKey() {
  return new Promise(resolve => {
    window.crypto.subtle
      .exportKey('jwk', theKeyPair.publicKey)
      .then(exportedKey => {
        // `exportedKey` is the key we should post with activity
        resolve(exportedKey);
      })
      .catch(err => {
        console.error('exportKey: ', err);
      });
  });
}

function generateKey() {
  // Generate an encryption key pair
  return window.crypto.subtle
    .generateKey(
      {
        // algorithm
        name: ASYMMETRIC_ALGORITHM_NAME,
        modulusLength: 1024,
        publicExponent: new Uint8Array([0x01, 0x00, 0x01]),
        hash: 'SHA-256',
      },
      true, // extractable
      ['wrapKey', 'unwrapKey'] // keyUsages
    )
    .then(keyPair => {
      theKeyPair = keyPair;
      return exportKey();
    })
    .catch(err => {
      console.error('generateKey: ', err);
    });
}

/**
 * Decrypt Activity Result
 * Account Manager Activity will return an encrypted result, the encrypted result contains an encrypted symmetric key and the encrypted account info which encrypted by the symmetric key (Only the success result needs to decrypt).
 * Step 1: unwrap symmetric key
 * Step 2: decrypt account info
 */
function unwrapKey(successResponse) {
  const { encrypted, symmetricKey, iv } = successResponse;
  return window.crypto.subtle
    .unwrapKey(
      'raw',
      symmetricKey, // the key you want to unwrap
      theKeyPair.privateKey,
      {
        name: 'RSA-OAEP',
        hash: { name: 'SHA-256' },
      },
      {
        name: 'AES-GCM',
        length: 256,
      },
      false,
      ['decrypt']
    )
    .then(key => {
      // get the pure symmetricKey
      return decryptResponse(key, encrypted, iv);
    })
    .catch(err => {
      console.error('unwrapKey: ', err);
    });
}

function decryptResponse(symmetricKey, encrypted, iv) {
  return new Promise(resolve => {
    const dec = new TextDecoder();
    window.crypto.subtle
      .decrypt(
        {
          name: 'AES-GCM',
          iv,
        },
        symmetricKey,
        encrypted
      )
      .then(decryptedText => {
        // account info
        const accountInfo = JSON.parse(dec.decode(decryptedText));
        console.log('decryptResponse: ', accountInfo);
        resolve(accountInfo);
      })
      .catch(err => {
        console.error('decryptResponse: ', err);
      });
  });
}

class AccountsManager {
  exportedKey = '';

  keyResolve = new Promise(resolve => {
    this._resolve = resolve;
  });

  constructor() {
    generateKey().then(exportedKey => {
      console.log('generate key', exportedKey);
      this._resolve(exportedKey);
    });
  }

  getAccounts() {
    const data = {
      action: 'getAccounts',
    };
    return this._sendActivity(data);
  }

  getCredential(account) {
    const data = {
      account,
      action: 'getCredential',
    };
    return this._sendActivity(data);
  }

  showLoginPage({ authenticatorId }, extraInfo) {
    const data = {
      authenticatorId,
      action: 'showLoginPage',
      extraInfo,
    };
    return this._sendActivity(data);
  }

  logout(account) {
    const data = {
      account,
      action: 'revokeCredential',
    };
    return this._sendActivity(data);
  }

  refreshCredential(account, credential) {
    const data = {
      action: 'refreshCredential',
      account,
      credential,
    };
    return this._sendActivity(data);
  }

  _sendActivity(_data) {
    const MAX_RETRY_TIMES = 5;
    let RETRY_TIMES = 0;
    const RETRY_COOLDOWN = 500;
    return new Promise((resolve, reject) => {
      this.keyResolve.then(publicKey => {
        const data = {
          publicKey,
          ..._data,
        };
        let activity;
        const startActivity = _activity => {
          this.timer = setTimeout(() => {
            RETRY_TIMES++;
            if (RETRY_TIMES > MAX_RETRY_TIMES) {
              return reject();
            }
            startActivity(_activity);
            console.error('activity error - timeout retry', _data);
          }, RETRY_COOLDOWN);
          _activity.start().then(
            result => {
              clearTimeout(this.timer);
              console.log('WebActivity Success', result);
              return unwrapKey(result).then(res => resolve(res));
            },
            error => {
              console.error('WebActivity Failure', error);
            }
          );
        };
        try {
          activity = new WebActivity('account-manager', data);
        } catch (error) {
          console.error('send account-manager activity error', error);
          // if app is in background, the activity will be fail with 'NS_ERROR_FAILURE', so we need restore the request after back.
          if ('NS_ERROR_FAILURE' === error.name) {
            document.addEventListener('visibilitychange', () => {
              if (!document.hidden) {
                activity = new WebActivity('account-manager', data);
                startActivity(activity);
              }
            });
          }
          return;
        }
        startActivity(activity);
      });
    });
  }
}

navigator.accountManager = new AccountsManager();
