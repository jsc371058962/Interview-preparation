const Redirect = (function Redirect() {
  const COMMS_APP_ORIGIN = `${document.location.protocol}//${document.location.host}`;

  const init = function init() {
    const hash = document.location.hash.substring(1);
    const parameters = {};

    const dataStart = hash.indexOf('access_token');

    if (dataStart !== -1) {
      const elements = hash.split('&');

      elements.forEach(function(p) {
        const values = p.split('=');
        parameters[values[0]] = values[1];
      });

      console.log('redirect.js parameters', parameters);
      const channel = new BroadcastChannel('contact-oauth2-result');
      channel.postMessage(parameters, COMMS_APP_ORIGIN);
      window.close();
    } else {
      window.close();
    }
  };

  return {
    init,
  };
})();

Redirect.init();
