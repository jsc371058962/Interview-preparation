import React from 'react';
import ReactDOM from 'react-dom';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import ContactEditor from './contact_editor';
import Utils from './contact_utils';
import ContactStore, { TAG_INDEX } from './contact_store';
import ContactDraftManager from './contact_draft_manager';

const FIELDS = ['name', 'tel'];

export default class SimContactEditor extends ContactEditor {
  FOCUS_SELECTOR = '.navigable:not(.hidden),.button';

  SCROLL_SELECTOR = '.list-item';

  blobs = new Map();

  constructor(props) {
    super(props);
    this.state = {
      fields: this.props.contact.dataMap,
    };
    window.seditor = this;
    this.utils = Utils;
  }

  componentDidMount() {
    const config = this.getConfig();
    window.seditor = this;
    this.utils = Utils;
    this.element = ReactDOM.findDOMNode(this);
    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element,
      this.SCROLL_SELECTOR
    );
    this._softKey = SoftKeyManager.create(this.element, config);
    this.saveDraft();
  }

  clear() {
    if (Service.query('isActivity')) {
      // Don't clear fields if we are requested by activity.
      return;
    }
    Array.from(this.element.querySelectorAll('input')).forEach(input => {
      input.value = '';
    });
    this.navigator.setFocus(this.element.querySelector('input'), true);
  }

  getConfig() {
    const savable = this.isChanged() && !this.isEmpty();
    const config = {
      left: 'cancel',
    };
    if (savable) {
      config.center = 'save';
    }
    return config;
  }

  updateSoftKeys() {
    this._softKey.update(this.getConfig());
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  onKeyDown(evt) {
    const dom = document.activeElement;
    if (this._isGoingBack) {
      return;
    }
    switch (evt.key) {
      case 'Enter':
        if (!this.isChanged() || this.isEmpty()) {
          return;
        }
        this.save();
        break;
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        if ('INPUT' === dom.tagName && '' !== dom.value) {
          return;
        }
      case 'EndCall': // eslint-disable-line
      case 'SoftLeft':
        evt.preventDefault();
        evt.stopPropagation();
        let shouldClose;
        if ('EndCall' === evt.key) {
          shouldClose = true;
        }
        const handleEndKey = () => {
          shouldClose && window.close();
        };
        if (this.isChanged()) {
          if (this.isEmpty()) {
            Service.request('showDialog', {
              header: 'confirm',
              content: 'discard-contact-data',
              ok: 'discard',
              onOk: () => {
                this._isGoingBack = true;
                this.props.contact.normalize();
                handleEndKey();
                this.backOrClose();
              },
            });
            return;
          }
          const content =
            'new' === this.props.contact.id
              ? 'confirm-discard-contact-data'
              : 'confirm-discard-contact-update-data';
          Service.request('showDialog', {
            header: 'confirm',
            content,
            type: 'custom',
            buttons: [
              {
                message: 'cancel',
              },
              {
                message: 'save',
              },
              {
                message: 'discard',
              },
            ],
            onOk: value => {
              if (2 === value.selectedButton) {
                // XXX: to avoid option menu shows
                this._isGoingBack = true;
                this.props.contact.normalize();
                handleEndKey();
                this.backOrClose();
              } else if (1 === value.selectedButton) {
                this.save().then(handleEndKey);
              }
            },
          });
          return;
        }
        handleEndKey();
        this.backOrClose();
        break;
      default:
        break;
    }
  }

  onFocus() {
    // XXX: better way?
    this._isGoingBack = false;
    this._processingSave = false;
    this.updateSoftKeys();
    if (
      this.element.contains(document.activeElement) &&
      document.activeElement !== this.element
    ) {
      const prev = this.element.querySelector('.focus');
      prev && prev.classList.remove('focus');
      if ('INPUT' === document.activeElement.tagName) {
        document.activeElement.parentNode.parentNode.classList.add('focus');
        Utils.setCursorToEnd(document.activeElement);
      }
    }
  }

  save() {
    if (this._processingSave) {
      return;
    }
    this._processingSave = true;
    let config = this.getInputData();

    if (this.props.contact) {
      FIELDS.forEach(field => {
        if (config[field]) {
          this.props.contact.contact[field] = config[field];
        } else {
          this.props.contact.contact[field] = null;
        }
      });
      config = this.props.contact.contact;
    }
    if (!config.category || 0 === config.category.length) {
      config.category = [
        TAG_INDEX.sim,
        'SIM' === this.props.target.toUpperCase()
          ? 'SIM0'
          : this.props.target.toUpperCase(),
        TAG_INDEX.kaiContact,
      ];
    }
    return ContactStore.createOrUpdate(config, true, 'manual').then(result => {
      Service.request('ToastManager:show', { text: result.message });
      this.backOrClose();
    });
  }

  onInput() {
    this.updateSoftKeys();
    this.saveDraft();
  }

  saveDraft() {
    if (Service.query('isActivity')) {
      if (this.isEmpty()) {
        return ContactDraftManager.removeItem();
      }
      const data = this.getInputData();
      if (!data.category || 0 === data.category.length) {
        data.category = [
          TAG_INDEX.sim,
          'SIM' === this.props.target.toUpperCase()
            ? 'SIM0'
            : this.props.target.toUpperCase(),
          TAG_INDEX.kaiContact,
        ];
      }
      data.id = 'new' !== this.props.contact.id ? this.props.contact.id : '';
      ContactDraftManager.setItem(data);
    }
  }

  getInputType(field) {
    switch (field) {
      case 'email':
        return 'email';
      case 'tel':
        return 'tel';
      case 'bday':
        return 'date';
      default:
        return 'text';
    }
  }

  onBlur(evt) {
    const dom = evt.target;
    if ('date' === dom.type) {
      const value = dom.value;
      if (!value) {
        this.props.contact.removeField('bday', 0);
        this.navigator.setFocus(ReactDOM.findDOMNode(this.refs.add));
        this.element.focus();
      } else {
        // XXX: need better way to locate the container
        this.navigator.setFocus(evt.target.parentNode.parentNode);
        evt.target.parentNode.parentNode.focus();
      }
    }
  }

  isTheSame(fieldA, fieldB) {
    return JSON.stringify(fieldA) === JSON.stringify(fieldB);
  }

  isChanged() {
    if (
      'open' === Service.query('activityType') ||
      ContactDraftManager.hasCache
    ) {
      return true;
    }
    let changed = false;
    const data = this.getInputData();
    FIELDS.some(field => {
      let current = this.props.contact.contact[field];
      let next = data[field];
      if (!Array.isArray(current)) {
        current = [current];
      }
      if (!Array.isArray(next)) {
        next = [next];
      }
      if (
        (!current.length || (1 === current.length && !current[0])) &&
        (!next.length || (1 === next.length && !next[0]))
      ) {
        return false;
      }

      if ('photo' === field && this.blobs.get('photo-0') !== current[0]) {
        changed = true;
        return true;
      }
      // XXX: This logic does not work for blob.
      if (
        !this.isTheSame(next, current) &&
        ('name' === field || 'tel' === field)
      ) {
        changed = true;
        return true;
      }
      return false;
    });
    return changed;
  }

  render() {
    const dom = [];
    let data = [];
    this.state.fields.forEach(array => {
      data = data.concat(array);
    });
    data.forEach(content => {
      const field = content.field;
      const index = content.index;
      const type = content.type;
      const containerKey = `${field}-${index}`;
      const value = content.value;
      switch (field) {
        case 'name':
        case 'tel':
          dom.push(
            <div
              className={`list-item ${'bday' === field ? 'navigable' : ''}`}
              tabIndex="-1"
              data-type="input"
              data-field={field}
              key={containerKey}
            >
              <div className="content">
                <label
                  id={`new-${containerKey}`}
                  className="secondary"
                  htmlFor={`new-${containerKey}`}
                  {...Utils.getFieldL10nConfig(field, type, 'sim')}
                />
                <input
                  aria-label={this.props.heading}
                  aria-describedby={`new-${containerKey}`}
                  type={this.getInputType(field)}
                  data-index={index}
                  data-field={field}
                  data-type={type}
                  id={`new-${field}-${index}`}
                  className={'bday' === field ? '' : 'navigable'}
                  name={field}
                  data-removable={field.indexOf('Name') >= 0 ? 'false' : 'true'}
                  onBlur={e => this.onBlur(e)}
                  defaultValue={value}
                  ref={`${containerKey}-input`}
                  maxLength={'tel' === field ? 20 : 14}
                />
              </div>
            </div>
          );
          break;
        default:
          break;
      }
    });
    return (
      <div
        role="form"
        className="contact-editor"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onFocus={e => this.onFocus(e)}
        onInput={e => this.onInput(e)}
      >
        {dom}
      </div>
    );
  }
}

SimContactEditor.propTypes = {
  contact: React.PropTypes.object,
};
