import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import perf from 'modules/perf';
import Service from 'service';
import ContactStore from './contact_store';
import ContactEditor from './contact_editor';
import SimContactEditor from './sim_contact_editor';
import ContactWrapper from './contact_wrapper';
import Utils from './contact_utils';
import ContactDraftManager from './contact_draft_manager';

export default class EditView extends BaseComponent {
  name = 'EditView';
  DEBUG = false;

  FOCUS_SELECTOR = '.navigable';

  constructor(props) {
    super(props);
    this.state = {
      contact: null,
      target: '',
    };
    window.editview = this;
  }

  componentDidMount() {
    // ensure listen the contact change event, when not enter speed_dial_
    // view page yet.
    import('./speed_dial_store');

    this.debug('did mount: id:', this.props.id);
    if ('new' === this.props.id) {
      perf.measure('enter-new-contact');
    }
    this.element = ReactDOM.findDOMNode(this);

    if (!Service.query('isActivity') && ContactDraftManager.hasCache) {
      // recover editor draft in normal start.
      ContactDraftManager.getItem().then(data => {
        const contact = new ContactWrapper(data);
        ContactStore.wrappedContactMap.set(contact.id, contact);
        Service.request('ToastManager:show', {
          text: window.api.l10n.get('draft-restored'),
        });
        this.setState({
          contact,
          target: Utils.isSIMContact(contact.contact) ? 'sim' : 'phone',
        });
      });
      return;
    }
    if (this.props.id) {
      if (
        this.props.tel ||
        this.props.email ||
        this.props.photo ||
        this.props.name
      ) {
        // #edit/${ID} from contact list
        ContactStore.getWrappedContact(this.props.id, this.props).then(
          contact => {
            this.setState({
              contact,
            });
          }
        );
      } else {
        ContactStore.getWrappedContact(this.props.id).then(contact => {
          this.setState({
            contact,
          });
        });
      }
    } else if (this.props.blob) {
      // #open from activity
      Utils.fromVcard(this.props.blob).then(contact => {
        const wrapper = new ContactWrapper(contact);
        // To let field chooser can access. even id is undefined.
        ContactStore.wrappedContactMap.set(wrapper.id, wrapper);
        this.setState({
          contact: wrapper,
        });
      });
    }
  }

  componentWillUnmount() {
    if ('new' === this.props.id) {
      ContactStore.wrappedContactMap.delete('new');
    }
  }

  componentDidUpdate() {
    this.onFocus();
  }

  onFocus() {
    if (document.activeElement === this.element && this.refs.editor) {
      ReactDOM.findDOMNode(this.refs.editor).focus();
    }
  }

  chooseMemory() {
    Utils.chooseMemory().then(memory => {
      if (!memory) {
        Utils.backOrClose();
      } else {
        this.setState({
          target: memory,
        });
      }
    });
  }

  render() {
    const heading =
      !this.props.id || 'new' === this.props.id
        ? 'new-contact-title'
        : 'edit-title';

    let editor = null;
    if (this.state.contact) {
      if (!this.props.target && !this.state.target && 'new' === this.props.id) {
        this.chooseMemory();
      } else {
        const target = this.props.target || this.state.target || '';
        if (target.startsWith('sim')) {
          editor = (
            <SimContactEditor
              ref="editor"
              heading={heading}
              contact={this.state.contact}
              target={target}
            />
          );
        } else if (Utils.isSIMContact(this.state.contact.contact)) {
          editor = (
            <SimContactEditor
              ref="editor"
              heading={heading}
              contact={this.state.contact}
              target={
                target ||
                (this.state.contact.contact.category &&
                  this.state.contact.contact.category[1])
              }
            />
          );
        } else {
          editor = (
            <ContactEditor
              ref="editor"
              heading={heading}
              contact={this.state.contact}
            />
          );
        }
      }
    }
    return (
      <div id="edit-view" tabIndex="-1" onFocus={e => this.onFocus(e)}>
        <div className="header h1" data-l10n-id={heading} />
        {editor}
      </div>
    );
  }
}

EditView.propTypes = {
  id: React.PropTypes.string,
};
