/*
 * Contacts editor draft manager
 * This file depends on "/shared/js/utils/storage/async_storage.js", an IndexedDB database, and the api looks like local storage.
 *
 * */
class ContactDraftManager {
  // storage key;
  STORE_NAME = 'contactEditorDraft';

  // expired time - 24 hours;
  EXPIRE_TIME = 24 * 60 * 60 * 1000;

  _draft = null;

  _fetched = false;

  constructor() {
    this._getItem();
  }

  get hasCache() {
    const timestamp = localStorage.getItem(this.STORE_NAME);
    return timestamp && Date.now() - timestamp < this.EXPIRE_TIME;
  }

  setItem(contact) {
    const data = {
      timestamp: Date.now(),
      contact,
    };
    return new Promise(resolve => {
      localStorage.setItem(this.STORE_NAME, data.timestamp);
      window.asyncStorage.setItem(this.STORE_NAME, data, () => {
        console.log('contactEditorDraft  stored', data);
        resolve();
      });
    });
  }

  _getItem() {
    return new Promise(resolve => {
      window.asyncStorage.getItem(this.STORE_NAME, data => {
        console.log('The data of contactEditorDraft is:', data);
        if (data) {
          const { contact, timestamp } = data;
          if (timestamp && Date.now() - timestamp < this.EXPIRE_TIME) {
            this._draft = contact;
          } else {
            this._draft = null;
          }
        }
        this._fetched = true;
        this.resolve && this.resolve(this._draft);
        resolve(this._draft);
      });
    });
  }

  getItem() {
    return new Promise(resolve => {
      if (this._fetched) {
        return resolve(this._draft);
      }
      this.resolve = resolve;
    });
  }

  removeItem() {
    return new Promise(resolve => {
      window.asyncStorage.removeItem(this.STORE_NAME, () => {
        localStorage.removeItem(this.STORE_NAME);
        console.log('contactEditorDraft  removed');
        resolve();
      });
    });
  }
}
export default new ContactDraftManager();
