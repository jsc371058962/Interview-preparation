import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import ContactStore from './contact_store';

export default class MemoryView extends BaseComponent {
  FOCUS_SELECTOR = '.list-item.navigable';

  constructor(props) {
    super(props);
  }

  componentDidMount() {
    window.mv = this;
    this.element = ReactDOM.findDOMNode(this);
    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element,
      null,
      this.index
    );
    this.updateSoftKeys();
  }

  updateSoftKeys() {
    const config = {
      left: 'cancel',
      center: 'ok',
    };

    this._softKey = SoftKeyManager.create(this.element, config);
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  onKeyDown(evt) {
    let value;
    switch (evt.key) {
      case 'Enter':
        value = document.activeElement.dataset.value;
        Service.request('back', value);
        break;
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('back');
        break;
      case 'SoftLeft':
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('back');
        break;
      default:
        break;
    }
  }

  render() {
    const dom = [];
    ['kaiContact', 'phone', 'sim'].forEach((value, index) => {
      const checked = ContactStore.source === value;
      if (checked) {
        this.index = index;
      }
      dom.push(
        <div
          className="list-item navigable"
          tabIndex="-1"
          data-value={value}
          data-checked={checked}
        >
          <div className="content">
            <div className="primary" data-l10n-id={value} />
          </div>
          <i
            className="icon control"
            data-icon={checked ? 'radio-on' : 'radio-off'}
            aria-hidden="true"
          />
          <input type="radio" checked={checked} className="hidden" />
        </div>
      );
    });
    return (
      <div id="sort-view" tabIndex="-1" onKeyDown={e => this.onKeyDown(e)}>
        <div className="header h1" data-l10n-id="memory" />
        <div className="body">{dom}</div>
      </div>
    );
  }
}
