import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import ContactStore from 'contact_store';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import OptionMenuHelper from 'option_menu_helper';
import {
  FIELDS,
  ADDRESS_SUBFIELDS,
  ACTIVE_SYNC_TAG,
  GOOGLE_TAG,
} from 'contact_wrapper';
import perf from 'modules/perf';
import ListItem from 'components/list_item';
import RTTSettings from 'rtt_settings';
import SimCardHelper from './sim_card_helper';
import Utils from './contact_utils';
import '../scss/contact_view.scss';

class ContactView extends BaseComponent {
  name = 'ContactView';
  DEBUG = false;

  FOCUS_SELECTOR = '.list-item.navigable';

  constructor(props) {
    super(props);
    this.state = {
      contact: null,
      showRingTone: true,
    };
    this.wrappedContact = null;
  }

  componentDidMount() {
    this.debug('did mount');
    perf.measure('enter-contact-detail');
    window.detail = this;
    this.element = ReactDOM.findDOMNode(this);
    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element
    );
    this.updateSoftKeys();

    if (this.props.id) {
      ContactStore.getWrappedContact(this.props.id).then(wrappedContact => {
        this.wrappedContact = wrappedContact;
        const contact = this.wrappedContact.contact;
        Utils.checkRingTone(contact.ringtone).then(bExist => {
          this.setState({
            contact,
            showRingTone: bExist,
          });
        });
        this.wrappedContact.on('changed', this.changeContactState);
      });
    } else if (this.props.blob) {
      // #open from activity
      Utils.fromVcard(this.props.blob).then(contact => {
        this.setState({
          contact,
        });
      });
    }
  }

  changeContactState = () => {
    this.setState({
      contact: this.wrappedContact.contact,
    });
  };

  componentDidUpdate() {
    const bodyHeight = this.refs.body.clientHeight;
    const data = {};
    let showMore = false;

    for (const key in this.refs) {
      if ('body' === key) {
        continue;
      }
      const dom = ReactDOM.findDOMNode(this.refs[key]);
      if (dom && dom.clientHeight > bodyHeight + 1) {
        dom.style.height = `${bodyHeight}px`;
        data[key] = true;
        showMore = true;
      }
    }

    if (showMore) {
      // eslint-disable-next-line react/no-did-update-set-state
      this.setState({
        showMoreItem: data,
      });
    }
  }

  componentWillUnmount() {
    this._softKey.destroy();
    this.navigator.destroy();
    if (this.props.id) {
      this.wrappedContact.off('changed', this.changeContactState);
      this.wrappedContact = null;
    }
  }

  componentWillReceiveProps(nextProps) {
    this.debug(
      'will receive props: next id, current id:',
      nextProps.id,
      this.props.id
    );
    if (nextProps.id === this.props.id) {
      return;
    }
    ContactStore.getContact(nextProps.id).then(contact => {
      Utils.checkRingTone(contact.ringtone).then(bExist => {
        this.setState({
          contact,
          showRingTone: bExist,
        });
      });
    });
  }

  updateSoftKeys() {
    const config = {};
    const field = document.activeElement.dataset.field;
    if (Service.query('isActivity') || this.props.viewOnly) {
      config.center = 'icon=ok';
    } else {
      config.right = 'options';
      config.center =
        'true' === document.activeElement.dataset.more ? 'select' : '';
      switch (field) {
        case 'tel':
          config.left = 'message';
          config.center = 'call';
          if (
            navigator.b2g.iccManager.iccIds.length > 1 &&
            !SimCardHelper.isAlwaysAsk()
          ) {
            config.center = {
              text: 'call',
              icon: `sim-${SimCardHelper.cardIndex + 1}`,
            };
          }
          if (RTTSettings.CONFIG_AUTOMATIC === RTTSettings.value) {
            config.center = 'rtt-call';
          }
          break;
        case 'email':
          config.center =
            Utils.SUPPORT_EMAIL && Utils.EMAIL_INSTALLED ? 'compose' : '';
          break;
        default:
          break;
      }
      if (this._isSdn) {
        config.left = '';
        config.right = '';
      }
    }

    this._softKey = SoftKeyManager.create(this.element, config);
  }

  onKeyDown(evt) {
    const field = document.activeElement.dataset.field;
    let options = [];
    switch (evt.key) {
      case 'Call':
        if (Service.query('isActivity') || this.props.viewOnly) {
          break;
        }
      case 'Enter': // eslint-disable-line
        if (Service.query('isActivity') || this.props.viewOnly) {
          evt.preventDefault();
          evt.stopPropagation();
          // XXX: Better way to judge when to back, when to leave.
          if (
            'import' === Service.query('activityType') ||
            'open' === Service.query('activityType')
          ) {
            Service.request('leaveActivity');
          } else {
            Service.request('back');
          }
          break;
        }
        if ('tel' === field) {
          perf.mark('enter-callscreen');
          Utils.dial(document.activeElement.dataset.value);
          evt.preventDefault();
          evt.stopPropagation();
        } else if ('email' === field && Utils.SUPPORT_EMAIL) {
          Utils.sendEmail(document.activeElement.dataset.value);
          evt.preventDefault();
          evt.stopPropagation();
        }
        if ('true' === document.activeElement.dataset.more) {
          Service.request('push', '/view-more', {
            value: document.activeElement.dataset.value,
          });
        }
        break;
      case 'MicrophoneToggle':
        evt.preventDefault();
        evt.stopPropagation();
        break;
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        Utils.backOrClose();
        break;
      case 'SoftLeft':
        if (Service.query('isActivity') || this.props.viewOnly || this._isSdn) {
          break;
        }
        if ('tel' === field) {
          Utils.sendSms(document.activeElement.dataset.value);
          evt.preventDefault();
          evt.stopPropagation();
        }
        break;
      case 'SoftRight':
        const numberBackUp = document.activeElement.dataset.value;
        if (Service.query('isActivity') || this.props.viewOnly || this._isSdn) {
          break;
        }
        evt.preventDefault();
        evt.stopPropagation();
        options = [
          {
            id: 'edit',
            callback: () => {
              Service.request('push', `/edit/${this.props.id}`);
            },
          },
          {
            id: 'speed-dial',
            callback: () => {
              Service.request('push', '/speeddial');
            },
          },
          {
            id: 'share',
            callback: () => {
              Utils.share(this.state.contact);
            },
          },
          {
            id: 'delete',
            callback: () => {
              Service.request('showDialog', {
                type: 'confirm',
                header: window.api.l10n.get('confirm'),
                content: window.api.l10n.get('confirm-contact-delete', {
                  name: Utils.getDisplayName(this.state.contact),
                }),
                translated: true,
                ok: 'delete',
                onOk: () => {
                  ContactStore.remove(this.state.contact).then(result => {
                    Service.request('ToastManager:show', {
                      text: result.message,
                    });
                  });
                  Service.request('back');
                },
              });
            },
          },
        ];

        const _contact = this.state.contact;
        const _ = window.api.l10n.get;
        if (!Utils.isSIMContact(_contact)) {
          if (_contact.group && _contact.group.length) {
            options.unshift({
              id: 'remove-from-group',
              callback: () => {
                OptionMenuHelper.pickAGroup(_contact.group, 'remove').then(
                  groupID => {
                    ContactStore.contactRemoveGroup(_contact, groupID);
                    Service.request('ToastManager:show', {
                      text: _('removed-from', {
                        group: ContactStore.getGroupNameByID(groupID),
                      }),
                    });
                  }
                );
              },
            });
          }

          const accountContact =
            _contact.category &&
            (_contact.category.includes(GOOGLE_TAG) ||
              _contact.category.includes(ACTIVE_SYNC_TAG));

          if (
            !accountContact &&
            ContactStore.hasGroups() &&
            ContactStore.contactHasNotAddAllGroup(_contact)
          ) {
            options.unshift({
              id: 'add-to-group',
              callback: () => {
                OptionMenuHelper.pickAGroup(
                  ContactStore.getContactRemainGroups(_contact)
                ).then(groupID => {
                  ContactStore.contactAddGroup(_contact, groupID);
                  Service.request('ToastManager:show', {
                    text: _('added-to', {
                      group: ContactStore.getGroupNameByID(groupID),
                    }),
                  });
                });
              },
            });
          }
          options.unshift({
            id: ContactStore.isFavorite(_contact)
              ? 'remove-favorite'
              : 'add-favorite',
            callback: () => {
              ContactStore.toggleFavorite(_contact).then(() => {
                Service.request('ToastManager:show', {
                  text: _('changes-saved'),
                });
              });
            },
          });
          !accountContact &&
            options.push({
              id: 'find-dup',
              callback: () => {
                Service.request('push', `/merge/${this.props.id}`);
              },
            });
        }

        // Only phone and email can be blocked.
        if ('tel' === field || (Utils.EMAIL_INSTALLED && 'email' === field)) {
          const addTag = 'tel' === field ? 'add-block' : 'add-block-email';
          const removeTag =
            'tel' === field ? 'remove-block' : 'remove-block-email';
          options.push({
            id: ContactStore.isBlockContact(numberBackUp) ? removeTag : addTag,
            callback: () => {
              if (ContactStore.isBlockContact(numberBackUp)) {
                ContactStore.removeBlockContact(numberBackUp)
                  .then(() => {
                    ContactStore.toogleBlock(_contact);
                  })
                  .catch(err => {
                    console.error(err);
                  });
              } else {
                Service.request('showDialog', {
                  type: 'confirm',
                  header: 'confirm',
                  content:
                    'tel' === field
                      ? 'add-block-contact-warning'
                      : 'add-block-email-warning',
                  ok: 'block',
                  onOk: () => {
                    ContactStore.addBlockContact(numberBackUp)
                      .then(() => {
                        ContactStore.toogleBlock(_contact);
                      })
                      .catch(err => {
                        console.error(err);
                      });
                  },
                });
              }
            },
          });
        }

        if (Service.query('isLowMemoryDevice')) {
          options = options.filter(o => o.id !== 'share');
        }
        Service.request('showOptionMenu', {
          options,
          onCancel: () => {
            // lastFocus && lastFocus.focus();
          },
        });
        break;
      default:
        break;
    }
  }

  get _isSdn() {
    return this.state.contact && this.state.contact.category.includes('sdn');
  }

  render() {
    this.debug('render');
    let style = {};
    const contact = this.state.contact;
    let photo = '';
    const showRingTone = this.state.showRingTone;
    if (!Service.query('isLowMemoryDevice')) {
      if (contact && contact.photo && contact.photo.length) {
        style = {
          backgroundImage: `url('${URL.createObjectURL(contact.photo[0])}')`,
        };
        photo = <span className="icon photo" style={style} />;
      } else {
        photo = (
          <i
            className="icon"
            data-icon="contacts"
            role="presentation"
            style={style}
          />
        );
      }
    }
    let favoriteDOM = null;
    const isFavorite = contact && ContactStore.isFavorite(contact);
    if (isFavorite) {
      favoriteDOM = <i className="icon" data-icon="favorite-on" />;
    }
    const porfolio = (
      <div className="contact list-item portfolio">
        {photo}
        <div className="content">
          <div className="primary">
            <a>{contact ? Utils.getDisplayName(contact) : ''}</a>
          </div>
          {!Service.query('isLowMemoryDevice') &&
          contact &&
          contact.org &&
          contact.org.length ? (
            <div className="secondary">{contact.org.join(',')}</div>
          ) : null}
        </div>
        {favoriteDOM}
      </div>
    );
    const dom = [];
    if (contact) {
      let array = [];
      FIELDS().forEach(field => {
        let value = '';
        switch (field) {
          case 'photo':
          case 'name':
          case 'familyName':
          case 'givenName':
          case 'additionalName':
            break;
          case 'bday':
            if (!contact.bday) {
              break;
            }
            value = Utils.unifyDateString(contact.bday);
            dom.push(
              <div
                className="list-item navigable"
                tabIndex="-1"
                key={`field-${field}`}
              >
                <div className="content">
                  <label
                    className="secondary"
                    htmlFor="no-input"
                    {...Utils.getFieldL10nConfig(field)}
                  />
                  <div className="primary">{value}</div>
                </div>
              </div>
            );
            break;
          case 'group':
            if (!contact.group || !contact.group.length) {
              break;
            }
            value = Utils.buildUpGroupName(contact.group);
            dom.push(
              <div
                className="list-item navigable"
                tabIndex="-1"
                key={`field-${field}`}
              >
                <div className="content">
                  <label
                    className="secondary"
                    htmlFor="no-input"
                    {...Utils.getFieldL10nConfig(field)}
                  />
                  <div className="primary">{value}</div>
                </div>
              </div>
            );
            break;
          case 'ringtone':
            if (!contact.ringtone || !showRingTone) {
              break;
            }
            dom.push(
              <div
                className="list-item navigable"
                tabIndex="-1"
                key={`field-${field}`}
              >
                <div className="content">
                  <label
                    className="secondary"
                    htmlFor="no-input"
                    {...Utils.getFieldL10nConfig(field)}
                  />
                  <div className="primary">
                    {Utils.guessRingtoneName(contact.ringtone)}
                  </div>
                </div>
              </div>
            );
            break;
          case 'adr':
          case 'note':
          case 'org':
          case 'tel':
          case 'email':
            array = contact[field];
            if (Array.isArray(array)) {
              array.forEach((data, index) => {
                const type =
                  data.type && data.type.length ? data.type[0] : 'other';
                value = data.value || data;
                const label = (
                  <label
                    htmlFor="no-input"
                    className="secondary"
                    {...Utils.getFieldL10nConfig(
                      field,
                      type,
                      Utils.isSIMContact(contact) ? 'sim' : 'phone'
                    )}
                  />
                );
                let icon = null;
                if ('tel' === field && !Service.query('isLowMemoryDevice')) {
                  icon = <i className="icon" data-icon="call" />;
                } else if ('email' === field) {
                  icon = <i className="icon" data-icon="email" />;
                }
                let blockIcon = null;
                let bTelOrEmail = false;
                if ('tel' === field || 'email' === field) {
                  if (ContactStore.isBlockContact(value)) {
                    blockIcon = (
                      <i className="icon smaller-size" data-icon="block" />
                    );
                  }
                  bTelOrEmail = true;
                }
                if ('adr' === field) {
                  value = ADDRESS_SUBFIELDS.map(key => {
                    return data[key];
                  })
                    .filter(d => d && d.length)
                    .join(', ');
                }
                let showMore = false;
                const ref = `${field}-${index}`;
                if (this.state.showMoreItem) {
                  showMore = this.state.showMoreItem[ref] && !bTelOrEmail;
                }
                dom.push(
                  <div
                    className="list-item navigable"
                    tabIndex="-1"
                    key={`field-${field}-${index}`} // eslint-disable-line
                    data-field={field}
                    data-type={type}
                    data-value={value}
                    data-more={showMore}
                    ref={ref}
                  >
                    {icon}
                    <div className="content view-content">
                      {label}
                      <div
                        className={`primary ${'tel' !== field ? '' : 'number'}`}
                      >
                        <div>{value}</div>
                        {showMore ? (
                          <div className="view-more">
                            <div data-l10n-id="more-info">More</div>
                            <i
                              className="icon"
                              data-icon="forward"
                              role="presentation"
                            />
                          </div>
                        ) : null}
                      </div>
                    </div>
                    {blockIcon}
                  </div>
                );
              });
            }
            break;
          default:
            break;
        }
      });
      if (
        contact.category &&
        (contact.category.includes(GOOGLE_TAG) ||
          contact.category.includes(ACTIVE_SYNC_TAG))
      ) {
        dom.push(
          <ListItem secondaryId="account" secondaryAsTitle>
            {contact.category.find(v => Utils.isEmailValid(v))}
          </ListItem>
        );
      }
    }
    return (
      <div
        id="contact-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onFocus={() => this.updateSoftKeys()}
      >
        {porfolio}
        <div className="body contact-detail" ref="body">
          {dom}
        </div>
      </div>
    );
  }
}

ContactView.propTypes = {
  id: React.PropTypes.string,
};

export default ContactView;
