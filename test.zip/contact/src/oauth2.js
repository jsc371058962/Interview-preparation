import BaseModule from 'base-module';
import ImportStatusData from './import_status_data';
import oauthflow from './oauthflow';

const STORAGE_KEY = 'tokenData';

class Oauth2 extends BaseModule {
  name = 'Oauth2';
  DEBUG = false;

  start() {
    this.accessTokenCbData = null;
    this.isd = ImportStatusData;
  }

  clearStorage(service) {
    ImportStatusData.remove(this.getKey(service));
  }

  getKey(service) {
    let key = STORAGE_KEY;
    if (service !== 'facebook') {
      key = `${STORAGE_KEY}_${service}`;
    }

    return key;
  }

  /**
   *  Obtains the access token. The access token is retrieved from the local
   *  storage and if not present a OAuth 2.0 flow is started
   */
  getAccessToken(service) {
    return new Promise((resolve, reject) => {
      this.accessTokenCbData = {
        state: 'friends',
        service,
        resolve,
        reject,
      };

      ImportStatusData.get(this.getKey(service)).then(tokenData => {
        if (!tokenData || !tokenData.access_token) {
          this.debug('no existing token data, will start oauth flow soon');
          this.startOAuth(service);
          return;
        }

        const access_token = tokenData.access_token;
        const expires = Number(tokenData.expires);
        const token_ts = tokenData.token_ts;

        if (expires !== 0 && Date.now() - token_ts >= expires) {
          this.debug('Access token has expired, restarting flow');
          this.startOAuth(service);
          return;
        }

        resolve(access_token);
      });
    });
  }

  startOAuth(service) {
    this.debug('starting flow');
    this.clearStorage(service);

    // This page will be in charge of handling authorization
    oauthflow
      .startFlow(service)
      .then(parameters => {
        this.debug('got parameters:');
        const end = parameters.expires_in;

        ImportStatusData.put(this.getKey(this.accessTokenCbData.service), {
          access_token: parameters.access_token,
          expires: end * 1000,
          token_ts: Date.now(),
        });
        this.accessTokenCbData &&
          this.accessTokenCbData.resolve(parameters.access_token);
        this.accessTokenCbData = null;
      })
      .catch(e => {
        this.debug('oauthflow aborted', e);
        this.accessTokenCbData && this.accessTokenCbData.reject();
        this.accessTokenCbData = null;
      });
  }
}

const oauth2 = new Oauth2();
oauth2.start();

window.oauth2 = oauth2;

export default oauth2;
