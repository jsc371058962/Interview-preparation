import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';

export default class FieldChooser extends BaseComponent {
  name = 'FieldChooser';
  DEBUG = false;

  FOCUS_SELECTOR = '.list-item';

  TYPE_MAP = {
    email: ['personal', 'work', 'other', 'custom-label'],
    tel: [
      'mobile',
      'home',
      'work',
      'personal',
      'fax-home',
      'fax-office',
      'fax-other',
    ],
    adr: ['current', 'home', 'work', 'custom-label'],
  };

  DEFAULT_TYPE = {
    email: 'personal',
    tel: 'mobile',
    adr: 'home',
  };

  constructor(props) {
    super(props);
    const field = this.props.field || '';
    let types = [];
    if (field) {
      types = this.TYPE_MAP[field];
    }
    this.state = {
      fields: this.props.contact.getFieldsToChoose(),
      types,
      activeField: field,
    };
  }

  componentDidMount() {
    this.debug('did mount');
    this.element = ReactDOM.findDOMNode(this);
    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element
    );
    this.updateSoftKeys();
    this.onChanged = () => {
      this.setState({
        fields: this.props.contact.getFieldsToChoose(),
      });
    };
    this.props.contact.on('fieldchanged', this.onChanged);
    this.store = this.props.contact;
    window.fc = this;
  }

  componentWillUnmount() {
    this.props.contact.off('fieldchanged', this.onChanged);
    this.navigator.destroy();
    this._softKey.destroy();
    this.element = null;
  }

  updateSoftKeys() {
    const config = {
      left: this.state.types.length ? 'cancel' : '',
      center: 'select',
    };

    this._softKey = SoftKeyManager.create(this.element, config);
  }

  onKeyDown(evt) {
    switch (evt.key) {
      case 'Enter':
        if (evt.target.querySelector('i')) {
          if (this.element.querySelector('i[data-icon="radio-on"]')) {
            this.element.querySelector('i[data-icon="radio-on"]').dataset.icon =
              'radio-off';
          }
          evt.target.querySelector('i').dataset.icon = 'radio-on';
        }
        this.pickType(evt.target.dataset.field, evt.target.dataset.type);
        break;
      case 'SoftLeft':
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        if ('SoftLeft' === evt.key && !this.state.types.length) {
          return;
        }
        Service.request('back');
        break;
      default:
        break;
    }
  }

  pickType(field, type) {
    this.debug('pickType: field, type, index:', field, type, this.props.index);
    switch (field) {
      case 'tel':
      case 'email':
      case 'adr':
        if (!type) {
          type = this.DEFAULT_TYPE[field];
          this.props.contact.addField(
            field,
            type,
            this.props.index ? +this.props.index : undefined
          );
          Service.request('back');
        } else if ('custom-label' === type) {
          Service.request('showDialog', {
            type: 'prompt',
            header: 'custom-label',
            maxLength: 20,
            onOk: tag => {
              this.props.contact.addField(
                field,
                tag,
                this.props.index ? +this.props.index : undefined
              );
              setTimeout(() => Service.request('back'));
            },
          });
        } else {
          this.props.contact.addField(
            field,
            type,
            this.props.index ? +this.props.index : undefined
          );
          Service.request('back');
        }
        break;
      case 'org':
      case 'photo':
      case 'note':
      case 'ringtone':
      case 'bday':
        this.props.contact.addField(
          field,
          '',
          this.props.index ? +this.props.index : undefined
        );
        Service.request('back');
        break;
      default:
        break;
    }
  }

  render() {
    const dom = [];
    const types = this.state.types;
    if (types.length) {
      const isCustom = field !== 'tel' && !types.includes(this.props.active);
      const field = this.state.activeField;
      types.forEach((type, index) => {
        const selected =
          type === this.props.active ||
          (isCustom && index === types.length - 1);
        dom.push(
          <div
            className="list-item"
            tabIndex="-1"
            data-field={field}
            data-type={type}
            key={`${field}-${type}`}
          >
            <div className="content">
              <div className="primary" data-l10n-id={type} />
            </div>
            <i
              className="icon"
              data-icon={selected ? 'radio-on' : 'radio-off'}
            />
          </div>
        );
      });
    } else {
      this.state.fields.forEach(field => {
        dom.push(
          <div
            className="list-item"
            tabIndex="-1"
            data-field={field}
            key={field}
          >
            <div className="content">
              <div className="primary" data-l10n-id={`add-${field}`} />
            </div>
          </div>
        );
      }, this);
    }
    return (
      <div
        className="field-chooser"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
      >
        {dom}
      </div>
    );
  }
}

FieldChooser.propTypes = {
  contact: React.PropTypes.object,
};
