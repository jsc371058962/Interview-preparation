import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import ListItem from 'components/list_item';
import { accountStore } from 'account/account_manager';
import Utils from 'contact_utils';
import ContactStore from './contact_store';
import SimStore from './sim_store';

class SettingView extends BaseComponent {
  name = 'SettingView';

  DEBUG = false;

  constructor(props) {
    super(props);
    this.debug('constructor');
    this.state = {
      rule: ContactStore.sortingRule,
      memory: ContactStore.source,
      sdn: false,
      accounts: [],
      isOnLine: Utils.isOnLine(),
    };

    Utils.handleNetworkEvent.call(this, 'add');
  }

  handleNetwork = evt => {
    if (navigator.connection) {
      this.setState(
        {
          isOnLine: evt.detail,
        },
        () => {
          !evt.detail && Service.request('offlineCallback');
        }
      );
    } else {
      const isNetworkConnected = navigator.onLine;
      this.setState(
        {
          isOnLine: isNetworkConnected,
        },
        () => {
          !isNetworkConnected && Service.request('offlineCallback');
        }
      );
    }
  };

  FOCUS_SELECTOR = '.navigable';

  componentDidMount() {
    this.debug('did mount');
    this.element = ReactDOM.findDOMNode(this);
    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element
    );
    this.updateSoftKeys();

    SimStore.getCardWithSDNList().then(() => {
      if (
        SimStore.getSDNContacts().some(list => {
          return list && list.length;
        })
      ) {
        this.setState({
          sdn: true,
        });
      }
    });

    if (!this.state.isOnLine) {
      Service.request('offlineCallback');
    }
    accountStore.whenReady.then(() => {
      this.setState({
        accounts: accountStore.getAccounts(),
      });
      accountStore.on('changed', accountId => {
        this.setState(
          {
            accounts: accountStore.getAccounts(),
          },
          () => {
            const focusedItem = this.element.querySelector(
              `[data-account-id="${accountId}"]`
            );
            focusedItem && this.navigator.setFocus(focusedItem);
          }
        );
      });
    });
  }

  componentWillUnmount() {
    this.debug('will unmount');
    this._softKey.destroy();
    Utils.handleNetworkEvent.call(this, 'remove');
  }

  updateSoftKeys() {
    const itemDisabled = document.activeElement.classList.contains('disabled');
    const config = {
      center: itemDisabled ? '' : 'select',
    };
    this._softKey = SoftKeyManager.create(this.element, config);
  }

  onFocus() {
    this.updateSoftKeys();
  }

  onKeyDown(evt) {
    switch (evt.key) {
      case 'Enter':
        if (document.activeElement.classList.contains('disabled')) {
          return;
        }
        switch (document.activeElement.dataset.actionType) {
          case 'import':
            if (ContactStore.fullDisk) {
              const _ = window.api.l10n.get;
              Service.request('showDialog', {
                header: _('phone-storage-full'),
                type: 'confirm',
                content: _('import-contact-storage-full'),
                translated: true,
                ok: 'settings',
                onOk: () => {
                  const activity = new WebActivity('configure', {
                    target: 'device',
                    section: 'mediaStorage',
                  });
                  activity.start().then(
                    () => {},
                    () => {
                      console.warn(
                        'Configure activity error:',
                        activity.error.name
                      );
                    }
                  );
                },
              });
            } else {
              Service.request('push', '/import');
            }
            break;
          case 'export':
            Service.request('push', '/export');
            break;
          case 'ice':
            Service.request('push', '/ice');
            break;
          case 'group':
            Service.request('showCreateGroupDialog');
            break;
          case 'block':
            Service.request('push', '/block');
            break;
          case 'speeddial':
            Service.request('push', '/speeddial');
            break;
          case 'sort':
            Service.request('popup', '/sort').then(value => {
              if (!value || !value.length) {
                return;
              }
              ContactStore.sortingRule = value[0];
              this.setState({
                rule: ContactStore.sortingRule,
              });
            });
            break;
          case 'memory':
            Service.request('popup', '/memory').then(value => {
              if (!value || !value.length) {
                return;
              }
              ContactStore.source = value;
              Service.request('List:reload');
              this.setState({
                memory: ContactStore.source,
              });
            });
            break;
          case 'sdn':
            // multiple cards existed
            if (
              navigator.b2g.iccManager &&
              navigator.b2g.iccManager.iccIds.length > 1
            ) {
              const options = [];
              SimStore.getSDNContacts().forEach((contacts, index) => {
                if (!contacts) {
                  return;
                }
                options.push({
                  label: `SIM ${index + 1}`,
                  callback: () => {
                    Service.request('push', `/sdn/${index}`);
                  },
                });
              });
              Service.request('showOptionMenu', {
                header: 'select-sim',
                options,
              });
            } else {
              Service.request('push', '/sdn/0');
            }
            break;
          case 'account':
            Service.request('push', '/account/adding');
            break;
          case 'accountInfo':
            Service.request('push', '/account/info', {
              authenticatorId: document.activeElement.dataset.authenticatorId,
              accountId: document.activeElement.dataset.accountId,
            });
            break;
          default:
            break;
        }
        break;
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('back');
        break;
      default:
        break;
    }
  }

  render() {
    this.debug('render');
    const hasNoContacts = 0 === ContactStore.currentContacts.length;
    const isSimOnly = 'sim' === this.state.memory;
    const disableSortContacts = isSimOnly || hasNoContacts;
    const fullDisk = ContactStore.fullDisk;
    const { isOnLine } = this.state;

    return (
      <div
        id="setting-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onFocus={e => this.onFocus(e)}
      >
        <div className="header h1" data-l10n-id="settings-title" />
        <div className="body">
          <ListItem
            primaryId="memory"
            secondaryId={this.state.memory}
            data-action-type="memory"
            disabled={fullDisk}
          />
          <ListItem
            primaryId="sort-contacts"
            secondaryId={
              'givenName' === this.state.rule
                ? 'sort-by-first-name'
                : 'sort-by-last-name'
            }
            data-action-type="sort"
            disabled={disableSortContacts || fullDisk}
          />
          {this.state.sdn ? (
            <ListItem primaryId="service-number" data-action-type="sdn" />
          ) : null}
          <ListItem
            itemType="button"
            primaryId="set-speed-dial"
            data-action-type="speeddial"
          />
          <ListItem
            itemType="button"
            primaryId="setICEButton"
            data-action-type="ice"
            disabled={hasNoContacts || fullDisk}
          />
          <ListItem
            itemType="button"
            primaryId="create-group"
            data-action-type="group"
            disabled={isSimOnly}
          />
          <ListItem
            itemType="button"
            primaryId="block-contacts"
            data-action-type="block"
          />
          <div className="separator secondary" data-l10n-id="import-export" />
          <ListItem
            itemType="button"
            primaryId="import-contacts"
            data-action-type="import"
            disabled={isSimOnly}
          />
          <ListItem
            itemType="button"
            primaryId="export-contacts"
            data-action-type="export"
            disabled={hasNoContacts}
          />
          <div className="separator secondary" data-l10n-id="accounts" />
          {this.state.accounts.map(({ authenticatorId, accountId }) => (
            <ListItem
              key={accountId}
              data-action-type="accountInfo"
              data-account-id={accountId}
              data-authenticator-id={authenticatorId}
              disabled={!isOnLine}
            >
              {accountId}
            </ListItem>
          ))}
          <ListItem
            itemType="button"
            primaryId="add-account"
            data-action-type="account"
            disabled={!isOnLine}
          />
        </div>
      </div>
    );
  }
}

export default SettingView;
