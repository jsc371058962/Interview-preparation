import BaseModule from 'base-module';
import ContactStore, { TAG_INDEX } from 'contact_store';
import { convertContactToSim } from './contact_wrapper';

class SimStore extends BaseModule {
  _sdn_contacts = [];
  iccIds = navigator.b2g.iccManager ? navigator.b2g.iccManager.iccIds : [];

  getSDNContacts() {
    console.log('getSDNContacts', JSON.stringify(this._sdn_contacts));
    return this._sdn_contacts;
  }

  getCardWithSDNList() {
    const promises = this.iccIds.map((iccId, index) => {
      return this.fetchSDN(index);
    });
    return Promise.all(promises);
  }

  fetchSDN(index) {
    if (!this._sdn_contacts.length) {
      this.iccIds.forEach(() => {
        this._sdn_contacts.push(null);
      });
    }
    return new Promise(resolve => {
      console.log('fetchSDN index', index, JSON.stringify(this._sdn_contacts));
      if (this._sdn_contacts[index]) {
        resolve(this._sdn_contacts[index]);
        return;
      }
      const icc =
        navigator.b2g.iccManager &&
        navigator.b2g.iccManager.getIccById(this.iccIds[index]);
      console.log('fetchSDN icc', icc);
      if (!icc) {
        resolve([]);
        return;
      }
      _getContactFor(icc, 'sdn').then(res => {
        this._sdn_contacts[index] = res;
        resolve(res);
      });
    });
  }

  import(index) {
    return new Promise(resolve => {
      import('./sim_importer').then(module => {
        const SimImporter = module.default;
        this.importer = new SimImporter(index);
        this.importer.import();
        resolve(this.importer);
      });
    });
  }

  getSimIndex = contact => {
    let index = 0;
    const simLabelMap = {};
    if (!Array.isArray(contact.category)) {
      return Promise.reject();
    }
    Object.entries(TAG_INDEX).forEach(([key, value]) => {
      if (key.startsWith('sim') && 'sim' !== key) {
        simLabelMap[value] = key;
      }
    });
    contact.category.forEach(tag => {
      if (simLabelMap[tag]) {
        index = parseInt(simLabelMap[tag].replace('sim', ''), 10);
      }
    });
    return index;
  };

  saveContactToSim(contact) {
    const index = this.getSimIndex(contact);
    return new Promise((resolve, reject) => {
      const icc = navigator.b2g.iccManager.getIccById(this.iccIds[index]);
      const toRemoteContact = convertContactToSim(contact);
      const request = icc.updateContact('adn', toRemoteContact);
      request.onsuccess = () => {
        console.log('save contact to sim', request.result);
        resolve(request.result);
      };
      request.onerror = () => {
        console.error('save contact to sim error', request.error);
        reject(request.error);
      };
    });
  }

  deleteSimContact(contact) {
    const index = this.getSimIndex(contact);
    return new Promise((resolve, reject) => {
      const icc = navigator.b2g.iccManager.getIccById(this.iccIds[index]);
      const toRemoteContact = convertContactToSim(contact, true);
      const request = icc.updateContact('adn', toRemoteContact);
      request.onsuccess = () => {
        console.log('delete contact to sim', request.result);
        resolve();
      };
      request.onerror = () => {
        console.error('delete contact to sim error', request.error);
        reject(request.error);
      };
    });
  }

  clearSimContact = () => {
    const batchSize = 5;
    let index = 0;
    const simList = ContactStore.getSourceContacts('sim');
    return new Promise(resolve => {
      const cursor = () => {
        Promise.all(
          simList
            .slice(index, (index += batchSize))
            .map(c => this.deleteSimContact(c))
        ).then(() => {
          if (index >= simList.length) {
            resolve();
          } else {
            cursor();
          }
        });
      };
      cursor();
    });
  };
}

const simStore = new SimStore();

window.simstore = simStore;

export default simStore;

function _getContactFor(icc, service) {
  return new Promise(resolve => {
    const request = icc.readContacts(service);
    request.onsuccess = () => {
      console.log('SIMStore icc.readContacts', JSON.stringify(request.result));
      import('./sim_importer').then(module => {
        const iccToMozContact = module.iccToMozContact;
        const items = request.result.map(item => {
          if ('sdn' === service) {
            item._id = service + item.id;
          }
          return iccToMozContact(icc.iccInfo.iccid, item);
        });
        console.log('SIMStore icc item', JSON.stringify(items));
        resolve(items);
      });
    };
    request.onerror = () => {
      resolve([]);
    };
  });
}

// for debugging
// eslint-disable-next-line no-unused-vars
function _mock_getContactFor(icc, service) {
  return new Promise(resolve => {
    const mock = [
      {
        id: '1',
        name: [`${service} 1`],
      },
      {
        id: '2',
        name: [`${service} 2`],
        tel: [{ value: '111' }],
      },
    ];
    import('./sim_importer').then(module => {
      const iccToMozContact = module.iccToMozContact;
      const items = mock.map(item => {
        return iccToMozContact(icc.iccInfo.iccid, item);
      });
      console.log('_mock_getContactFor: items:', items);
      resolve(items);
    });
  });
}
