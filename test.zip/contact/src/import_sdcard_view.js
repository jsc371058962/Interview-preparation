import React from 'react';
import ReactDOM from 'react-dom';
import Service from 'service';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import SdcardStore from './sdcard_store';

const _ = window.api.l10n.get;

export default class ImportSdcardView extends BaseComponent {
  name = 'ImportSdcardView';

  constructor(props) {
    super(props);
    this.state = {
      saved: '',
      progress: 0,
      total: 0,
      error: false,
    };
  }

  componentDidMount() {
    const config = {};
    this.element = ReactDOM.findDOMNode(this);
    window.isv = this;
    this._softKey = SoftKeyManager.create(this.element, config);
    this.import();
  }

  updateSoftKeys() {
    const config = {};
    if (this.state.error) {
      config.left = 'cancel';
      config.right = 'retry';
    } else {
      config.left = 'cancel';
    }
    this._softKey.update(config);
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  import() {
    const showFileSizeLimitDialog = () => {
      Service.request('showDialog', {
        header: _('import-limit-header'),
        content: _('inner-import-limit-content'),
        type: 'alert',
        translated: true,
        onOk: () => {
          Service.request('back');
        },
        onBack: () => {
          Service.request('back');
        },
      });
      SdcardStore.hasFilter = false;
    };
    SdcardStore.import().then(
      importer => {
        this.importer = importer;
        this.updateSoftKeys();
        this.setState({
          total: importer.total,
        });
        importer.on('imported', name => {
          this.setState({
            saved: name,
            progress: importer.imported,
            total: importer.total,
          });
        });
        importer.on('finished', () => {
          importer.contents = '';
          importer = null;
          if (SdcardStore.hasFilter) {
            showFileSizeLimitDialog();
          } else {
            Service.request('back');
          }
        });
      },
      err => {
        if (SdcardStore.hasFilter) {
          showFileSizeLimitDialog();
        }
        this.setState({
          error: err || true,
        });
      }
    );
  }

  onKeyDown(e) {
    switch (e.key) {
      case 'SoftLeft':
      case 'EndCall':
      case 'Backspace':
        e && e.preventDefault();
        this.importer && this.importer.cancel();
        if (this.state.error) {
          Service.request('back');
        }
        break;
      case 'SoftRight':
        if (this.state.error) {
          this.setState({
            error: false,
          });
          this.import();
        }
        break;
      default:
        break;
    }
  }

  onFocus = () => {
    Service.request('ensureDialog');
  };

  render() {
    let progressDOM = null;
    let divider = null;
    let importStatus = null;
    if (this.state.error) {
      if ('novCardFiles' === this.state.error) {
        Service.request('showDialog', {
          header: 'import-contacts',
          type: 'alert',
          content: 'novCardFiles',
          onOk: () => Service.request('back'),
          onBack: () => Service.request('back'),
        });
      }
      importStatus = (
        <div
          className="primary"
          key="import-sd-error"
          data-l10n-id="memoryCardContacts-error"
        />
      );
    } else if (this.state.total) {
      const progress = 100 * (this.state.progress / this.state.total);
      const activeStyle = { width: `${progress}%` };
      const inactiveStyle = { width: `calc(100% - ${progress}% - 0.3rem)` };
      progressDOM = (
        <div className="progress">
          <div className="progress-active" style={activeStyle} />
          <div className="progress-inactive" style={inactiveStyle} />
        </div>
      );
      divider = (
        <div className="secondary">
          {this.state.progress}/{this.state.total}
        </div>
      );
      importStatus = (
        <div className="primary" data-l10n-id="importing-contacts-from-sd" />
      );
    } else {
      importStatus = (
        <div
          className="primary"
          key="import-sd-reading"
          data-l10n-id="reading-contacts-from-sd"
        />
      );
    }
    return (
      <div
        className="import-sdcard-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onFocus={this.onFocus}
      >
        <div
          className="header h1"
          ref="header"
          data-l10n-id="importContactsTitle"
        />
        <div className="body">
          <div className="list-item" data-multi-line="true">
            <div className="content">
              {importStatus}
              {divider}
              {progressDOM}
            </div>
          </div>
        </div>
      </div>
    );
  }
}
