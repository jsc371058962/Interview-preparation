import BaseModule from 'base-module';
import Service from 'service';
import RTTSettings from 'rtt_settings';
import Utils from './contact_utils';
import SimCardHelper from './sim_card_helper';
import ContactStore, { MAX_GROUP_NUMBER } from './contact_store';

class OptionMenuHelper extends BaseModule {
  name = 'OptionMenuHelper';
  DEBUG = false;

  constructor(props) {
    super(props);

    Utils.checkEmailInstalled();
    Service.register('pickANumber', this);
    Service.register('showCreateGroupDialog', this);
  }

  optionsForContact(contact) {
    const options = [];

    options.push({
      id: 'edit-contact',
      callback: () => {
        Service.request('push', `/edit/${contact.id}`);
      },
    });
    if (contact && contact.tel && contact.tel.length) {
      let label = 'call';
      if (
        navigator.b2g.iccManager.iccIds.length > 1 &&
        !SimCardHelper.isAlwaysAsk()
      ) {
        label = `call-sim-${SimCardHelper.cardIndex + 1}`;
      }
      switch (RTTSettings.value) {
        case RTTSettings.CONFIG_MANUAL:
          options.push(
            {
              id: label,
              callback: () => {
                this.pickANumber(contact).then(tel => {
                  Utils.dial(tel, true);
                });
              },
            },
            {
              id: 'rtt-call',
              callback: () => {
                this.pickANumber(contact).then(tel => {
                  Utils.dial(tel, true, true);
                });
              },
            }
          );
          break;
        case RTTSettings.CONFIG_AUTOMATIC:
          options.push({
            id: 'rtt-call',
            callback: () => {
              this.pickANumber(contact).then(tel => {
                Utils.dial(tel, true, true);
              });
            },
          });
          break;
        case undefined:
        case RTTSettings.CONFIG_VISIBLE:
          options.push({
            id: label,
            callback: () => {
              this.pickANumber(contact).then(tel => {
                Utils.dial(tel, true);
              });
            },
          });
          break;
        default:
          break;
      }

      options.push({
        id: 'send-message',
        callback: () => {
          this.pickANumber(contact).then(tel => {
            Utils.sendSms(tel);
          });
        },
      });
    }

    if (!Service.query('isLowMemoryDevice')) {
      if (
        contact &&
        contact.email &&
        contact.email.length &&
        Utils.SUPPORT_EMAIL &&
        Utils.EMAIL_INSTALLED
      ) {
        options.push({
          id: 'send-email',
          callback: () => {
            this.pickAMail(contact).then(email => {
              Utils.sendEmail(email);
            });
          },
        });
      }

      options.push({
        id: 'speed-dial',
        callback: () => {
          Service.request('push', '/speeddial');
        },
      });

      options.push({
        id: 'share',
        callback: () => {
          Utils.share(contact);
        },
      });
    } else {
      options.push({
        id: 'speed-dial',
        callback: () => {
          Service.request('push', '/speeddial');
        },
      });
    }
    return options;
  }

  optionsForContacts() {
    const options = [];
    options.push({
      id: 'massive-delete',
      callback: () => {
        Service.request('setEditMode', 'delete');
      },
    });

    if (
      navigator.b2g.iccManager &&
      navigator.b2g.iccManager.iccIds &&
      navigator.b2g.iccManager.iccIds.length > 0
    ) {
      options.push({
        id: 'move-contacts',
        callback: () => {
          this.migrateContacts('move');
        },
      });

      options.push({
        id: 'copy-contacts',
        callback: () => {
          this.migrateContacts('copy');
        },
      });
    }

    return options;
  }

  pickANumber(contact) {
    return new Promise(resolve => {
      if (!contact.tel) {
        resolve(null);
        return;
      }
      if (contact.tel.length > 1) {
        const options = [];
        contact.tel.forEach(tel => {
          options.push({
            label: `(${tel.type[0].toUpperCase()[0]}) ${tel.value}`,
            callback: () => {
              resolve(tel.value);
            },
          });
        });
        Service.request('showOptionMenu', {
          header: 'choose-number',
          options,
          onCancel: () => {},
        });
      } else if (contact.tel.length && contact.tel[0].value) {
        resolve(contact.tel[0].value);
      } else {
        resolve(null);
      }
    });
  }

  pickAMail(contact) {
    return new Promise(resolve => {
      if (contact.email.length > 1) {
        const options = [];
        contact.email.forEach(email => {
          options.push({
            label: email.value,
            callback: () => {
              resolve(email.value);
            },
          });
        });
        Service.request('showOptionMenu', {
          header: 'choose-mail-adress',
          options,
          onCancel: () => {},
        });
      } else {
        resolve(contact.email[0].value);
      }
    });
  }

  pickAGroup(groups, type = 'add') {
    if (!groups || !groups.length) {
      return;
    }
    return new Promise(resolve => {
      const options = [];
      groups.forEach(group => {
        options.push({
          label: ContactStore.getGroupNameByID(group),
          callback: () => {
            resolve(group);
          },
        });
      });
      if ('remove' === type && 1 === options.length) {
        options[0].callback();
        return;
      }
      Service.request('showOptionMenu', {
        header: 'select-group',
        options,
        onCancel: () => {},
      });
    });
  }

  migrateContacts(mode) {
    this.chooseSource(mode)
      .then(source => {
        return this.chooseTarget(mode, source);
      })
      .then(path => {
        this.debug('migrate from, to:', path[0], path[1]);
        Service.request('popup', path[0]).then(ids => {
          if (ids && ids[0]) {
            Service.request('popup', path[1], { ids: ids[0] });
          }
        });
      });
  }

  chooseSource(mode) {
    return new Promise(resolve => {
      const options = [];
      if (ContactStore.getSourceContacts('phone').length) {
        options.push({
          id: 'phone-memory',
          callback: () => resolve('phone'),
        });
      }
      Utils.getSIMOptions().forEach(({ id, cardIndex }) => {
        if (ContactStore.getSourceContacts(`sim${cardIndex}`).length) {
          options.push({
            id,
            callback: () => resolve(`sim${cardIndex}`),
          });
        }
      });

      Service.request('showOptionMenu', {
        header: `${mode}-from`,
        options,
      });
    });
  }

  chooseTarget(mode, source) {
    return new Promise(resolve => {
      let options = [];
      if ('phone' === source) {
        options = Utils.getSIMOptions().map(({ id, cardIndex }) => ({
          id,
          callback: () => {
            resolve([`/${mode}/from/phone`, `/${mode}/to/sim${cardIndex}`]);
          },
        }));
      } else {
        options = [
          {
            id: 'phone-memory',
            callback: () => {
              resolve([`/${mode}/from/${source}`, `/${mode}/to/phone`]);
            },
          },
        ];
      }
      Service.request('showOptionMenu', {
        header: 'to',
        options,
      });
    });
  }

  showCreateGroupDialog(options = {}) {
    const { rename, id, initialValue } = options;
    return new Promise(resolve => {
      Service.request('showDialog', {
        header: rename ? 'rename-group' : 'create-group',
        content: 'group-name',
        type: 'prompt',
        ok: 'save',
        maxLength: 20,
        hideOkWhenNoInputValue: true,
        initialValue,
        onOk: value => {
          const _ = window.api.l10n.get;
          ContactStore.saveGroup(value, id).then(
            () => {
              if (!rename) {
                Service.request('ToastManager:show', {
                  text: _('new-group-created'),
                });
              }
              resolve();
            },
            err => {
              let content = err;
              if ('too-many' === err) {
                content = _('create-group-too-many', {
                  number: MAX_GROUP_NUMBER,
                });
              } else if ('duplicate' === err) {
                content = _('create-group-duplicate');
              }
              Service.request('showDialog', {
                type: 'alert',
                header: _('group'),
                content: `${_(
                  rename ? 'rename-group-failed' : 'create-group-failed'
                )}\n${content}`,
                translated: true,
              });
            }
          );
        },
      });
    });
  }
}

export default new OptionMenuHelper();
