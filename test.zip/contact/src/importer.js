import React from 'react';
import Service from 'service';
import BaseComponent from 'base-component';
import SocialServiceStore from './social_service_store';

export default class Importer extends BaseComponent {
  name = 'Importer';

  constructor(props) {
    super(props);
    this.state = {
      service: '',
      access_token: '',
    };
  }

  componentDidMount() {
    window.importer = this;
    window.addEventListener('message', this);
    Service.register('load', this);
  }

  _handle_message(evt) {
    switch (evt.data.type) {
      case 'authenticated':
        this.access_token = evt.data.data;
        SocialServiceStore.setAccessToken(this.state.service, evt.data.data);
        // will this being opened twice?
        Service.request('popup', `/import/service/${this.state.service}`);
        break;
      case 'import_updated':
        this.refs.extensions.contentWindow.postMessage(
          {
            type: 'contacts_loaded',
            data: '',
          },
          window.location.origin
        );
        break;
      case 'messaging_ready':
        this.refs.extensions.contentWindow.postMessage(
          {
            type: 'token',
            data: this.access_token,
          },
          window.location.origin
        );
        break;
      default:
        break;
    }
  }

  load(serviceName) {
    this.setState({
      service: serviceName,
    });
    this.refs.oauth.contentWindow.postMessage(
      {
        type: 'start',
        data: {
          from: 'friends',
          service: serviceName,
        },
      },
      window.location.origin
    );
  }

  render() {
    return (
      <div className="importer">
        <iframe ref="extensions" id="fb-extensions" />
      </div>
    );
  }
}
