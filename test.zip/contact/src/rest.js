import BaseModule from 'base-module';

function RestRequest(xhr) {
  let cancelled = false;
  this.cancel = function oncancel() {
    cancelled = true;
    window.setTimeout(xhr.abort.bind(xhr), 0);
  };
  this.isCancelled = function isCancelled() {
    return cancelled;
  };
}

class Rest extends BaseModule {
  name = 'Rest';
  DEBUG = false;

  get(uri, callback, pOptions) {
    const DEFAULT_TIMEOUT = 30000;
    const options = pOptions || {};

    const xhr = new XMLHttpRequest({
      mozSystem: true,
    });
    const outReq = new RestRequest(xhr);

    this.debug('xhr open:', uri);
    xhr.open('GET', uri, true);
    const responseType = options.responseType || 'json';
    xhr.responseType = responseType;
    const responseProperty =
      'xml' === responseType ? 'responseXML' : 'response';

    xhr.timeout = options.operationsTimeout || DEFAULT_TIMEOUT;
    if (
      !xhr.timeout ||
      (xhr.timeout === DEFAULT_TIMEOUT &&
        parent &&
        parent.config &&
        parent.config.operationsTimeout)
    ) {
      xhr.timeout = parent.config.operationsTimeout;
    }

    if (options.requestHeaders) {
      for (const header in options.requestHeaders) {
        xhr.setRequestHeader(header, options.requestHeaders[header]);
      }
    }

    xhr.onload = e => {
      this.debug('xhr onload:');
      if (200 === xhr.status || 400 === xhr.status || 0 === xhr.status) {
        if (callback && 'function' === typeof callback.success) {
          setTimeout(() => {
            callback.success(xhr[responseProperty]);
          }, 0);
        }
      } else {
        console.error(
          'HTTP error executing GET. ',
          uri,
          ' Status: ',
          xhr.status,
          e
        );
        if (callback && 'function' === typeof callback.error) {
          setTimeout(() => {
            callback.error({ status: xhr.status });
          }, 0);
        }
      }
    }; // onload

    xhr.ontimeout = e => {
      this.debug('xhr ontimeout:');
      console.error('Timeout!!! while HTTP GET: ', uri, e);
      if (callback && 'function' === typeof callback.timeout) {
        setTimeout(callback.timeout, 0);
      }
    }; // ontimeout

    xhr.onerror = e => {
      this.debug('xhr onerror:');
      console.error('Error while executing HTTP GET: ', uri, ': ', e);
      if (
        callback &&
        'function' === typeof callback.error &&
        !outReq.isCancelled()
      ) {
        setTimeout(() => {
          callback.error(e);
        }, 0);
      }
    }; // onerror

    xhr.send();

    return outReq;
  }
}

const rest = new Rest();

export default rest;
