import BaseModule from 'base-module';
import { TAG_INDEX } from 'contact_store';
import Rest from './rest';

const LIVE_ENDPOINT = 'https://graph.microsoft.com/v1.0/';
const CONTACTS_RESOURCE = 'me/contacts';
const QUERY_STRING = '?$top=10000';

// API reference: https://msdn.microsoft.com/en-us/office/office365/api/contacts-rest-operations#get-contact-photo-and-metadata
const PICTURE_RESOURCE = '/photo/$value';

function fillAddress(addrType, addrValue) {
  const out = {
    type: [addrType],
    streetAddress: addrValue.street || '',
    locality: addrValue.city || '',
    region: addrValue.state || '',
    countryName: addrValue.countryOrRegion || '',
    postalCode: addrValue.postalCode || '',
  };

  return out;
}

function getURI(liveContact) {
  return `urn:uuid:${liveContact.user_id || liveContact.id}`;
}

function resolveURI(uri) {
  const components = uri.split(':');
  // The third element is the user id of the live contact
  return components[2];
}

class LiveConnector extends BaseModule {
  name = 'LiveConnector';
  DEBUG = false;

  _requestHeaders = {};

  listAllContacts(access_token, callbacks) {
    this.debug('listAllContacts:');
    this.access_token = access_token;
    Object.assign(this._requestHeaders, {
      Authorization: `Bearer ${access_token}`,
    });
    const uriElements = [LIVE_ENDPOINT, CONTACTS_RESOURCE, QUERY_STRING];

    return Rest.get(uriElements.join(''), callbacks, {
      requestHeaders: this._requestHeaders,
    });
  }

  listDeviceContacts(callbacks) {
    const filterOptions = {
      filterValue: TAG_INDEX.phone,
      filterOp: 'contains',
      filterBy: ['category'],
    };
    const req = ContactsManager.find(filterOptions);
    req.onsuccess = () => {
      callbacks.success(req.result);
    };
    req.onerror = () => {
      callbacks.error(req.error);
    };
  }

  cleanContacts() {
    // Just a placeholder for the moment
  }

  adaptDataForShowing(source) {
    this.debug('adaptDataForShowing:');
    const out = {};

    out.uid = source.id;
    out.givenName = [source.givenName || ''];
    out.familyName = [source.surname || ''];
    out.email1 = source.emailAddresses[0]
      ? source.emailAddresses[0].address
      : '';

    // XXX: need photo url

    return out;
  }

  // raw contact properties: https://developer.microsoft.com/en-us/graph/docs/api-reference/v1.0/resources/contact
  adaptDataForSaving(liveContact) {
    this.debug('adaptDataForSaving:', liveContact.displayName);
    const out = {
      givenName: [liveContact.givenName || ''],
      familyName: [liveContact.surname || ''],
      name: [liveContact.displayName || ''],
      tel: [],
      email: [],
      adr: [],
      category: [TAG_INDEX.phone, TAG_INDEX.kaiContact],
      url: [
        {
          type: ['source'],
          value: getURI(liveContact),
        },
      ],
    };

    // bday
    if (liveContact.birthday) {
      out.bday = new Date(liveContact.birthday);
    }

    // email
    if (Array.isArray(liveContact.emailAddresses)) {
      liveContact.emailAddresses.forEach(email => {
        email.address &&
          out.email.push({
            type: ['personal'],
            value: email.address,
          });
      });
    }

    // tel
    if (liveContact.mobilePhone) {
      out.tel.push({
        type: ['mobile'],
        value: liveContact.mobilePhone,
      });
    }
    if (Array.isArray(liveContact.homePhones)) {
      liveContact.homePhones.forEach(phone => {
        out.tel.push({
          type: ['home'],
          value: phone,
        });
      });
    }
    if (Array.isArray(liveContact.businessPhones)) {
      liveContact.businessPhones.forEach(phone => {
        out.tel.push({
          type: ['work'],
          value: phone,
        });
      });
    }

    // adr
    if (liveContact.homeAddress) {
      if (0 !== Object.keys(liveContact.homeAddress).length) {
        out.adr.push(fillAddress('home', liveContact.homeAddress));
      }
    }
    if (liveContact.businessAddress) {
      if (0 !== Object.keys(liveContact.businessAddress).length) {
        out.adr.push(fillAddress('work', liveContact.businessAddress));
      }
    }

    return out;
  }

  // It would allow to know the UID of a service contact already imported
  // on the device. That is needed by the generic importer, for live
  // a dummy implementation as we are currently not supporting updates
  getContactUid(deviceContact) {
    let out = '-1';

    const url = deviceContact.url;
    if (Array.isArray(url)) {
      const targetUrls = url.filter(aUrl => {
        return Array.isArray(aUrl.type) && aUrl.type.indexOf('source') !== -1;
      });
      if (targetUrls[0]) {
        out = resolveURI(targetUrls[0].value);
      }
    }

    return out;
  }

  get automaticLogout() {
    return true;
  }

  // XXX: need verify
  downloadContactPicture(contact, callbacks) {
    this.debug('downloadContactPicture: id:', contact.id);
    if (contact.id) {
      const uriElements = [
        LIVE_ENDPOINT,
        CONTACTS_RESOURCE,
        `('${contact.id}')`,
        PICTURE_RESOURCE,
      ];

      return Rest.get(uriElements.join(''), callbacks, {
        requestHeaders: this._requestHeaders,
        responseType: 'blob',
      });
    }
    callbacks.success(null);
  }

  startSync() {
    // Sync not supported
  }
}

const liveConnector = new LiveConnector();

export default liveConnector;
