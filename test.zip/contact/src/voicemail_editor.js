import React from 'react';
import BaseComponent from 'base-component';
import SimpleNavigationHelper from 'simple-navigation-helper';
import SoftKeyManager from 'modules/soft_key_manager';
import InputItem from 'components/input_item';
import Voicemail from './voicemail';
import Utils from './contact_utils';

export default class VoicemailEditor extends BaseComponent {
  name = 'VoicemailEditor';
  cardNum = 0;
  DEBUG = false;

  constructor(props) {
    super(props);
    this.state = {
      values: Voicemail.getValues(),
    };
    this.onKeyDown = this.onKeyDown.bind(this);
    this.onFocus = this.onFocus.bind(this);
    this._updateValues = this._updateValues.bind(this);
  }

  componentDidMount() {
    this.debug('did mount');
    this.cardNum = navigator.b2g.iccManager
      ? navigator.b2g.iccManager.iccIds.length
      : 0;
    this.navigator = new SimpleNavigationHelper(
      '.list-item:not(.disabled) .navigable',
      this.element
    );
    this.updateSoftKeys();
    Voicemail.on('changed', this._updateValues);
  }

  componentWillUnmount() {
    Voicemail.off('changed', this._updateValues);
  }

  _updateValues() {
    this.setState({
      values: Voicemail.getValues(),
    });
  }

  updateSoftKeys(changeFlag) {
    const config = {
      left: 'cancel',
      right: changeFlag ? 'save' : '',
    };
    this._softKey = SoftKeyManager.create(this.element, config);
  }

  onKeyDown(evt) {
    this.debug('onKeyDown: key:', evt.key);
    switch (evt.key) {
      case 'SoftRight':
        if (!this.element.contains(document.activeElement) || !this.cardNum) {
          break;
        }
        if (!this._softKey.getSoftKeyValue('right')) {
          break;
        }
        Voicemail.set(this.state.values);
        Utils.backOrClose();
        break;
      case 'SoftLeft':
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        Utils.backOrClose();
        break;
      default:
        break;
    }
  }

  onFocus() {
    this.updateSoftKeys();
  }

  render() {
    this.debug('render');

    let voiceMailId = 'voice-mail-number';
    let args;
    const simSlots = navigator.b2g.mobileConnections;
    // b2g.mobileConnections is a Array-Like Objects.
    const dom = Array.prototype.map.call(simSlots, (connection, cardIndex) => {
      const cardExisted = connection.iccId;

      const onChange = e => {
        const values = [].concat(this.state.values);
        values[cardIndex] = e.target.value;
        this.setState({
          values,
        });
        this.updateSoftKeys(true);
      };

      if (1 === simSlots.length) {
        voiceMailId = 'voice-mail-number-single';
        args = null;
      } else {
        args = JSON.stringify({ n: cardIndex + 1 });
      }

      return (
        <InputItem
          key={cardIndex}
          type="tel"
          labelL10nId={voiceMailId}
          labelL10nArgs={args}
          disabled={
            !cardExisted || navigator.b2g.voicemail.getNumber(cardIndex)
          }
          ariaLabel="voice-mail"
          maxLength={20}
          value={cardExisted ? this.state.values[cardIndex] : ''}
          onChange={onChange}
        />
      );
    });

    return (
      <div
        ref={e => {
          this.element = e;
        }}
        id="voicemail-editor"
        tabIndex="-1"
        role="form"
        onKeyDown={this.onKeyDown}
        onFocus={this.onFocus}
      >
        <div className="header h1" data-l10n-id="voice-mail" />
        {dom}
      </div>
    );
  }
}
