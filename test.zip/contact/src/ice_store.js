import BaseModule from 'base-module';

const STORE_NAME = 'ice_contacts';
class ICEStore extends BaseModule {
  // Get a reference to the store, or returns it if
  // we already have.
  name = 'ICEStore';
  DEBUG = false;

  contacts = [];
  start() {
    this.initContacts();
    this.fetchRemote();
    ContactsManager.addEventListener(
      ContactsManager.EventMap.CONTACT_CHANGE,
      this._handle_contactchange
    );
  }

  initContacts = () => {
    this.contacts = [
      {
        id: undefined,
      },
      {
        id: undefined,
      },
      {
        id: undefined,
      },
      {
        id: undefined,
      },
      {
        id: undefined,
      },
    ];
  };

  setItem(data) {
    try {
      window.localStorage.setItem(STORE_NAME, JSON.stringify(data));
    } catch (e) {
      console.error(`localStorage:set ${STORE_NAME} value error: ${e}`);
    }
  }

  has(id) {
    return this.contacts.some(data => {
      if (data.id === id) {
        return true;
      }
      return false;
    });
  }

  _handle_contactchange = evt => {
    if (ContactsManager.ChangeReason.REMOVE !== evt.reason) {
      return;
    }
    const { id } = evt.contacts[0];
    if (id) {
      this.contacts.forEach((ice, index) => {
        if (ice.id === id) {
          this.unsetContact(index, id);
        }
      });
    }
  };

  clearAllIce = () => {
    this.initContacts();
    this.setItem(this.contacts);
    this.emit('changed');
  };

  fetchRemote() {
    ContactsManager.getAllICE().then((ices = []) => {
      ices.forEach(({ contactId, position }) => {
        if (contactId) {
          this.contacts[position - 1].id = contactId;
        }
      });
      this.setItem(this.contacts);
      this.emit('changed');
    });
  }

  /**
   * Set the value of an ICE contact, both in local and daemon
   * @param id (string) contact id
   * @param pos (int) current position (0,4)
   */
  setContact(id, pos) {
    // Save locally
    this.contacts[pos] = {
      id,
    };
    this.setItem(this.contacts);
    this.emit('changed');
    // Save in the daemon
    return ContactsManager.setICE(id, +pos + 1);
  }

  unsetContact(pos, id) {
    this.contacts[pos] = {
      id: '',
    };
    this.emit('changed');
    this.setItem(this.contacts);
    return ContactsManager.removeICE(id);
  }

  /**
   * Retrieves the in case of emergency contacts
   * @returns {Promise}
   */
  getAll() {
    return this.contacts;
  }

  isEmpty() {
    return this.contacts.every(item => {
      return !item.id;
    });
  }
}

const iceStore = new ICEStore();
iceStore.start();

export default iceStore;
