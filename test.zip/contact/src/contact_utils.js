import Service from 'service';
import RTTSettings from 'rtt_settings';
import ContactStore from './contact_store';

const utils = {
  SUPPORT_EMAIL: !Service.query('isLowMemoryDevice'),
  SUPPORT_VOICEMAIL: true,
  EMAIL_INSTALLED: false,

  backOrClose() {
    if (Service.query('canGoBack')) {
      Service.request('back');
    } else if (Service.query('isActivity')) {
      Service.request('leaveActivity');
    } else {
      Service.request('back');
    }
  },

  isSIMContact(contact) {
    return contact && contact.category && contact.category.indexOf('SIM') >= 0;
  },

  hasContent(field) {
    return (
      Array.isArray(field) &&
      field.length > 0 &&
      field[0].value &&
      field[0].value.trim()
    );
  },

  toVcard(contact) {
    return new Promise(resolve => {
      import('./vcard_utils').then(module => {
        const VcardUtils = module.default;
        VcardUtils.ContactToVcardBlob([contact], {
          type: 'text/x-vcard',
        }).then(vcardBlob => {
          resolve({
            name: VcardUtils.getVcardFilename(contact),
            blob: vcardBlob,
          });
        });
      });
    });
  },

  fromVcard(blob) {
    return new Promise(resolve => {
      const fileReader = new FileReader();
      fileReader.readAsText(blob);
      fileReader.onloadend = () => {
        if ('null' === fileReader.result) {
          Service.request('showDialog', {
            title: 'alert',
            content: 'invalid-vcf-file',
            onOk: () => {
              Service.request('back');
            },
          });
        } else {
          import('./vcard_reader').then(module => {
            const VCardReader = module.default;
            const reader = new VCardReader(fileReader.result);
            if (reader.total > 1) {
              Service.request('showDialog', {
                header: 'confirm',
                type: 'alert',
                content: 'no-support-open-multi-vcard',
                onOk: () => {
                  Service.request('leaveActivity');
                },
              });
              return;
            }
            reader.on('parsed', contact => {
              resolve(contact);
            });
            reader.import(true);
          });
        }
      };
    });
  },

  share(contact) {
    import('./vcard_utils').then(module => {
      const VcardUtils = module.default;
      VcardUtils.ContactToVcardBlob([contact], {
        type: 'text/x-vcard',
      }).then(vcardBlob => {
        const filename = VcardUtils.getVcardFilename(contact);
        new window.WebActivity('share', {
          type: 'text/vcard',
          number: 1,
          blobs: [
            new window.File([vcardBlob], filename, {
              type: vcardBlob.type || 'text/vcard',
            }),
          ],
          filenames: [filename],
        }).start();
        // The MIME of the blob should be this for some MMS gateways
      });
    });
  },

  setCursorToEnd(el) {
    const range = document.createRange();
    range.selectNodeContents(el);
    range.collapse(false);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    if (el.setSelectionRange) {
      el.setSelectionRange(el.value.length, el.value.length);
    }
  },

  guessRingtoneName(filename) {
    if (!filename) {
      return '';
    }
    const a = filename.split('/');
    filename = a[a.length - 1];
    return filename.replace('ringer_', '');
  },

  checkRingTone(ringTone) {
    return new Promise(resolve => {
      if (ringTone && ringTone.indexOf('builtin:ringtone') !== 0) {
        const deviceStorages = navigator.b2g.getDeviceStorages('sdcard');
        return this.getFile(deviceStorages[0], ringTone).then(
          result => {
            resolve(!!result);
          },
          () => {
            return this.getFile(deviceStorages[1], ringTone).then(
              result => {
                resolve(!!result);
              },
              () => {
                resolve(false);
              }
            );
          }
        );
      }
      resolve(true);
    });
  },

  getFile(storage, filename) {
    return new Promise((resolve, reject) => {
      const request = storage.get(filename);
      request.onsuccess = () => {
        resolve(request.result);
      };
      request.onerror = reject;
    });
  },

  isEmailValid(email) {
    const emailExp = /\S+@\S+\.\S+/;
    return emailExp.test(email);
  },

  sendSms(number) {
    import('./dial_helper').then(module => {
      const DialHelper = module.default;
      if (!DialHelper.isValid(number)) {
        Service.request('showDialog', {
          type: 'alert',
          header: 'invalidNumberToSendTitle',
          content: 'invalidNumberToSendMessage',
        });
      } else {
        new window.WebActivity('new', {
          type: 'websms/sms',
          number,
        }).start();
      }
    });
  },

  sendEmail(address) {
    if (!this.SUPPORT_EMAIL) {
      return;
    }
    new window.WebActivity('new', {
      type: 'mail',
      URI: `mailto:${address}`,
    }).start();
  },

  extraCharExp: /(\s|-|\.|\(|\))/g,

  /**
   * Get items for option menu when choosing sim cards.
   * Normally we will create callback for each items in the result array.
   * @return {array} The item object looks like { id: ... , cardIndex: ... }.
   */
  getSIMOptions: () => {
    const options = [];
    const availableCardIndex = [];
    SIMSlotManager.getSlots().forEach((slot, index) => {
      if (!slot.isAbsent() && !slot.isLocked()) {
        availableCardIndex.push(index);
      }
    });

    if (1 === availableCardIndex.length) {
      options.push({
        id: 'sim-memory',
        cardIndex: '',
      });
    } else if (availableCardIndex.length > 1) {
      availableCardIndex.forEach(index => {
        options.push({
          id: `sim-${index}-memory`,
          cardIndex: index,
        });
      });
    }
    return options;
  },

  chooseMemory() {
    return new Promise(resolve => {
      const memory = ContactStore.source;
      let options = [];
      if ('sim' !== memory) {
        options = [
          {
            id: 'phone-memory',
            callback: () => {
              resolve('phone');
            },
          },
        ];
      }
      let addEmail = false;
      if (
        Service.query('isActivity') &&
        Service.query('activityParams') &&
        Service.query('activityParams').email
      ) {
        addEmail = true;
      }
      if ('phone' !== memory) {
        if (!addEmail) {
          options = options.concat(
            this.getSIMOptions().map(({ id, cardIndex }) => ({
              id,
              callback: () => {
                resolve(`sim${cardIndex}`);
              },
            }))
          );
        } else if ('sim' === memory) {
          Service.request('showDialog', {
            header: 'add-contact-failed',
            content: 'email-cannot-add-to-sim',
            type: 'alert',
            onOk: () => {
              resolve(null);
            },
          });
          return;
        } else {
          options = [
            {
              id: 'phone-memory',
              callback: () => {
                resolve('phone');
              },
            },
          ];
        }
      }

      if (0 === options.length) {
        Service.request('showDialog', {
          header: 'add-contact-failed',
          content: 'no-sim-card-available',
          type: 'alert',
          onOk: () => {
            resolve(null);
          },
        });
      } else if (1 === options.length) {
        options[0].callback();
      } else {
        Service.request('showOptionMenu', {
          options,
          onCancel: () => {
            resolve(null);
          },
        });
      }
    });
  },

  dial(number, isFromOption, isRTT) {
    if (!Array.isArray(number)) {
      if (!number) {
        Service.request('ToastManager:show', {
          text: window.api.l10n.get('no-phone-number-to-dial'),
        });
        return;
      }
    }

    const options = [];
    DeviceCapabilityManager.get('device.vilte').then(hasVT => {
      const videoCallItem = {
        id: 'video-call',
        callback: () => {
          import('./dial_helper').then(module => {
            const DialHelper = module.default;
            DialHelper.dial(number, true);
          });
        },
      };
      if (isFromOption) {
        options.push({
          id: 'call',
          callback: () => {
            import('./dial_helper').then(module => {
              const DialHelper = module.default;
              DialHelper.dial(number, false, isRTT);
            });
          },
        });
      } else {
        switch (RTTSettings.value) {
          case RTTSettings.CONFIG_MANUAL:
            options.push({
              id: 'call',
              callback: () => {
                import('./dial_helper').then(module => {
                  const DialHelper = module.default;
                  DialHelper.dial(number);
                });
              },
            });
            options.push({
              id: 'rtt-call',
              callback: () => {
                import('./dial_helper').then(module => {
                  const DialHelper = module.default;
                  DialHelper.dial(number, false, true);
                });
              },
            });
            break;
          case RTTSettings.CONFIG_AUTOMATIC:
            options.push({
              id: 'rtt-call',
              callback: () => {
                import('./dial_helper').then(module => {
                  const DialHelper = module.default;
                  DialHelper.dial(number, false, true);
                });
              },
            });
            break;
          case undefined:
          case RTTSettings.CONFIG_VISIBLE:
            options.push({
              id: 'call',
              callback: () => {
                import('./dial_helper').then(module => {
                  const DialHelper = module.default;
                  DialHelper.dial(number);
                });
              },
            });
            break;
          default:
            break;
        }
      }

      hasVT && options.push(videoCallItem);
      if (1 === options.length) {
        options[0].callback();
      } else {
        Service.request('showOptionMenu', {
          options,
        });
      }
    });
  },

  isDefined(field) {
    return (
      Array.isArray(field) &&
      field[0] &&
      (('string' === typeof field[0] && field[0].trim().length > 0) ||
        'object' === typeof field[0])
    );
  },

  getThumbsConfig() {
    return new Promise(resolve => {
      // This was loading config file from disk before.
      // For now we don't provide the build time customization anymore.
      resolve({
        format: 'image/jpeg',
        size: 65,
        quality: 1.0,
      });
    });
  },

  getSourceSimUrl(aContact) {
    let out;

    if (
      Array.isArray(aContact.category) &&
      aContact.category.indexOf('sim') !== -1 &&
      Array.isArray(aContact.url)
    ) {
      for (let j = 0; j < aContact.url.length; j++) {
        const aUrl = aContact.url[j];
        if (
          aUrl.type.indexOf('source') !== -1 &&
          aUrl.type.indexOf('sim') !== -1
        ) {
          out = aUrl.value;
        }
      }
    }

    return out;
  },

  hasName(contact) {
    return (
      Array.isArray(contact.name) &&
      contact.name[0] &&
      contact.name[0].trim &&
      contact.name[0].trim()
    );
  },

  getCompleteName(contact) {
    const givenName = Array.isArray(contact.givenName)
      ? contact.givenName[0]
      : '';

    const familyName = Array.isArray(contact.familyName)
      ? contact.familyName[0]
      : '';

    const completeName =
      givenName && familyName
        ? `${givenName} ${familyName}`
        : givenName || familyName;

    return completeName;
  },

  isCustomTag(field, type) {
    const types = {
      email: ['personal', 'work', 'other', 'custom'],
      tel: [
        'mobile',
        'home',
        'work',
        'personal',
        'fax-home',
        'fax-office',
        'fax-other',
        'other',
      ],
      adr: ['current', 'home', 'work'],
    };

    if (!types[field]) {
      return false;
    }

    if (types[field].indexOf(type) >= 0) {
      return false;
    }
    return true;
  },

  getFieldL10nConfig(field, type, tag = 'phone') {
    const options = {};
    if (type && 'phone' === tag && this.isCustomTag(field, type)) {
      options['data-l10n-id'] = `custom-${field}`;
      options['data-l10n-args'] = JSON.stringify({ type });
    } else {
      switch (field) {
        case 'tel':
        case 'email':
        case 'adr':
          if ('sim' === tag && 'tel' === field) {
            options['data-l10n-id'] = 'tel';
            break;
          }
          options['data-l10n-id'] = `${type}-${field}`;
          break;
        case 'bday':
          options['data-l10n-id'] = 'birthday';
          break;
        case 'org':
        case 'ringtone':
        case 'note':
        case 'givenName':
        case 'familyName':
        case 'name':
        case 'group':
          options['data-l10n-id'] = field;
          break;
        default:
          break;
      }
    }
    return options;
  },

  getPlaceholderConfig(field, type) {
    const options = {};
    if (type && this.isCustomTag(field, type)) {
      options['data-l10n-id'] = `custom-${field}`;
      options['data-l10n-args'] = JSON.stringify({ type });
    } else {
      switch (field) {
        case 'tel':
        case 'email':
        case 'adr':
          options.placeholder = window.api.l10n.get(`${type}-${field}`);
          break;
        case 'bday':
          options.placeholder = 'Birthday';
          break;
        case 'org':
        case 'ringtone':
        case 'note':
        case 'givenName':
        case 'familyName':
        case 'name':
        case 'group':
          options.placeholder = window.api.l10n.get(field);
          break;
        default:
          break;
      }
    }
    return options;
  },

  getDisplayName(contact, empty) {
    let _ = null;
    if (!window.api.l10n || window.api.l10n.readyState !== 'complete') {
      _ = e => {
        return e;
      };
    } else {
      _ = window.api.l10n.get;
    }
    let name = empty ? _('empty') : _('no-name');
    if (!contact) {
      return name;
    }

    if (this.hasName(contact)) {
      name = contact.name[0];
    } else if (this.hasContent(contact.tel)) {
      name = contact.tel[0].value;
    } else if (this.hasContent(contact.email)) {
      name = contact.email[0].value;
    }
    return name;
  },

  getSortItemName(contact) {
    const sortBy = window.localStorage.getItem('sort') || 'givenName';
    let name;
    if ('givenName' !== sortBy) {
      name = contact.familyName && contact.familyName[0];
    }
    if (navigator.language.indexOf('zh-') < 0 && this.isChinese(name)) {
      return null;
    }
    return name;
  },

  isChinese(str) {
    if (!str) {
      return true;
    }
    const reg = new RegExp('[\\u4E00-\\u9FA5\\uF900-\\uFA2D]+$', 'g');
    return reg.test(str);
  },

  startsWithUpper(str) {
    const firstLetter = str.charAt(0);
    const capFirstLetter = firstLetter.toLocaleUpperCase();

    return capFirstLetter === firstLetter;
  },

  checkEmailInstalled() {
    const manifestUrl = window.AppOrigin.getManifestURL('email');
    AppsManager.getApp(manifestUrl).then(
      app => {
        console.log(`get email app:${JSON.stringify(app)}`);
        utils.EMAIL_INSTALLED = true;
      },
      err => {
        console.log(`err:${JSON.stringify(err)}`);
      }
    );
  },

  parseName(nameString) {
    // Minimum length to consider a token as significative
    const MIN_LENGHT_SIGNIFICATIVE = 3;
    // Minimum length of a token to consider it a familyName
    const MIN_LENGHT_FN = 2;

    const out = {
      givenName: '',
      familyName: '',
    };

    if (!nameString) {
      return out;
    }
    const str = nameString.trim();
    if (!str) {
      return out;
    }

    // First step of the algorithm is to split the name in its tokens
    const tokens = nameString.split(/\s+/);
    const significativeTokens = {};
    for (let j = 0; j < tokens.length; j++) {
      const token = tokens[j];
      // A significative token os one with that min length and which starts with
      // uppercase letter
      if (
        token.length > MIN_LENGHT_SIGNIFICATIVE ||
        this.startsWithUpper(token)
      ) {
        significativeTokens[token] = true;
      }
    }

    const totalTokens = tokens.length;
    let lastToken = totalTokens - 1;
    let rolePrevToken;
    let remainingTokens = Object.keys(significativeTokens).length;
    const outGivenNames = [];
    const outFamilyNames = [];
    // We need to keep the totals in a different variable as a familyName
    // can be composed by more than one token
    let numFns = 0;

    while (lastToken >= 0) {
      if (significativeTokens[tokens[lastToken]]) {
        remainingTokens--;
      }

      const currToken = tokens[lastToken];
      const nextToken = tokens[lastToken + 1];
      const prevToken = tokens[lastToken - 1];

      // The last element is taken as part of the family name
      if (!nextToken && prevToken) {
        outFamilyNames.push(currToken);
        numFns++;
        rolePrevToken = 'FN';
      } else if (!prevToken) {
        outGivenNames.push(currToken);
        rolePrevToken = 'GN';
      } else if (nextToken) {
        if (!significativeTokens[currToken]) {
          if ('FN' === rolePrevToken) {
            // Here the number of fns is not incremented as this is a non
            // significative token
            outFamilyNames.push(currToken);
          } else {
            outGivenNames.push(currToken);
          }
        } else if (currToken.length < MIN_LENGHT_FN) {
          outGivenNames.push(currToken);
          rolePrevToken = 'GN';
        } else if (remainingTokens >= 2 && numFns < 2) {
          // Number of familyNames will be two at most
          // Preference is given to the givenName over familyName
          // We prefer two givenNames instead of two family Names
          outFamilyNames.push(currToken);
          numFns++;
          rolePrevToken = 'FN';
        } else {
          outGivenNames.push(currToken);
          rolePrevToken = 'GN';
        }
      }

      lastToken--;
    }

    out.givenName = outGivenNames
      .reverse()
      .join(' ')
      .trim();
    out.familyName = outFamilyNames
      .reverse()
      .join(' ')
      .trim();

    return out;
  },
  // format date with locale
  unifyDateString(dateObj) {
    if (dateObj && dateObj instanceof Date) {
      const locale = navigator.language;
      const options = { year: 'numeric', month: 'long', day: 'numeric' };
      return dateObj.toLocaleDateString(locale, options);
    }
    return '';
  },

  // build up group name by group array for contact view
  buildUpGroupName(groups) {
    if (!Array.isArray(groups)) {
      throw new Error('groups must be ARRAY');
    } else {
      return groups
        .map(group => ContactStore.getGroupNameByID(group))
        .join(', ');
    }
  },

  /**
   * Load photo image of the contact
   * Draw on the canvas element when loaded
   */
  drawPhoto(data, canvas, target, callback) {
    let bResize = false;
    let contact;
    let img;
    let type;
    if (!canvas) {
      canvas = document.createElement('canvas');
      bResize = true;
      type = data.type;
    } else {
      contact = data;
      img = contact._photoImage;
    }

    if ((contact && contact.photo && contact.photo.length) || bResize) {
      const _drawSquare = url => {
        const scalex = img.width / target;
        const scaley = img.height / target;
        const scale = Math.min(scalex, scaley);

        const l = target * scale;
        const x = (img.width - l) / 2;
        const y = (img.height - l) / 2;

        canvas.width = target;
        canvas.height = target;
        let context = canvas.getContext('2d', {
          willReadFrequently: true,
        });
        context.drawImage(img, x, y, l, l, 0, 0, target, target);
        if (url) {
          URL.revokeObjectURL(url);
        }
        if (callback) {
          img.src = '';
          img = null;
          canvas.toBlob(reSized => {
            context = null;
            canvas.width = 0;
            canvas.height = 0;
            canvas = null;
            callback(reSized);
          }, type || 'image/jpeg');
        }
      };

      if (!bResize) {
        for (let i = 0; i < window.cachedContacts.length; i++) {
          if (window.cachedContacts[i].id === contact.id) {
            contact._photoImage = window.cachedContacts[i]._photoImage;
            img = window.cachedContacts[i]._photoImage;
            window.cachedContacts.splice(i, 1);
            break;
          }
        }
      }

      if (img) {
        _drawSquare();
      } else {
        img = new Image();
        const url = URL.createObjectURL(bResize ? data : contact.photo[0]);

        img.src = url;
        img.onload = () => {
          _drawSquare(url);
        };
        img.onerror = () => {
          img.src = '';
          URL.revokeObjectURL(url);
        };
      }
    }
  },

  getType(type) {
    return 'cellular' === type || 'wifi' === type;
  },

  isOnLine() {
    const connection = navigator.connection;
    if (connection) {
      return this.getType(connection.type);
    }
    return navigator.onLine;
  },

  handleNetworkEvent(action) {
    const actionListener = `${action}EventListener`;
    if (navigator.connection) {
      window[actionListener]('network-changed', this.handleNetwork);
    } else {
      window[actionListener]('online', this.handleNetwork);
      window[actionListener]('offline', this.handleNetwork);
    }
  },
  generateUUID() {
    let d = new Date().getTime();
    if (window.performance && 'function' === typeof window.performance.now) {
      d += performance.now();
    }
    const uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(
      /[xy]/g,
      function(c) {
        const r = (d + Math.random() * 16) % 16 | 0;
        d = Math.floor(d / 16);
        return ('x' === c ? r : (r & 0x3) | 0x8).toString(16);
      }
    );
    return uuid;
  },
};

window.utils = utils;

export default utils;
