import BaseEmitter from 'base-emitter';
import Voicemail from './voicemail';
import SpeedDialModel from './speed_dial_model';
import Utils from './contact_utils';

class SpeedDialStore extends BaseEmitter {
  SIZE = 9;
  contacts = [];
  presetDialId = 'presetSpeedDial';

  start() {
    window.sds = this;
    this._initData();
    this._fetch();

    ContactsManager.addEventListener(
      ContactsManager.EventMap.CONTACT_CHANGE,
      this._onContactChanged
    );
    ContactsManager.addEventListener(
      ContactsManager.EventMap.SPEED_DIAL_CHANGE,
      this._onSpeedDialChange
    );
    SettingsObserver.getValue('custom.speeddials').then((values = []) => {
      values.forEach(value => {
        if (value) {
          const { key, name, tel } = value;
          this.contacts[key - 1] = {
            dial: key,
            tel,
            contact: {
              id: this.presetDialId,
              name: [name],
            },
          };
          this.emit('changed');
        }
      });
    });

    if (Utils.SUPPORT_VOICEMAIL) {
      Voicemail.on('changed', () => {
        this.contacts[0].tel = Voicemail.getValues().join('|');
        this.emit('changed');
      });
    }
  }

  _onSpeedDialChange = e => {
    const { dialKey } = e.speeddial;
    this.contacts[+dialKey - 1].sync().then(() => {
      this.emit('changed');
    });
  };

  getAll() {
    return this.contacts;
  }

  _initData() {
    let index = 0;
    this.contacts = [];
    if (Utils.SUPPORT_VOICEMAIL) {
      this.contacts[index++] = {
        dial: 1,
        tel: Voicemail.getValues().join('|'),
        voicemail: true,
        contact: {
          id: 'voicemail',
          name: ['voicemail'],
        },
      };
    }

    for (let i = index; i < this.SIZE; i++) {
      this.contacts.push(
        new SpeedDialModel({
          dial: i + 1,
        })
      );
    }
  }

  _fetch() {
    ContactsManager.getSpeedDials().then(configs => {
      console.log('[SpeedDialStore]: got speedDials:', configs);
      const promises = configs.map(config => {
        return this.contacts[+config.dialKey - 1].updateByRawData(config);
      });

      Promise.all(promises).then(() => {
        this.emit('changed');
      });
    });
  }

  _onContactChanged = e => {
    // sync contact data to speed dial model
    console.log('[SpeedDialStore]: contactchange:', e.reason);
    const contact = e.contacts[0];
    this.contacts.forEach(aSpeedDial => {
      if (aSpeedDial.contact && aSpeedDial.contact.id !== 'voicemail') {
        if (contact.id === aSpeedDial.contact.id || !contact.id) {
          // After spec changes, no matter UPDATE or DELETE contact, remove
          // the name of speedDial and keep the tel. it means contact would
          // not relate to the speedDial after set.
          this.set(aSpeedDial.dial, {
            contact: {
              id: '',
              tel: [{ value: aSpeedDial.originTel }],
            },
            telIndex: 0,
          });
        }
      }
    });
  };

  set(dial, { contact, telIndex }) {
    let isAdd;
    if (telIndex === undefined) {
      telIndex = this.contacts[dial - 1].telIndex;
    }
    if (!this.contacts[dial - 1].contact) {
      isAdd = true;
    }
    const req = ContactsManager.setSpeedDial(isAdd, {
      dialKey: dial,
      tel: contact.tel[telIndex].value,
      contactId: contact.id,
    });
    req.onerror = err => {
      console.warn('Failed to set speed dial', err);
    };
  }

  remove(dial) {
    const req = ContactsManager.removeSpeedDial(dial);
    req.onerror = err => {
      console.warn('Failed to remove speed dial', err);
    };
  }
}

const speedDialStore = new SpeedDialStore();
speedDialStore.start();

export default speedDialStore;
