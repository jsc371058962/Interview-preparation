/*
 * Module for communication of import status data between FTU and Comms Apps via
 * Datastore.
 *
 */

import BaseModule from 'base-module';

const DS_NAME = 'Import_Status_Data';
const LAST_IMPORT_TIMESTAMP_SUFFIX = '_last_import_timestamp';

class ImportStatusData extends BaseModule {
  name = 'ImportStatusData';
  DEBUG = false;

  start() {
    this.store = {};
    this.getDatastore();
  }

  getDatastore() {
    const store = localStorage.getItem(DS_NAME);
    if (store) {
      this.store = JSON.parse(store);
    }
  }

  setDatastore = () => {
    localStorage.setItem(DS_NAME, JSON.stringify(this.store));
  };

  put(key, obj) {
    return new Promise(resolve => {
      this.store[key] = obj;
      this.setDatastore();
      resolve();
    });
  }

  remove(key) {
    return new Promise(resolve => {
      delete this.store[key];
      this.setDatastore();
      resolve();
    });
  }

  get(key) {
    return new Promise(resolve => {
      resolve(this.store[key]);
    });
  }

  clear() {
    return new Promise(resolve => {
      this.store = {};
      this.setDatastore();
      resolve();
    });
  }

  setTimestamp(type) {
    this.debug('setTimestamp:', type);
    const time = Date.now();
    return this.put(type + LAST_IMPORT_TIMESTAMP_SUFFIX, time).then(() => {
      this.emit('importchanged', type, time);
    });
  }

  getTimestamp(type) {
    this.debug('getTimestamp:', type);
    return this.get(type + LAST_IMPORT_TIMESTAMP_SUFFIX);
  }
}

const importStatusData = new ImportStatusData();
importStatusData.start();

export default importStatusData;
