import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import SdcardManager from 'vendor/sdcard-manager';
import ContactStore from './contact_store';

export default class ExportView extends BaseComponent {
  FOCUS_SELECTOR = '.list-item.navigable';
  SUPPORT_BT = false;

  constructor(props) {
    super(props);
    this.state = {
      sd: null,
      bluetooth: null,
      sdIsAvailable: SdcardManager.checkStorageCard(),
    };
  }

  componentDidMount() {
    const config = {
      left: 'cancel',
      center: this.checkCenterVaule(),
    };
    window.ev = this;
    this.element = ReactDOM.findDOMNode(this);
    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element
    );
    this._softKey = SoftKeyManager.create(this.element, config);
    SettingsObserver.observe('bluetooth.enabled', '', this.observe_bluetooth);
    SdcardManager.on('statechanged', this.onSdStatusChange);
    this.SUPPORT_BT = !!navigator.b2g.bluetooth;
  }

  onSdStatusChange = () => {
    this.setState({
      sdIsAvailable: SdcardManager.checkStorageCard(),
    });
  };

  observe_bluetooth = value => {
    this.setState({
      bluetooth: value,
    });
  };

  checkCenterVaule() {
    const focusSection = document.activeElement.dataset.target;
    if (
      ('sdcard' === focusSection && SdcardManager.checkStorageCard()) ||
      ('bluetooth' === focusSection && this.state.bluetooth)
    ) {
      return 'select';
    }
  }

  updateSoftKeys() {
    const config = {
      left: 'cancel',
      center: this.checkCenterVaule(),
    };
    this._softKey.update(config);
  }

  componentWillUnmount() {
    this._softKey.destroy();
    SettingsObserver.unobserve('bluetooth.enabled', this.observe_bluetooth);
  }

  onFocus() {
    this.updateSoftKeys();
  }

  onKeyDown(evt) {
    switch (evt.key) {
      case 'Enter':
        if (document.activeElement.classList.contains('disabled')) {
          return;
        }
        Service.request('popup', '/pick/export').then(ids => {
          if (!ids || !ids[0]) {
            return;
          }
          ContactStore.export(ids[0], document.activeElement.dataset.target);
        });
        break;
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('back');
        break;
      case 'SoftLeft':
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('back');
        break;
      default:
        break;
    }
  }

  render() {
    const btDisabledClass = this.state.bluetooth ? '' : 'disabled';
    const sdDisabledClass = this.state.sdIsAvailable ? '' : 'disabled';
    let dom = '';
    if (this.SUPPORT_BT) {
      dom = (
        <div
          className={`list-item navigable ${btDisabledClass}`}
          tabIndex="-1"
          data-target="bluetooth"
          data-multi-line="true"
        >
          <div className="content">
            <div className="primary" data-l10n-id="bluetooth" />
            {btDisabledClass ? (
              <div className="secondary" data-l10n-id="bluetoothNoConnection" />
            ) : null}
          </div>
        </div>
      );
    }
    return (
      <div
        id="export-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onFocus={e => this.onFocus(e)}
      >
        <div className="header h1" data-l10n-id="export-contacts" />
        <div className="body">
          <div
            className={`list-item navigable ${sdDisabledClass}`}
            tabIndex="-1"
            data-target="sdcard"
            data-multi-line="true"
          >
            <div className="content">
              <div className="primary" data-l10n-id="sdcard" />
              {sdDisabledClass ? (
                <div className="secondary" data-l10n-id="noSdcardExport" />
              ) : null}
            </div>
          </div>
          {dom}
        </div>
      </div>
    );
  }
}
