import BaseModule from 'base-module';
import Service from 'service';
import { TAG_INDEX } from 'contact_store';
import clone from './utils';

export const FIELDS = function() {
  return Service.query('isLowMemoryDevice')
    ? ['givenName', 'familyName', 'name', 'tel']
    : [
        'photo',
        'givenName',
        'familyName',
        'name',
        'tel',
        'email',
        'org',
        'adr',
        'bday',
        'note',
        'ringtone',
        'group',
      ];
};

const Necessary_field_list = [
  'givenName',
  'familyName',
  'name',
  'tel',
  'email',
];

export const ADDRESS_SUBFIELDS = [
  'streetAddress',
  'locality',
  'region',
  'postalCode',
  'countryName',
];

// eas and google account contact support field, for edit.
export const ACTIVESYNC_FIELDS = [
  'givenName',
  'familyName',
  'name',
  'tel',
  'email',
  'org',
  'adr',
  'bday',
  'note',
];

export const GOOGLE_FIELDS = [
  'givenName',
  'familyName',
  'name',
  'tel',
  'email',
  'org',
  'adr',
  'bday',
  'note',
];
// To eliminate 'magic string'
export const ACTIVE_SYNC_TAG = 'EXCHANGE';

export const GOOGLE_TAG = 'GOOGLE';

export const CLOUD_TAG = 'ACCOUNT';

export const MAX_TEL_LENGTH = 20;

export const MAX_TEXT_LENGTH = 100;

/**
 * MozContact is used to instead of window.mozContact
 * that will padding the required field.
 * @param {Object} contact info.
 */
export class MozContact {
  published = new Date();

  updated = new Date();

  bday = new Date(0);

  anniversary = new Date();

  photoBlob = [];

  photoType = 'image/jpeg';

  category = [TAG_INDEX.kaiContact];

  constructor(data) {
    Object.entries(data).forEach(([field, value]) => {
      if (value) {
        this[field] = value;
      }
    });
    if (!this.category.includes(TAG_INDEX.kaiContact)) {
      this.category.concat(TAG_INDEX.kaiContact);
    }
  }
}

/**
 * Adapter the data structure from api daemon to local.
 * atype property need to be type, nameField need to be [string].
 * @param {Object} contact info.
 */
export const convertContactToLocal = contact => {
  const typeField = ['tel', 'email'];
  const nameField = ['givenName', 'familyName', 'name'];
  const CONVERTED_LABEL = '_converted_to_local';
  if (!contact || contact[CONVERTED_LABEL]) {
    return contact;
  }

  const obj = clone(contact);

  if (obj.addresses && obj.addresses.length) {
    obj.adr = obj.addresses.map(data => {
      const type = data.atype;
      delete data.atype;
      return { ...data, type: [type] };
    });
    obj.addresses = null;
  }

  nameField.forEach(field => {
    if (Array.isArray(obj[field])) {
      return;
    }
    if (obj[field] && 'string' === typeof obj[field]) {
      const value = obj[field];
      obj[field] = [value];
    }
  });

  typeField.forEach(field => {
    const dataArr = obj[field];
    if (dataArr && dataArr.length) {
      obj[field] = dataArr
        .filter(data => data.value)
        .map(data => {
          return {
            type: [data.atype],
            value: data.value,
          };
        });
    }
  });

  if (obj.photoBlob && obj.photoBlob.length) {
    obj.photo = [new Blob([obj.photoBlob], { type: obj.photoType })];
  }

  if (0 === new Date(obj.bday).getTime()) {
    delete obj.bday;
  } else {
    obj.bday = new Date(obj.bday);
  }

  if (obj.groups && obj.groups.length) {
    obj.group = obj.groups;
  }

  const kaiContact = TAG_INDEX.kaiContact;
  if (!obj.category) {
    obj.category = [kaiContact];
  } else {
    !obj.category.includes(kaiContact) && obj.category.push(kaiContact);
  }

  obj[CONVERTED_LABEL] = true;
  return obj;
};

/**
 * Adapter the data structure from local to api daemon.
 * type property need to be atype, nameField need to be string.
 * @param {Object} contact info.
 */
export const convertContactToRemote = contact => {
  return new Promise(resolve => {
    const typeField = ['tel', 'email', 'adr'];
    const nameField = ['givenName', 'familyName', 'name'];
    const CONVERTED_LABEL = '_converted_to_remote';

    if (!contact || contact[CONVERTED_LABEL]) {
      return resolve(contact);
    }
    contact[CONVERTED_LABEL] = true;

    const obj = clone(contact);

    typeField.forEach(field => {
      const dataArr = obj[field];
      if (dataArr && dataArr.length) {
        dataArr.map(data => {
          data.atype = data.type && data.type[0];
          delete data.type;
          return data;
        });
        obj[field] = dataArr;
      }
    });

    nameField.forEach(field => {
      if (obj[field] && obj[field].length) {
        obj[field] = obj[field][0];
      }
    });

    if (obj.group && obj.group.length) {
      obj.groups = obj.group;
    }

    if (obj.adr && obj.adr.length) {
      obj.addresses = obj.adr;
      obj.adr = null;
    }

    // default remove photoBlob, maybe the photo is null.
    obj.photoBlob = [];

    if (obj.photo && obj.photo.length) {
      return obj.photo[0].arrayBuffer().then(buffer => {
        obj.photoBlob = new Uint8Array(buffer);
        return resolve(new MozContact(obj));
      });
    }

    return resolve(new MozContact(obj));
  });
};

/**
 * Adapter the data structure from local to sim card.
 * sim contact only need name and number(tel).
 * @param {Object} contact info.
 */
export const convertContactToSim = (contact, isDelete) => {
  const obj = { id: '', name: '', number: '', email: '' };
  obj.id = contact.id;
  if (isDelete) {
    return new IccContact(obj.id, '', '', '');
  }
  if (contact.name && contact.name.length) {
    obj.name = contact.name[0];
  }
  if (contact.tel && contact.tel.length) {
    obj.number = contact.tel[0].value;
  }
  if (contact.email && contact.email.length) {
    obj.email = contact.email[0].value;
  }
  return new IccContact(obj.id, obj.name, obj.number, obj.email);
};

const generateKey = function() {
  return Math.random()
    .toString(36)
    .substr(2, 9);
};

/**
 * The purpose of wrapped contact is to normalize
 * any mozContact object into a serialized object and
 * make it being communicated between panels.
 */
export default class ContactWrapper extends BaseModule {
  name = 'ContactWrapper';
  DEBUG = false;

  constructor(mozContactData, embedData) {
    super();
    this.FIELDS = FIELDS();
    if (mozContactData) {
      this.contact = mozContactData;
      this.id = mozContactData.id;
      if (mozContactData.category.includes(ACTIVE_SYNC_TAG)) {
        this.FIELDS = ACTIVESYNC_FIELDS;
      }
      if (mozContactData.category.includes(GOOGLE_TAG)) {
        this.FIELDS = GOOGLE_FIELDS;
      }
    } else {
      this.id = 'new';
      this.contact = {};
    }
    this.normalize();
    if (embedData) {
      this.FIELDS.forEach(key => {
        const content = this.dataMap.get(key);
        let value = embedData[key];
        if (value) {
          let type;
          let index = 0;
          if (!this.contact[key] || 'new' === this.id) {
            content.splice(0, 1);
          }

          switch (key) {
            case 'tel':
              index = content.length;
              type = 'mobile';
              value = embedData[key].slice(0, MAX_TEL_LENGTH);
              break;
            case 'email':
              index = content.length;
              type = 'personal';
              break;
            case 'photo':
              value = embedData[key].length ? embedData[key][0] : null;
              break;
            case 'adr':
              type = 'home';
              const hasValue = ADDRESS_SUBFIELDS.some(field => {
                return !!value[field];
              });
              if (!hasValue) {
                value = null;
              }
              break;
            case 'ringtone':
              value = null;
              break;
            default:
              break;
          }

          if (value) {
            content.push({
              field: key,
              index,
              type,
              value,
              key: generateKey(),
            });
          }
        }
      });
    }
  }

  getFieldsToChoose() {
    const availableFields = [];
    this.dataMap.forEach((array, field) => {
      if (
        'givenName' === field ||
        'familyName' === field ||
        'name' === field ||
        'group' === field
      ) {
        return;
      }
      if (
        array.length &&
        ('bday' === field ||
          'ringtone' === field ||
          'photo' === field ||
          'note' === field)
      ) {
        return;
      }
      availableFields.push(field);
    });
    return availableFields;
  }

  update(contact) {
    this.contact = contact;
    this.normalize();
    this.emit('changed');
  }

  normalize() {
    this.dataMap = new Map();
    this.FIELDS.forEach(field => {
      this.dataMap.set(field, []);
    });
    this.dataMap.forEach((data, field) => {
      let contents = this.contact[field];
      if (!Array.isArray(contents)) {
        contents = [contents];
      }
      contents.forEach((content, index) => {
        if (!content) {
          return;
        }
        let value = '';
        let type =
          content.type && content.type.length ? content.type[0] : 'other';
        switch (field) {
          case 'givenName':
          case 'familyName':
          case 'photo':
          case 'note':
          case 'org':
          case 'name':
          case 'ringtone':
            value = content;
            break;
          case 'adr':
            value = {};
            ADDRESS_SUBFIELDS.forEach(key => {
              value[key] = content[key];
            });
            break;
          case 'bday':
            value = content.toISOString().split('T')[0];
            break;
          case 'tel':
          case 'email':
            value = content.value;
            break;
          default:
            return;
        }
        if (['tel', 'email', 'adr'].indexOf(field) < 0) {
          type = undefined;
        }
        data.push({
          field,
          type,
          index,
          value,
          key: generateKey(),
        });
      });
    });
    this.dataMap.forEach((array, field) => {
      if (0 === array.length && Necessary_field_list.indexOf(field) >= 0) {
        const defaultConfig = {
          field,
          index: 0,
          value: '',
          key: generateKey(),
        };
        if ('tel' === field) {
          defaultConfig.type = 'mobile';
        } else if ('email' === field) {
          defaultConfig.type = 'personal';
        }
        array.push(defaultConfig);
      }
    });
  }

  addField(field, type, index) {
    this.debug('addField: field, type, index:', field, type, index);
    const fieldArray = this.dataMap.get(field);
    if (!fieldArray[index]) {
      const config = {
        field,
        index: fieldArray.length,
        key: generateKey(),
      };
      if (type) {
        config.type = type;
      }
      if ('adr' === field) {
        const value = {};
        ADDRESS_SUBFIELDS.forEach(key => {
          value[key] = '';
        });
        config.value = value;
      }
      fieldArray.push(config);
    } else if (type) {
      fieldArray[index].type = type;
    }
    this.emit('fieldchanged', 'add', field);
  }

  removeField(field, index) {
    this.debug('removeField: field, index:', field, index);
    const fieldArray = this.dataMap.get(field);
    fieldArray.splice(index, 1);
    fieldArray.forEach((item, i) => {
      item.index = i;
    });
    this.emit('fieldchanged', 'remove', field);
  }
}

window.ContactWrapper = ContactWrapper;
