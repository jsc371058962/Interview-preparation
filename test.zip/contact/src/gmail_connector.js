import BaseModule from 'base-module';
import { TAG_INDEX } from 'contact_store';
import Rest from './rest';
/*
  Gmail Contacts connector

  Provides the capabilities to connect to the Gmail Contacts service
  and return the contacts on a readable and importable format.
*/

// Google contacts service end point,
// force a huge number of contacts to not paginate :S
const END_POINT =
  'https://www.google.com/m8/feeds/contacts/default/full/?max-results=10000';
const GROUPS_END_POINT = 'https://www.google.com/m8/feeds/groups/default/full/';
const EXTRA_HEADERS = {
  'GData-Version': '3.0',
};
const GD_NAMESPACE = 'http://schemas.google.com/g/2005';

const CATEGORY = 'DEVICE';
const URN_IDENTIFIER = 'urn:service:gmail:uid:';

class GmailConnector extends BaseModule {
  name = 'GmailConnector';

  constructor() {
    super();
    // Will be used as a cache for the thumbnail url for each contact
    this.photoUrls = {};
    // In some cases we will need the access token, cache a copy
    this.accessToken = null;
  }

  // We have a xml response from Google, all the entries in an array,
  // no matter if they are xml entries.
  // Despite of being a node, inject a 'uid' as this will be necessary
  // for the selection
  nodeListToArray(response) {
    const entries = response.getElementsByTagName('entry');
    const contacts = [];
    const numContacts = entries.length;
    for (let i = 0; i < numContacts; i++) {
      contacts.push(this.gContactToJson(entries[i]));
    }

    return contacts;
  }

  // Returns the object used to build the headers necesary by the service
  buildRequestHeaders(access_token) {
    const requestHeaders = EXTRA_HEADERS;
    requestHeaders.Authorization = `OAuth ${access_token}`;

    return requestHeaders;
  }

  // Gets a list of all contacts giving a valid access token
  listAllContacts(access_token, callbacks) {
    // Copy the access_token
    this.accessToken = access_token;
    this.photoUrls = {};
    this.getContactsGroup(access_token, callbacks);
  }

  getContactsGroup(access_token, callbacks) {
    const groupCallbacks = {
      success: response => {
        // Locate the entry witch systemGroup id is 'Contacts'
        const feed = response.querySelector('feed');
        if (null === feed) {
          callbacks.error();
          return;
        }

        const sgc = feed.querySelector('systemGroup[id="Contacts"]');
        if (sgc !== null) {
          const id = sgc.parentNode.querySelector('id').textContent;
          this.getContactsByGroup(id, access_token, callbacks);
        } else {
          callbacks.error();
        }
      },
      error: e => {
        if (e && 401 === e.status) {
          // This is a token expired / invalid token problem
          window.console.warn(
            'GMail Access token expired or invalid. ',
            'restarting flow!'
          );
          callbacks.success({
            error: {
              code: 190,
            },
          });
        } else {
          callbacks.error();
        }
      },
      timeout: callbacks.timeout,
    };

    return this.performAPIRequest(
      GROUPS_END_POINT,
      groupCallbacks,
      access_token
    );
  }

  // Retrieve all the contacts for the specific groupId
  getContactsByGroup(groupId, access_token, callbacks) {
    const listingCallbacks = {
      success: response => {
        callbacks.success({
          data: this.nodeListToArray(response),
        });
      },
      error: callbacks.error,
      timeout: callbacks.timeout,
    };

    const groupUrl = `${END_POINT}&group=${groupId}`;
    return this.performAPIRequest(groupUrl, listingCallbacks, access_token);
  }

  // Given a Google contacts api url add the authentication and
  // extra headers to perform the correct request
  performAPIRequest(url, callbacks, access_token) {
    return Rest.get(url, callbacks, {
      requestHeaders: this.buildRequestHeaders(access_token),
      responseType: 'xml',
    });
  }

  // Return the list of contacts on the device imported using this connector
  listDeviceContacts() {
    return new Promise(resolve => {
      const filterOptions = {
        filterValue: CATEGORY,
        filterOp: 'contains',
        filterBy: ['category'],
      };

      const req = ContactsManager.find(filterOptions);
      req.onsuccess = () => {
        resolve(req.result);
      };
      req.onerror = () => {
        resolve([]);
      };
    });
  }

  cleanContacts() {
    // var cleaner = new window.ContactsCleaner(contactsList);
    // XXX: es6 ContactsCleaner
  }

  getValueForNode(doc, name, def) {
    const defaultValue = def || '';

    if (null === doc || null === name) {
      return defaultValue;
    }

    const node = doc.querySelector(name);

    if (node && node.textContent) {
      return node.textContent;
    }

    return defaultValue;
  }

  /*
    Given an xml contact entry from gmail contacts we will need to output
    a json object that contains the minimun viable information to display
    that contact into a list.

    The fields for that minimun visualization object are:
    uid
    givenName
    familyName
    email1
  */
  adaptDataForShowing(contact) {
    const output = {
      uid: '-1',
      givenName: '',
      familyName: '',
      email1: '',
      contactPictureUri: '',
    };

    output.uid = contact.uid;

    if (contact.familyName) {
      output.familyName = contact.familyName;
    }

    if (contact.email && contact.email.length > 0) {
      output.email1 = contact.email[0].value;
    }
    let tel;
    if (contact.tel && contact.tel.length > 0) {
      tel = contact.tel[0].value;
    }
    output.givenName =
      contact.givenName || tel || output.email1 || contact.org || '';

    const photoUrl = this.buildContactPhotoURL(contact);
    if (photoUrl) {
      output.contactPictureUri = photoUrl;
    }

    return output;
  }

  adaptDataForSaving(contact) {
    contact.category = [TAG_INDEX.kaiContact, TAG_INDEX.phone];
    return contact;
  }

  // Transform a Google contact entry into json format.
  // The json format is the same used in Contacts api ;P
  gContactToJson(googleContact) {
    const output = {};

    // This field will be needed for indexing within the
    // import process, not for the api
    output.uid = this.getUid(googleContact);

    output.name = [this.getValueForNode(googleContact, 'title')];

    // Store the photo url, not in the contact itself
    let photoUrl = googleContact.querySelector('link[type="image/*"]');
    if (photoUrl) {
      photoUrl = photoUrl.getAttribute('href');
    } else {
      // No image link
      photoUrl = '';
    }
    this.photoUrls[output.uid] = photoUrl;

    const name = googleContact.querySelector('name');
    if (name) {
      const contactName = this.getValueForNode(name, 'givenName');
      if (contactName) {
        output.givenName = [contactName];
      }
      const contactFamilyName = this.getValueForNode(name, 'familyName');
      if (contactFamilyName) {
        output.familyName = [contactFamilyName];
      }
      const contactSuffix = this.getValueForNode(name, 'additionalName');
      if (contactSuffix) {
        output.additionalName = [contactSuffix];
      }
    }

    output.email = this.parseEmails(googleContact);

    output.adr = this.parseAddress(googleContact);

    output.tel = this.parsePhones(googleContact);

    const org = googleContact.querySelector('organization');
    if (org) {
      output.org = [this.getValueForNode(org, 'orgName')];
      output.jobTitle = [this.getValueForNode(org, 'orgTitle')];
    }

    const bday = googleContact.querySelector('birthday');
    if (bday) {
      const bdayMS = Date.parse(bday.getAttribute('when'));
      if (!isNaN(bdayMS)) {
        output.bday = new Date(bdayMS);
      }
    }

    const content = googleContact.querySelector('content');
    if (content) {
      output.note = [content.textContent];
    }

    output.category = [CATEGORY];
    output.url = [
      {
        type: ['source'],
        value: this.getContactURI(output),
      },
    ];

    return output;
  }

  getContactURI(contact) {
    return URN_IDENTIFIER + contact.uid;
  }

  // This will be a full url like:
  // http://www.google.com/m8/feeds/contacts/<email>/base/<contact_id>
  // for a specific contact node
  getUid(contact) {
    return contact.querySelector('id').textContent;
  }

  // Returns an array with the possible emails found in a contact
  // as a ContactField format
  parseEmails(googleContact) {
    const DEFAULT_EMAIL_TYPE = 'other';
    const emails = [];
    const fields = googleContact.getElementsByTagNameNS(GD_NAMESPACE, 'email');
    if (fields && fields.length > 0) {
      for (let i = 0; i < fields.length; i++) {
        const emailField = fields.item(i);

        // Type format: rel="http://schemas.google.com/g/2005#home"
        let type = emailField.getAttribute('rel') || DEFAULT_EMAIL_TYPE;
        if (type.indexOf('#') > -1) {
          type = type.substr(type.indexOf('#') + 1);
        }

        emails.push({
          type: [type],
          value: emailField.getAttribute('address'),
        });
      }
    }

    return emails;
  }

  // Given a google contact returns an array of ContactAddress
  parseAddress(googleContact) {
    const addresses = [];
    const DEFAULT_ADR_TYPE = 'home';
    const fields = googleContact.getElementsByTagNameNS(
      GD_NAMESPACE,
      'structuredPostalAddress'
    );
    if (fields && fields.length > 0) {
      for (let i = 0; i < fields.length; i++) {
        const field = fields.item(i);
        const address = {};

        address.streetAddress = this.getValueForNode(field, 'street');
        address.locality = this.getValueForNode(field, 'city');
        address.region = this.getValueForNode(field, 'region');
        address.postalCode = this.getValueForNode(field, 'postcode');
        address.countryName = this.getValueForNode(field, 'country');
        address.type = [DEFAULT_ADR_TYPE];

        addresses.push(address);
      }
    }
    return addresses;
  }

  // Given a google contact this function returns an array of
  // ContactField with the pones stored for that contact
  parsePhones(googleContact) {
    const DEFAULT_PHONE_TYPE = 'other';
    const GMAIL_MAP = {
      work_fax: 'faxOffice',
      home_fax: 'faxHome',
      pager: 'other',
      main: 'other',
    };
    const phones = [];
    const fields = googleContact.getElementsByTagNameNS(
      GD_NAMESPACE,
      'phoneNumber'
    );
    if (fields && fields.length > 0) {
      for (let i = 0; i < fields.length; i++) {
        const field = fields.item(i);

        // Type format: rel="http://schemas.google.com/g/2005#home"
        let type = field.getAttribute('rel') || DEFAULT_PHONE_TYPE;
        if (type.indexOf('#') > -1) {
          type = type.substr(type.indexOf('#') + 1);
        }

        phones.push({
          type: [GMAIL_MAP[type] || type],
          value: field.textContent,
        });
      }
    }

    return phones;
  }

  // Given a contact from the mozcontact api, fetch the Google Contacts
  // identifier
  getContactUid(deviceContact) {
    let out = -1;

    const url = deviceContact.url;
    if (Array.isArray(url)) {
      const targetUrls = url.filter(aUrl => {
        return (
          Array.isArray(aUrl.type) &&
          aUrl.type.indexOf('source') !== -1 &&
          aUrl.value
        );
      });

      if (targetUrls[0]) {
        out = this.resolveURI(targetUrls[0].value);
      }
    }

    return out;
  }

  // From a contact URL, that we expect to be a URI
  // return the google contact id if we find it on
  // the uri, -1 otherwise
  resolveURI(uri) {
    if (uri && 0 === uri.indexOf(URN_IDENTIFIER)) {
      const output = uri.substr(URN_IDENTIFIER.length);
      if (output && output.length > 0) {
        return output;
      }
    }

    return -1;
  }

  downloadContactPicture(googleContact, callbacks) {
    const url = this.buildContactPhotoURL(googleContact);
    return Rest.get(url, callbacks, {
      responseType: 'blob',
    });
  }

  // Build the url of the photo with the access token
  buildContactPhotoURL(contact) {
    if (this.photoUrls && this.photoUrls[contact.uid]) {
      return `${this.photoUrls[contact.uid]}?access_token=${this.accessToken}`;
    }

    return null;
  }

  startSync() {
    // We don't sync Google contacts (yet)
  }

  getServiceName() {
    return 'gmail';
  }

  getAutomaticLogout() {
    return true;
  }
}

const gmailConnector = new GmailConnector();

export default gmailConnector;
