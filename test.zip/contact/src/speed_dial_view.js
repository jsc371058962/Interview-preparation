import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import SpeedDialStore from './speed_dial_store';
import SpeedDialListItem from './speed_dial_list_item';
import ContactStore from './contact_store';
import Utils from './contact_utils';
import '../scss/list.scss';

export default class SpeedDialView extends BaseComponent {
  name = 'SpeedDialView';
  DEBUG = false;
  FOCUS_SELECTOR = '.list-item';

  constructor(props) {
    super(props);
    this.state = {
      contacts: SpeedDialStore.getAll(),
    };

    this.onFocus = this.onFocus.bind(this);
  }

  componentDidMount() {
    this.debug('did mount');
    const config = this.getConfig();
    this.element = ReactDOM.findDOMNode(this);

    this.onChanged = () => {
      this.debug('SpeedDialStore onChanged');
      this.setState({
        contacts: SpeedDialStore.getAll(),
      });
    };
    SpeedDialStore.on('changed', this.onChanged);

    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element
    );
    this._softKey = SoftKeyManager.create(this.element, config);
  }

  componentWillUnmount() {
    SpeedDialStore.off('changed', this.onChanged);
    this._softKey.destroy();
  }

  getConfig() {
    const dataset = document.activeElement.dataset;
    const config = {};
    if ('true' === dataset.voicemail) {
      config.right = 'edit';
    } else if (!dataset.tel) {
      if (!ContactStore.isEmpty()) {
        config.center = 'assign';
      }
    } else {
      config.right = 'options';
      config.center = '';
    }
    if (SpeedDialStore.presetDialId === dataset.id) {
      config.right = '';
    }
    return config;
  }

  updateSoftKeys() {
    this._softKey.update(this.getConfig());
  }

  componentDidUpdate() {
    this.debug('did update');
    this.updateSoftKeys();
  }

  onKeyDown(evt) {
    const _ = window.api.l10n.get;
    const dataset = document.activeElement.dataset;
    switch (evt.key) {
      case 'Call':
        const { id, tel } = dataset;
        'voicemail' === id ? Utils.dial(tel.split('|')) : Utils.dial(tel);
        break;
      case 'SoftRight':
        if (!this._softKey.getSoftKeyValue('right')) {
          break;
        }
        if (SpeedDialStore.presetDialId === dataset.id) {
          break;
        }
        if ('true' === dataset.voicemail) {
          Service.request('push', '/voicemail');
          break;
        }

        if (dataset.tel) {
          Service.request('showOptionMenu', {
            options: [
              {
                id: 'replace',
                callback: () => {
                  const req = new WebActivity('pick', {
                    type: 'webcontacts/tel',
                    params: { typeOfContact: 'device' },
                  });

                  req.start().then(result => {
                    if (!result.id) {
                      return;
                    }
                    const res = {
                      contact: result,
                      telIndex: 0,
                    };
                    Service.request('showDialog', {
                      header: _('confirm'),
                      content: _('custom-dialog-replace-speed-dial', {
                        oldSpeedDial: dataset.name,
                        newSpeedDial: Utils.getDisplayName(res.contact),
                      }),
                      ok: 'replace',
                      type: 'confirm',
                      translated: true,
                      onOk: () => {
                        SpeedDialStore.set(+dataset.dial, res);
                        Service.request('ToastManager:show', {
                          text: window.api.l10n.get('speed-dial-replaced'),
                        });
                      },
                    });
                  });
                },
              },
              {
                id: 'remove-from-speed-dial',
                callback: () => {
                  Service.request('showDialog', {
                    header: _('confirm'),
                    content: _('custom-dialog-remove-speed-dial', {
                      name: dataset.name,
                    }),
                    ok: 'remove',
                    type: 'confirm',
                    translated: true,
                    onOk: () => {
                      SpeedDialStore.remove(+dataset.dial);
                      Service.request('ToastManager:show', {
                        text: window.api.l10n.get('speed-dial-removed'),
                      });
                    },
                  });
                },
              },
            ],
          });
        }
        break;
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        Utils.backOrClose();
        break;
      case 'Enter':
        if (!this._softKey.getSoftKeyValue('center')) {
          break;
        }
        if (!dataset.tel) {
          const req = new WebActivity('pick', {
            type: 'webcontacts/tel',
            params: { typeOfContact: 'device' },
          });

          req.start().then(result => {
            if (!result.id) {
              return;
            }
            const res = {
              contact: result,
              telIndex: 0,
            };
            SpeedDialStore.set(+dataset.dial, res);
            Service.request('ToastManager:show', {
              text: window.api.l10n.get('speed-dial-added'),
            });
          });
        }
        break;
      default:
        break;
    }
  }

  onFocus() {
    this.debug('onFocus:');
    this.updateSoftKeys();
    // to ensure `replace` confirmation dialog focused
    Service.request('ensureDialog');
  }

  render() {
    const dom = this.state.contacts.map(item => (
      <SpeedDialListItem speeddial={item} key={`speed-dial-${item.dial}`} />
    ));
    return (
      <div
        id="speed-dial-list-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onFocus={this.onFocus}
      >
        <div className="header h1" data-l10n-id="speed-dial" />
        <div className="body">{dom}</div>
      </div>
    );
  }
}
