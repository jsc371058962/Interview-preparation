import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import ContactList from 'components/contact_list';
import ICEStore from './ice_store';
import ContactStore from './contact_store';

export default class ICEList extends BaseComponent {
  name = 'ICEList';
  DEBUG = false;
  FOCUS_SELECTOR = '.list-item';

  constructor(props) {
    super(props);
    this.state = {
      contacts: ICEStore.getAll(),
    };
  }

  componentDidMount() {
    this.debug('did mount');
    const config = {
      center: 'select',
      right: 'options',
    };
    this.element = ReactDOM.findDOMNode(this);
    this._softKey = SoftKeyManager.create(this.element, config);

    this.onIceChanged = () => {
      this.setState({
        contacts: ICEStore.getAll(),
      });
    };
    ICEStore.on('changed', this.onIceChanged);

    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element
    );
  }

  componentWillUnmount() {
    this._softKey.destroy();
    ICEStore.off('changed', this.onIceChanged);
  }

  onFocus() {
    if (ICEStore.isEmpty()) {
      Service.request('back');
    } else {
      Service.request('ensureDialog');
    }
  }

  onKeyDown(evt) {
    Service.request('onContactKeyDown', evt);
  }

  render() {
    const contacts = this.state.contacts
      .map(item => {
        return ContactStore.contactMap.get(item.id);
      })
      .filter(item => item);

    return (
      <div
        id="ice-contact-list-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onFocus={e => this.onFocus(e)}
      >
        <div className="header h1" data-l10n-id="ICEContactsGroup" />
        <div className="body">
          <ContactList contacts={contacts} />
        </div>
      </div>
    );
  }
}
