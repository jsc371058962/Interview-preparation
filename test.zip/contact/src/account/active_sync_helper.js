import { ACTIVE_SYNC_TAG, CLOUD_TAG } from 'contact_wrapper';
import { TAG_INDEX } from '../contact_store';

/**
 * Transform mozContact to exchange contact object.
 * Skip `photo` for now.
 * This is a synchronous operation.
 * Exchange person object schema:
 /* {
    "HomeAddressStreet": "zhuequestreet,south.1st",
    "BusinessAddressPostalCode": "710000",
    "JobTitle": "fe",
    "FileAs": "haoqing, mao",
    "BusinessPhoneNumber": "111",
    "LastName": "haoqing",
    "BusinessAddressState": "shaanxi",
    "Birthday": "2013-03-07T11:59:00.000Z",
    "Department": "rd",
    "BusinessAddressCountry": "china",
    "FirstName": "mao",
    "HomeAddressState": "shaanxi",
    "HomeAddressCountry": "china",
    "MobilePhoneNumber": "333",
    "Email1Address": "\"kai\" <haoqing.mao@kaitostech.com>",
    "BusinessAddressCity": "xian",
    "ManagerName": "manager",
    "HomeAddressPostalCode": "71000",
    "HomePhoneNumber": "222",
    "NativeBodyType": "1",
    "HomeAddressCity": "xian",
    "CompanyName": "kaios",
    "AssistantName": "assistant",
    "OfficeLocation": "xian",
    "BusinessAddressStreet": "jinyest"
/* }
 * @param {object} contact - a mozContact object
 * @return {object}
 */
export function mozContactToExchangeContact(contact) {
  const { givenName, familyName, tel, email, adr, bday, note, org } = contact;

  const person = {};

  if (givenName && givenName[0]) {
    person.FirstName = givenName[0];
  }
  if (familyName && familyName[0]) {
    person.LastName = familyName[0];
  }

  if (tel) {
    encodeTels(tel, person);
  }

  if (email) {
    email.map((v, index) => {
      // Only support 3 mail address at most
      if (index < 3) {
        person[`Email${index + 1}Address`] = v.value;
      }
    });
  }

  if (org) {
    person.CompanyName = org[0];
  }

  if (note) {
    person.Body = note[0];
  }

  if (adr) {
    adr.map(v => {
      const type = v.type && v.type[0] ? v.type[0] : 'other';
      const dict = {
        home: 'HomeAddress',
        work: 'BusinessAddress',
        other: 'OtherAddress',
      };
      const prefix = dict[type];
      Object.assign(person, {
        [`${prefix}Street`]: v.streetAddress,
        [`${prefix}State`]: v.region,
        [`${prefix}Country`]: v.countryName,
        [`${prefix}PostalCode`]: v.postalCode,
        [`${prefix}City`]: v.locality,
      });
    });
  }

  if (bday) {
    person.Birthday = bday.toISOString();
  }

  return person;
}

/**
 * Transform exchange people object to mozContact.
 * Skip `photos` for now.
 * This is a synchronous operation.
 * @param {object} person - a exchange person object
 * @param {object} accountId - a string containing the account name
 * @return {object} - a mozContact object
 */
export function exchangeContactToMozContact(person, accountId) {
  console.log('[exchange_helper] (_personToMozContact) to transform:', person);

  const { FirstName, LastName, CompanyName, Body, Birthday } = person;

  const aContact = {};
  const originAdrArr = [
    {
      name: 'BusinessAddress',
      value: {},
    },
    {
      name: 'HomeAddress',
      value: {},
    },
    {
      name: 'OtherAddress',
      value: {},
    },
  ];

  // transform field data
  Object.assign(aContact, {
    name: [`${FirstName || ''} ${LastName || ''}`.trim()],
    givenName: [FirstName || ''],
    familyName: [LastName || ''],
  });

  if (CompanyName) {
    aContact.org = [CompanyName];
  }

  if (Birthday && Date.parse(Birthday)) {
    aContact.bday = new Date(Birthday);
  }

  // transform address phone fax email
  aContact.email = [];
  aContact.tel = [];
  aContact.adr = [];

  for (const item in person) {
    if (item.includes('Email')) {
      let emailAddress = person[item];
      if (emailAddress) {
        const emailMatch = emailAddress.match(/<(\w*\W*\s*\S*)*>/);
        if (emailMatch) {
          emailAddress = emailMatch[1];
        }
        aContact.email.push({
          value: emailAddress,
          type: ['personal'],
        });
      }
    }

    if (item.includes('Number')) {
      decodeTels(item, person[item], aContact.tel);
    }

    originAdrArr.some((data, index) => {
      if (item.includes(data.name)) {
        originAdrArr[index].value[decodeAdrItem(item.replace(data.name, ''))] =
          person[item];
        return true;
      }
    });
  }

  // EAS note contains in response body
  if (Body) {
    aContact.note = [Body];
  }

  aContact.adr = originAdrArr
    .filter(adr => {
      let hasItem = false;
      for (const i in adr.value) {
        // eslint-disable-next-line no-prototype-builtins
        if (adr.value.hasOwnProperty(i)) {
          hasItem = true;
          break;
        }
      }
      return hasItem;
    })
    .map(item =>
      Object.assign(item.value, {
        type: [decodeAdrType(item.name)],
      })
    );

  // the `DEVICE` category indicates an account contact is saving to device(not SIM).
  // this will trigger contacts limit checking in contact_store.
  aContact.category = [
    CLOUD_TAG,
    accountId,
    ACTIVE_SYNC_TAG,
    TAG_INDEX.phone,
    TAG_INDEX.kaiContact,
  ];
  const contact = Object.assign({}, aContact);
  console.log(
    '[exchange_helper] (_personToMozContact) transformed result:',
    contact
  );
  return contact;
}

function encodeTels(tels = [], exchangeContact) {
  tels.map(item => {
    const type = item.type[0];
    switch (type) {
      case 'home':
        if (!exchangeContact.HomePhoneNumber) {
          exchangeContact.HomePhoneNumber = item.value;
        } else if (!exchangeContact.Home2PhoneNumber) {
          exchangeContact.Home2PhoneNumber = item.value;
        }
        break;
      case 'mobile':
        exchangeContact.MobilePhoneNumber = item.value;
        break;
      case 'work':
        if (!exchangeContact.BusinessPhoneNumber) {
          exchangeContact.BusinessPhoneNumber = item.value;
        } else if (!exchangeContact.Business2PhoneNumber) {
          exchangeContact.Business2PhoneNumber = item.value;
        }
        break;
      case 'personal':
        exchangeContact.OtherPhoneNumber = item.value;
        break;
      case 'fax-home':
        exchangeContact.HomeFaxNumber = item.value;
        break;
      case 'fax-office':
        exchangeContact.BusinessFaxNumber = item.value;
        break;
      case 'fax-other':
        exchangeContact.OtherFaxNumber = item.value;
        break;
      default:
        break;
    }
  });
}

function decodeTels(name, value, tels = []) {
  const dict = {
    HomePhoneNumber: 'home',
    Home2PhoneNumber: 'home',
    MobilePhoneNumber: 'mobile',
    BusinessPhoneNumber: 'work',
    Business2PhoneNumber: 'work',
    OtherPhoneNumber: 'personal',
    HomeFaxNumber: 'fax-home',
    BusinessFaxNumber: 'fax-office',
    OtherFaxNumber: 'fax-other',
  };
  tels.push({
    value,
    type: [dict[name] || 'mobile'],
  });
}

function decodeAdrItem(name) {
  const valueDict = {
    City: 'locality',
    Country: 'countryName',
    PostalCode: 'postalCode',
    State: 'region',
    Street: 'streetAddress',
  };
  return valueDict[name];
}

function decodeAdrType(name) {
  const valueDict = {
    OtherAddress: 'current',
    HomeAddress: 'home',
    BusinessAddress: 'work',
  };
  return valueDict[name];
}
