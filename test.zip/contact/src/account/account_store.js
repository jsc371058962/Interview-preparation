import BaseModule from 'base-module';

/**
 * Responsible for application level account CRUD
 */
class AccountStore extends BaseModule {
  // map accountId to account instance
  _accountMap = {};

  _showSwitchMap = {};

  // resolved with `this` instance after `init` done
  whenReady = new Promise(resolve => {
    this._resolve = resolve;
  });

  /**
   * Store account instances created by `AccountManager`.
   * @param {array} accounts -
   */
  init = accounts => {
    accounts.forEach(account => {
      this._accountMap[account.accountId] = account;
      this._showSwitchMap[account.accountId] = account.store
        ? account.store._shouldShowContacts
        : true;
    });
    this.updateCache();
    this.emit('changed');
    this._resolve(this);
  };

  set = account => {
    this._accountMap[account.accountId] = account;
    this._showSwitchMap[account.accountId] = account.store._shouldShowContacts;
    this.updateCache();
    this.emit('changed', account.accountId);
  };

  remove = accountId => {
    delete this._accountMap[accountId];
    delete this._showSwitchMap[accountId];
    this.updateCache();
    this.emit('changed');
  };

  getAccountIds = () => {
    return Object.keys(this._accountMap);
  };

  getAccounts = () => {
    return Object.values(this._accountMap);
  };

  getAccountById = id => {
    return this._accountMap[id] || {};
  };

  find = filterCallback => {
    return Object.values(this._accountMap).find(filterCallback);
  };

  updateCache = () => {
    try {
      window.localStorage.setItem(
        'AccountsShow',
        JSON.stringify(this._showSwitchMap)
      );
    } catch (e) {
      console.error(`localStorage:set AccountsShow error: ${e}`);
    }
  };
}

export default AccountStore;
