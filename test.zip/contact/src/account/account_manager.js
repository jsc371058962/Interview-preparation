import AccountStore from 'account/account_store';
import GoogleAccount from 'account/google_account';
import ActiveSyncAccount from 'account/active_sync_account';
import AccountDataStore from 'account/account_data_store';
import Service from 'service';
import ContactStore, { CONTACT_STORE_ERROR } from 'contact_store';
import { CLOUD_TAG } from 'contact_wrapper';

const am = navigator.accountManager;
const _ = window.api.l10n.get;

export const SYNC_OPERATION = {
  PUSH: 'push',
  PULL: 'pull',
  PULL_ALL: 'pullAll',
  QUEUE_DELETION: 'queueDeletion',
};

const SUPPORTED_ACCOUNT_TYPES = ['google', 'activesync'];

/**
 * Utilize `navigator.accountManager` api to do some operations on AccountStore instance
 */
class AccountsManager {
  // an `AccountStore` instance
  _store = null;

  // see `contactDeletionQueue`
  _contactDeletionQueue = [];

  // see `contactDeletionQueue`
  _contactDeletionLock = false;

  // map accountId to a boolean value
  // indicating if the account is synchronizable
  _syncSwitchMap = {};

  constructor(store) {
    this._store = store;
    // To observe exchange account status change and run callback function you defined.
    AccountManager.observe('activesync', this._onAccountChanged);
    // To observe google account status change and run callback function you defined.
    AccountManager.observe('google', this._onAccountChanged);

    amCall('getAccounts')
      .then(
        (objs = []) => {
          const waitCreating = objs
            .filter(obj =>
              SUPPORTED_ACCOUNT_TYPES.includes(obj.authenticatorId)
            )
            .map(createAccount);
          return Promise.all(waitCreating);
        },
        () => []
      )
      .then(store.init);

    SettingsObserver.observe('contactsSyncEnable', null, obj => {
      this._syncSwitchMap = obj;
    });

    Service.registerState('isSyncingContacts', this);
  }

  // react to account changes from other apps
  _onAccountChanged = data => {
    const store = this._store;
    /** authenticatorId:
     *  1. google
     *  2. activesync
     *  3. kaiaccount
     *
     * state:
     *  - LOGGED_IN: 0
     *  - LOGGED_OUT: 1
     *  - REFRESH: 2
     */

    const { state, accountId, authenticatorId } = data;
    const accountObj = { accountId, authenticatorId };
    console.log('[AccountManager] _onAccountChanged:', state, data);
    if (!SUPPORTED_ACCOUNT_TYPES.includes(authenticatorId)) {
      return;
    }
    switch (state) {
      case 0:
        createAccount(accountObj).then(account => {
          store.set(account);
          this.operateSync(SYNC_OPERATION.PULL, { account });
        });
        break;
      case 1: {
        const account = accountStore.getAccountById(accountId);
        account.reset();
        store.remove(accountId);
        break;
      }
      case 2:
        // Update account data if account refreshed
        amCall('getCredential', accountObj).then(credential => {
          const account = accountStore.getAccountById(accountId);
          account._credential = credential;
          accountStore.set(account);
        });
        break;
      default:
        break;
    }
  };

  /**
   * Push, pull or delete data from cloud.
   * @param {string} operationType - One of `SYNC_OPERATION`
   * @return {promise}
   */
  operateSync = (operationType, { contact, account } = {}) => {
    console.log('[AccountManager] operateSync:', operationType, contact);
    if (Service.query('isActivity')) {
      return;
    }
    return this._store.whenReady.then(accountStore => {
      if (contact) {
        account = accountStore.find(acc => acc.store.hasContact(contact.id));
        if (account && !this.isSyncEnabled(account)) {
          console.log(
            '[AccountManager] operateSync: syncEnable false, skip:',
            account
          );
          return Promise.resolve(true);
        }
      }

      return this[`_sync_${operationType}`]({
        accountStore,
        contact,
        account,
      });
    });
  };

  isSyncEnabled = ({ accountId, authenticatorId }) =>
    this._syncSwitchMap[`${authenticatorId}:${accountId}`];

  /**
   * Find the parent account of the contact and push data to cloud.
   * @return {promise}
   */
  _sync_push = ({ contact, account }) =>
    account ? account.pushContact(contact) : false;

  /**
   * Sync all account contacts to mozContacts.
   * Should be executed after `ContactStore` ready,
   * otherwise will result in duplicated contacts in the end.
   * @return {promise} Will be resolved with accounts count.
   */
  _sync_pullAll = ({ accountStore }) => {
    // This will create all http requests(one per account) at the same time.
    // It should not be a big problem as long as an user has only few accounts.
    // Otherwise we may need to execute `account.syncContacts` one by one.
    const promises = accountStore
      .getAccounts()
      .filter(this.isSyncEnabled)
      .map(account => account.syncContacts());
    return this._managedSyncing(Promise.all(promises), true);
  };

  _sync_pull = ({ account }) => {
    return this._managedSyncing(account.syncContacts());
  };

  /**
   * A decorator function that wraps a syncing promise with UI notification.
   * We manage it to be always resolved(never be rejected)
   * and no need to be worry about error handling from client side.
   * @return {promise}
   */
  _managedSyncing = (syncingPromise, isToast = false) => {
    this.isSyncingContacts = true;
    ContactStore.setEventEmittingState(false);
    return syncingPromise
      .then(result => {
        if (!result) {
          return false;
        }
        this.isSyncingContacts = false;
        ContactStore.setEventEmittingState(true);
        if (Array.isArray(result) && !result.length) {
          // try to sync all accounts but none has isSyncEnabled true
          return true;
        }
        Service.request('ToastManager:show', {
          text: _('all-contacts-synced'),
        });
        return true;
      })
      .catch(e => {
        this.isSyncingContacts = false;
        ContactStore.setEventEmittingState(true);
        const _isToast = isToast || e.isToast;
        let content =
          e.msg || [_('sync-failed-warn'), _('accessing-warn')].join('\n');
        if (e === CONTACT_STORE_ERROR.LIMIT_EXCEEDED) {
          content = _('contacts-sync-limit-exceed');
        }
        if ('re-enter-password-on-setting' === e.msg) {
          const tempContent = [
            _('accessing-warn'),
            _('re-enter-password-on-setting'),
          ].join('');
          content = [_('sync-failed-warn'), tempContent].join('\n');
          return new Promise(resolve => {
            Service.request('showDialog', {
              header: _('sync-title'),
              content,
              ok: _('settings'),
              translated: true,
              onOk: () => {
                Service.request('push', '/account/change-password', e.params);
                resolve();
              },
            });
          });
        }

        if (_isToast) {
          Service.request('ToastManager:show', { text: content });
          return Promise.resolve();
        }

        return new Promise(resolve => {
          Service.request('showDialog', {
            header: _('sync-title'),
            type: 'alert',
            content,
            translated: true,
            onOk: () => resolve(e),
          });
        });
      });
  };

  /**
   * Delete contacts from cloud one by one.
   * Utilize a queue to avoid heavy http requests in a short moment.
   * @return {promise}
   */
  _sync_queueDeletion = ({ contact, account }) => {
    if (!contact.category || !contact.category.includes(CLOUD_TAG)) {
      console.log(
        '[AccountManager] _sync_queueDeletion: not an account contact, skip'
      );
      return Promise.resolve(true);
    }
    if (!account) {
      console.log('[AccountManager] _sync_queueDeletion: account false, skip');
      return Promise.resolve(true);
    }
    this._contactDeletionQueue.push({ contact, account });

    if (this._contactDeletionLock) {
      console.log(
        '[AccountManager] deleting contacts still ongoing, queued one'
      );
      return Promise.resolve(true);
    }

    this._contactDeletionLock = true;
    // use iterator instead of looping `_contactDeletionQueue` directly,
    // because user may append(queue) more contacts to delete when deleting on the fly
    const iterator = this._contactDeletionQueue[Symbol.iterator]();
    const deleteOne = () => {
      const { value, done } = iterator.next();
      if (done) {
        console.log(
          '[AccountManager] deleting contacts from cloud done: count:',
          this._contactDeletionQueue.length
        );
        this._contactDeletionLock = false;
        this._contactDeletionQueue = [];
        return true;
      }

      const { contact: theContact, account: theAccount } = value;
      return theAccount
        .deleteContact(theContact)
        .then(deleteOne)
        .catch(deleteOne);
    };
    return deleteOne();
  };

  /**
   * Filter out an account contact if `shouldShowContacts` false.
   * Can be used as a callback of `array.filter()`.
   * @return {bool} - false for filtering out.
   */
  accountContactsFilter = contact => {
    // not an account contact, skip
    if (!contact.category.includes(CLOUD_TAG)) return true;

    // leave loop once found among all account contacts that are expected to be shown
    return this._store.find(
      account =>
        account.store.shouldShowContacts && account.store.hasContact(contact.id)
    );
  };
}

const store = new AccountStore();
const manager = new AccountsManager(store);

export const authenticatorIds = [
  'google',
  'activesync',
  // XXX: support ActiveSync account
];

export const showLoginPage = (account, option = {}) => {
  if (!option.headerBackgroundColor) {
    option.headerBackgroundColor = 'var(--header-lime-background)';
  }
  return amCall('showLoginPage', account, option);
};
export const logout = arg => amCall('logout', arg);
export const getCredential = (account, ...args) =>
  amCall('getCredential', account, ...args);

export const changePassword = accountObj => {
  const { authenticatorId, accountId } = accountObj;
  if ('activesync' === authenticatorId) {
    const account = accountStore.getAccountById(accountId);
    return account.reEnterPassword(accountObj);
  }
  return Promise.reject('Support activesync only.');
};

export const refreshCredential = (account, credential) =>
  amCall('refreshCredential', account, credential);

export const accountStore = store;
export const { operateSync, isSyncEnabled, accountContactsFilter } = manager;
export default manager;

/**
 * Access `navigator.accountManager` API with customized error log
 */
function amCall(methodName, ...args) {
  console.log(`[AccountManager] (amCall) ${methodName}:`, ...args);
  return am[methodName](...args).catch(e => {
    console.error(`[AccountManager] ${methodName} error:`, e);
    throw e;
  });
}

/**
 * Create an account including its credential
 * @return {promise} - Resolved with account instance
 */
function createAccount(accountObj) {
  const { authenticatorId, accountId } = accountObj;
  return amCall('getCredential', accountObj).then(credential => {
    if ('google' === authenticatorId) {
      return new GoogleAccount(
        Object.assign(accountObj, {
          credential,
          store: new AccountDataStore(accountId, authenticatorId),
        })
      );
    }
    // XXX: support ActiveSync account
    if ('activesync' === authenticatorId) {
      return new ActiveSyncAccount(
        Object.assign(accountObj, {
          credential,
          store: new AccountDataStore(accountId, authenticatorId),
        })
      );
    }
    return accountObj;
  });
}
