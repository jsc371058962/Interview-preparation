import { batchOperate } from 'contact_store';
import Utils from 'contact_utils';
import { refreshCredential } from './account_manager';
import {
  mozContactToExchangeContact,
  exchangeContactToMozContact,
} from './active_sync_helper';
import {
  getConnection,
  getSyncData,
  updateContact,
  deleteContact,
} from './active_sync_api';

export default class ActiveSyncAccount {
  authenticatorId = '';

  accountId = '';

  // an `AccountDataStore` instance
  store = null;

  // active sync connection instance
  connection = null;

  constructor({ authenticatorId, accountId, credential, store }) {
    this.authenticatorId = authenticatorId;
    this.accountId = accountId;
    this.store = store;

    // A credentail object defined in `navigator.accountManager` is
    // {
    //    username: "xx@kaiostech.com",
    //    password: "xx",
    //    configInfo: {
    //      deviceId: "c15ef538c20c35c2dfaea624d915ef11"
    //      policyKey: "4117595896"
    //      server: 'https://outlook.office365.com'
    //    }
    // }
    this._credential = credential;
  }

  /**
   * Info page need this method, check the password is valid or not.
   * @return {promise}
   */
  isValid(account) {
    return this._checkPasswordIsValid(
      Object.assign(account, { password: account._credential.password })
    );
  }

  /**
   * reEnter password. change_password page need this method.
   * This is used to reEnter password. and verify NetWork, isValid
   * @return Promise
   */
  reEnterPassword(account) {
    return this._checkPasswordIsValid(account);
  }

  /**
   * Make api call to check password and verify NetWork isValid
   * @return Promise
   */
  _checkPasswordIsValid(account) {
    const { authenticatorId, accountId, password } = account;
    const self = this;
    return new Promise(function(resolve, reject) {
      if (!Utils.isOnLine()) {
        return reject('no-network-warn');
      }
      if (authenticatorId) {
        console.log(`Change password of account: ${accountId}`);
        const _account = {
          accountId,
          authenticatorId,
        };

        refreshCredential(_account, { ...self._credential, password }).then(
          credential => {
            console.log(`Account:${accountId} refreshCredential`, credential);
            resolve(true);
          },
          e => {
            // error message maybe "incorrect password" "error"
            console.log(`Account:${accountId} refreshCredential failed`, e);
            reject('password-incorrect');
          }
        );
      } else {
        reject('wrong account type');
      }
    });
  }

  /**
   * Clear cache and account related contacts.
   * Normally, this is used when deleting an account.
   */
  reset() {
    this.store.clearCache();
    const contactsToRemove = this.store.contactIds.map(id => ({ id }));
    return batchOperate(contactsToRemove, {
      operation: 'remove',
      onContactChanged: contact => {
        this.store.removeContact(contact.id);
      },
    });
  }

  /**
   * Make API call to get google people objects from cloud
   * then convert and save as mozContact in local.
   * @return {promise}
   */
  syncContacts() {
    // prevent multiple syncing at the same time
    if (this._syncLock) {
      return Promise.resolve(false);
    }
    console.log('[Exchange] syncContacts:', this.accountId);
    this._syncLock = true;
    return getConnection(this, false, this.store.syncKey)
      .then(conn => {
        return getSyncData(conn)
          .then(data => {
            const aData = data[0];
            const dData = data[1];
            if (0 === aData.length && 0 === dData.length) {
              // nothing to sync
              return true;
            }

            const contactsToSave = [];
            const contactsToRemove = [];
            aData.forEach(person => {
              // contactId exist, update the contact
              const contactId = this.store.findOneContact(obj => {
                return obj.guid === person.guid;
              });

              // clear invalid synced contacts
              if (0 === this.store.syncKey && contactId) {
                contactsToRemove.push({ id: contactId });
                return;
              }

              const exchangeContact = exchangeContactToMozContact(
                person,
                this.accountId
              );
              // for later usage
              exchangeContact.guid = person.guid;
              exchangeContact.id = contactId || Utils.generateUUID();
              contactsToSave.push(exchangeContact);
            });
            dData.forEach(person => {
              const contactId = this.store.findOneContact(obj => {
                return obj.guid === person.guid;
              });
              if (contactId) {
                contactsToRemove.push({ id: contactId });
              }
            });
            this.store.syncKey = conn.syncKey;

            return batchOperate(contactsToRemove, {
              operation: 'remove',
              onContactChanged: contact => {
                this.store.removeContact(contact.id);
              },
            }).then(() => {
              return batchOperate(contactsToSave, {
                operation: 'createOrUpdate',
                onContactChanged: (contact, index) => {
                  this.store.setContact(contact.id, {
                    guid: contactsToSave[index].guid,
                  });
                },
              });
            });
          })
          .then(result => {
            this._syncLock = false;
            this.store.updateCache();
            return result;
          })
          .catch(e => {
            // set syncKey to 0 when return error, we need clear
            // the synced data when the next sync occurs
            this.store.syncKey = 0;
            this.store.updateCache();
            this._syncLock = false;
            console.error('[ExchangeAccount] syncContacts error:', e);
            throw e;
          });
      })
      .catch(e => {
        this._syncLock = false;
        console.error('[ExchangeAccount] syncContacts error:', e);
        throw e;
      });
  }

  /**
   * Make API call to update contact data to cloud.
   * @return {promise}
   */
  pushContact(contact) {
    console.log('[ExchangeAccount] pushContact:', this.accountId, contact);
    return getConnection(this).then(conn => {
      const storePerson = this.store.getContact(contact.id);
      const person = Object.assign(
        {},
        storePerson,
        mozContactToExchangeContact(contact)
      );
      return updateContact(conn, person).then(result => {
        if (result.guid) {
          storePerson.guid = result.guid;
        }
        this.store.setContact(contact.id, storePerson);
        this.store.syncKey = conn.syncKey;
        this.store.updateCache();
        return result;
      });
    });
  }

  /**
   * Make API call to delete contact data from cloud.
   * @return {promise}
   */
  deleteContact(contact) {
    console.log('[ExchangeAccount] deleteContact:', this.accountId, contact);
    return getConnection(this).then(conn => {
      const person = this.store.getContact(contact.id);
      return deleteContact(conn, person).then(result => {
        this.store.syncKey = conn.syncKey;
        this.store.removeContact(contact.id);
        this.store.updateCache();
        return result;
      });
    });
  }
}
