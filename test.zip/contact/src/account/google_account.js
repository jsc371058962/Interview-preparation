import {
  getConnections,
  updateContact,
  deleteContact,
} from 'account/google_api';
import { mozContactToPerson, personToMozContact } from 'account/google_helper';
import { refreshCredential } from 'account/account_manager';
import { batchOperate } from 'contact_store';
import Utils from 'contact_utils';

const _ = window.api.l10n.get;

/**
 * Mainly used as a google api client.
 * Adapt data from `navigator.accountManager` to a GoogleAccount instance.
 */
class GoogleAccount {
  authenticatorId = '';

  accountId = '';

  // an `AccountDataStore` intance
  store = null;

  constructor({ authenticatorId, accountId, credential, store }) {
    this.authenticatorId = authenticatorId;
    this.accountId = accountId;
    this.store = store;

    // A credentail object defined in `navigator.accountManager` is
    // {
    //   access_token: string,
    //   token_type: string,
    //   expire_timestamp: date
    // }
    this._credential = credential;

    this.bReFresh = false;
  }

  get accessToken() {
    return this._credential.access_token;
  }
  get authorization() {
    const { token_type, access_token } = this._credential;
    return `${token_type} ${access_token}`;
  }

  // `nextSyncToken` will be cached
  // This is used to avoid pulling down data redundantly.
  get nextSyncToken() {
    return this.store.getProp('nextSyncToken');
  }
  set nextSyncToken(syncToken) {
    this.store.setProp('nextSyncToken', syncToken);
  }

  /**
   * Clear cache and account related contacts.
   * Normally, this is used when deleting an account.
   */
  reset() {
    this.store.clearCache();
    const contactsToRemove = this.store.contactIds.map(id => ({ id }));
    return batchOperate(contactsToRemove, {
      operation: 'remove',
      onContactChanged: contact => {
        this.store.removeContact(contact.id);
      },
    });
  }

  /**
   * Make API call to check the token is valid or not.
   * @return {promise}
   */
  isValid = () => {
    return this._refreshIfNeed();
  };

  /**
   * Make API call to get google people objects from cloud
   * then convert and save as mozContact in local.
   * @return {promise}
   */
  syncContacts() {
    // prevent multiple syncing at the same time
    if (this._syncLock) {
      return Promise.resolve(false);
    }
    console.log('[GoogleAccount] syncContacts:', this.accountId);
    this._syncLock = true;

    // restore nextSyncToken if got error when syncing,
    // thus we can fetch the same data and try syncing again
    const nextSyncTokenBackup = this.nextSyncToken;

    return this._refreshIfNeed()
      .then(() => getConnections(this))
      .then(people => {
        if (0 === people.length) {
          // nothing to sync
          return true;
        }
        const contactsToRemove = [];
        const contactsToSave = [];
        people.forEach(person => {
          const contactId = this.store.findOneContact(obj => {
            return obj.resourceName === person.resourceName;
          });
          if (2 === Object.keys(person).length) {
            // means only has `resourceName` and `etag`,
            // that is the result of removing person since last syncing
            contactId &&
              contactsToRemove.push({
                id: contactId,
              });
          } else {
            const googleContact = personToMozContact(person, this.accountId);
            // for later usage
            googleContact._person = person;
            googleContact.id = contactId || Utils.generateUUID();
            contactsToSave.push(googleContact);
          }
        });

        return batchOperate(contactsToRemove, {
          operation: 'remove',
          onContactChanged: contact => {
            this.store.removeContact(contact.id);
          },
        }).then(() => {
          return batchOperate(contactsToSave, {
            operation: 'createOrUpdate',
            onContactChanged: (contact, index) => {
              const { resourceName, etag } = contactsToSave[index]._person;
              this.store.setContact(contact.id, { resourceName, etag });
            },
          });
        });
      })
      .then(result => {
        this._syncLock = false;
        this.store.updateCache();
        return result;
      })
      .catch(e => {
        this._syncLock = false;
        if (!this.bReFresh && ('invalid_grant' === e || 401 === e.status)) {
          this.bReFresh = true;
          return this.syncContacts();
        }
        this.nextSyncToken = nextSyncTokenBackup;
        console.error('[GoogleAccount] syncContacts error:', e);
        if ('timeout' === e) {
          throw {
            msg: _('connect-time-out', {
              server: this.accountId,
            }),
            isToast: true,
          };
        }
        throw e;
      });
  }

  /**
   * Make API call to update contact data to cloud.
   * @return {promise}
   */
  pushContact(contact) {
    console.log('[GoogleAccount] pushContact:', this.accountId, contact);
    return this._refreshIfNeed().then(() => {
      const storePerson = this.store.getContact(contact.id);
      const person = Object.assign(
        {},
        storePerson,
        mozContactToPerson(contact)
      );
      return updateContact(this, person).then(result => {
        storePerson.etag = result.etag;
        this.store.setContact(contact.id, storePerson);
        this.store.updateCache();
        return result;
      });
    });
  }

  /**
   * Make API call to delete contact data from cloud.
   * @return {promise}
   */
  deleteContact(contact) {
    console.log('[GoogleAccount] deleteContact:', this.accountId, contact);
    return this._refreshIfNeed().then(() => {
      const person = this.store.getContact(contact.id);
      return deleteContact(this, person).then(result => {
        this.store.removeContact(contact.id);
        this.store.updateCache();
        return result;
      });
    });
  }

  /**
   * Refresh credential if it's gonna expired.
   * Use before every API call to avoid token expired error.
   * @return {promise}
   */
  _refreshIfNeed() {
    if (!Utils.isOnLine()) {
      return Promise.reject({
        msg: _('no-network-warn'),
        isToast: true,
      });
    }
    // keep 5 minutes margin before truely expired
    if (
      this._credential.expire_timestamp > Date.now() + 5 * 60 * 1000 &&
      !this.bReFresh
    ) {
      return Promise.resolve(true);
    }
    this.bReFresh = true;
    console.log('[GoogleAccount] need to refresh credential:');
    const account = {
      accountId: this.accountId,
      authenticatorId: this.authenticatorId,
    };
    return refreshCredential(account, this._credential);
  }
}

export default GoogleAccount;
