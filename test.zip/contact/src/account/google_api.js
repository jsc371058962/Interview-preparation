import req from 'modules/requester';

const baseAuthUrl = 'https://www.googleapis.com/oauth2/v3';
const basePeopleUrl = 'https://people.googleapis.com/v1';
const MAX_CONTACTS = 1000;

/**
 * See https://developers.google.com/identity/sign-in/web/backend-auth#calling-the-tokeninfo-endpoint
 * @return {promise}
 */
export function getTokenInfo(accessToken) {
  return req({
    method: 'GET',
    url: `${baseAuthUrl}/tokeninfo?access_token=${accessToken}`,
  }).then(result => {
    if (result.error_description) {
      console.error('[google_api] getTokenInfo error:', result);
      throw result;
    }
    console.log('[google_api] getTokenInfo ok:', result);
    return result;
  });
}

/**
 * GET /people/me/connections
 * see https://developers.google.com/people/api/rest/v1/people.connections
 * Each time when `getConnections` done, `nextSyncToken` will be updated.
 * This ensures no redundant people will be fetched.
 * @param {object} account - A GoogleAccount instance
 * @return {promise}
 */
export function getConnections(account) {
  const { authorization } = account;
  const fields = [
    'names',
    'phoneNumbers',
    'emailAddresses',
    'birthdays',
    'biographies',
    'organizations',
    'addresses',
  ].join(',');

  const qs = [
    `personFields=${fields}`,
    account.nextSyncToken
      ? `syncToken=${account.nextSyncToken}`
      : 'requestSyncToken=true',
    `pageSize=${MAX_CONTACTS}`,
  ].join('&');

  return req({
    authorization,
    method: 'GET',
    url: `${basePeopleUrl}/people/me/connections?${qs}`,
  })
    .then(result => {
      const { connections, nextSyncToken } = JSON.parse(result);
      console.log(
        '[google_api] getConnections ok:',
        connections,
        nextSyncToken
      );
      account.nextSyncToken = nextSyncToken;
      return connections || [];
    })
    .catch(e => {
      console.error('[google_api] getConnections error:', e);
      throw e;
    });
}

/**
 * PATCH /people/${personId}:updateContact
 * see https://developers.google.com/people/api/rest/v1/people/updateContact
 * @param {object} account - A GoogleAccount instance
 * @return {promise}
 */
export function updateContact(account, person) {
  const { authorization } = account;
  const fields = [
    'names',
    'phoneNumbers',
    'emailAddresses',
    'birthdays',
    'biographies',
    'organizations',
    'addresses',
  ].join(',');

  const qs = `updatePersonFields=${fields}`;

  return req({
    authorization,
    method: 'PATCH',
    url: `${basePeopleUrl}/${person.resourceName}:updateContact?${qs}`,
    params: person,
  })
    .then(result => {
      const { etag } = JSON.parse(result);
      console.log('[google_api] updateContact ok:', person, etag);
      return { etag };
    })
    .catch(e => {
      console.error('[google_api] updateContact error:', e);
      throw e;
    });
}

/**
 * DELETE /people/${personId}:deleteContact
 * see https://developers.google.com/people/api/rest/v1/people/deleteContact
 * @param {object} account - A GoogleAccount instance
 * @return {promise}
 */
export function deleteContact(account, person) {
  const { authorization } = account;
  return req({
    authorization,
    method: 'DELETE',
    url: `${basePeopleUrl}/${person.resourceName}:deleteContact`,
  })
    .then(result => {
      console.log('[google_api] deleteContact ok:', result);
      return result;
    })
    .catch(e => {
      console.error('[google_api] deleteContact error:', e);
      throw e;
    });
}
