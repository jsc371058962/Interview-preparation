import Utils from 'contact_utils';

const _ = window.api.l10n.get;

/**
 * GET connection
 * @param {object} account - A ExchangeAccount instance
 * @return {promise}
 */
export function getConnection(account, useCache = true, syncKey = null) {
  if (!Utils.isOnLine()) {
    return Promise.reject({
      msg: _('no-network-warn'),
      isToast: true,
    });
  }
  const { username, password, configInfo } = account._credential;
  const { deviceId, policyKey, server } = configInfo;
  return new Promise((resolve, reject) => {
    require.ensure([], require => {
      const { Connection } = require('./activesync/protocol');
      if (account.connection && account.connection.connected && useCache) {
        return resolve(account.connection);
      }
      account.connection = new Connection(deviceId, policyKey, syncKey);
      account.connection.open(server, username, password, account.accountId);
      account.connection.timeout = 30 * 1000;
      account.connection.connect(error => {
        if (error) {
          reject(errorStatusHandler(error, account));
        }
        resolve(account.connection);
      });
    });
  }).catch(e => {
    console.error('[ExchangeAccount] connect error:', e);
    throw e;
  });
}

/**
 * GET /people/me/connections
 * This ensures no redundant people will be fetched.
 * @param {object} connection - A Exchange connection
 * @return {promise}
 */
export function getSyncData(connection) {
  return new Promise((resolve, reject) => {
    connection.getSyncData((data, err) => {
      if (err) {
        return reject(err);
      }
      resolve(data || []);
    });
  }).catch(e => {
    console.error('[ExchangeAccount] getSyncData error:', e);
    throw e;
  });
}

/**
 * UPDATE EAS:updateEvent
 * @param {object} connection - A Exchange connection
 * @param {object} people - A exchangeContact instance with ServerId
 * @return {promise}
 */
export function updateContact(connection, people) {
  return new Promise((resolve, reject) => {
    connection.updateData(people, (res, err) => {
      if (err) {
        return reject(err);
      }
      resolve(res);
    });
  }).catch(e => {
    console.error('[ExchangeAccount] updateContact error:', e);
    throw e;
  });
}

/**
 * DELETE EAS:deleteEvent
 * @param {object} connection - A Exchange connection
 * @param {object} people - A exchangeContact instance with ServerId
 * @return {promise}
 */
export function deleteContact(connection, people) {
  return new Promise((resolve, reject) => {
    connection.deleteData(people, res => {
      if (res) {
        return reject(res);
      }
      resolve(true);
    });
  }).catch(e => {
    console.error('[ExchangeAccount] deleteContact error:', e);
    throw e;
  });
}

function errorStatusHandler(error, account) {
  if ('timeout' === error.status) {
    return {
      msg: _('connect-time-out', {
        server: account._credential.configInfo.server,
      }),
      isToast: true,
    };
  }
  if (400 <= error.status && 500 > error.status) {
    return {
      msg: 're-enter-password-on-setting',
      params: {
        accountId: account.accountId,
        authenticatorId: account.authenticatorId,
        invalidPassword: true,
      },
    };
  }
  if (500 <= error.status) {
    return {
      msg: _('server-error'),
      isToast: true,
    };
  }
}
