/* Copyright 2012 Mozilla Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

define(function(require, exports, module) {
  'use strict';
  let WBXML = require('account/activesync/wbxml/wbxml');
  let ASCP = require('account/activesync/codepages');
  const USER_AGENT = 'KaiOS ActiveSync Client';

  function nullCallback() {}

  /**
   * Create a constructor for a custom error type that works like a built-in
   * Error.
   *
   * @param name the string name of the error
   * @param parent (optional) a parent class for the error, defaults to Error
   * @param extraArgs an array of extra arguments that can be passed to the
   *        constructor of this error type
   * @return the constructor for this error
   */
  function makeError(name, parent, extraArgs) {
    function CustomError() {
      // Try to let users call this as CustomError(...) without the "new". This
      // is imperfect, and if you call this function directly and give it a
      // |this| that's a CustomError, things will break. Don't do it!
      let self = this instanceof CustomError ?
        this : Object.create(CustomError.prototype);
      let tmp = Error();
      let offset = 1;

      self.stack = tmp.stack.substring(tmp.stack.indexOf('\n') + 1);
      self.message = arguments[0] || tmp.message;
      if (extraArgs) {
        offset += extraArgs.length;
        for (let i = 0; i < extraArgs.length; i++)
          self[extraArgs[i]] = arguments[i+1];
      }

      let m = /@(.+):(.+)/.exec(self.stack);
      self.fileName = arguments[offset] || (m && m[1]) || "";
      self.lineNumber = arguments[offset + 1] || (m && m[2]) || 0;

      return self;
    }
    CustomError.prototype = Object.create((parent || Error).prototype);
    CustomError.prototype.name = name;
    CustomError.prototype.constructor = CustomError;

    return CustomError;
  }

  let AutodiscoverError = makeError('ActiveSync.AutodiscoverError');
  exports.AutodiscoverError = AutodiscoverError;

  exports.AutodiscoverDomainError = makeError('ActiveSync.AutodiscoverDomainError',
                                              AutodiscoverError);

  let HttpError = makeError('ActiveSync.HttpError', null, ['status']);
  exports.HttpError = HttpError;

  function nsResolver(prefix) {
    const baseUrl = 'http://schemas.microsoft.com/exchange/autodiscover/';
    const ns = {
      rq: baseUrl + 'mobilesync/requestschema/2006',
      ad: baseUrl + 'responseschema/2006',
      ms: baseUrl + 'mobilesync/responseschema/2006'
    };
    return ns[prefix] || null;
  }

  function Version(str) {
    let details = str.split('.').map(function(x) {
      return parseInt(x);
    });
    this.major = details[0];
    this.minor = details[1];
  }
  exports.Version = Version;
  Version.prototype = {
    eq: function(other) {
      if (!(other instanceof Version))
        other = new Version(other);
      return this.major === other.major && this.minor === other.minor;
    },
    ne: function(other) {
      return !this.eq(other);
    },
    gt: function(other) {
      if (!(other instanceof Version))
        other = new Version(other);
      return this.major > other.major ||
             (this.major === other.major && this.minor > other.minor);
    },
    gte: function(other) {
      if (!(other instanceof Version))
        other = new Version(other);
      return this.major >= other.major ||
             (this.major === other.major && this.minor >= other.minor);
    },
    lt: function(other) {
      return !this.gte(other);
    },
    lte: function(other) {
      return !this.gt(other);
    },
    toString: function() {
      return this.major + '.' + this.minor;
    },
  };

  /**
   * Set the Authorization header on an XMLHttpRequest.
   *
   * @param xhr the XMLHttpRequest
   * @param username the username
   * @param password the user's password
   */
  function setAuthHeader(xhr, username, password) {
    const authorization = 'Basic ' + btoa(username + ':' + password);
    xhr.setRequestHeader('Authorization', authorization);
  }

  /**
   * Create a new ActiveSync connection.
   *
   * ActiveSync connections use XMLHttpRequests to communicate with the
   * server. These XHRs are created with mozSystem: true and mozAnon: true to,
   * respectively, help with CORS, and to ignore the authentication cache. The
   * latter is important because 1) it prevents the HTTP auth dialog from
   * appearing if the user's credentials are wrong and 2) it allows us to
   * connect to the same server as multiple users.
   *
   * @param aDeviceId (optional) a string identifying this device
   * @param aPolicyKey(optional) a string with a maximum of 64 characters, it
   *        is used by the server to mark the state of policy settings on the
   *        client in the settings
   download phase of the Provision command.

   * @param aDeviceType (optional) a string identifying the type of this device
   */
  function Connection(aDeviceId, aPolicyKey, syncKey, aDeviceType) {
    this._deviceId = aDeviceId || 'v140Device';
    this._deviceType = aDeviceType || 'KaiOS';
    this.timeout = 0;

    this._connected = false;
    this._waitingForConnection = false;
    this._connectionCallbacks = [];

    this.baseUrl = null;
    this._username = null;
    this._password = null;
    this._accountId = null;

    this.SyncKey = syncKey;
    this.CollectionId = null;

    this.versions = [];
    this.supportedCommands = [];
    this.currentVersion = null;
    this.policyKey = aPolicyKey || 0;

    /**
     * Debug support function that is called every time an XHR call completes.
     * This is intended to be used for logging.
     *
     * The arguments to the function are:
     *
     * - type: 'options' if caused by a call to getOptions.  'post' if caused by
     *   a call to postCommand/postData.
     *
     * - special: 'timeout' if a timeout error occurred, 'redirect' if the
     *   status code was 451 and the call is being reissued, 'error' if some
     *   type of error occurred, or 'ok' on success.  Check xhr.status for the
     *   specific http status code.
     *
     * - xhr: The XMLHttpRequest used.  Use this to check the statusCode,
     *   statusText, or response headers.
     *
     * - params: The object dictionary of parameters encoded into the URL.
     *   Always present if type is 'post', not present for 'options'.
     *
     * - extraHeaders: Optional dictionary of extra request headers that were
     *   provided.  These will not include the always-present request headers of
     *   MS-ASProtocolVersion and Content-Type.
     *
     * - sent data: If type is 'post', the ArrayBuffer provided to xhr.send().
     *
     * - response: In the case of a successful 'post', the WBXML Reader instance
     *   that will be passed to the callback for the method.  If you use the
     *   reader, you are responsible for calling rewind() on it.
     */
    this.onmessage = null;
  }
  exports.Connection = Connection;
  Connection.prototype = {
    /**
     * Perform any callbacks added during the connection process.
     *
     * @param aError the error status (if any)
     */
    _notifyConnected: function(aError) {
      if (aError)
        this.disconnect();

      for (let callback of this._connectionCallbacks) {
        callback.apply(callback, arguments);
      }
      this._connectionCallbacks = [];
    },

    /**
     * Get the connection status.
     *
     * @return true if we are fully connected to the server
     */
    get connected() {
      return this._connected;
    },

    get syncKey() {
      return this.SyncKey;
    },

    /*
     * Initialize the connection with a server and account credentials.
     *
     * @param aURL the ActiveSync URL to connect to
     * @param aUsername the account's username
     * @param aPassword the account's password
     */
    open: function(aURL, aUsername, aPassword, accountId) {
      // XXX: We add the default service path to the URL if it's not already
      // there. This is a hack to work around the failings of Hotmail (and
      // possibly other servers), which doesn't provide the service path in its
      // URL. If it turns out this causes issues with other domains, remove it.
      const servicePath = '/Microsoft-Server-ActiveSync';
      this.baseUrl = aURL;
      if (!this.baseUrl.endsWith(servicePath))
        this.baseUrl += servicePath;

      this._username = aUsername;
      this._password = aPassword;
      this._accountId = accountId ? accountId.toLowerCase() : null;
    },

    /**
     * Connect to the server with this account by getting the OPTIONS and
     * policy from the server (and verifying the account's credentials).
     *
     * @param aCallback a callback taking an error status (if any) and the
     *        server's options.
     */
    connect: function(aCallback) {
      // If we're already connected, just run the callback and return.
      if (this.connected) {
        if (aCallback)
          aCallback(null);
        return;
      }

      // Otherwise, queue this callback up to fire when we do connect.
      if (aCallback)
        this._connectionCallbacks.push(aCallback);

      // Don't do anything else if we're already trying to connect.
      if (this._waitingForConnection)
        return;

      this._waitingForConnection = true;

      this.getOptions((aError, aOptions) => {
        this._waitingForConnection = false;

        if (aError) {
          console.error('Error connecting to ActiveSync:', aError);
          return this._notifyConnected(aError, aOptions);
        }

        this._connected = true;
        this.versions = aOptions.versions;
        this.supportedCommands = aOptions.commands;
        this.currentVersion = new Version(aOptions.versions.slice(-1)[0]);

        this.enforcement((aError, aResponse) => {
          const errorStr = 'Error connecting to ActiveSync: ';
          if (aError) {
            console.error(errorStr, aError);
            return this._notifyConnected(aError, aOptions);
          }

          let e = new WBXML.EventParser();
          let fh = ASCP.FolderHierarchy.Tags;

          e.addEventListener([fh.FolderSync, fh.Changes,
            [fh.Add, fh.Delete, fh.Update]], (node) => {
            let folder = {};
            for (let child of node.children) {
              folder[child.localTagName] = child.children[0].textContent;
            }

            if (folder.Type === '9') {
              this.CollectionId = folder.ServerId;
              if (this.SyncKey) {
                aCallback();
              } else {
                this.getSynckey((aError, aResponse) => {
                  const err = 'Error get contacts folder: ';
                  if (aError) {
                    console.error(err, aError);
                    return this._notifyConnected(aError, aOptions);
                  }

                  let e = new WBXML.EventParser();
                  let as = ASCP.AirSync.Tags;

                  e.addEventListener([as.Sync, as.Collections, as.Collection, as.SyncKey],
                    (node) => {
                    this.SyncKey = node.children[0].textContent;
                    aCallback();
                  });

                  try {
                    e.run(aResponse);
                  }
                  catch (ex) {
                    console.error(err, ex);
                  }
                });
              }
            }
          });

          try {
            e.run(aResponse);
          }
          catch (ex) {
            console.error(errorStr, ex);
          }
        });
      });
    },

    /**
     * Disconnect from the ActiveSync server, and reset the connection state.
     * The server and credentials remain set however, so you can safely call
     * connect() again immediately after.
     */
    disconnect: function() {
      if (this._waitingForConnection)
        throw new Error("Can't disconnect while waiting for server response");

      this._connected = false;
      this.versions = [];
      this.supportedCommands = [];
      this.currentVersion = null;
    },

    /**
     * Get the options for the server associated with this account.
     *
     * @param aCallback a callback taking an error status (if any), and the
     *        resulting options.
     */
    getOptions: function(aCallback) {
      if (!aCallback) aCallback = nullCallback;

      let conn = this;
      let xhr = new XMLHttpRequest({mozSystem: true, mozAnon: true});
      xhr.open('OPTIONS', this.baseUrl, true);
      setAuthHeader(xhr, this._username, this._password);
      xhr.setRequestHeader('User-Agent', USER_AGENT);
      xhr.timeout = this.timeout;

      xhr.upload.onprogress = xhr.upload.onload = function() {
        xhr.timeout = 0;
      };

      xhr.onload = function() {
        if (xhr.status < 200 || xhr.status >= 300) {
          console.error('ActiveSync options request failed with response ' +
                        xhr.status);
          if (conn.onmessage)
            conn.onmessage('options', 'error', xhr, null, null, null, null);
          aCallback(new HttpError(xhr.statusText, xhr.status));
          return;
        }

        // These headers are comma-separated lists. Sometimes, people like to
        // put spaces after the commas, so make sure we trim whitespace too.
        let result = {
          versions: xhr.getResponseHeader('MS-ASProtocolVersions')
                       .split(/\s*,\s*/),
          commands: xhr.getResponseHeader('MS-ASProtocolCommands')
                       .split(/\s*,\s*/)
        };

        if (conn.onmessage)
          conn.onmessage('options', 'ok', xhr, null, null, null, result);
        aCallback(null, result);
      };

      xhr.ontimeout = xhr.onerror = function() {
        const error = new Error('Error getting OPTIONS URL');
        console.error(error);
        if (conn.onmessage)
          conn.onmessage('options', 'timeout', xhr, null, null, null, null);
        aCallback({status: 'timeout'});
      };

      // Set the response type to "text" so that we don't try to parse an empty
      // body as XML.
      xhr.responseType = 'text';
      xhr.send();
    },

    /**
     * Check if the server supports a particular command. Requires that we be
     * connected to the server already.
     *
     * @param aCommand a string/tag representing the command type
     * @return true iff the command is supported
     */
    supportsCommand: function(aCommand) {
      if (!this.connected)
        throw new Error('Connection required to get command');

      if (typeof aCommand === 'number')
        aCommand = ASCP.__tagnames__[aCommand];
      return this.supportedCommands.indexOf(aCommand) !== -1;
    },

    /**
     * DEPRECATED. See postCommand() below.
     */
    doCommand: function() {
      console.warn('doCommand is deprecated. Use postCommand instead.');
      this.postCommand.apply(this, arguments);
    },

    /**
     * Send a WBXML command to the ActiveSync server and listen for the
     * response.
     *
     * @param aCommand {WBXML.Writer|String|Number}
     *   The WBXML representing the command or a string/tag representing the
     *   command type for empty commands
     * @param aCallback a callback to call when the server has responded; takes
     *        two arguments: an error status (if any) and the response as a
     *        WBXML reader. If the server returned an empty response, the
     *        response argument is null.
     * @param aExtraParams (optional) an object containing any extra URL
     *        parameters that should be added to the end of the request URL
     * @param aExtraHeaders (optional) an object containing any extra HTTP
     *        headers to send in the request
     * @param aProgressCallback (optional) a callback to invoke with progress
     *        information, when available. Two arguments are provided: the
     *        number of bytes received so far, and the total number of bytes
     *        expected (when known, 0 if unknown).
     */
    postCommand: function(aCommand, aCallback, aExtraParams, aExtraHeaders,
                          aProgressCallback) {
      const contentType = 'application/vnd.ms-sync.wbxml';

      if (typeof aCommand === 'string' || typeof aCommand === 'number') {
        this.postData(aCommand, contentType, null, aCallback, aExtraParams,
                      aExtraHeaders);
      }
      // WBXML.Writer
      else {
        let commandName = ASCP.__tagnames__[aCommand.rootTag];
        this.postData(
          commandName, contentType,
          aCommand.dataType === 'blob' ? aCommand.blob : aCommand.buffer,
          aCallback, aExtraParams, aExtraHeaders, aProgressCallback);
      }
    },

    /**
     * Send arbitrary data to the ActiveSync server and listen for the response.
     *
     * @param aCommand a string (or WBXML tag) representing the command type
     * @param aContentType the content type of the post data
     * @param aData {ArrayBuffer|Blob} the data to be posted
     * @param aCallback a callback to call when the server has responded; takes
     *        two arguments: an error status (if any) and the response as a
     *        WBXML reader. If the server returned an empty response, the
     *        response argument is null.
     * @param aExtraParams (optional) an object containing any extra URL
     *        parameters that should be added to the end of the request URL
     * @param aExtraHeaders (optional) an object containing any extra HTTP
     *        headers to send in the request
     * @param aProgressCallback (optional) a callback to invoke with progress
     *        information, when available. Two arguments are provided: the
     *        number of bytes received so far, and the total number of bytes
     *        expected (when known, 0 if unknown).
     */
    postData: function(aCommand, aContentType, aData, aCallback, aExtraParams,
      aExtraHeaders, aProgressCallback) {
      // Make sure our command name is a string.
      if (typeof aCommand === 'number')
        aCommand = ASCP.__tagnames__[aCommand];

      if (!this.supportsCommand(aCommand)) {
        let error = new Error("This server doesn't support the command " +
          aCommand);
        console.error(error);
        aCallback(error);
        return;
      }

      // Build the URL parameters.
      let params = [
        ['Cmd', aCommand],
        ['User', this._username],
        ['DeviceId', this._deviceId],
        ['DeviceType', this._deviceType]
      ];
      if (aExtraParams) {
        for (let param of params) {
          if (param[0] in aExtraParams)
            throw new TypeError('reserved URL parameter found');
        }

        for (let key in aExtraParams)
          params.push([key, aExtraParams[key]]);
      }
      let paramsStr = params.map(function(i) {
        return encodeURIComponent(i[0]) + '=' + encodeURIComponent(i[1]);
      }).join('&');

      // Now it's time to make our request!
      let xhr = new XMLHttpRequest({mozSystem: true, mozAnon: true});
      xhr.open('POST', this.baseUrl + '?' + paramsStr, true);
      setAuthHeader(xhr, this._username, this._password);
      xhr.setRequestHeader('MS-ASProtocolVersion', this.currentVersion);
      xhr.setRequestHeader('Content-Type', aContentType);
      xhr.setRequestHeader('User-Agent', USER_AGENT);
      // xhr.setRequestHeader('X-MS-PolicyKey', this.policyKey);

      // Add extra headers if we have any.
      if (aExtraHeaders) {
        for (let iter in aExtraHeaders) {
          let key = iter, value = aExtraHeaders[iter];
          xhr.setRequestHeader(key, value);
        }
      }

      xhr.timeout = this.timeout;

      xhr.upload.onprogress = xhr.upload.onload = function() {
        xhr.timeout = 0;
      };
      xhr.onprogress = function(event) {
        if (aProgressCallback)
          aProgressCallback(event.loaded, event.total);
      };

      let conn = this;
      let parentArgs = arguments;
      xhr.onload = function() {
        // This status code is a proprietary Microsoft extension used to
        // indicate a redirect, not to be confused with the draft-standard
        // "Unavailable For Legal Reasons" status. More info available here:
        // <http://msdn.microsoft.com/en-us/library/gg651019.aspx>
        if (xhr.status === 451) {
          conn.baseUrl = xhr.getResponseHeader('X-MS-Location');
          if (conn.onmessage)
            conn.onmessage(aCommand, 'redirect', xhr, params, aExtraHeaders,
              aData, null);
          conn.postData.apply(conn, parentArgs);
          return;
        }

        if (xhr.status < 200 || xhr.status >= 300) {
          console.error('ActiveSync command ' + aCommand + ' failed with ' +
            'response ' + xhr.status);
          if (conn.onmessage)
            conn.onmessage(aCommand, 'error', xhr, params, aExtraHeaders,
              aData, null);
          aCallback(new HttpError(xhr.statusText, xhr.status));
          return;
        }

        let response = null;
        if (xhr.response.byteLength > 0)
          response = new WBXML.Reader(new Uint8Array(xhr.response), ASCP);
        if (conn.onmessage)
          conn.onmessage(aCommand, 'ok', xhr, params, aExtraHeaders,
            aData, response);
        aCallback(null, response);
      };

      xhr.ontimeout = xhr.onerror = function(evt) {
        let error = new Error('Command URL ' + evt.type + ' for command ' +
          aCommand + ' at baseUrl ' + this.baseUrl);
        console.error(error);
        if (conn.onmessage)
          conn.onmessage(aCommand, evt.type, xhr, params, aExtraHeaders,
                         aData, null);
        aCallback(error);
      }.bind(this);

      xhr.responseType = 'arraybuffer';
      xhr.send(aData);
    },

    getSynckey: function(aCallback) {
      let as = ASCP.AirSync.Tags;
      let w = new WBXML.Writer('1.3', 1, 'UTF-8');
      w.stag(as.Sync)
        .stag(as.Collections)
          .stag(as.Collection)
            .tag(as.SyncKey, '0')
            .tag(as.CollectionId, this.CollectionId)
          .etag()
        .etag()
      .etag();
      this.postCommand(w, aCallback);
    },

    enforcement: function(aCallback) {
      let fh = ASCP.FolderHierarchy.Tags;
      let w = new WBXML.Writer('1.3', 1, 'UTF-8');
      w.stag(fh.FolderSync)
          .tag(fh.SyncKey, '0')
        .etag();
      this.postCommand(w, aCallback);
    },

    syncData: function(aCallback) {
      let as = ASCP.AirSync.Tags;
      let asb = ASCP.AirSyncBase.Tags;
      let type = ASCP.AirSyncBase.Enums.Type;
      let w = new WBXML.Writer('1.3', 1, 'UTF-8');
      w.stag(as.Sync)
        .stag(as.Collections)
          .stag(as.Collection)
            .tag(as.SyncKey, this.SyncKey)
            .tag(as.CollectionId, this.CollectionId)
            .tag(as.DeletesAsMoves)
            .tag(as.GetChanges)
            .stag(as.Options)
              .stag(asb.BodyPreference)
                .tag(asb.Type, type.PlainText)
              .etag()
            .etag()
          .etag()
        .etag()
      .etag();
      this.postCommand(w, aCallback);
    },

    getSyncData: function (callback, contacts = [[], []]) {
      let moreAvailable = false;
      this.syncData((aError, aResponse) => {
        const errorStr = 'Error get contacts data: ';
        if (aError) {
          console.error(errorStr, aError);
          return this._notifyConnected(aError);
        }

        let e = new WBXML.EventParser();
        let as = ASCP.AirSync.Tags;
        let asb = ASCP.AirSyncBase.Tags;
        let asEnum = ASCP.AirSync.Enums;
        let type = ASCP.AirSyncBase.Enums.Type;
        let base = [as.Sync, as.Collections, as.Collection];
        let tContacts = contacts;
        let aContacts = tContacts[0];
        let dContacts = tContacts[1];
        let status;

        if (!aResponse) {
          console.log('Sync completed with empty response');
          callback(tContacts);
          return;
        }

        e.addEventListener(base.concat(as.SyncKey), (node) => {
          this.SyncKey = node.children[0].textContent;
        });

        e.addEventListener(base.concat(as.MoreAvailable), () => {
          moreAvailable = true;
        });

        e.addEventListener(base.concat(as.Status), (node) => {
          status = node.children[0].textContent;
        });

        e.addEventListener(base.concat(as.Commands,
          [[as.Add, as.Change]]), (node) => {
          let contactData = {};
          let guid;

          for (let child of node.children) {
            switch (child.tag) {
              case as.ServerId:
                guid = child.children[0].textContent;
                break;
              case as.ApplicationData:
                for (let childData of child.children) {
                  if (!childData.children[0]) {
                    contactData[childData.localTagName] = null;
                  } else {
                    // Todo: ActiveSync 2.5 contact note sync
                    // ActiveSync 12.0+
                    if (childData.tag === asb.Body) {
                      let bNote = true;
                      for (let grandchild of childData.children) {
                        switch (grandchild.tag) {
                          case asb.Type:
                            bNote = type.PlainText === grandchild.children[0].textContent;
                            break;
                          case asb.Data:
                            if (bNote) {
                              contactData[childData.localTagName] = grandchild.children[0].textContent;
                            }
                            break;
                        }
                      }
                    } else {
                      contactData[childData.localTagName] = childData.children[0].textContent;
                    }
                  }
                }
                break;
            }
          }
          contactData.guid = guid;
          aContacts.push(contactData);
        });

        e.addEventListener(base.concat(as.Commands, [[as.Delete, as.SoftDelete]]),
          (node) => {
          let contactData = {};
          let guid;

          for (let child of node.children) {
            switch (child.tag) {
              case as.ServerId:
                guid = child.children[0].textContent;
                break;
            }
          }
          contactData.guid = guid;
          dContacts.push(contactData);
        });

        try {
          e.run(aResponse);
        }
        catch (ex) {
          console.error(errorStr, ex);
        }
        if (status === asEnum.Status.Success) {
          if (moreAvailable) {
            this.getSyncData(callback, tContacts);
          } else {
            callback(tContacts);
          }
        }
      });
    },

    updateContactData: function(data, aCallback) {
      let as = ASCP.AirSync.Tags;
      let asb = ASCP.AirSyncBase.Tags;
      let cn = ASCP.Contacts.Tags;
      let type = ASCP.AirSyncBase.Enums.Type;
      let w = new WBXML.Writer('1.3', 1, 'UTF-8');
      let cTag = data.guid ? as.Change : as.Add;
      let uId = data.guid ? as.ServerId : as.ClientId;
      let uValue = data.guid ? data.guid : Date.now().toString()+'@kaigaia';

      w.stag(as.Sync)
        .stag(as.Collections)
          .stag(as.Collection)
            .tag(as.SyncKey, this.SyncKey)
            .tag(as.CollectionId, this.CollectionId)
            .stag(as.Commands)
              .stag(cTag)
                .tag(uId, uValue)
                .stag(as.ApplicationData)
                  for (let item in data) {
                    if (data.hasOwnProperty(item) && cn[item]) {
                      if (item === 'Body') {
                        w.stag(asb[item])
                          w.tag(asb.Type, type.PlainText)
                          w.tag(asb.Data, data[item])
                        w.etag()
                      } else if (item !== 'guid') {
                        w.tag(cn[item], data[item])
                      }
                    }
                  }
                w.etag()
              .etag()
            .etag()
          .etag()
        .etag()
      .etag();
      this.postCommand(w, aCallback);
    },

    updateData: function(data, callback) {
      this.updateContactData(data, (aError, aResponse) => {
        const errorStr = 'Error update contact for ActiveSync: ';
        if (aError) {
          console.error(errorStr, aError);
          return this._notifyConnected(aError);
        }

        let e = new WBXML.EventParser();
        let as = ASCP.AirSync.Tags;
        let base = [as.Sync, as.Collections, as.Collection];
        let result = {};

        e.addEventListener(base.concat(as.SyncKey), (node) => {
          this.SyncKey = node.children[0].textContent;
          callback(result);
        });

        e.addEventListener(base.concat(as.Commands,
            [[as.Add, as.Change]]), (node) => {
          let guid;

          for (let child of node.children) {
            switch (child.tag) {
              case as.ServerId:
                guid = child.children[0].textContent;
                break;
            }
          }
          result.guid = guid;
          callback(result);
        });

        try {
          e.run(aResponse);
        }
        catch (ex) {
          console.error(errorStr, ex);
          callback(null, ex);
        }
      });
    },

    deleteContactData: function(data, aCallback) {
      let as = ASCP.AirSync.Tags;
      let w = new WBXML.Writer('1.3', 1, 'UTF-8');

      w.stag(as.Sync)
        .stag(as.Collections)
          .stag(as.Collection)
            .tag(as.SyncKey, this.SyncKey)
            .tag(as.CollectionId, this.CollectionId)
            .tag(as.DeletesAsMoves)
            .tag(as.GetChanges)
            .stag(as.Commands)
              .stag(as.Delete)
                .tag(as.ServerId, data.guid)
              .etag()
            .etag()
          .etag()
        .etag()
      .etag();
      this.postCommand(w, aCallback);
    },

    deleteData: function(data, callback) {
      this.deleteContactData(data, (aError, aResponse) => {
        const errorStr = 'Error delete contact for ActiveSync: ';
        if (aError) {
          console.error(errorStr, aError);
          return this._notifyConnected(aError);
        }

        let e = new WBXML.EventParser();
        let as = ASCP.AirSync.Tags;
        let base = [as.Sync, as.Collections, as.Collection];

        e.addEventListener(base.concat(as.SyncKey), (node) => {
          this.SyncKey = node.children[0].textContent;
          callback();
        });

        try {
          e.run(aResponse);
        }
        catch (ex) {
          console.error(errorStr, ex);
          callback(ex);
        }
      });
    }
  };

  return exports;
});
