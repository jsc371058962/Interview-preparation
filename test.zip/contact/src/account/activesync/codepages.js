/* Copyright 2012 Mozilla Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

define(function(require, exports, module) {  
  'use strict';
  var WBXML = require('./wbxml/wbxml');
  var Common = require('./codepages/Common');
  var AirSync = require('./codepages/AirSync');
  var Contacts = require('./codepages/Contacts');
  var Email = require('./codepages/Email');
  var Calendar = require('./codepages/Calendar');
  var Move = require('./codepages/Move');
  var ItemEstimate = require('./codepages/ItemEstimate');
  var FolderHierarchy = require('./codepages/FolderHierarchy');
  var MeetingResponse = require('./codepages/MeetingResponse');
  var Tasks = require('./codepages/Tasks');
  var ResolveRecipients = require('./codepages/ResolveRecipients');
  var ValidateCert = require('./codepages/ValidateCert');
  var Contacts2 = require('./codepages/Contacts2');
  var Ping = require('./codepages/Ping');
  var Provision = require('./codepages/Provision');
  var Search = require('./codepages/Search');
  var GAL = require('./codepages/GAL');
  var AirSyncBase = require('./codepages/AirSyncBase');
  var Settings = require('./codepages/Settings');
  var DocumentLibrary = require('./codepages/DocumentLibrary');
  var ItemOperations = require('./codepages/ItemOperations');
  var ComposeMail = require('./codepages/ComposeMail');
  var Email2 = require('./codepages/Email2');
  var Notes = require('./codepages/Notes');
  var RightsManagement = require('./codepages/RightsManagement');

  var codepages = {
    Common: Common,
    AirSync: AirSync,
    Contacts: Contacts,
    Email: Email,
    Calendar: Calendar,
    Move: Move,
    ItemEstimate: ItemEstimate,
    FolderHierarchy: FolderHierarchy,
    MeetingResponse: MeetingResponse,
    Tasks: Tasks,
    ResolveRecipients: ResolveRecipients,
    ValidateCert: ValidateCert,
    Contacts2: Contacts2,
    Ping: Ping,
    Provision: Provision,
    Search: Search,
    GAL: GAL,
    AirSyncBase: AirSyncBase,
    Settings: Settings,
    DocumentLibrary: DocumentLibrary,
    ItemOperations: ItemOperations,
    ComposeMail: ComposeMail,
    Email2: Email2,
    Notes: Notes,
    RightsManagement: RightsManagement
  };

  WBXML.CompileCodepages(codepages);

  return codepages;
});