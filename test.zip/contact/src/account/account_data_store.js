/**
 * Store account data that needs to be cahced in localStorage.
 */
class AccountDataStore {
  _accountId = '';

  _shouldShowContacts = true;
  _shouldSyncContacts = true;

  // Map mozContact id to the raw contact data we need(partial)
  // We don't store full cloud data in local(since that would be complicated for syncing),
  // instead, manually sync data to cloud when need.
  _contactMap = {};

  // account props to be cached
  _propMap = {};

  _syncKey;

  constructor(accountId, authenticatorId) {
    this._accountId = accountId;
    this._authenticatorId = authenticatorId;

    this._cache = cacheFactory(`AccountDataStore#${accountId}`);
    const cacheObj = this._cache.get();
    if (cacheObj) {
      // restore cache
      const {
        _shouldShowContacts,
        _shouldSyncContacts,
        _propMap,
        _contactMap,
        _syncKey,
      } = cacheObj;
      this._shouldShowContacts = _shouldShowContacts;
      this._shouldSyncContacts = _shouldSyncContacts;
      this._propMap = _propMap;
      this._contactMap = _contactMap;
      this._syncKey = _syncKey;
    }
  }

  updateCache() {
    this._cache.save({
      _shouldShowContacts: this._shouldShowContacts,
      _shouldSyncContacts: this._shouldSyncContacts,
      _propMap: this._propMap,
      _contactMap: this._contactMap,
      _syncKey: this._syncKey,
    });
  }

  clearCache() {
    this._cache.clear();
  }

  get shouldShowContacts() {
    return this._shouldShowContacts;
  }
  set shouldShowContacts(value) {
    this._shouldShowContacts = value;
    this.updateCache();
  }

  // this getter sync status is not real time but the cache.
  get shouldSyncContacts() {
    return this._shouldSyncContacts;
  }
  set shouldSyncContacts(value) {
    this._shouldSyncContacts = value;
    this.setSyncStatus(this._accountId, this._authenticatorId, value);
    this.updateCache();
  }

  setSyncStatus(accountId, authenticatorId, status) {
    return new Promise(function(resolve) {
      SettingsObserver.getValue('contactsSyncEnable').then(result => {
        const syncKey = `${authenticatorId}:${accountId}`;
        const syncValue = result;
        if (syncValue[syncKey] === status) {
          return resolve(syncValue);
        }
        syncValue[syncKey] = status;
        return SettingsObserver.setValue([
          { name: 'contactsSyncEnable', value: syncValue },
        ]).then(() => {
          resolve(syncValue);
        });
      });
    });
  }

  getProp(key) {
    return this._propMap[key];
  }
  setProp(key, value) {
    this._propMap[key] = value;
  }

  getContact(contactId) {
    return this._contactMap[contactId];
  }
  setContact(contactId, obj) {
    this._contactMap[contactId] = obj;
  }
  removeContact(contactId) {
    delete this._contactMap[contactId];
  }

  get syncKey() {
    return this._syncKey;
  }
  set syncKey(value) {
    this._syncKey = value;
  }

  /**
   * @retrun {string} - The contactId
   */
  findOneContact(filterCallback) {
    let result = '';
    Object.entries(this._contactMap).some(([contactId, obj]) => {
      const hit = filterCallback(obj);
      if (hit) result = contactId;
      return hit;
    });
    return result;
  }

  hasContact(contactId) {
    return !!this._contactMap[contactId];
  }

  get contactIds() {
    return Object.keys(this._contactMap);
  }
}

// Create a simple localStorage controller object
function cacheFactory(key) {
  return {
    save: jsonObj => {
      try {
        localStorage.setItem(key, JSON.stringify(jsonObj));
      } catch (e) {
        console.error(`localStorage:set ${key} value error: ${e}`);
      }
    },
    get: () => {
      const cache = localStorage.getItem(key);
      return cache ? JSON.parse(cache) : false;
    },
    clear: () => {
      window.localStorage.removeItem(key);
    },
  };
}

export default AccountDataStore;
