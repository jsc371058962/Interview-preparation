import React from 'react';
import BaseComponent from 'base-component';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import SoftKeyManager from 'modules/soft_key_manager';
import ListItem from 'components/list_item';
import {
  accountStore,
  logout,
  isSyncEnabled,
  operateSync,
  SYNC_OPERATION,
} from 'account/account_manager';
import Utils from 'contact_utils';

const _ = window.api.l10n.get;
const PAGE_STATUS = {
  LOADING: 'loading',
  CAN_SYNC: 'canSync',
  CAN_NOT_SYNC: 'canNotSync',
  VERIFICATION_FAILED: 'verificationFailed',
  DELETING: 'deleting',
};

export default class AccountInfo extends BaseComponent {
  name = 'AccountInfo';

  DEBUG = false;

  static defaultProps = {
    authenticatorId: '',
    accountId: '',
  };

  constructor(props) {
    super(props);
    this.debug('constructor:');
    this._account = accountStore.getAccountById(props.accountId);

    this.state = {
      pageStatus: PAGE_STATUS.LOADING,
      shouldShowContacts: this._account.store.shouldShowContacts,
      shouldSyncContacts: isSyncEnabled(this._account),
    };

    // to prevent changing pageStatus when deleting
    this._deletingLock = false;
    Utils.handleNetworkEvent.call(this, 'add');
  }

  handleNetwork = evt => {
    if (navigator.connection) {
      !evt.detail && Service.request('back');
    } else {
      !navigator.onLine && Service.request('back');
    }
  };

  componentDidMount() {
    this.debug('did mount');

    this.navigator = new SimpleNavigationHelper(
      '.navigable:not(.disabled)',
      this.element
    );
    this._softKey = SoftKeyManager.create(this.element, {
      left: 'delete-account',
    });

    if (!Utils.isOnLine()) {
      Service.request('offlineCallback');
      return;
    }

    this._account
      .isValid(this._account)
      .then(() => {
        this._updatePageStatus(
          this.state.shouldSyncContacts
            ? PAGE_STATUS.CAN_SYNC
            : PAGE_STATUS.CAN_NOT_SYNC
        );
      })
      .catch(() => {
        this.debug('account invalid');
        this._updatePageStatus(PAGE_STATUS.VERIFICATION_FAILED);
      });
  }

  componentWillUnmount() {
    this.debug('will unmount');
    this._softKey.destroy();
    Utils.handleNetworkEvent.call(this, 'remove');
    if (
      this._account.store.shouldShowContacts !== this.state.shouldShowContacts
    ) {
      this._account.store.shouldShowContacts = this.state.shouldShowContacts;
      accountStore.set(this._account);
      Service.request('ToastManager:show', {
        text: _('changes-saved'),
      });
      Service.request('List:reload');
    }
  }

  onKeyDown = evt => {
    const actionType = document.activeElement.dataset.actionType;
    switch (evt.key) {
      case 'Enter':
        if ('toggleShowing' === actionType) {
          this.setState(
            {
              shouldShowContacts: !this.state.shouldShowContacts,
            },
            () => {
              this.updateSoftKeys();
            }
          );
          return;
        }
        if ('toggleSyncing' === actionType) {
          const updateSyncContacts = () => {
            this.setState(
              {
                shouldSyncContacts: !this.state.shouldSyncContacts,
              },
              () => {
                this._account.store.shouldSyncContacts = this.state.shouldSyncContacts;
                this._updatePageStatus(
                  this.state.shouldSyncContacts
                    ? PAGE_STATUS.CAN_SYNC
                    : PAGE_STATUS.CAN_NOT_SYNC
                );
              }
            );
          };

          if (this.state.shouldSyncContacts) {
            Service.request('showDialog', {
              header: _('sync-title'),
              content: _('sync-account-contacts-warning', {
                switch: _('sync-account-contacts'),
              }),
              translated: true,
              ok: 'yes',
              onOk: () => {
                updateSyncContacts();
              },
            });
          } else {
            updateSyncContacts();
          }
          return;
        }
        if ('reEnterPassword' === actionType) {
          this._reEnterPassword();
          return;
        }
        break;
      case 'SoftRight':
        if (this.state.pageStatus === PAGE_STATUS.CAN_SYNC) {
          this._sync();
        }
        break;
      case 'SoftLeft':
        if (this._deletingLock) {
          break;
        }
        Service.request('showDialog', {
          header: 'delete-account-long',
          content: 'delete-account-warn',
          ok: 'delete',
          onOk: () => {
            this._deleteAccount().then(() => {
              Service.request('ToastManager:show', {
                text: _('delete-account-ok'),
              });
              Service.request('back');
            });
          },
        });
        break;
      case 'Backspace':
        if (this._deletingLock) {
          break;
        }
        Service.request('back');
        break;
      default:
        return;
    }
    evt.preventDefault();
    evt.stopPropagation();
  };

  _sync() {
    if (!isSyncEnabled(this._account)) {
      Service.request('showDialog', {
        header: _('sync-title'),
        type: 'alert',
        content: [_('sync-failed-warn'), _('sync-off-warn')].join('\n'),
        translated: true,
      });
      return;
    }

    Service.request('ToastManager:show', {
      text: _('contact-syncing'),
    });

    operateSync(SYNC_OPERATION.PULL, { account: this._account });
  }

  _deleteAccount() {
    // if deleting fail, we need fall back previous status
    const lastPageStatus = this.state.pageStatus;
    this._updatePageStatus(PAGE_STATUS.DELETING);

    this._deletingLock = true;
    return this._account
      .reset()
      .then(() => {
        return logout(this._account);
      })
      .then(() => {
        this._deletingLock = false;
        return true;
      })
      .catch(e => {
        this._deletingLock = false;
        this._updatePageStatus(lastPageStatus);
        console.error('[AccountInfo] delete account error:', e);
        Service.request('ToastManager:show', {
          text: _('delete-account-failed'),
        });
        throw e;
      });
  }

  _reEnterPassword() {
    Service.request('popup', '/account/change-password', {
      accountId: this._account.accountId,
      authenticatorId: this._account.authenticatorId,
      invalidPassword:
        this.state.pageStatus === PAGE_STATUS.VERIFICATION_FAILED,
    }).then(result => {
      if (result[0] && result[0].invalidPassword) {
        this._updatePageStatus(PAGE_STATUS.VERIFICATION_FAILED);
      } else {
        this._updatePageStatus(PAGE_STATUS.CAN_SYNC);
      }
    });
  }

  _updatePageStatus(pageStatus) {
    if (this._deletingLock) return;

    this.setState(
      {
        pageStatus,
      },
      () => {
        this.focus();
      }
    );
    // bind pageStatus with its own softKey
    this.updateSoftKeys(pageStatus);
  }

  updateSoftKeys(status) {
    if (status && PAGE_STATUS.DELETING === status) {
      return;
    }
    if (!status && PAGE_STATUS.DELETING === this.state.pageStatus) {
      this._softKey.update({});
      return;
    }
    const actionType = document.activeElement.dataset.actionType;
    const config = { left: 'delete-account' };
    config.right =
      this.state.shouldSyncContacts &&
      PAGE_STATUS.VERIFICATION_FAILED !== this.state.pageStatus
        ? 'sync'
        : '';
    switch (actionType) {
      case 'toggleShowing':
        config.center = this.state.shouldShowContacts ? 'deselect' : 'select';
        break;
      case 'toggleSyncing':
        config.center = this.state.shouldSyncContacts ? 'deselect' : 'select';
        break;
      case 'reEnterPassword':
        config.center = 'select';
        break;
      default:
        config.right = '';
        break;
    }
    this._softKey.update(config);
  }

  onFocus = () => {
    this.updateSoftKeys();
  };

  render() {
    const { accountId, authenticatorId } = this.props;
    const { pageStatus } = this.state;

    // set UI for different pageStatus
    let items = [
      <ListItem
        key="show-account-contacts"
        primaryId="show-account-contacts"
        data-action-type="toggleShowing"
        rightIcon={this.state.shouldShowContacts ? 'check-on' : 'check-off'}
      />,
      <ListItem
        key="sync-account-contacts"
        primaryId="sync-account-contacts"
        data-action-type="toggleSyncing"
        rightIcon={this.state.shouldSyncContacts ? 'check-on' : 'check-off'}
      />,
    ];

    'activesync' === authenticatorId &&
      items.push(
        <ListItem
          key="re-enter-password"
          primaryId="re-enter-password"
          data-action-type="reEnterPassword"
        />
      );

    if (pageStatus === PAGE_STATUS.LOADING) {
      items.push(
        <ListItem
          key="loading"
          primaryId="loading"
          isLoading
          navigable={false}
        />
      );
    } else if (pageStatus === PAGE_STATUS.VERIFICATION_FAILED) {
      items.push(
        <ListItem key="accessing-warn" multiLine>
          <span className="warn" data-l10n-id="accessing-warn" />{' '}
          <span
            className="warn"
            data-l10n-id={
              'activesync' === authenticatorId
                ? 'accessing-warn-password'
                : 'accessing-warn-relogin'
            }
          />
        </ListItem>
      );
    } else if (pageStatus === PAGE_STATUS.DELETING) {
      const progressDOM = (
        <div className="progress" data-infinite="true">
          <div className="progress-active" />
        </div>
      );
      items = (
        <div className="list-item text" tabIndex="-1">
          <div className="content">
            <div className="primary" data-l10n-id="deleting-account" />
            {progressDOM}
          </div>
        </div>
      );
    }

    return (
      <div
        ref={e => {
          this.element = e;
        }}
        tabIndex="-1"
        className="account-info"
        onKeyDown={this.onKeyDown}
        onFocus={this.onFocus}
      >
        <div className="header h1">{accountId}</div>
        {items}
      </div>
    );
  }
}
