import React from 'react';
import BaseComponent from 'base-component';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import SoftKeyManager from 'modules/soft_key_manager';
import ListItem from 'components/list_item';
import {
  authenticatorIds,
  showLoginPage,
  operateSync,
  SYNC_OPERATION,
} from 'account/account_manager';
import Utils from 'contact_utils';

const _ = window.api.l10n.get;

export default class AccountAdding extends BaseComponent {
  name = 'AccountAdding';

  DEBUG = false;

  constructor(props) {
    super(props);
    this.debug('constructor:');

    this.state = {
      onLoginPage: false,
    };
  }

  componentDidMount() {
    this.debug('did mount');
    this.navigator = new SimpleNavigationHelper(
      '.navigable:not(.disabled)',
      this.element
    );
    this._softKey = SoftKeyManager.create(this.element, {
      left: 'cancel',
      center: 'select',
    });
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  onKeyDown = evt => {
    if (this.state.onLoginPage) {
      return;
    }
    switch (evt.key) {
      case 'Enter':
        if (!Utils.isOnLine()) {
          Service.request('offlineCallback');
          return;
        }
        this._setOnLoginPage();
        break;
      case 'SoftLeft':
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('back');
        break;
      default:
        break;
    }
  };

  _setOnLoginPage() {
    this.setState(
      {
        onLoginPage: true,
      },
      () => {
        this.focus();
      }
    );

    const authenticatorId = document.activeElement.dataset.actionType;
    showLoginPage({ authenticatorId })
      .then(() => 'leavePage')
      .catch(e => {
        if ('duplicate_account' === e) {
          Service.request('ToastManager:show', {
            text: _('duplicate-account-warn'),
          });
          return operateSync(SYNC_OPERATION.PULL_ALL).then(() => 'leavePage');
        }
        return true;
      })
      .then(result => {
        this.setState({
          onLoginPage: false,
        });
        'leavePage' === result && Service.request('back');
      });
  }

  componentDidUpdate() {
    this.debug('did update');
    const { onLoginPage } = this.state;
    this._softKey.update({
      left: onLoginPage ? '' : 'cancel',
      center: onLoginPage ? '' : 'select',
    });
  }

  render() {
    const { onLoginPage } = this.state;
    const items = authenticatorIds.map(authenticatorId => {
      if (
        Service.query('isLowMemoryDevice') &&
        'activesync' === authenticatorId
      ) {
        return '';
      }
      return (
        <ListItem key={authenticatorId} data-action-type={authenticatorId}>
          {// capitalize
          authenticatorId[0].toUpperCase() + authenticatorId.slice(1)}
        </ListItem>
      );
    });

    return (
      <div
        ref={e => {
          this.element = e;
        }}
        tabIndex="-1"
        className="account-adding"
        onKeyDown={this.onKeyDown}
      >
        <div className="header h1" data-l10n-id="add-account" />
        {onLoginPage ? (
          <ListItem
            primaryId="setting-up-account"
            navigable={false}
            isLoading
          />
        ) : (
          items
        )}
      </div>
    );
  }
}
