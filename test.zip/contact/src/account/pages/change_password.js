import React from 'react';
import BaseComponent from 'base-component';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import SoftKeyManager from 'modules/soft_key_manager';
import ListItem from 'components/list_item';
import InputItem from 'components/input_item';
import { changePassword } from 'account/account_manager';

const _ = window.api.l10n.get;

export default class AccountChangePassword extends BaseComponent {
  name = 'AccountChangePassword';

  DEBUG = false;

  static defaultProps = {
    authenticatorId: '',
    accountId: '',
    invalidPassword: false,
  };

  constructor(props) {
    super(props);
    this.debug('constructor:');
    this.state = {
      password: '',
      shouldShowPassword: false,
      invalidPassword: this.props.invalidPassword,
    };
  }

  componentDidMount() {
    this.debug('did mount');
    this.navigator = new SimpleNavigationHelper(
      '.navigable:not(.disabled)',
      this.element
    );
    this._softKey = SoftKeyManager.create(this.element, {
      left: 'cancel',
      right: 'save',
    });
    this.inputElement.setAttribute('x-inputmode', 'plain');
    this.navigator.setFocus(this.inputElement);
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  _changePassword() {
    this.setState({
      onChangingPassword: true,
    });
    const accountObj = {
      password: this.state.password,
      accountId: this.props.accountId,
      authenticatorId: this.props.authenticatorId,
    };
    changePassword(accountObj)
      .then(() => {
        this.setState(
          {
            onChangingPassword: false,
            invalidPassword: false,
          },
          this._goBack
        );
      })
      .catch(e => {
        Service.request('ToastManager:show', {
          text: _(e) || e,
        });
        this.setState({
          onChangingPassword: false,
          invalidPassword: 'password-incorrect' === e,
          password: '',
        });
      });
  }

  _goBack() {
    Service.request('back', {
      invalidPassword: this.state.invalidPassword,
    });
  }

  updateSoftKeys() {
    const actionType = document.activeElement.dataset.actionType;
    const config = {
      left: 'cancel',
      center: 'toggleShowPassword' === actionType ? 'select' : '',
      right: 'save',
    };
    this._softKey.update(config);
  }

  onKeyDown = evt => {
    const actionType = document.activeElement.dataset.actionType;
    if (this.state.onChangingPassword) {
      return;
    }
    switch (evt.key) {
      case 'Enter':
        if ('toggleShowPassword' === actionType) {
          this.setState({
            shouldShowPassword: !this.state.shouldShowPassword,
          });
        }
        break;
      case 'SoftRight':
        if (!this.state.password) {
          return;
        }
        this._changePassword();
        break;
      case 'SoftLeft':
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        this._goBack();
        break;
      default:
        break;
    }
  };

  get inputElement() {
    return this.element.querySelector('input');
  }

  onFocus = () => {
    this.updateSoftKeys();
  };

  render() {
    const { accountId } = this.props;
    const items = [
      <ListItem
        key="username"
        primaryId="username"
        data-action-type="username"
        secondaryLabel={accountId}
      />,
      <InputItem
        id="new-password"
        labelL10nId="password"
        ariaLabel="new-password"
        type={this.state.shouldShowPassword ? 'text' : 'password'}
        onChange={e => {
          this.setState({ password: e.target.value });
        }}
        value={this.state.password}
      />,
      <ListItem
        key="show-password"
        primaryId="show-password"
        data-action-type="toggleShowPassword"
        rightIcon={this.state.shouldShowPassword ? 'check-on' : 'check-off'}
      />,
    ];

    return (
      <div
        ref={e => {
          this.element = e;
        }}
        tabIndex="-1"
        className="account-change-password"
        onKeyDown={this.onKeyDown}
        onFocus={this.onFocus}
      >
        <div className="header h1" data-l10n-id="re-enter-password" />
        {items}
      </div>
    );
  }
}
