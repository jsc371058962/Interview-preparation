import { GOOGLE_TAG, CLOUD_TAG } from 'contact_wrapper';
import { TAG_INDEX } from '../contact_store';

/**
 * Transform mozContact to google contact object.
 * Skip `photo` for now.
 * This is a synchronous operation.
 * Google person object schema: https://developers.google.com/people/api/rest/v1/people#Person
 * @param {object} contact - a mozContact object
 * @return {object}
 */
export function mozContactToPerson(contact) {
  const { givenName, familyName, tel, email, org, adr, bday, note } = contact;

  const person = {};

  if (givenName || familyName) {
    const personName = {};
    if (givenName && givenName[0]) {
      personName.givenName = givenName[0];
    }
    if (familyName && familyName[0]) {
      personName.familyName = familyName[0];
    }
    person.names = [personName];
  }

  if (tel) {
    person.phoneNumbers = tel.map(v => ({
      type: v.type && v.type[0] ? v.type[0] : 'mobile',
      value: v.value,
    }));
  }

  if (email) {
    person.emailAddresses = email.map(v => ({
      type: v.type && v.type[0] ? v.type[0] : 'personal',
      value: v.value,
    }));
  }

  if (org) {
    person.organizations = org.map(v => ({
      name: v,
    }));
  }

  if (adr) {
    person.addresses = adr.map(v => ({
      streetAddress: v.streetAddress,
      city: v.locality,
      region: v.region,
      postalCode: v.postalCode,
      country: v.countryName,
      type: v.type && v.type[0] ? v.type[0] : 'home',
    }));
  }

  if (bday) {
    person.birthdays = [
      {
        text: bday.toLocaleDateString(),
      },
    ];
  }

  if (note) {
    person.biographies = note.map(v => ({
      value: v,
    }));
  }

  return person;
}

/**
 * Transform google people object to mozContact.
 * Skip `photos` for now.
 * This is a synchronous operation.
 * Google person object schema: https://developers.google.com/people/api/rest/v1/people#Person
 * @param {object} person - a google person object
 * @return {object} - a mozContact object
 */
export function personToMozContact(person, accountId) {
  console.log('[google_helper] (_personToMozContact) to transform:', person);

  Object.keys(person).forEach(f => {
    if (Array.isArray(person[f])) {
      // possible source type: https://developers.google.com/people/api/rest/v1/people#Person.SourceType
      // we only want data with source type `CONTACT`
      person[f] = person[f].filter(v => 'CONTACT' === v.metadata.source.type);
    }
  });

  const {
    names,
    phoneNumbers,
    emailAddresses,
    birthdays,
    biographies,
    organizations,
    addresses,
  } = person;

  const aContact = {};

  // transform field data
  names &&
    Object.assign(aContact, {
      name: names.map(v => v.displayName),
      givenName: names.map(v => v.givenName || ''),
      familyName: names.map(v => v.familyName || ''),
    });

  if (phoneNumbers) {
    aContact.tel = phoneNumbers.map(v => ({
      type: [v.type || 'mobile'],
      value: v.value,
    }));
  }

  if (emailAddresses) {
    aContact.email = emailAddresses.map(v => ({
      type: [v.type || 'personal'],
      value: v.value,
    }));
  }

  if (birthdays) {
    const date = birthdays[0].date;
    if (Date.parse(birthdays[0].text)) {
      aContact.bday = new Date(birthdays[0].text);
    } else if (date) {
      aContact.bday = new Date(date.year, date.month - 1, date.day);
    }
  }

  if (biographies) {
    aContact.note = biographies.map(v => v.value);
  }

  if (organizations) {
    aContact.org = organizations.map(v => v.name);
  }

  if (addresses) {
    aContact.adr = addresses.map(v => ({
      streetAddress: v.streetAddress,
      locality: v.city,
      region: v.region,
      postalCode: v.postalCode,
      countryName: v.country,
      type: [v.type],
    }));
  }

  // the `DEVICE` category indicates an account contact is saving to device(not SIM).
  // this will trigger contacts limit checking in contact_store.
  aContact.category = [
    CLOUD_TAG,
    accountId,
    GOOGLE_TAG,
    TAG_INDEX.phone,
    TAG_INDEX.kaiContact,
  ];
  const contact = Object.assign({}, aContact);
  console.log(
    '[google_helper] (_personToMozContact) transformed result:',
    contact
  );
  return contact;
}
