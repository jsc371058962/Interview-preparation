import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import ContactStore from './contact_store';
import GroupListItem from './group_list_item';

export default class GroupList extends BaseComponent {
  FOCUS_SELECTOR = '.list-item.navigable';

  constructor(props) {
    super(props);
    this.state = {
      group: ContactStore.getGroups(),
    };
    this.isPicker = Service.query('isActivity');
  }

  getConfig() {
    let config = {
      left: 'new-group',
      center: 'select',
      right: 'options',
    };
    if (this.isPicker) {
      config = {
        left: '',
        center: 'select',
        right: '',
      };
    }
    return config;
  }

  updateSoftKeys() {
    this._softKey.update(this.getConfig());
  }

  componentDidMount() {
    const config = this.getConfig();
    this.element = ReactDOM.findDOMNode(this);
    this._softKey = SoftKeyManager.create(this.element, config);

    this.onGroupChanged = () => {
      const groups = ContactStore.getGroups();
      if (groups.length) {
        this.setState({
          group: groups,
        });
      } else {
        Service.request('back');
      }
    };

    ContactStore.on('group-changed', this.onGroupChanged);

    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element
    );
  }

  componentWillUnmount() {
    this._softKey.destroy();
    ContactStore.off('group-changed', this.onGroupChanged);
  }

  onKeyDown(evt) {
    const id = document.activeElement.dataset.id;
    const name = document.activeElement.dataset.name;
    switch (evt.key) {
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('back', { isFromGroup: true });
        break;
      case 'SoftLeft':
        evt.preventDefault();
        evt.stopPropagation();
        if (this.isPicker) {
          break;
        }
        Service.request('showCreateGroupDialog');
        break;
      case 'Enter':
        if (!name) {
          break;
        }
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('push', `/group/${name}/${id}`);
        break;
      case 'SoftRight':
        if (!id) {
          break;
        }
        if (this.isPicker) {
          break;
        }
        const options = [
          {
            id: 'rename',
            callback: () => {
              Service.request('showCreateGroupDialog', {
                rename: true,
                id,
                initialValue: name,
              });
            },
          },
          {
            id: 'delete',
            callback: () => {
              const _ = window.window.api.l10n.get;
              Service.request('showDialog', {
                header: _('confirm'),
                content: _('delete-group', { group: name }),
                ok: 'delete',
                type: 'confirm',
                translated: true,
                onOk: () => {
                  ContactStore.removeGroup(id).then(() => {
                    const listItems = Array.from(
                      this.element.querySelectorAll(this.FOCUS_SELECTOR)
                    );
                    if (listItems.length) {
                      this.navigator.setFocus(listItems[0]);
                    }
                  });
                },
              });
            },
          },
          {
            id: 'settings',
            callback: () => {
              Service.request('push', '/setting');
            },
          },
        ];
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('showOptionMenu', {
          options,
          onCancel: () => {},
        });
        break;
      default:
        break;
    }
  }

  onFocus() {
    Service.request('ensureDialog');
    this.updateSoftKeys();
  }

  componentDidUpdate() {
    this.updateSoftKeys();
  }

  render() {
    const dom = [];
    this.state.group.forEach(item => {
      dom.push(<GroupListItem groupItem={item} />);
    });

    let header = 'group';
    if (this.isPicker) {
      header = 'select-a-contact';
    }

    return (
      <div
        className="group-list-view list-view"
        id="group-list-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onFocus={e => this.onFocus(e)}
      >
        <div className="header h1" data-l10n-id={header} />
        <div className="body">{dom}</div>
      </div>
    );
  }
}
