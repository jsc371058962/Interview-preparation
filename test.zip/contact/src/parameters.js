export default {
  facebook: {
    redirectURI: 'https://www.facebook.com/connect/login_success.html',
    loginPage: 'https://m.facebook.com/dialog/oauth/?',
    applicationId: '123456',
    scope: [
      'friends_about_me',
      'friends_birthday',
      'friends_hometown',
      'friends_location',
      'friends_work_history',
      'read_stream',
    ],
    redirectMsg:
      'http://intense-tundra-4122.herokuapp.com/fbowd/oauth2_new/dialogs_end.html',
    redirectLogout:
      'http://intense-tundra-4122.herokuapp.com/fbowd/oauth2_new/dialogs_end.html',
    imgDetailWidth: 200,
    imgThumbSize: 120,
  },
  // Microsoft Graph API OAuth flow: https://developer.microsoft.com/en-us/graph/docs/concepts/auth_v2_user
  // Request for contacts: https://developer.microsoft.com/en-us/graph/docs/api-reference/v1.0/api/user_list_contacts
  // REST APIs: https://docs.microsoft.com/en-us/outlook/rest/get-started
  // Appilication registration portal: https://apps.dev.microsoft.com
  live: {
    redirectURI: 'http://localhost/redirect/contact/redirect.html',
    loginPage:
      'https://login.microsoftonline.com/common/oauth2/v2.0/authorize?',
    applicationId: 'b350a264-2829-40d8-bf49-69112c5d4c7f',
    scope: ['contacts.read'],
    logoutUrl: 'https://login.live.com/logout.srf',
  },
  gmail: {
    redirectURI: 'http://localhost/redirect/contact/redirect.html',
    loginPage: 'https://accounts.google.com/o/oauth2/auth?',
    applicationId:
      '100183967378-i5vsj453tr6e6od88p6ijrtjqf8lakfe.apps.googleusercontent.com',
    scope: ['https://www.google.com/m8/feeds/'],
    logoutUrl: 'https://accounts.google.com/Logout',
  },
};
