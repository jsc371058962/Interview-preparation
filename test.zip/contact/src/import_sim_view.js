import React from 'react';
import ReactDOM from 'react-dom';
import Service from 'service';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import SimStore from './sim_store';

export default class ImportSimView extends BaseComponent {
  name = 'ImportSimView';

  constructor(props) {
    super(props);
    this.state = {
      saved: '',
      progress: 0,
      total: 0,
      error: false,
    };
  }

  componentDidMount() {
    const config = {
      left: 'cancel',
    };
    this.element = ReactDOM.findDOMNode(this);
    window.ssv = this;
    this._softKey = SoftKeyManager.create(this.element, config);
    this.import();
  }

  import() {
    SimStore.import(+this.props.index).then(importer => {
      this.importer = importer;

      importer.on('ready', () => {
        this.setState({
          total: importer.total,
        });
      });
      importer.on('imported', name => {
        this.setState({
          saved: name,
          progress: importer.imported,
        });
      });
      importer.on('finished', () => {
        Service.request('back');
      });
      importer.on('error', () => {
        this.setState({
          error: true,
        });
      });
    });
  }

  componentDidUpdate() {
    this.updateSoftKeys();
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  updateSoftKeys() {
    const config = {};
    if (this.state.error) {
      config.left = 'cancel';
      config.right = 'retry';
    } else {
      config.left = 'cancel';
    }
    this._softKey.update(config);
  }

  onKeyDown(e) {
    switch (e.key) {
      case 'SoftLeft':
      case 'EndCall':
      case 'Backspace':
        e && e.preventDefault();
        this.importer && this.importer.cancel();
        Service.request('back');
        break;
      case 'SoftRight':
        if (this.state.error) {
          this.setState({
            error: false,
          });
          this.importer && this.importer.import();
        }
        break;
      default:
        break;
    }
  }

  render() {
    let progressDOM = null;
    let divider = null;
    let importStatus = null;
    if (this.state.error) {
      importStatus = (
        <div className="primary" data-l10n-id="simContacts-error" />
      );
    } else if (this.state.total) {
      const progress = 100 * (this.state.progress / this.state.total);
      const activeStyle = { width: `${progress}%` };
      const inactiveStyle = { width: `calc(100% - ${progress}% - 0.3rem)` };
      progressDOM = (
        <div className="progress">
          <div className="progress-active" style={activeStyle} />
          <div className="progress-inactive" style={inactiveStyle} />
        </div>
      );
      divider = (
        <div className="secondary">
          {this.state.progress}/{this.state.total}
        </div>
      );
      importStatus = (
        <div className="primary" data-l10n-id="importing-contacts-from-sim" />
      );
    } else {
      importStatus = (
        <div className="primary" data-l10n-id="reading-contacts-from-sim" />
      );
    }
    return (
      <div tabIndex="-1" onKeyDown={e => this.onKeyDown(e)}>
        <div
          className="header h1"
          ref="header"
          data-l10n-id="importContactsTitle"
        />
        <div className="body">
          <div className="list-item" data-multi-line="true">
            <div className="content">
              {importStatus}
              {divider}
              {progressDOM}
            </div>
          </div>
        </div>
      </div>
    );
  }
}
