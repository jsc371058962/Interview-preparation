// Deep clone
export default function clone(x) {
  if (typeof x !== 'object') return x;

  let k;
  let tmp;
  const str = Object.prototype.toString.call(x);

  switch (str) {
    case '[object Object]':
      if (x.constructor !== Object && 'function' === typeof x.constructor) {
        tmp = new x.constructor();
        for (k in x) {
          // eslint-disable-next-line no-prototype-builtins
          if (tmp.hasOwnProperty(k) && tmp[k] !== x[k]) {
            tmp[k] = clone(x[k]);
          }
        }
      } else {
        tmp = {}; // null
        for (k in x) {
          if ('__proto__' === k) {
            Object.defineProperty(tmp, k, {
              value: clone(x[k]),
              configurable: true,
              enumerable: true,
              writable: true,
            });
          } else {
            tmp[k] = clone(x[k]);
          }
        }
      }
      return tmp;

    case '[object Array]':
      k = x.length;
      for (tmp = Array(k); k--; ) {
        tmp[k] = clone(x[k]);
      }
      return tmp;

    case '[object Set]':
      tmp = new Set();
      x.forEach(function(val) {
        tmp.add(clone(val));
      });
      return tmp;

    case '[object Map]':
      tmp = new Map();
      x.forEach(function(val, key) {
        tmp.set(clone(key), clone(val));
      });
      return tmp;

    case '[object Date]':
      return new Date(+x);

    case '[object RegExp]':
      tmp = new RegExp(x.source, x.flags);
      tmp.lastIndex = x.lastIndex;
      return tmp;

    case '[object DataView]':
      return new x.constructor(clone(x.buffer));

    case '[object ArrayBuffer]':
      return x.slice(0);
    default:
      break;
  }

  // ArrayBuffer.isView(x)
  // ~> `new` bcuz `Buffer.slice` => ref
  if ('Array]' === str.slice(-6)) {
    return new x.constructor(x);
  }

  return x;
}
