import BaseModule from 'base-module';

class RttSettings extends BaseModule {
  name = 'RttSettings';
  DEBUG = false;
  CONFIG_MANUAL = 'always-visible-manual';
  CONFIG_AUTOMATIC = 'always-visible-automatic';
  CONFIG_VISIBLE = 'visible-during-calls';

  _value = undefined;
  lastValue = undefined;

  constructor() {
    super();
    // get rtt setting ENABLED status must on the behind of PREFERRED.
    SettingsObserver.observe(
      'ril.rtt.preferredSettings',
      undefined,
      this['_observe_ril.rtt.preferredSettings'].bind(this)
    );
    SettingsObserver.observe(
      'ril.rtt.enabled',
      undefined,
      this['_observe_ril.rtt.enabled'].bind(this)
    );
  }

  get value() {
    return this._value;
  }

  '_observe_ril.rtt.preferredSettings'(value) {
    this.debug('detect rttSettings changed:', value);
    this._value = value;
    this.lastValue = value;
  }

  '_observe_ril.rtt.enabled'(value) {
    this.debug('detect rtt_enabled changed:', value);
    if (value) {
      this._value = this.lastValue;
    } else {
      this._value = this.CONFIG_VISIBLE;
    }
  }
}

const RTTSettings = new RttSettings();

window.RTTSettings = RTTSettings;

export default RTTSettings;
