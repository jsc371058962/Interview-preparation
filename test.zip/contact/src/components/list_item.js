import React from 'react';
import 'list_item.scss';

/**
 * Generic stateless component as an one row list item.
 * XXX: replace all .list-item elements with this
 */
const ListItem = props => {
  const {
    disabled,
    navigable = true,
    itemType = 'text',
    primaryId,
    secondaryId,
    secondaryLabel,
    secondaryAsTitle = false,
    rightIcon = '',
    isLoading,
    multiLine = false,
    children,
  } = props;

  // bypass the standard data-* attributes
  const dataset = {};
  Object.keys(props).forEach(value => {
    if (0 === value.indexOf('data-')) {
      dataset[value] = props[value];
    }
  });

  const disabledClass = disabled ? 'disabled' : '';
  const navigableClass = navigable ? 'navigable' : '';
  const multiLineClass = multiLine ? 'multi-line' : '';
  const primaryContent = (
    <div className="primary" data-l10n-id={primaryId}>
      {children}
    </div>
  );
  const secondaryContent = (
    <div className="secondary" data-l10n-id={secondaryId}>
      {secondaryLabel}
    </div>
  );
  return (
    <div
      className={`list-item ${navigableClass} ${disabledClass} ${multiLineClass} ${itemType}`}
      tabIndex="-1"
      {...dataset}
    >
      {isLoading ? <div className="loading-container" /> : null}
      <div className="content">
        {secondaryAsTitle ? secondaryContent : null}
        {primaryContent}
        {secondaryAsTitle ? null : secondaryContent}
      </div>
      {rightIcon ? <i data-icon={rightIcon} className="icon" /> : null}
    </div>
  );
};

export default ListItem;
