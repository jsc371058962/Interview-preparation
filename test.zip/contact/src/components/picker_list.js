import React from 'react';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import ContactList from './contact_list';

export default class PickerList extends BaseComponent {
  name = 'PickerList';
  DEBUG = false;

  static defaultProps = {
    target: '',
    tel: '',
    email: '',
  };

  constructor(props) {
    super(props);
    this.debug('constructor:');
  }

  componentDidMount() {
    this.debug('did mount');
    this._softKey = SoftKeyManager.create(this.element, {
      left: 'cancel',
      center: 'select',
      right: 'view',
    });
  }

  onKeyDown = e => {
    switch (e.key) {
      case 'Enter':
        break;
      case 'SoftRight':
        break;
      default:
        break;
    }
  };

  componentWillUnmount() {
    this._softKey.destroy();
  }

  render() {
    const itemProps = Object.assign({}, this.props);
    if (this.props.filter) {
      const contacts = [];
      this.props.contacts.forEach(contact => {
        if ('tel' === this.props.target || 'email' === this.props.target) {
          if (contact[this.props.target]) {
            contacts.push(contact);
          }
        } else if ('tel,email' === this.props.target) {
          if (contact.tel || contact.email) {
            contacts.push(contact);
          }
        } else {
          contacts.push(contact);
        }
      });
      itemProps.contacts = contacts;
    }
    return (
      <div
        className="picker-list"
        ref={e => {
          this.element = e;
        }}
        onKeyDown={this.onKeyDown}
      >
        <ContactList {...itemProps} />
      </div>
    );
  }
}
