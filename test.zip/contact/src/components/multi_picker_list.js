import React from 'react';
import BaseComponent from 'base-component';
import Service from 'service';
import SelectionList from 'components/selection_list';
import ContactListItem from './contact_list_item';

export default class MultiPickerList extends BaseComponent {
  name = 'MultiPickerList';
  DEBUG = false;

  _selectedMap = {};
  _maxCount = Service.query('isLowMemoryDevice') ? 20 : 50;

  static defaultProps = {
    contacts: [],
    selectMode: '',
    isSearching: false,
    onSelectionChange: () => {},
  };

  constructor(props) {
    super(props);
    this.debug('constructor:');
  }

  // Items for rendering and returning as activity result,
  // ex. [{
  //  id: string,
  //  telIndex: number,
  //  contact: mozContact,
  //  selectedValues: [...]
  // }, ...]
  get _items() {
    const items = [];
    this.props.contacts.forEach(contact => {
      contact.tel &&
        contact.tel.forEach((tel, telIndex) => {
          items.push({
            id: `${contact.id}${telIndex}`,
            telIndex,
            contact,
            selectedValues: [tel],
          });
        });
    });
    return items;
  }

  _itemDecorator = item => {
    return (
      <ContactListItem
        contact={item.contact}
        selected={!!this._selectedMap[item.id]}
        selectMode={this.props.selectMode}
        filter={this.props.filter}
        tel={item.selectedValues[0].value}
      />
    );
  };

  _onSelectionDone = (selectMode, selectedItems) => {
    Service.request('postResult', selectedItems);
  };

  _onSelectionChange = selectedMap => {
    this.props.onSelectionChange(selectedMap);
    this._selectedMap = selectedMap;
  };

  render() {
    this.debug('render');
    const itemProps = Object.assign({}, this.props);
    itemProps.items = this._items;
    itemProps.itemDecorator = this._itemDecorator;
    itemProps.onSelectionDone = this._onSelectionDone;
    itemProps.onSelectionChange = this._onSelectionChange;
    itemProps.maxCount = this._maxCount;

    return (
      <div
        className="multi-picker-list"
        ref={e => {
          this.element = e;
        }}
      >
        <SelectionList {...itemProps} />
      </div>
    );
  }
}
