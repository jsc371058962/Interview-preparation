import React from 'react';

/**
 * Stateless component as the input field
 */
const InputItem = ({
  id,
  l10nId,
  type,
  disabled,
  labelL10nId,
  labelL10nArgs,
  ariaLabel,
  maxLength,
  value,
  onChange,
}) => {
  let inputElement = null;
  const labelId = `input-item-label-${Date.now()}`;

  return (
    <div
      className={`list-item input-item ${disabled ? 'disabled' : ''}`}
      tabIndex="-1"
      data-type="input"
      onFocus={e => {
        e.currentTarget.classList.add('focus');
        inputElement && inputElement.setSelectionRange(1000, 1000);
      }}
      onBlur={e => {
        e.currentTarget.classList.remove('focus');
      }}
    >
      <div className="content">
        {labelL10nId ? (
          <label
            id={labelId}
            className="secondary"
            htmlFor={labelId}
            data-l10n-id={labelL10nId}
            data-l10n-args={labelL10nArgs}
          />
        ) : null}
        <input
          aria-label={ariaLabel}
          aria-describedby={labelId}
          id={id}
          type={type}
          data-l10n-id={l10nId}
          className="navigable primary"
          value={value}
          maxLength={maxLength}
          onChange={onChange}
          // caveat: e may be null between transitions due to React's implementation
          ref={e => {
            inputElement = e;
          }}
        />
      </div>
    </div>
  );
};

export default InputItem;
