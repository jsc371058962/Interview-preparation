import React from 'react';

/**
 * Part of items for rendering
 */
const SlicedItems = ({
  items = [],
  indexesToRender = [], // falsy then render all
  noItemL10n = '',
  itemDecorator = item => item,
}) => {
  const indexes =
    indexesToRender.length > 0 ? indexesToRender : Object.keys(items);
  const itemsToRender = indexes
    .filter(index => items[index])
    .map((index, viewIndex) => {
      const item = items[index];
      return (
        <div
          className="list-item"
          tabIndex="-1"
          key={`list-item-${item.id}`}
          data-id={item.id}
          data-type="list"
          data-index={index}
          data-view-index={viewIndex}
          role="menuitem"
        >
          {itemDecorator(item)}
        </div>
      );
    });
  return (
    <div className="list-items">
      {itemsToRender.length ? (
        itemsToRender
      ) : (
        <div className="no-result primary">
          <div data-l10n-id={noItemL10n} tabIndex="-1" />
        </div>
      )}
    </div>
  );
};

export default SlicedItems;
