import React from 'react';
import BaseComponent from 'base-component';
import ContactListItem from './contact_list_item';
import SlicedItems from './sliced_items';

export default class ContactList extends BaseComponent {
  name = 'ContactList';
  DEBUG = false;

  static defaultProps = {
    contacts: [],
    noItemL10n: 'no-contacts',
    selectMode: '',
    selectedMap: {},
  };

  constructor(props) {
    super(props);
    this.debug('constructor:');
  }

  get listItems() {
    return this.props.items !== undefined
      ? this.props.items
      : (this.props.indexesToRender && this.props.indexesToRender.length > 0) ||
        // For not have property 'indexesToRender', for example: group, favorite, ice.
        this.props.indexesToRender === undefined
      ? this.props.contacts
      : [];
  }

  // default itemDecorator for SlicedItems
  _itemDecorator = item => {
    return (
      <ContactListItem
        contact={item}
        selected={!!this.props.selectedMap[item.id]}
        selectMode={this.props.selectMode}
        filter={this.props.filter}
      />
    );
  };

  render() {
    this.debug('render');
    const itemProps = Object.assign(
      {
        itemDecorator: this._itemDecorator,
      },
      this.props
    );
    if (this.props.items) {
      itemProps.indexesToRender = null;
    }
    itemProps.items = this.listItems;

    return (
      <div
        className="contact-list"
        ref={e => {
          this.element = e;
        }}
      >
        <SlicedItems {...itemProps} />
      </div>
    );
  }
}
