import React from 'react';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import ContactList from './contact_list';

export default class MainList extends BaseComponent {
  name = 'MainList';
  DEBUG = false;

  static defaultProps = {
    contacts: [],
    filter: '',
  };

  constructor(props) {
    super(props);
    this.debug('constructor:');
  }

  componentDidMount() {
    this.debug('did mount');
    this._softKey = SoftKeyManager.create(this.element, {
      left: 'new-contact',
      center: this._hasItems ? 'select' : '',
      right: this._hasItems ? 'options' : 'settings',
    });
  }

  componentDidUpdate() {
    this.debug('did update');
    this._softKey.update({
      left: this.props.filter ? '' : 'new-contact',
      center: this._hasItems ? 'select' : '',
      right: this._hasItems ? 'options' : 'settings',
    });
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  get _hasItems() {
    return !!this.props.contacts.length;
  }

  onKeyDown = e => {
    switch (e.key) {
      case 'Enter':
        break;
      case 'SoftRight':
        break;
      default:
        break;
    }
  };

  render() {
    return (
      <div
        className="main-list"
        ref={e => {
          this.element = e;
        }}
        onKeyDown={this.onKeyDown}
      >
        <ContactList {...this.props} />
      </div>
    );
  }
}
