import React from 'react';
import BaseComponent from 'base-component';
import Service from 'service';
import ContactStore from 'contact_store';
import Utils from 'contact_utils';
import 'contact_list_item.scss';

const PHOTO_SIZE = 32;

export default class ContactListItem extends BaseComponent {
  name = 'ContactListItem';
  DEBUG = false;
  filter = null;

  highlight(data, bName = false) {
    if (!this.filter) {
      return data;
    }
    const { contact } = this.props;
    const filter = this.filter.toLowerCase();
    const name = data.toLowerCase();
    const familyName =
      contact.familyName && contact.familyName[0].toLowerCase();
    const givenName = contact.givenName && contact.givenName[0].toLowerCase();
    let index = name.indexOf(filter);
    if (index >= 0) {
      // name highlight must start from the beginning of firstName or lastName.
      // highlight name should first find in the correct sorting rule name part.
      if (bName) {
        const sortByGivenName = 'givenName' === ContactStore.sortingRule;
        if (sortByGivenName) {
          if (givenName.startsWith(filter)) {
            index = 0;
          } else if (familyName.startsWith(filter)) {
            index = name.lastIndexOf(familyName);
          } else {
            return data;
          }
        } else if (familyName.startsWith(filter)) {
          index = name.lastIndexOf(familyName);
        } else if (givenName.startsWith(filter)) {
          index = 0;
        } else {
          return data;
        }
      }
      const length = filter.length;
      return (
        <span>
          {data.substring(0, index)}
          <span className="highlight">
            {data.substring(index, index + length)}
          </span>
          {data.substring(index + length, data.length)}
        </span>
      );
    }
    return data;
  }

  onChange() {
    this.refs.box.dataset.icon = this.refs.checkbox.checked
      ? 'check-on'
      : 'check-off';
  }

  toggle() {
    const checked = this.refs.checkbox.checked;
    this.refs.checkbox.checked = !checked;
    this.onChange();
  }

  select() {
    this.refs.checkbox.checked = true;
    this.onChange();
  }

  deselect() {
    this.refs.checkbox.checked = false;
    this.onChange();
  }

  componentDidMount() {
    this.iconCanvas &&
      Utils.drawPhoto(this.props.contact, this.iconCanvas, PHOTO_SIZE);
  }

  componentDidUpdate() {
    this.iconCanvas &&
      Utils.drawPhoto(this.props.contact, this.iconCanvas, PHOTO_SIZE);
  }

  render() {
    const item = this.props.contact;
    let icon = '';
    if (this.props.selectMode) {
      icon = (
        <div
          className="icon"
          data-icon={this.props.selected ? 'check-on' : 'check-off'}
          ref="box"
        />
      );
    } else if (!Service.query('isLowMemoryDevice')) {
      icon =
        item && item.photo && item.photo.length ? (
          <span className="icon photo">
            <canvas
              ref={e => {
                this.iconCanvas = e;
              }}
            />
          </span>
        ) : (
          <i className="icon" data-icon="contacts" role="presentation" />
        );
    }
    const name = Utils.getDisplayName(item);
    const itemHighlighted = [];
    let numberDOM = [];
    let searchEmail = false;
    let searchTel = false;

    if (Service.query('isActivity')) {
      const activityData = Service.query('activityData');
      if (activityData.type) {
        if (activityData.type.includes('webcontacts/email')) {
          searchEmail = true;
        } else if (activityData.type.includes('webcontacts/tel')) {
          searchTel = true;
        }
      }
    }

    this.filter = this.props.filter;
    if (this.filter) {
      let newItem;
      if (searchEmail || searchTel) {
        newItem = searchEmail ? item.email : item.tel;
      } else if (item.tel) {
        newItem = item.tel.concat(item.email);
      } else if (item.email) {
        newItem = item.email;
      }

      if (newItem) {
        newItem.forEach(obj => {
          if (
            obj &&
            obj.value.toLowerCase().indexOf(this.filter.toLowerCase()) >= 0
          ) {
            if (itemHighlighted.indexOf(obj.value) < 0) {
              itemHighlighted.push(obj.value);
            }
          }
        });
      }
    } else {
      this.filter = Utils.getSortItemName(item);
    }

    const getSimIconId = c => {
      let iconId;
      const simNum = navigator.b2g.iccManager
        ? navigator.b2g.iccManager.iccIds.length
        : 0;
      if (1 === simNum) {
        iconId = `sim-card`;
      } else {
        iconId = `sim-card-${c.category.indexOf('SIM0') >= 0 ? '1' : '2'}`;
      }
      return iconId;
    };

    if (itemHighlighted.length) {
      for (let i = 0; i < itemHighlighted.length; i++) {
        numberDOM.push(
          <div className="secondary number">
            {this.highlight(itemHighlighted[i])}
          </div>
        );
      }
    } else if (this.props.tel) {
      numberDOM = <div className="secondary">{this.props.tel}</div>;
    }
    return (
      <div className="contact-list-item">
        {icon}
        <div className="content">
          <div className="primary">
            <input
              key="checkbox"
              ref="checkbox"
              type="checkbox"
              value={item ? item.id : ''}
              defaultChecked={!!this.props.selected}
              onChange={e => this.onChange(e)}
            />
            <a href={`/contacts/${item ? item.id : ''}`}>
              {this.highlight(name, true)}
            </a>
          </div>
          {numberDOM}
        </div>

        {Utils.isSIMContact(item) ? (
          <i data-icon={getSimIconId(item)} className="icon" />
        ) : null}
        {ContactStore.isFavorite(item) ? (
          <i className="icon" data-icon="favorite-on" />
        ) : null}
      </div>
    );
  }
}
