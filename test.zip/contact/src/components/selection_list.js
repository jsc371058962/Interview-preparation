import React from 'react';
import BaseComponent from 'base-component';
import Service from 'service';
import SoftKeyManager from 'modules/soft_key_manager';
import { CLOUD_TAG } from 'contact_wrapper';
import ContactList from './contact_list';

export default class SelectionList extends BaseComponent {
  name = 'SelectionList';
  DEBUG = false;

  /**
   * Useful hash index for toggling items chechbox.
   */
  _itemMap = {};

  static defaultProps = {
    selectMode: '',
    maxCount: Number.MAX_SAFE_INTEGER,
    isSearching: false,
    onSelectionChange: () => {},
    onSelectionDone: () => {},
  };

  constructor(props) {
    super(props);
    this.debug('constructor:');
    this.state = {
      selectedMap: {},
    };
  }

  get _selectedItems() {
    return Object.values(this.state.selectedMap);
  }

  get _isAllSelected() {
    return this._selectedItems.length === this.listElement.listItems.length;
  }

  componentDidMount() {
    this.debug('did mount');
    const config = {
      left: 'select-all2',
      center: 'select',
      right: '',
    };
    this._softKey = SoftKeyManager.create(this.element, config);
    this._genItemMap();
  }

  getConfig() {
    const selected = !!this.state.selectedMap[
      document.activeElement.dataset.id
    ];
    const config = {
      left: this.props.isSearching
        ? ''
        : this._isAllSelected
        ? 'deselect-all2'
        : 'select-all2',
      center: selected ? 'deselect' : 'select',
      right: this._selectedItems.length ? this.props.selectMode : '',
    };
    if (this.isGroupSelect) {
      config.left = '';
      config.right = selected ? 'add' : '';
    }
    return config;
  }

  componentDidUpdate() {
    this.debug('did update');
    this._softKey.update(this.getConfig());

    // in the case props.contacts(or props.items) changed
    // generally this will happen at startup(keep fetching data from db)
    if (
      this.listElement.listItems.length !== Object.keys(this._itemMap).length
    ) {
      this._genItemMap();
    }
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  _genItemMap() {
    this.listElement.listItems.forEach(item => {
      if ('group' === this.props.selectMode) {
        if (item.category.includes(CLOUD_TAG)) {
          return;
        }
      }
      this._itemMap[item.id] = item;
    });
  }

  get isGroupSelect() {
    return 'group' === this.props.selectMode;
  }

  onFocus = () => {
    this.debug('onfocus');
    this._softKey.update(this.getConfig());
  };

  onKeyDown = evt => {
    const map = Object.assign({}, this.state.selectedMap);
    const id = document.activeElement.dataset.id;
    switch (evt.key) {
      case 'SoftLeft':
        if (!this._softKey.getSoftKeyValue('left')) {
          break;
        }
        this._isAllSelected ? this._setMap({}) : this._selectAll();
        break;
      case 'Enter':
        if (this._itemMap[id]) {
          if (map[id]) {
            delete map[id];
          } else {
            map[id] = this._itemMap[id];
          }
          this._setMap(map);
        } else {
          Service.request('ToastManager:show', {
            text: window.api.l10n.get('unable-add-warn'),
          });
        }
        break;
      case 'SoftRight':
        if (!this._softKey.getSoftKeyValue('right')) {
          break;
        }
        if (this._selectedItems.length) {
          this.props.onSelectionDone(
            this.props.selectMode,
            this._selectedItems
          );
        }
        break;
      default:
        return;
    }
    evt.preventDefault();
    evt.stopPropagation();
  };

  _selectAll() {
    const map = {};
    this.listElement.listItems.some(item => {
      if (Object.keys(map).length === this.props.maxCount) {
        this._showMaxWarn();
        return true;
      }
      if (item.id) {
        map[item.id] = item;
      }
      return false;
    });

    this._setMap(map);
  }

  _setMap(map) {
    if (Object.keys(map).length > this.props.maxCount) {
      this._showMaxWarn();
      return;
    }
    this.setState(
      {
        selectedMap: map,
      },
      () => {
        this.props.onSelectionChange(this.state.selectedMap);
      }
    );
  }

  _showMaxWarn() {
    Service.request('ToastManager:show', {
      text: window.api.l10n.get('multi-pick-max-warn', {
        n: this.props.maxCount,
      }),
    });
  }

  render() {
    this.debug('render');
    return (
      <div
        className="selection-list"
        ref={e => {
          this.element = e;
        }}
        onFocus={this.onFocus}
        onKeyDown={this.onKeyDown}
      >
        <ContactList
          ref={e => {
            this.listElement = e;
          }}
          {...this.props}
          selectedMap={this.state.selectedMap}
        />
      </div>
    );
  }
}
