import React from 'react';
import Service from 'service';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Utils from 'contact_utils';
import SocialServiceStore from './social_service_store';
import ContactsImporter from './contacts_importer';
import GmailConnector from './gmail_connector';
import LiveConnector from './live_connector';

export default class SocialServiceImporter extends BaseComponent {
  name = 'SocialServiceImporter';
  DEBUG = false;

  constructor(props) {
    super(props);
    this.state = {
      progress: -1,
      total: 0,
    };
  }

  componentDidMount() {
    this.debug('did mount');
    const config = {};
    window.ssimporter = this;
    this.store = SocialServiceStore;
    this._softKey = SoftKeyManager.create(this.element, config);
    this.import(this.props.service);
  }

  import(service) {
    SocialServiceStore.getFriends(service)
      .then(friendsHash => {
        this.debug('friendsHash:');
        console.info(friendsHash);
        this.GmailConnector = GmailConnector;
        this.ContactsImporter = ContactsImporter;
        let connector;
        if ('gmail' === service) {
          connector = GmailConnector;
        } else if ('live' === service) {
          connector = LiveConnector;
        }
        const ci = new ContactsImporter(friendsHash, connector);
        this.importer = ci;
        this.updateSoftKeys();
        ci.on('imported', contact => {
          this.setState({
            saved: contact.name,
            progress: ci.imported,
            total: ci.total,
          });
        });
        ci.on('finished', () => {
          ci.offAll('imported');
          ci.offAll('finished');
          connector = null;
          ci.removeNetworkHandler();
          Service.request('back');
        });
        ci.import();
      })
      .catch(e => {
        this.debug('getFriends aborted', e);
        const _ = window.api.l10n.get;
        const serviceNameMap = {
          gmail: 'Gmail',
          live: 'Outlook',
        };
        let errorId = 'socialServiceContacts-error';
        if (!Utils.isOnLine()) {
          errorId = 'socialServiceContacts-noNetwork';
        }
        Service.request('ToastManager:show', {
          text: _(errorId, {
            service: serviceNameMap[service],
          }),
        });
        Service.request('back');
      });
  }

  updateSoftKeys() {
    const config = {
      left: 'cancel',
      center: '',
      right: '',
    };

    this._softKey.update(config);
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  onKeyDown(e) {
    switch (e.key) {
      case 'SoftLeft':
      case 'EndCall':
      case 'Backspace':
        e && e.preventDefault();
        this.importer && this.importer.cancel();
        break;
      default:
        break;
    }
  }

  render() {
    let progressDOM = null;
    let divider = null;
    let importStatus = null;
    if (this.state.total) {
      const progress = 100 * (this.state.progress / this.state.total);
      const activeStyle = { width: `${progress}%` };
      const inactiveStyle = { width: `calc(100% - ${progress}% - 0.3rem)` };
      progressDOM = (
        <div className="progress">
          <div className="progress-active" style={activeStyle} />
          <div className="progress-inactive" style={inactiveStyle} />
        </div>
      );
      divider = (
        <div className="secondary">
          {this.state.progress}/{this.state.total}
        </div>
      );
      importStatus = (
        <div
          className="primary"
          data-l10n-id={`importing-contacts-from-${this.props.service}`}
        />
      );
    } else {
      importStatus = (
        <div
          className="primary"
          data-l10n-id={`reading-contacts-from-${this.props.service}`}
        />
      );
    }
    return (
      <div
        className="social-service-importer"
        ref={e => {
          this.element = e;
        }}
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
      >
        <div
          className="header h1"
          data-l10n-id="importContactsTitle"
          ref="header"
        />
        <div className="body">
          <div className="list-item" data-multi-line="true">
            <div className="content">
              {importStatus}
              {divider}
              {progressDOM}
            </div>
          </div>
        </div>
      </div>
    );
  }
}
