import BaseExporter from './base_exporter';

export default class SimExporter extends BaseExporter {
  constructor(index, ids) {
    super(ids);
    this.ids = ids;
    this.current = 0;
    const iccId = SIMSlotManager.getSlots()[index].conn.iccId;
    const icc = navigator.b2g.iccManager.getIccById(iccId);
    this.icc = icc;
    this.iccId = this.icc.iccInfo && this.icc.iccInfo.iccid;
  }

  name = 'SimExporter';

  ERRORS = {
    NoFreeRecordFound: false,
    CannotAccessPhoneBook: true,
  };

  hasDeterminativeProgress = true;

  title = 'simExport-title';

  // Returns the iccContactId to be used for exporting this contact
  // undefined if not iccContactId is found
  // url content is urn:uuid:<iccid>-icccontactid
  _getIccContactId(theContact) {
    let out;
    const contactUrl = theContact.url;
    if (!Array.isArray(contactUrl)) {
      return out;
    }

    for (let j = 0; j < contactUrl.length; j++) {
      const aUrl = contactUrl[j];
      if (
        aUrl.type.indexOf('source') !== -1 &&
        aUrl.type.indexOf('sim') !== -1
      ) {
        const value = aUrl.value.split(':')[2];
        const iccInfo = value.split('-');
        if (iccInfo[0] === this.iccId) {
          out = iccInfo[1];
          break;
        }
      }
    }
    return out;
  }

  _generateIccContactUrl(contactid) {
    let urlValue = 'urn:' + 'uuid:' + (this.iccId || 'iccId') + '-' + contactid; // eslint-disable-line
    return {
      type: ['source', 'sim'],
      value: urlValue,
    };
  }

  _updateContactSimSource(theContact, iccContact) {
    return new Promise((resolve, reject) => {
      theContact.url = theContact.url || [];
      theContact.url.push(this._generateIccContactUrl(iccContact.id));
      const req = ContactsManager.save(theContact);
      req.onsuccess = resolve;
      req.onerror = () => {
        reject(req.error);
      };
    });
  }

  next(contact) {
    this.current++;
    this.emit('exported', contact);
    if (this.current === this.total) {
      this.done();
    }
    this.continue();
  }

  continue() {
    if (this.aborted) {
      console.warn('aborted, no con');
      return;
    }

    const theContact = this.contacts[this.current];
    const originalContactId = theContact.id;
    theContact.id = null;

    const request = this.icc.updateContact('adn', theContact);
    request.onsuccess = () => {
      // Restoring the original contact.id to avoid duplicating it
      theContact.id = originalContactId;

      // Now it is needed to save the provided id in case we don't have one
      const iccContact = request.result;
      this._updateContactSimSource(theContact, iccContact).then(
        () => {
          this.next(theContact);
        },
        err => {
          window.console.error('Error while updating: ', err.name);
          this.next(theContact);
        }
      );
    };

    request.onerror = e => {
      const error = e.target.error;
      window.console.error(
        'Error while exporting: ',
        originalContactId,
        error.name
      );

      const errorName =
        'boolean' === typeof this.ERRORS[error.name]
          ? error.name
          : 'GenericError';

      if (errorName !== 'GenericError') {
        this.emit('error', errorName);
        this.error = errorName;
        this.done();
      } else {
        this.next(theContact);
      }
    };
  }
}
