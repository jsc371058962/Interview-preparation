import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import MainList from 'components/main_list';
import SelectionList from 'components/selection_list';
import PickerList from 'components/picker_list';
import MultiPickerList from 'components/multi_picker_list';
import ICEStore from 'ice_store';
import ContactStore, { TAG_INDEX } from 'contact_store';
import Utils from 'contact_utils';
import Search from 'search';
import OptionMenuHelper from 'option_menu_helper';
import { accountStore, accountContactsFilter } from 'account/account_manager';
import perf from 'modules/perf';
import ContactDraftManager from 'contact_draft_manager';
import 'list.scss';

const FILTER_FIELDS = ['tel', 'email'];

export default class List extends BaseComponent {
  name = 'List';
  DEBUG = false;
  FOCUS_SELECTOR =
    ':not(.hidden) > .list-item:not([data-type="input"]):not(.hidden),input[type="text"], .main-list [data-l10n-id="start-adding"]';

  firstTime = true;

  PAGE_SIZE = 20;

  VIEWPORT_SIZE = 5;

  isBackFromGroup = false;
  latestFocusIndex = null;

  constructor(props) {
    super(props);
    this.debug('constructor');
    this.state = {
      contacts: ContactStore.getSourceContacts(this._source),
      iceContacts: [],
      editMode: '',
      selectedCount: 0,
      indexesToRender: [],
      filter: '',
      matchedContacts: [],
    };
    if (!props.target && !props.source) {
      this.state.iceContacts = ICEStore.getAll();
    }

    this.state.indexesToRender = this._rangeFromStart(this.state.contacts, 0);

    Service.register('setEditMode', this);
    Service.register('onContactKeyDown', this);
    Service.register('reload', this);
    Service.register('pick', this);
  }

  get _isSearching() {
    return !!this.state.filter;
  }

  get _source() {
    let source;
    if (this.props.source) {
      // copy/move contacts
      source = this.props.source;
    } else if (this.isPicker() && this.props.target !== 'update') {
      if (this.props.noSimContact) {
        source = 'phone';
      } else {
        source = 'kaiContact';
      }
    } else {
      // main screen
      source = ContactStore.source;
    }
    return source;
  }

  setEditMode(mode) {
    if (mode) {
      // when delete, cache main screen focus index.
      const activeElement = this.navigator.element.activeElement;
      this.latestFocusIndex = activeElement
        ? activeElement.dataset.index
        : null;
    }
    const config = {
      editMode: mode,
    };
    if (!mode) {
      config.selectedCount = 0;
      config.filter = '';
    }
    this.setState(config, () => {
      const searchElement = this.refs.search
        ? this.refs.search.inputElement
        : null;
      if (this.state.editMode) {
        this.navigator.setFocus(searchElement);
      } else if (this.latestFocusIndex !== null) {
        const nextElement = this.element.querySelector(
          `.contact-list .list-item[data-index="${this.latestFocusIndex}"]`
        );
        const isFocusSearch =
          this.navigator.element.activeElement === searchElement;
        // if it is focus search, it means has set focus to search before, such as after delete. focus on search can not go to edit mode.
        !isFocusSearch && this.navigator.setFocus(nextElement);
        this.latestFocusIndex = null;
      }
    });
  }

  reload() {
    this.debug('reloading...');
    this._fetchSource(ContactStore.source);
  }

  _rangeFromStart(contacts, start, count = this.PAGE_SIZE) {
    this.debug(
      '_rangeFromStart: contacts length, start, count:',
      contacts.length,
      start,
      count
    );
    start = Math.min(start, contacts.length - 1);
    start = start < 0 ? 0 : start;
    count = Math.min(count, contacts.length);

    const indexes = [];
    for (let i = start; indexes.length <= count && i < contacts.length; i++) {
      const shouldShow = this._itemFilter(contacts[i]);
      if (shouldShow) {
        indexes.push(i);
      }
    }

    this.debug(
      '_rangeFromStart: return: start, indexes length:',
      start,
      indexes.length
    );
    return indexes;
  }

  _rangeToEnd(contacts, end, count = this.PAGE_SIZE) {
    this.debug(
      '_rangeToEnd: contacts.length, end, count:',
      contacts.length,
      end,
      count
    );
    end = Math.min(end, contacts.length - 1);
    end = end < 0 ? 0 : end;
    count = Math.min(count, contacts.length);

    const indexes = [];
    for (let i = end; indexes.length <= count && i >= 0; i--) {
      const shouldShow = this._itemFilter(contacts[i]);
      if (shouldShow) {
        indexes.unshift(i);
      }
    }

    this.debug('_rangeToEnd: return: end, length:', end, indexes.length);
    return indexes;
  }

  /**
   * Determine whether the item should be skipped or not according to SPEC
   * @param {object} item - The mozContact object
   * @return {boolean} - `false` means should be skipped
   */
  _itemFilter(item) {
    if (!item) {
      return false;
    }
    let target = this.props.target;
    if ('ice' === target) {
      target = 'tel';
      if (
        this.state.iceContacts.some(ice => {
          return ice.id === item.id;
        })
      ) {
        return fasle;
      }
    } else if ('export' === target || 'vcard' === target || 'move' === target) {
      target = '';
    }

    // when in pick activity type 'webcontacts/select', no tel and email don't
    // show
    if ('tel,email' === target) {
      if (
        !(item.tel && item.tel.length) &&
        !(item.email && item.email.length)
      ) {
        return false;
      }
    }

    if (
      FILTER_FIELDS.includes(target) &&
      (!item[target] || 0 === item[target].length)
    ) {
      return false;
    }

    // skip sim contacts if adding more tel or email and set picture
    if (Utils.isSIMContact(item)) {
      if (
        this.props.noSimContact ||
        ('phone' === ContactStore.source && !this.isCopyOrMoveMode)
      ) {
        return false;
      }
      if (
        this.props.target &&
        ['update', 'contact'].includes(this.props.target)
      ) {
        if (
          (this.props.tel && item.tel && item.tel.length) ||
          this.props.email
        ) {
          return false;
        }
      }
    } else if ('sim' === ContactStore.source && !this.isCopyOrMoveMode) {
      return false;
    }

    return true;
  }

  get isCopyOrMoveMode() {
    return 'move' === this.props.selectMode || 'copy' === this.props.selectMode;
  }

  get _selectMode() {
    return this.state.editMode || this.props.selectMode || '';
  }

  checkContactAvailable() {
    if (
      Service.query('isActivity') &&
      this.isPicker() &&
      this._fetched &&
      0 === this.state.indexesToRender.length
    ) {
      let header;
      let content;
      const hasContacts = ContactStore.fullContacts.length > 0;
      const isSimOrAllAreSimContacts =
        'sim' === ContactStore.source ||
        ('kaiContact' === ContactStore.source && this.isAllSimContacts());

      if (hasContacts) {
        if (
          Service.query('activityParams') &&
          Object.keys(Service.query('activityParams')).length > 0
        ) {
          // Add number or email to contacts
          if (Service.query('activityParams').email) {
            if (isSimOrAllAreSimContacts || 'phone' === ContactStore.source) {
              header = 'add-info-failed';
              content = 'no-contact-to-add';
            }
          } else if (Service.query('activityParams').typeOfContact) {
            // ICE or speed dial
            header = 'contacts';
            content = 'requested-contact-not-available';
          }
          // Only when param is number can execute else flow.
          else if (
            isSimOrAllAreSimContacts ||
            'phone' === ContactStore.source
          ) {
            header = 'add-info-failed';
            content = 'no-contact-to-add';
          }
        }
      } else {
        return;
      }

      Service.request('showDialog', {
        type: 'alert',
        header: header || 'contacts',
        content: content || 'requested-contact-not-available',
        onOk: () => {
          this.backOrClose();
        },
        onBack: () => {
          this.backOrClose();
        },
      });
    }
  }

  isAllSimContacts() {
    const contacts = ContactStore.fullContacts;
    let isAllSimContacts = false;
    if (contacts.length > 0) {
      isAllSimContacts = contacts.every(contact => Utils.isSIMContact(contact));
    }
    return isAllSimContacts;
  }

  componentDidMount() {
    this.debug('did mount: source:', this.props.source);
    window.list = this;
    this.element = ReactDOM.findDOMNode(this);
    if (!this.props.source) {
      this.element.focus();
    }

    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element
    );
    if (!this._fetched) {
      this.navigator.loopable = false;
    }

    ContactStore.on('changed', this._onContactChanged);
    ContactStore.on('group-changed', this._onGroupChanged);
    accountStore.whenReady.then(() => {
      this._fetchSource(this._source);
    });

    if (!this.props.target && !this.props.source) {
      this.onIceChanged = () => {
        this.setState({
          iceContacts: ICEStore.getAll(),
        });
      };
      ICEStore.on('changed', this.onIceChanged);
    }

    if (Service.query('isActivity') && this.isPicker()) {
      this.createSoftKey(this.element, {
        left: 'cancel',
        center: '',
        right: '',
      });
    }

    if (this._selectMode && !this.state.contacts.length) {
      this.createSoftKey(this.element, {});
    }

    this.navigator.onBeforeNavDown = this.tryFetch.bind(this, 'navDown');
    this.navigator.onBeforeNavUp = this.tryFetch.bind(this, 'navUp');
    window.performance.mark('navigationLoaded');
    this.firstTime = false;
    window.addEventListener('bootRoute', this._bootRoute);
  }

  _bootRoute = ({ detail: { action } }) => {
    window.removeEventListener('bootRoute', this._bootRoute);
    ContactDraftManager.getItem().then(data => {
      if (data) {
        const path = !data.id ? '/new' : `/edit/${data.id}`;
        Service.request('push', path);
      } else {
        switch (action) {
          case 'new':
            this.createNewContact();
            break;
          case 'settings':
            Service.request('push', '/setting');
            break;
          default:
            break;
        }
      }
    });
  }

  _onGroupChanged = ({ reason } = {}) => {
    if (
      ContactsManager.ChangeReason.REMOVE === reason &&
      !ContactStore.hasGroups() &&
      this.getListItems().length > 0
    ) {
      this.navigator.setFocus(this.getListItems()[0]);
    }
  }

  getListItems() {
    return this.element.querySelectorAll('.list-all .list-item');
  }

  /**
   * Do different contact store fetching according to different context
   */
  _fetchSource(source) {
    this._fetched = false;
    const currentFetchingId = Date.now();
    this._fetchingId = currentFetchingId;

    if (window.ssrHasContacts) {
      const searchElement = this.element.querySelector('input[type="text"]');
      searchElement && searchElement.focus();
      window.ssrHasContacts = false;
    }
    ContactStore.getByBatch({
      source,
      onBatch: ({ currentContacts }) => {
        const contacts = ContactStore.interceptContact(
          currentContacts.filter(accountContactsFilter)
        );
        this.debug('got batch: current length:', contacts.length);
        if (!this.hideSSR && contacts.length) {
          window.dispatchEvent(new CustomEvent('fullyloaded'));
          this.hideSSR = true;
        }
        if (currentFetchingId !== this._fetchingId) {
          this.debug('onBatch: interrupted by newer _fetchSource:');
          return;
        }
        this._setContacts(contacts);
      },
    }).then(contacts => {
      if (currentFetchingId !== this._fetchingId) {
        this.debug('fetched: interrupted by newer _fetchSource:');
        return;
      }
      this._fetched = true;
      this._setContacts(ContactStore.interceptContact(contacts));

      this.debug('ContactStore fetched, toggle to loopable');
      this.navigator.loopable = true;
      window.performance.mark('fullyLoaded');
      if (!this.hideSSR) {
        window.dispatchEvent(new CustomEvent('fullyloaded'));
        this.hideSSR = true;
      }
    });
  }

  _onContactChanged = ({ atIndex } = {}) => {
    this.debug('_onContactChanged: atIndex:', atIndex);
    const contacts = ContactStore.currentContacts;
    if (this._isSearching) {
      if (!contacts.length) {
        this.setState({
          filter: '',
          contacts: [],
        });
        return;
      }
      this.reSearch = true;
    }
    this._setContacts(contacts, atIndex);
  };

  _setContacts = (contacts, focusIndex) => {
    // determine the next indexes range for new contacts
    // let current focused item(or specified focusIndex) approximately in the middle
    const currentIndex = +document.activeElement.dataset.index;
    this.debug(
      '_setContacts: focusIndex, current index:',
      focusIndex,
      currentIndex
    );

    focusIndex = this._selectMode ? -1 : focusIndex || currentIndex || -1;

    const start =
      focusIndex -
      Math.max(this.VIEWPORT_SIZE, parseInt(this.PAGE_SIZE / 2, 10));

    this.debug('_setContacts: start:', start);
    this.setState(
      {
        contacts,
        indexesToRender: this._rangeFromStart(contacts, start),
      },
      () => {
        const searchElement = this.refs.search
          ? this.refs.search.inputElement
          : null;
        const nextElement =
          focusIndex !== -1
            ? this.element.querySelector(
                `.contact-list .list-item[data-index="${focusIndex}"]`
              )
            : searchElement;
        this.debug('try focus nextElement:', nextElement);
        nextElement && this.navigator.setFocus(nextElement);
      }
    );
  };

  /**
   * Since we don't render all items at once,
   * try fetching if close enough to the margin(start or end) when navigating
   * @param {string} direction - 'navUp' or 'navDown'
   */
  tryFetch(direction) {
    this.debug('tryFetch:', direction);

    const indexes = this.state.indexesToRender;
    if (indexes.length === this.state.contacts.length) {
      this.debug('tryFetch: all rendered, do nothing.');
      return;
    }

    const currentViewIndex = +document.activeElement.dataset.viewIndex || 0;
    const currentIndex = indexes[currentViewIndex];
    this.debug(
      'currentIndex, indexes length, start:',
      currentIndex,
      indexes.length,
      indexes[0]
    );

    let newStart;
    let newEnd;
    let contacts;
    let contactsLength;
    // Distinguish.
    if (this._isSearching) {
      contacts = this.state.matchedContacts;
      contactsLength = this.state.matchedContacts.length;
    } else {
      contacts = this.state.contacts;
      contactsLength = this.state.contacts.length;
    }
    switch (direction) {
      case 'navDown':
        if (currentViewIndex === indexes.length - 1) {
          // hit bottom
          newStart = 0;
        } else if (
          indexes.length - currentViewIndex < this.VIEWPORT_SIZE &&
          contactsLength - 1 !== indexes[indexes.length - 1]
        ) {
          newStart =
            indexes[Math.max(currentViewIndex - this.VIEWPORT_SIZE, 0)];
        } else {
          this.debug('no need to fetch');
          break;
        }

        this.debug('nav down: newStart:', newStart);
        newEnd = Math.min(newStart + (this.PAGE_SIZE - 1), contactsLength - 1);
        this.setState({
          indexesToRender: this._rangeFromStart(contacts, newStart),
        });
        break;
      case 'navUp':
        if ('INPUT' === document.activeElement.tagName) {
          // hit top
          if (!this._fetched) {
            break;
          }
          newEnd = contactsLength - 1;
        } else if (currentViewIndex < this.VIEWPORT_SIZE && 0 !== indexes[0]) {
          newEnd =
            indexes[
              Math.min(
                currentViewIndex + this.VIEWPORT_SIZE,
                indexes.length - 1
              )
            ];
        } else {
          this.debug('no need to fetch');
          break;
        }

        this.debug('nav up: newEnd:', newEnd);
        newStart = Math.max(0, newEnd - (this.PAGE_SIZE - 1));
        this.setState({
          indexesToRender: this._rangeToEnd(contacts, newEnd),
        });
        // in case of jumping to bottom directly
        // update candidates after bottom items rendered
        this.navigator.updateCandidates();
        break;
      default:
        break;
    }
  }

  componentWillUnmount() {
    ContactStore.off('changed', this._onContactChanged);
    ContactStore.off('group-changed', this._onGroupChanged);
    this._softKey && this._softKey.destroy();
  }

  isPicker() {
    return !!(this.props && (this.props.target || this.props.isPicker));
  }

  backOrClose() {
    if (Service.query('isActivity')) {
      Service.request('leaveActivity');
    } else {
      Service.request('back');
    }
  }

  createNewContact() {
    Utils.chooseMemory().then(memory => {
      if (!memory) {
        return;
      }
      perf.mark('enter-new-contact');
      Service.request('push', `/new/${memory}`);
    });
  }

  onKeyDown(evt) {
    const sInput = this.refs.search &&
      this.refs.search.inputElement === document.activeElement;
    if (sInput && this._selectMode && evt.key !== 'Backspace') {
      return;
    }
    const id = document.activeElement.dataset.id;
    let contact = null;
    if (id) {
      contact = ContactStore.getContactSync(id);
    }
    let anchor;
    let location = '';
    let options = [];
    switch (evt.key) {
      case 'Call':
        if (!contact) {
          break;
        }
        // when CALLSCREEN open activity, Call key should not dial and response.
        if (Service.query('isActivity')) {
          const activityData = Service.query('activityData');
          if (
            activityData.type &&
            activityData.type.includes('webcontacts/tel')
          ) {
            break;
          }
        }
        Service.request('pickANumber', contact).then(tel => {
          Utils.dial(tel);
        });
        break;
      case 'SoftLeft':
        if (this._softKey && !this._softKey.getSoftKeyValue('left')) {
          break;
        }
        if (!this.isPicker()) {
          if (!this._isSearching || sInput) {
            this.createNewContact();
          }
        } else {
          this.backOrClose();
        }
        break;
      case 'Backspace':
        if (this.state.filter && !sInput) {
          evt.preventDefault();
          evt.stopPropagation();
          // bug-39303: workaround, possible IME issue
          const handleKeyup = () => {
            this.element.removeEventListener('keyup', handleKeyup);
            this.navigator.setFocus(this.refs.search.inputElement);
          };
          this.element.addEventListener('keyup', handleKeyup);
          break;
        }
        if (this.state.editMode) {
          if ('delete' === this.state.editMode) {
            this.setEditMode('');
          } else {
            Service.request('back');
          }
          evt.preventDefault();
          evt.stopPropagation();
          return;
        }
        if (this.props.target || this.props.selectMode) {
          evt.preventDefault();
          evt.stopPropagation();
          this.backOrClose();
          break;
        }
        if (Service.query('isSyncingContacts')) {
          Service.request('showDialog', {
            type: 'confirm',
            header: 'stop-syncing-warn-title',
            content: 'stop-syncing-warn',
            ok: 'close',
            onOk: () => {
              window.close();
            },
          });
          evt.preventDefault();
          evt.stopPropagation();
        }
        break;
      case 'Enter':
        if (!id) {
          break;
        }
        if (this.isPicker() && 'group' !== id) {
          this.pick(id);
        } else {
          anchor = evt.target.querySelector('a');
          location = anchor.pathname;
          evt.preventDefault();
          evt.stopPropagation();
          perf.mark('enter-contact-detail');
          Service.request('push', location).then(option => {
            if (option && option.length > 0 && option[0].isFromGroup) {
              this.isBackFromGroup = option[0].isFromGroup;
            }
          });
          if (this.refs.search) {
            this.refs.search.cancelSearch();
          }
        }
        break;
      case 'SoftRight':
        if (this.props.target) {
          anchor = evt.target.querySelector('a');
          if (!anchor) {
            break;
          }
          location = anchor.pathname;
          if (!location) {
            break;
          }
          if ('group' === id) {
            break;
          }
          evt.preventDefault();
          evt.stopPropagation();
          Service.request('popup', location.replace('contacts', 'view'));
          break;
        }

        const _id = document.activeElement.dataset.id;
        if (_id) {
          if (_id !== 'favorite' && _id !== 'icelist' && _id !== 'group') {
            options = options.concat(
              OptionMenuHelper.optionsForContact(contact)
            );
            if (this.state.contacts.length && !this._isSearching) {
              options = options.concat(OptionMenuHelper.optionsForContacts());
            }
            // Add search option in order to scroll to top
            options.push({
              id: 'search-option',
              callback: () => {
                this.navigator.scrollIntoView(this.element);
                this.navigator.setFocus(this.refs.search.inputElement);
              },
            });
          }
        }
        if (!this._isSearching || sInput) {
          options.push({
            id: 'settings',
            callback: () => {
              Service.request('push', '/setting');
            },
          });
        }
        evt.preventDefault();
        evt.stopPropagation();
        if (!options.length) {
          return;
        }
        if ((!this.state.contacts.length || sInput) &&
            1 === options.length) {
          options[0].callback();
          return;
        }
        Service.request('showOptionMenu', {
          options,
          onCancel: () => {
            // lastFocus && lastFocus.focus();
          },
        });
        break;
      default:
        break;
    }
  }

  // For favorite_view and ice_list_view
  // XXX: merge with onKeyDown?
  onContactKeyDown(evt) {
    const id = document.activeElement.dataset.id;
    const contact = ContactStore.getContactSync(id);
    let anchor;
    let options = [];
    switch (evt.key) {
      case 'Call':
        if (!contact) {
          break;
        }
        Service.request('pickANumber', contact).then(tel => {
          Utils.dial(tel);
        });
        break;
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('back');
        break;
      case 'Enter':
        anchor = evt.target.querySelector('a');
        if (!anchor) {
          break;
        }
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('push', anchor.pathname);
        if (this.refs.search) {
          this.refs.search.cancelSearch();
        }
        break;
      case 'SoftRight':
        if (!contact) {
          break;
        }
        options = options.concat(
          OptionMenuHelper.optionsForContact(contact),
          {
            id: 'massive-delete',
            callback: () => {
              Service.request('back');
              Service.request('setEditMode', 'delete');
            },
          },
          {
            id: 'settings',
            callback: () => {
              Service.request('push', '/setting');
            },
          }
        );
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('showOptionMenu', {
          options,
          onCancel: () => {},
        });
        break;
      default:
        break;
    }
  }

  pickTarget(contact) {
    return new Promise(resolve => {
      const options = [];
      this.props.target.split(',').forEach(field => {
        if ('tel' === field) {
          contact.tel &&
            contact.tel.forEach(tel => {
              options.push({
                label: `(${tel.type[0].toUpperCase()[0]}) ${tel.value}`,
                callback: () => {
                  resolve(tel);
                },
              });
            });
        } else if ('email' === field) {
          contact.email &&
            contact.email.forEach(email => {
              options.push({
                label: email.value,
                callback: () => {
                  resolve(email);
                },
              });
            });
        }
      });
      if (1 === options.length) {
        options[0].callback();
      } else {
        Service.request('showOptionMenu', {
          header: 'select',
          options,
          onCancel: () => {},
        });
      }
    });
  }

  pickTel(contact) {
    if (contact.tel.length > 1) {
      const options = contact.tel.map((tel, telIndex) => {
        return {
          label: `(${tel.type[0].toUpperCase()[0]}) ${tel.value}`,
          callback: () => {
            const data = {
              contact,
              telIndex,
            };
            // bug-39353: deprecated, keep for compatibility only
            const ret = Object.assign({}, contact);
            ret.tel = [tel];
            ret.id = contact.id;
            if (Service.query('isActivity')) {
              Service.request('postResult', ret, data);
            } else {
              // XXX: This is a workaround to avoid
              // option menu wants to focus back to us,
              // but we want to focus back to parent panel.
              setTimeout(() => {
                Service.request('back', ret, data);
              });
            }
          },
        };
      });
      Service.request('showOptionMenu', {
        header: 'choose-number',
        options,
        onCancel: () => {},
      });
    } else {
      // only 1 number
      const data = {
        contact,
        telIndex: 0,
      };
      if (Service.query('isActivity')) {
        // bug-39353: for compatibility
        Service.request('postResult', contact, data);
      } else {
        Service.request('back', contact, data);
      }
    }
  }

  pickEmail(contact) {
    const ret = {
      name: contact.name,
      email: null,
    };
    if (contact.email.length > 1) {
      const options = [];
      contact.email.forEach(email => {
        options.push({
          label: email.value,
          callback: () => {
            ret.email = email.value;
            if (Service.query('isActivity')) {
              Service.request('postResult', ret);
            } else {
              // XXX: This is a workaround to avoid
              // option menu wants to focus back to us,
              // but we want to focus back to parent panel.
              setTimeout(() => {
                Service.request('back', ret);
              });
            }
          },
        });
      });
      Service.request('showOptionMenu', {
        header: 'choose-email-address',
        options,
        onCancel: () => {},
      });
    } else {
      // only 1 email
      ret.email = contact.email[0].value;
      if (Service.query('isActivity')) {
        Service.request('postResult', ret);
      } else {
        Service.request('back', ret);
      }
    }
  }

  pick(id) {
    const contact = ContactStore.getContactSync(id);
    switch (this.props.target) {
      case 'vcard':
        Utils.toVcard(contact).then(result => {
          Service.request('postResult', result);
        });
        break;
      case 'update':
        Service.request('push', `/edit/${id}`, {
          tel: this.props.tel,
          email: this.props.email,
        });
        break;
      case 'contact':
        Service.request('postResult', { contact });
        break;
      case 'multiple':
      case 'export':
      case 'move':
        break;
      case 'ice':
        if (ICEStore.has(contact.id)) {
          Service.request('showDialog', {
            header: 'add-ice-failed',
            content: 'already-ice-contact',
            type: 'alert',
            onOk: () => {
              Service.request('back');
            },
          });
          break;
        }
        Service.request('postResult', contact);
        break;
      case 'tel': // eslint-disable-line
        this.pickTel(contact);
        break;
      case 'email':
        this.pickEmail(contact);
        break;
      case 'tel,email':
        this.pickTarget(contact).then(select => {
          Service.request('postResult', {
            contact,
            selectedValues: [select],
          });
        });
        break;
      default:
        break;
    }
  }

  updateScroll() {
    if (!this.refs.scroll) {
      return;
    }
    let index = +document.activeElement.dataset.index;
    if (!index) {
      index = 0;
    }
    let total = this._isSearching
      ? this.state.matchedContacts.length
      : this.state.contacts.length;
    if (0 === total) {
      return;
    }
    total += 1; // Search
    let top = 0;
    let ratio = 1;

    if (total > this.refs.body.clientHeight) {
      ratio = this.refs.body.clientHeight / total;
      total = this.refs.body.clientHeight;
    }
    if (index >= 3) {
      index -= 2;
      top =
        ((this.refs.body.clientHeight - (1 - ratio) * 4) * index * ratio) /
        total;
    }
    this.refs.scroll.style.top = `${top}px`;
    this.refs.scroll.style.height = `${(this.refs.body.clientHeight * 4) /
      total}px`;

    if (this.refs.listAll) {
      if (this.refs.body.clientHeight >= this.refs.listAll.clientHeight) {
        return;
      }
    }
    clearTimeout(this.scrollTimer);
    this.refs.scroll.classList.remove('hidden');

    this.scrollTimer = setTimeout(() => {
      if (this.refs.scroll) {
        this.refs.scroll.classList.add('hidden');
      }
    }, 1500);
  }

  componentDidUpdate() {
    this.debug('did update:');

    if (this.refs.search) {
      if (this._isSearching) {
        this.refs.search.inputElement.value = this.state.filter;
        if (this.reSearch) {
          this.refs.search.doSearch(this.state.filter);
          this.reSearch = false;
        }
      }

      if (window._search_cache) {
        this.refs.search.inputElement.value = window._search_cache;
        this.refs.search.doSearch(window._search_cache);
        window._search_cache = null;
      }
    }
    if (this.element.contains(document.activeElement)) {
      this.navigator.scrollIntoView(document.activeElement);
    }

    this.updateScroll();
    !this._isSearching && this.checkContactAvailable();
    if (document.activeElement === document.body) {
      this.debug('try retaking focus from body');
      Service.request('focus');
    }
  }

  firstLaunch = true;

  onFocus() {
    this.debug('focus on index:', document.activeElement.dataset.index);
    Service.request('ensureDialog');
    if (this.firstLaunch) {
      this.firstLaunch = false;
      if (this.DEBUG) {
        window.performance.mark('navigationInteractive');
        window.performance.mark('contentInteractive');
        console.timeEnd('loadreact');

        window.performance.getEntries().forEach(e => console.log(e));
      }
    }

    this.updateScroll();
  }

  onSearch = ({ filter, matchedContacts }) => {
    this.debug(
      'onSearch: filter, matched length:',
      filter,
      matchedContacts.length
    );
    const realMatchedContacts = matchedContacts.filter(item => {
      return item.category && item.category.includes(TAG_INDEX[this._source]);
    });
    if (realMatchedContacts.length > 0) {
      const currentIndex = +document.activeElement.dataset.index;
      const focusIndex = currentIndex >= 0 ? currentIndex : -1;
      const start =
        focusIndex -
        Math.max(this.VIEWPORT_SIZE, parseInt(this.PAGE_SIZE / 2, 10));
      this.setState({
        filter,
        matchedContacts: realMatchedContacts,
        indexesToRender: this._rangeFromStart(realMatchedContacts, start),
      });
    } else {
      this.setState({
        filter,
        matchedContacts: realMatchedContacts,
        indexesToRender:
          filter !== '' ? [] : this._rangeFromStart(this.state.contacts, 0),
      });
    }
  };

  getContacts() {
    if (!this.props.source) {
      return ContactStore.currentContacts;
    }
    return this.state.contacts;
  }

  _onSelectionDone = (selectMode, selectedItems) => {
    const ids = selectedItems.map(c => c.id);
    if ('delete' === selectMode) {
      Service.request('showDialog', {
        type: 'confirm',
        header: window.api.l10n.get('confirm'),
        content: window.api.l10n.get('ContactConfirmDel', {
          n: selectedItems.length,
        }),
        translated: true,
        ok: 'delete',
        onOk: () => {
          this.refs.search && this.refs.search.cancelSearch();
          perf.mark('delete-one-contact');
          perf.mark('delete-all-contacts');
          Service.request('push', '/deletes', {
            ids,
          }).then(() => {
            perf.measure('delete-one-contact');
            perf.measure('delete-all-contacts');
            this.setEditMode('');
          });
        },
      });
    } else if ('group' === selectMode) {
      Service.request('back', selectedItems);
    } else {
      Service.request('back', ids);
    }
  };

  _onSelectionChange = selectedMap => {
    this.setState({
      selectedCount: Object.keys(selectedMap).length,
    });
  };

  onGroupFocus = element => {
    if (this.isBackFromGroup) {
      this.navigator.setFocus(element);
      this.isBackFromGroup = false;
    }
  };

  createSoftKey = (element, config) => {
    this._softKey = SoftKeyManager.create(element, config);
  };

  render() {
    this.debug('render');
    const hasItems = !!this.state.contacts.length;
    const dom = [];
    if (!this._selectMode && !this._isSearching && !this.firstTime) {
      if (
        ContactStore.source !== 'sim' &&
        this.state.iceContacts.some(ice => {
          return !!ice.id;
        })
      ) {
        dom.push(
          <GroupListItem
            hasItems={hasItems}
            id="icelist"
            path="/icelist"
            labelL10nId="ICEContactsGroup"
            key="icelist"
            createSoftKey={this.createSoftKey}
          />
        );
      }

      if (ContactStore.hasFavorites() && !this.props.target) {
        dom.push(
          <GroupListItem
            hasItems={hasItems}
            id="favorite"
            path="/favorite"
            labelL10nId="favorite-contacts"
            key="favorite"
            createSoftKey={this.createSoftKey}
          />
        );
      }

      if (ContactStore.hasGroups()) {
        dom.push(
          <GroupListItem
            hasItems={hasItems}
            id="group"
            path="/group-list"
            labelL10nId="group"
            key="group"
            onGroupFocus={this.onGroupFocus}
            createSoftKey={this.createSoftKey}
          />
        );
      }
    }

    let header = null;
    if (this._selectMode) {
      header = this._isSearching ? (
        <span data-l10n-id="search-option" key="select-mode" />
      ) : (
        <span
          data-l10n-id="selected-contacts"
          key="select-mode"
          data-l10n-args={JSON.stringify({ n: this.state.selectedCount })}
        />
      );
    } else if (this.isPicker()) {
      header = <span data-l10n-id="select-a-contact" key="pick-mode" />;
    }

    let ListClass = MainList;
    const listProps = {
      contacts: this.state.contacts,
      indexesToRender: this.state.indexesToRender,
    };

    if (!hasItems) {
      if ((this.props.source || !ContactStore._cached) && this.firstTime) {
        listProps.noItemL10n = 'reading-contacts';
      } else if (!this.isPicker()) {
        listProps.noItemL10n = 'start-adding';
      }
    }

    if (this._isSearching) {
      // Need use the state contacts to search every time.
      listProps.shouldFilterContacts = this.state.contacts;
      listProps.contacts = this.state.matchedContacts;
      listProps.noItemL10n = 'no-contacts-found';
      listProps.filter = this.state.filter;
    }

    if (this._selectMode) {
      listProps.selectMode = this._selectMode;
      listProps.onSelectionChange = this._onSelectionChange;
      const index = Number(document.activeElement.dataset.index);
      if (!Number.isNaN(index) && !listProps.indexesToRender.includes(index)) {
        listProps.indexesToRender = this._rangeFromStart(
          this.state.contacts,
          0
        );
      }
      if ('add' === listProps.selectMode) {
        ListClass = MultiPickerList;
      } else {
        ListClass = SelectionList;
        listProps.isSearching = this._isSearching;
        listProps.onSelectionDone = this._onSelectionDone;
      }
    } else if (this.isPicker()) {
      ListClass = PickerList;
      listProps.target = this.props.target;
      listProps.tel = this.props.tel;
      listProps.email = this.props.email;
    }

    return (
      <div
        className="list-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onFocus={e => this.onFocus(e)}
      >
        {header ? <div className="header h1">{header}</div> : null}
        <div className={`body ${header ? 'contact-header' : null}`} ref="body">
          <div className="scroll hidden" ref="scroll" />
          <div
            className="list"
            ref={d => {
              this.list = d;
            }}
          >
            {hasItems || window.ssrHasContacts ? (
              <Search {...listProps} onSearch={this.onSearch} ref="search" />
            ) : null}
            <div className="list-all" ref="listAll">
              {dom}
              {hasItems || !dom.length ? <ListClass {...listProps} /> : null}
            </div>
          </div>
        </div>
        {!this._fetched ? <div className="header-progress" /> : null}
      </div>
    );
  }
}

/**
 * Stateless component for rendering favorite list and ice list
 */
const GroupListItem = ({
  hasItems,
  id,
  path,
  labelL10nId,
  onGroupFocus,
  createSoftKey,
}) => {
  const _domRef = element => {
    if ('group' === id && element) {
      onGroupFocus(element);
    }
    let config = {
      left: 'new-contact',
      center: 'select',
      right: hasItems ? 'options' : 'settings',
    };
    if (Service.query('isActivity')) {
      config = {
        left: 'cancel',
        center: 'select',
        right: '',
      };
    }
    element && createSoftKey(element, config);
  };
  let icon;
  if ('icelist' === id) {
    icon = 'ice-contacts';
  }
  if ('favorite' === id) {
    icon = 'favorite-on';
  }
  if ('group' === id) {
    icon = 'group-contacts';
  }
  return (
    <div
      className="list-item"
      tabIndex="-1"
      data-id={id}
      ref={_domRef}
      role="menuitem"
    >
      <i className="icon icon-list" data-icon={`${icon}`} role="presentation" />
      <div className="content">
        <div className="primary">
          <a href={path}>
            <span data-l10n-id={labelL10nId} />
          </a>
        </div>
      </div>
      <i className="icon" data-icon="forward" role="presentation" />
    </div>
  );
};
