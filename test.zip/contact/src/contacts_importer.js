import Utils from 'contact_utils';
import BaseImporter from './base_importer';

export default class ContactsImporter extends BaseImporter {
  name = 'ContactsImporter';
  DEBUG = false;

  _currentIndex = 0;

  constructor(pContacts, pConnector) {
    super();
    this.debug('init:');

    // type will be live or gmail
    this.type = pConnector.name.replace('Connector', '').toLowerCase();
    this.contacts = Object.values(pContacts);
    this.total = this.contacts.length;

    this.connector = pConnector;

    // To count the number of merged duplicate contacts
    this.numMergedDuplicated = 0;
    this.isOnLine = navigator.connection
      ? Utils.getType(navigator.connection.type)
      : navigator.onLine;
    Utils.handleNetworkEvent.call(this, 'add');
  }

  handleNetwork = evt => {
    if (navigator.connection) {
      this.isOnLine = evt.detail;
    } else {
      this.isOnLine = navigator.onLine;
    }
  };

  removeNetworkHandler = () => {
    Utils.handleNetworkEvent.call(this, 'remove');
  };

  importContact() {
    this.debug('importContact: _currentIndex:', this._currentIndex);
    const serviceContact = this.contacts[this._currentIndex];
    const deviceContact = this.connector.adaptDataForSaving(serviceContact);

    // We need to get the picture
    const callbacks = {
      success: blob => {
        this.pictureReady(blob, deviceContact);
      },
      error: this.save.bind(this, deviceContact),
      timeout: this.save.bind(this, deviceContact),
    };

    if (true === this.isOnLine) {
      this.connector.downloadContactPicture(serviceContact, callbacks);
    } else {
      callbacks.success(null);
    }
    this._currentIndex++;
  }

  pictureReady(blobPicture, contact) {
    // Photo is assigned to the service contact as it is needed by the
    // Fb Connector
    if (!blobPicture) {
      this.save(contact);
      return;
    }

    // XXX: thumbnail image
    contact.photo = [blobPicture];
    this.save(contact);
  }

  _import() {
    if (0 === this.total) {
      this.done();
      return;
    }
    this.importContact();
  }

  continue() {
    this.debug(
      'continue save: imported, aborted:',
      this.imported,
      this.aborted
    );
    if (this.aborted || this._currentIndex === this.total) {
      this.done();
    } else {
      this._import();
    }
  }
}
