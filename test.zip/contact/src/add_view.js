import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import FieldChooser from './field_chooser';
import ContactStore from './contact_store';

export default class AddView extends BaseComponent {
  name = 'AddView';

  constructor(props) {
    super(props);
    this.state = {
      contact: null,
    };
    window.add = this;
  }

  componentDidMount() {
    window.addv = this;
    this.element = ReactDOM.findDOMNode(this);
    ContactStore.getWrappedContact(this.props.id || 'new').then(contact => {
      this.setState({
        contact,
      });
    });
  }

  componentWillUnmount() {
    this.element = null;
  }

  componentDidUpdate() {
    this.onFocus();
  }

  onFocus() {
    if (document.activeElement === this.element && this.refs.editor) {
      // XXX: For some reason if we focus this.refs.list.element directly,
      // onFocus will not trigger for this.refs.list
      ReactDOM.findDOMNode(this.refs.editor).focus();
    }
  }

  render() {
    return (
      <div id="add-view" tabIndex="-1" onFocus={e => this.onFocus(e)}>
        <div
          className="header h1"
          data-l10n-id={this.props.field ? `${this.props.field}-type` : 'add'}
        />
        <div className="body">
          {this.state.contact ? (
            <FieldChooser ref="editor" {...this.state} {...this.props} />
          ) : null}
        </div>
      </div>
    );
  }
}
