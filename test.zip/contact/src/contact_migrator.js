import BaseModule from 'base-module';
import Service from 'service';
import ContactStore, { TAG_INDEX } from './contact_store';
import clone from './utils';

export default class ContactMigrator extends BaseModule {
  name = 'ContactMigrator';
  DEBUG = false;
  migrated = 0;
  failed = 0;
  total = 0;

  /**
   * The source of contacts to store as key in ImportStatusData
   * @type {String}
   */
  type = '';
  aborted = false;
  constructor(target, contacts, isMove) {
    super();
    this.target = TAG_INDEX[target];
    this.contacts = contacts;
    this.total = contacts.length;
    this.isMove = isMove;
    this.isMultiSIM = navigator.b2g.iccManager
      ? navigator.b2g.iccManager.iccIds.length > 1
      : false;

    this.targetCode =
      !this.isMultiSIM && target.startsWith('sim')
        ? 'sim'
        : this.target.toLowerCase();
    ContactStore.setEventEmittingState(false);
  }

  /**
   * This should be override by importers.
   * @return {Object} A promise
   */
  migrate() {
    this.debug('start migrate()');
    return new Promise(() => {
      this.wakeLock = navigator.b2g.requestWakeLock('cpu');
      return this._migrate();
    });
  }

  _migrate() {
    this.save(this.contacts[this.migrated]);
  }

  continue() {
    if (this.migrated === this.total || this.aborted) {
      this.done();
    } else {
      this._migrate();
    }
  }

  cancel() {
    this.migrating = false;
    // XXX: Better way to notify CS.
    ContactStore.setEventEmittingState(true);
    this.aborted = true;
    this.emit('aborted');
  }

  showToast() {
    const _ = window.api.l10n.get;
    Service.request('ToastManager:show', {
      text: _(
        `contact-${this.isMove ? 'move' : 'copy'}-to-${this.targetCode}`,
        {
          migrated: this.migrated - this.failed,
        }
      ),
    });
  }

  done() {
    ContactStore.setEventEmittingState(true);
    this.finished = true;
    setTimeout(() => {
      this.emit('finished', this);
    });
    this.wakeLock && this.wakeLock.unlock();
    this.showToast();
    Service.request('List:reload');
  }

  save(contactData) {
    const newContact = clone(contactData);
    newContact.id = '';
    if ('DEVICE' === this.target) {
      newContact.category = ['DEVICE', 'KAICONTACT'];

      // restore familyName, givenName from name
      if (newContact.name) {
        const ar = newContact.name[0].split(' ');
        newContact.givenName = [ar.shift()];
        newContact.familyName = [ar.join(' ')];
      }
    } else {
      // move/copy to sim
      newContact.category = [
        'SIM',
        'SIM' === this.target ? 'SIM0' : this.target,
        'KAICONTACT',
      ];
      [
        'photo',
        'givenName',
        'familyName',
        'email',
        'org',
        'adr',
        'bday',
        'note',
        'ringtone',
        'group',
      ].forEach(field => {
        newContact[field] = null;
      });

      // check and ignore unavailable contact(No valid SIM contact item)
      const validContact =
        (newContact.name && newContact.name[0] && newContact.name[0].length) ||
        (newContact.tel && newContact.tel[0] && newContact.tel[0].value.length);
      if (!validContact) {
        this.emit('migrated');
        this.migrated++;
        this.failed++;
        return this.continue();
      }

      // This is a workaround, we can't support saving multiple phone numbers
      // in SIM contact, so only keep the first number, should remove this
      // after we support multiple phone numbers.
      if (newContact.tel && newContact.tel.length > 1) {
        newContact.tel = [newContact.tel[0]];
      }
    }

    this.debug('ready to save: target, name:', this.target, newContact.name);
    ContactStore.createOrUpdate(newContact, false).then(result => {
      if (result.error) {
        const _ = window.api.l10n.get;
        switch (result.error) {
          case 'NoFreeRecordFound':
            result.message = _(
              `contact-${this.isMove ? 'move' : 'copy'}-error-sim-full`
            );
            break;
          case 'contacts-limit-exceeded':
            result.message = _(
              `contact-${this.isMove ? 'move' : 'copy'}-error-limit-exceeded`
            );
            break;
          default:
            result.message = _(
              `contact-${this.isMove ? 'move' : 'copy'}-error-unknown`
            );
            break;
        }
        this.error = result;
        this.done();
      } else {
        this.migrated++;
        this.emit('migrated');
        if (this.isMove) {
          ContactStore.remove(contactData)
            .then(() => {
              this.continue();
            })
            .catch(() => {
              this.debug('error when removing the original contact');
              this.continue();
            });
        } else {
          this.continue();
        }
      }
    });
  }
}
