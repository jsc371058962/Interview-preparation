import React from 'react';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import InputItem from 'components/input_item';
import ContactStore from 'contact_store';
import perf from 'modules/perf';
import 'search_container.scss';

export default class Search extends BaseComponent {
  name = 'Search';
  DEBUG = false;

  static defaultProps = {
    onSearch: () => {},
  };

  constructor(props) {
    super(props);
    this.state = {
      filter: '',
      searching: false,
    };
    this.timer = null;
    this.timerCountdown = 100;
  }

  componentDidMount() {
    this.debug('did mount');
    window.sr = this;
    this._softKey = SoftKeyManager.create(this.element, {});
  }

  componentDidUpdate() {
    this._softKey.update({
      left: this.props.selectMode ? '' :
        this.props.target ? 'cancel' : 'new-contact',
      center: '',
      right: this.props.selectMode || this.props.target ?
        '' : 'settings',
    });
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  doSearch = filter => {
    perf.mark('search');
    this.setState(
      {
        searching: true,
        filter,
      },
      () => {
        const options = {
          value: filter,
          contacts: this.props.shouldFilterContacts,
        };
        ContactStore.search(options).then(matchedContacts => {
          this._onSearch(matchedContacts);
          this.setState({
            searching: false,
          });
        });
      }
    );
  };

  _onChange = e => {
    if (e && e.nativeEvent.isComposing) {
      return clearTimeout(this.timer);
    }
    const filter = e.target.value;
    this.debug('search filter:', filter);
    if (this.timer) {
      clearTimeout(this.timer);
    }
    this.timer = setTimeout(() => {
      this.doSearch(filter);
      clearTimeout(this.timer);
    }, this.timerCountdown);
  };

  _onSearch = matchedContacts => {
    this.props.onSearch({
      filter: this.state.filter,
      matchedContacts,
    });
  };

  cancelSearch() {
    this.inputElement.value = '';
    this.setState({
      searching: false,
      filter: '',
    });
  }

  get inputElement() {
    return this.element.querySelector('input');
  }

  render() {
    this.debug('render');

    const progress =
      this.state.filter && this.state.searching ? (
        <div className="header-progress" />
      ) : null;

    return (
      <div
        ref={e => {
          this.element = e;
        }}
        className="search-container"
        data-search-ended={!!(this.state.filter && !this.state.searching)}
      >
        <InputItem
          id="search"
          l10nId="search"
          type="text"
          maxLength={100}
          onChange={this._onChange}
        />
        {progress}
      </div>
    );
  }
}
