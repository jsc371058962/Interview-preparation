import { TAG_INDEX } from 'contact_store';
import BaseImporter from './base_importer';
import Utils from './contact_utils';

/**
 * Imports contacts stored in the SIM card and saves them into
 * ContactsManager. Three steps => three callback as arguments:
 *   - onread: SIM card has been read properly;
 *   - onimport: A Contact has been imported
 *   - onfinish: contacts have been saved into ContactsManager;
 *   - onerror: SIM card is empty or could not be read.
 */

const CHUNK_SIZE = 5;
const DEFAULT_TEL_TYPE = 'other';

export default class SimImporter extends BaseImporter {
  name = 'SimImporter';
  DEBUG = false;

  constructor(index) {
    super();
    window.si = this;
    this.type = `sim-${index}`;
    const iccId = SIMSlotManager.getSlots()[index].conn.iccId;
    const icc = navigator.b2g.iccManager.getIccById(iccId);
    this.icc = icc;
    this.iccId = this.icc.iccInfo && this.icc.iccInfo.iccid;
  }

  _import() {
    this.numResponses = 0;
    if (this.aborted) {
      this.done();
      return;
    }

    let requestAdn;
    let requestSdn;

    // request contacts with readContacts() -- valid types are:
    //   'adn': Abbreviated Dialing Numbers
    //   'fdn': Fixed Dialing Numbers
    //   'sdn': Service Dialing Numbers
    if (this.icc && this.icc.readContacts) {
      requestAdn = this.icc.readContacts('adn');
    } else {
      throw new Error('Not able to obtain a SIM import function from platform');
    }

    requestAdn.onsuccess = () => {
      this.debug('request adn success');
      if (this.aborted) {
        this.done();
        return;
      }
      this.items = requestAdn.result || [];

      requestSdn = this.icc.readContacts('sdn');
      requestSdn.onsuccess = () => {
        if (this.aborted) {
          this.done();
          return;
        }

        if (Array.isArray(requestSdn.result)) {
          this.items = this.items.concat(requestSdn.result);
        }
        this.onContactsReadyForImport();
      };
      requestSdn.onerror = error => {
        if (this.aborted) {
          this.done();
          return;
        }
        console.warn('Could not read SDN Contacts from SIM Card', error.name);
        this.onContactsReadyForImport();
      };
    };
    requestAdn.onerror = () => {
      this.debug('request adn error');
      console.error(requestAdn.error);
      this.emit('error', requestAdn.error);
    };
  }

  /**
   * store mozContact elements -- each returned mozContact has two properties:
   *   .name : [ string ]
   *   .tel  : [{ number: string, type: string }]
   * The 'name' property is only related to the mozContact element itself --
   * let's use it as the default 'givenName' value.
   */
  importSlice(from) {
    for (let i = from; i < from + CHUNK_SIZE && i < this.items.length; i++) {
      const item = iccToMozContact(this.iccId, item);

      // Item is presumably a mozContact but for some reason if
      // we don't create a new mozContact sometimes the save call fails
      this.save(item);
    }
  }

  continue() {
    this.numResponses++;
    if (this.imported < this.items.length && this.numResponses === CHUNK_SIZE) {
      this.numResponses = 0;
      if (this.aborted) {
        this.done();
      } else {
        this.importSlice(this.imported);
      }
    } else if (this.imported >= this.items.length) {
      this.done();
    }
  }

  startMigration() {
    if (!this.aborted && Array.isArray(this.items) && this.items.length > 0) {
      this.importSlice(0);
    } else {
      this.done();
    }
  }

  onContactsReadyForImport() {
    console.log('ready', this.items);
    this.total = this.items.length;
    if (0 === this.total) {
      this.emit('finished');
      return;
    }
    this.emit('ready');
    this.startMigration();
  }
}

/**
 * Basic MozContact schema:
 * {
 *  name: Array,
 *  givenName: Array,
 *  familyName: Array,
 *  tel: Array,
 *  category: Array,
 *  url: Array
 * }
 */
export function iccToMozContact(iccId, item) {
  const parsedName = Utils.parseName(item.name);
  const res = {};
  res.givenName = [parsedName.givenName];
  res.familyName = [parsedName.familyName];
  res.name = [item.name];

  if (item.number) {
    res.tel = [{ value: item.number, type: [DEFAULT_TEL_TYPE] }];
  }

  if (item.email) {
    res.email = [{ value: item.email, type: [DEFAULT_TEL_TYPE] }];
  }

  res.category = [TAG_INDEX.kaiContact, TAG_INDEX.sim, 'sdn'];
  res.url = [
    {
      type: ['source', 'sim'],
      value: `urn:uuid:${iccId || 'iccId'}-${item.id}`,
    },
  ];

  res.id = item._id;

  return res;
}
