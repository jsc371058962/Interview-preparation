import React from 'react';
import BaseComponent from 'base-component';
import ContactStore from './contact_store';

export default class BlockNumberListItem extends BaseComponent {
  render() {
    const item = this.props.blockitem;
    const contactList = ContactStore.speedFindContactByNumber(item);
    const dom = [];
    let count = 0;
    contactList.forEach(name => {
      count++;
      if (count <= 5) {
        dom.push(
          <div className="secondary">
            <span>{name}</span>
          </div>
        );
      }
    });

    if (count > 5) {
      dom.push(
        <div className="secondary">
          <span data-l10n-id="ellipsis" />
        </div>
      );
    }

    return (
      <div className={`list-item navigable`} tabIndex="-1">
        <div className="content">
          <div className="primary" data-name={item}>
            {item}
          </div>
          {dom}
        </div>
      </div>
    );
  }
}
