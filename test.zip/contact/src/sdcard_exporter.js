import BaseExporter from './base_exporter';
import Utils from './vcard_utils.js';

export default class SdcardExporter extends BaseExporter {
  name = 'SdcardExporter';
  DEBUG = false;

  hasDeterminativeProgress = true;

  title = 'memoryCardExport-title';

  continue() {
    const req = Utils.ContactToVcard(this.contacts, {
      // Set batchSize to 500K, will update vcard file using append-to-file
      batchSize: 500 * 1024,
    });

    this.on('canceled', () => {
      req.cancel();
      this.clearStorage();
    });

    req.onbatch = (vcards, nCards, done = false) => {
      this.debug('ready to append a batch to the storage:', nCards);
      if (this.aborted) {
        this.debug('aborted before getStorage');
        this.emit('canceled');
        return;
      }
      const blob = new Blob([vcards], { type: 'text/vcard' });
      this.pendingBatches.push({
        blob,
        bDone: done,
      });
      if (!this.storedFileName) {
        this.storedFileName = this.getFileName();
        this.saveVcardFile(this.storedFileName, false, false);
      } else if (this.append) {
        this.saveVcardFile(this.storedFileName, true, false);
      }
    };

    req.onsuccess = () => {
      this.debug('all batches processed success');
      // invoke done() when all batches are saved
    };

    req.onprogress = () => {
      if (this.aborted) {
        return true;
      }
      this.debug('onProgress:', this.current);
      this.current++;
      this.emit('exported');
    };
  }

  clearStorage() {
    if (!this.storage || !this.aborted) {
      return;
    }
    const name = this.storedFileName;
    const req = this.storage.delete(this.storedFileName);
    req.onsuccess = () => {
      this.debug('file deleted:', name);
    };
    req.onerror = e => {
      console.warn('something wrong when deleting file:', name, e);
    };
  }
}
