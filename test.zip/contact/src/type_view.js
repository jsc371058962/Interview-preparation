import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import FieldStore from './field_store';

export default class TypeView extends BaseComponent {
  name = 'TypeView';

  FOCUS_SELECTOR = '.list-item';

  componentDidMount() {
    this.element = ReactDOM.findDOMNode(this);
    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element
    );
    this.updateSoftKeys();
    window.typeview = this;
  }

  updateSoftKeys() {
    const config = {
      left: 'cancel',
      center: 'select',
    };

    this._softKey = SoftKeyManager.create(this.element, config);
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  onKeyDown(evt) {
    let type = '';
    switch (evt.key) {
      case 'Enter':
        type = evt.target.dataset.type;
        if (typeof this.props.index !== 'undefined') {
          FieldStore.add(this.props.field, type, +this.props.index);
        } else {
          FieldStore.add(this.props.field, type);
        }
        Service.request('back');
        break;
      case 'Backspace':
      case 'SoftLeft':
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('back');
        break;
      default:
        break;
    }
  }

  render() {
    return (
      <div
        id="new-contact-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onFocus={e => this.onFocus(e)}
      >
        <div className="header h1">Type</div>
        <div className="body">
          <div className="list-item" tabIndex="-1" data-type="home">
            <div className="content">
              <div className="primary">Home</div>
            </div>
          </div>
          <div className="list-item" tabIndex="-1" data-type="work">
            <div className="content">
              <div className="primary">Work</div>
            </div>
          </div>
          <div className="list-item" tabIndex="-1" data-type="mobile">
            <div className="content">
              <div className="primary">Mobile</div>
            </div>
          </div>
          <div className="list-item" tabIndex="-1" data-type="personal">
            <div className="content">
              <div className="primary">Personal</div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

TypeView.propTypes = {
  field: React.PropTypes.string,
  index: React.PropTypes.number,
};
