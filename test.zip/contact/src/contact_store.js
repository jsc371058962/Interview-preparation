import BaseModule from 'base-module';
import Service from 'service';
import ContactStoreCache, { sort } from 'modules/contact_store_cache';
import { convertContactToLocal, convertContactToRemote } from 'contact_wrapper';
import {
  operateSync,
  accountContactsFilter,
  SYNC_OPERATION,
  accountStore,
} from 'account/account_manager';
import simStore from './sim_store';

const PHONE_CONTACTS_LIMIT = 1000;
export const MAX_GROUP_NUMBER = 20;

export const TAG_INDEX = {
  phone: 'DEVICE',
  sim: 'SIM',
  sim0: 'SIM0',
  sim1: 'SIM1',
  kaiContact: 'KAICONTACT',
};

// These enumerated errors help other modules to identify error consistently
export const CONTACT_STORE_ERROR = {
  LIMIT_EXCEEDED: 'contacts-limit-exceeded',
};

/**
 * Get full contacts from ContactStoreCache, store as `fullContacts`
 * Listen to `contactchange` event and update `fullContacts`
 * Extract category contacts from `fullContacts`
 */
class ContactStore extends BaseModule {
  name = 'ContactStore';
  DEBUG = false;

  fullContacts = [];
  fullBlockContacts = new Set();
  contactMap = new Map();
  favoriteMap = new Map();
  groupMap = new Map();
  importing = false;
  fullDisk = false;
  dataStore = null;

  // Store a wrapper object which extends a specific mozContact by its id
  wrappedContactMap = new Map();

  /**
   * When false, will not emit `changed` event in `_handle_contactchange`.
   */
  _eventEmitting = true;

  isContactHasChanged = false;

  start() {
    if (!ContactsManager) {
      return;
    }
    ContactsManager.addEventListener(
      ContactsManager.EventMap.CONTACT_CHANGE,
      this._handle_contactchange
    );
    ContactsManager.addEventListener(
      ContactsManager.EventMap.BLOCKED_NUMBER_CHANGE,
      this._handle_blockednumberchange
    );
    ContactsManager.addEventListener(
      ContactsManager.EventMap.GROUP_CHANGE,
      this._handle_contactgroupchange
    );
    ContactStoreCache.on('simLoaded', this.handleSimLoaded);

    this.isDiskFull().then(fullDisk => {
      this.fullDisk = fullDisk;
    });
    navigator.b2g.onstoragefree = () => {
      this.fullDisk = false;
    };
    navigator.b2g.onstoragefull = () => {
      this.fullDisk = true;
    };

    ContactStoreCache.getFullContacts({
      onFetching: ({ currentContacts, contact }) => {
        this._changeMap(ContactsManager.ChangeReason.CREATE, contact);
        this.fullContacts = currentContacts;
      },
    }).then(contacts => {
      this.fullBlockContacts = ContactStoreCache._blockContacts;
      this.groupMap = ContactStoreCache._groupMap;
      this._cached = true;
      this.fullContacts = this.interceptContact(contacts);
      this.updateCache();
      this.updateSort();
      operateSync(SYNC_OPERATION.PULL_ALL);
      this.emit('loaded');
    });

    // keep _eventEmitting to false, to avoid the other activity save contact and trigger
    // changed event. this will lead to waste resource to sort and render the list.
    // after back from background recover the oldEventEmit except the state has set to true.
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this._oldEventEmitting = this._eventEmitting;
        this.setEventEmittingState(false);
      } else if (this.isContactHasChanged) {
        !this._setEventEmitToTrueInBack &&
          this.setEventEmittingState(this._oldEventEmitting);
        this._setEventEmitToTrueInBack = false;
        this.isContactHasChanged = false;
      } else {
        this._eventEmitting = true;
      }
    });
  }

  get currentContacts() {
    return this.getSourceContacts(this.source);
  }

  getSourceContacts(source) {
    const category = TAG_INDEX[source] || 'KAICONTACT';
    return this.fullContacts
      .filter(c => c.category && c.category.includes(category))
      .filter(accountContactsFilter);
  }

  set sortingRule(rule) {
    if (this.sortingRule === rule) {
      return;
    }
    this.setItem('sort', rule);
    this.fullContacts = sort(this.fullContacts);
    this.emit('changed');
  }

  get sortingRule() {
    const rule = window.localStorage.getItem('sort');
    return rule || 'givenName';
  }

  get source() {
    const rule = window.localStorage.getItem('memory');
    return rule || 'phone';
  }

  set source(settings) {
    this.setItem('memory', settings);
    this.updateSort(true);
  }

  get _category() {
    return TAG_INDEX[this.source] || TAG_INDEX.kaiContact;
  }

  isDiskFull() {
    return new Promise(resolve => {
      navigator.b2g
        .getDeviceStorage('apps')
        .isDiskFull()
        .then(result => {
          resolve(result);
        });
    });
  }

  updateCache() {
    this.debug('updateCache:');
    if (this.favoriteMap.size > 0) {
      this.setItem('hasFavorites', true);
    } else {
      window.localStorage.removeItem('hasFavorites');
    }
  }

  updateGroupCache() {
    this.debug('updateGroupCache:');
    if (this.groupMap.size > 0) {
      this.setItem('hasGroups', true);
    } else {
      window.localStorage.removeItem('hasGroups');
    }
  }

  setItem(name, data) {
    try {
      window.localStorage.setItem(name, data);
    } catch (e) {
      console.error(`localStorage:set ${name} value error: ${e}`);
    }
  }

  updateSort(bSort = false) {
    if (bSort) {
      this.fullContacts = sort(this.fullContacts);
      this.emit('changed');
    } else {
      let firstLoad = true;
      SettingsObserver.observe('language.current', '', value => {
        if (!firstLoad) {
          this.fullContacts = sort(this.fullContacts, value);
          this.emit('changed');
        } else {
          firstLoad = false;
        }
      });
    }
  }

  getContactSync(id) {
    return this.contactMap.get(id);
  }

  isEmpty() {
    return 0 === this.contactMap.size;
  }

  isSIMContact = contact => {
    return contact.category && contact.category.includes(TAG_INDEX.sim);
  };

  getContact(id) {
    return new Promise(resolve => {
      if (this.contactMap.get(id)) {
        resolve(this.contactMap.get(id));
      } else {
        resolve();
        // Use find API
      }
    });
  }

  getWrappedContact(id, data) {
    this.debug('getWrappedContact: id, data:', id, data);
    return new Promise(resolve => {
      import('./contact_wrapper').then(module => {
        const ContactWrapper = module.default;
        const raw = this.contactMap.get(id);
        if (data) {
          const contact = new ContactWrapper(raw, data);
          this.wrappedContactMap.set(id, contact);
          resolve(contact);
        } else if (this.wrappedContactMap.get(id)) {
          resolve(this.wrappedContactMap.get(id));
        } else {
          if (!raw && 'new' !== id) {
            this._findById(id).then(result => {
              if (result) {
                const contact = new ContactWrapper(result);
                this.wrappedContactMap.set(id, contact);
                resolve(contact);
              } else {
                // go through simstore for sdn contact
                import('./sim_store').then(m => {
                  const SimStore = m.default;
                  SimStore.getCardWithSDNList().then(() => {
                    const contacts = SimStore.getSDNContacts();
                    contacts.forEach(list => {
                      return list.some(sdn => {
                        if (sdn.id === id) {
                          this.wrappedContactMap.set(
                            id,
                            new ContactWrapper(sdn)
                          );
                          resolve(this.wrappedContactMap.get(id));
                          return true;
                        }
                        return false;
                      });
                    });
                  });
                });
              }
            });
            return;
          }
          const contact = new ContactWrapper(raw);
          this.wrappedContactMap.set(id, contact);
          resolve(contact);
        }
      });
    });
  }

  /**
   * Keep in-memory contacts sync to mozContacts
   * Because we don't know the just saved contact id from `mozContacts.save` result,
   * if we want to do something on the contact id, it only can be done here.
   * It will be inefficent when creating/updating massively.
   * Better of gecko to return the contact id in the result of `mozContacts.save`.
   */
  _handle_contactchange = evt => {
    this.isContactHasChanged = true;
    this.debug(
      '_handle_contactchange: reason, _eventEmitting:',
      evt.reason,
      this._eventEmitting
    );
    const contact = convertContactToLocal(evt.contacts[0]);
    switch (evt.reason) {
      case ContactsManager.ChangeReason.CREATE:
      case ContactsManager.ChangeReason.UPDATE:
        // save new sim contact need use update to pass ID
        !this.getContactSync(contact.id) && this.fullContacts.unshift(contact);
        ContactsManager.ChangeReason.UPDATE === evt.reason &&
          this.fullContacts.some((c, i) => {
            if (c.id === contact.id) {
              this.fullContacts[i] = contact;
              return true;
            }
            return false;
          });
        this._changeMap(evt.reason, contact);
        if (this._eventEmitting) {
          let atIndex = this.currentContacts.map(c => c.id).indexOf(contact.id);
          this.fullContacts = sort(this.fullContacts, null, atIndex);
          this.isContactHasChanged = false;
          if (false === this.updatedContact) {
            this.updatedContact = true;
            this.emit('changed');
          } else {
            atIndex = this.currentContacts.map(c => c.id).indexOf(contact.id);
            this.debug('emit changed: atIndex:', atIndex);
            this.emit('changed', { atIndex });
          }
        } else {
          this.updatedContact = true;
          this.reSort = true;
        }
        this.updateCache();
        break;
      case ContactsManager.ChangeReason.REMOVE:
        if (evt.contacts.length) {
          evt.contacts.forEach(_contact => {
            const localData = this.getContactSync(_contact.id);
            this._changeMap(evt.reason, _contact);
            const atIndex = this.fullContacts
              .map(c => c.id)
              .indexOf(_contact.id);
            this.fullContacts.splice(atIndex, 1);
            accountStore.getAccounts().length &&
              operateSync(SYNC_OPERATION.QUEUE_DELETION, {
                contact: localData,
              });
          });
        }
        if (!this.fullContacts.length) {
          window.ssrHasContacts = false;
        }

        if (this._eventEmitting) {
          this.isContactHasChanged = false;
          this.emit('changed', { atIndex: -1 });
        }
        this.updateCache();
        break;
      default:
        this.debug('unhandled oncontactchange reason:', evt.reason);
        break;
    }
  };

  _handle_blockednumberchange = evt => {
    switch (evt.reason) {
      case ContactsManager.ChangeReason.CREATE:
        this.fullBlockContacts.add(evt.number);
        break;
      case ContactsManager.ChangeReason.REMOVE:
        this.fullBlockContacts.delete(evt.number);
        break;
      default:
        break;
    }
  };

  _handle_contactgroupchange = evt => {
    this.debug('_handle_contactgroupchange: reason:', evt.reason);
    const { id, name } = evt.group;
    switch (evt.reason) {
      case ContactsManager.ChangeReason.CREATE:
      case ContactsManager.ChangeReason.UPDATE:
        this.groupMap.set(id, { id, name });
        this.updateGroupCache();
        this.emit('group-changed', { reason: evt.reason });
        break;
      case ContactsManager.ChangeReason.REMOVE:
        this.groupMap.delete(id);
        this.updateGroupCache();
        this.emit('group-changed', {
          reason: evt.reason,
        });
        break;
      default:
        break;
    }
  };

  handleSimLoaded = contacts => {
    if (contacts) {
      this.fullContacts = contacts;
      this.emit('change');
    }
  };

  _findById(id) {
    return new Promise(resolve => {
      ContactsManager.getContactByID(id).then(
        contact => {
          resolve(contact);
        },
        () => {
          resolve(null);
        }
      );
    });
  }

  speedFindContactByNumber(number) {
    const contactPacket = [];
    this.fullContacts.forEach(contact => {
      let addresses = [];

      if (contact.tel && contact.tel.length) {
        addresses = addresses.concat(contact.tel);
      }

      if (contact.email && contact.email.length) {
        addresses = addresses.concat(contact.email);
      }

      addresses.forEach(current => {
        if (current.value === number) {
          contactPacket.push(contact.name[0]);
        }
      });
    });
    return contactPacket;
  }

  /**
   * Set an internal state `_eventEmitting` as a switching of `changed` event.
   * When false, will not emit `changed` event in `_handle_contactchange`.
   * This is used when importing or removing massive contacts.
   */
  setEventEmittingState(state) {
    if (document.hidden && state) {
      this._setEventEmitToTrueInBack = true;
    }
    this._eventEmitting = state;
    if (state) {
      if (this.reSort) {
        this.fullContacts = sort(this.fullContacts);
        this.reSort = false;
      }
      this.debug('emit changed from setEventEmittingState true');
      this.emit('changed');
    } else {
      this.updatedContact = true;
    }
  }

  getCount() {
    return ContactsManager.getCount();
  }

  hasFavorites() {
    if (this.source !== 'sim') {
      if (window.localStorage.getItem('hasFavorites')) {
        return true;
      }
      return this.favoriteMap.size > 0;
    }
    window.localStorage.removeItem('hasFavorites');
    return false;
  }

  getFavorites() {
    return Array.from(this.favoriteMap.values());
  }

  // XXX: simplify since similar function signature as ContactStoreCache.get
  getByBatch({ source = this.source, onBatch = () => {} } = {}) {
    this.debug('getByBatch: source:', source);
    const category = TAG_INDEX[source] || 'KAICONTACT';
    if (this._cached) {
      const contacts = this.getSourceContacts(source);
      return Promise.resolve(contacts);
    }

    return ContactStoreCache.get({
      category,
      onBatch,
    }).then(contacts => contacts.filter(accountContactsFilter));
  }

  /**
   * Keep in-memory contactMap, favoriteMap sync to contacts
   */
  _changeMap(reason, contact) {
    const id = contact.id;
    switch (reason) {
      case ContactsManager.ChangeReason.CREATE:
      case ContactsManager.ChangeReason.UPDATE:
        this.contactMap.set(id, contact);
        if (this.isFavorite(contact)) {
          this.favoriteMap.set(id, contact);
        } else if (this.favoriteMap.has(id)) {
          this.favoriteMap.delete(id);
        }
        this.wrappedContactMap.get(id) &&
          this.wrappedContactMap.get(id).update(contact);
        break;
      case ContactsManager.ChangeReason.REMOVE:
        this.contactMap.delete(id);
        if (this.favoriteMap.has(id)) {
          this.favoriteMap.delete(id);
        }
        break;
      default:
        break;
    }
  }

  /**
   * @return {promise} Resolved with object: { data, message, error }
   */
  createOrUpdate(data = {}, bUpdate = false, action = null) {
    this.debug('createOrUpdate: id, name:', data.id, data.name);

    const _ = window.api.l10n.get;
    const category = data.category || [];
    // check limit when saving a phone contact
    if (0 === category.length || category.includes('DEVICE')) {
      if (
        this.getSourceContacts('phone').length >= PHONE_CONTACTS_LIMIT &&
        !bUpdate
      ) {
        return Promise.resolve({
          error: CONTACT_STORE_ERROR.LIMIT_EXCEEDED,
          message: _('phone-contacts-limit-exceeded'),
        });
      }
    }

    if (Service.query('isLowMemoryDevice') && data.photo) {
      data.photo = null;
      delete data.photo;
    }

    // Remove html content in name filed
    ['name', 'familyName', 'givenName'].forEach(field => {
      if (data[field] && data[field].length > 0 && data[field][0].length) {
        data[field][0] = data[field][0].replace(
          /<(?:[^"'>]|"[^"]*"|'[^']*')*>/g,
          ''
        );
      }
    });

    // Remove ' ' and '-' in the tel number
    if (data.tel && data.tel.length) {
      data.tel.forEach((number, index) => {
        data.tel[index].value = number.value.replace(/[\s|\-]/g, '');
      });
    }

    // XXX: refactor `createOrUpdate`
    // the usage of `bUpdate` and `action` are unclear
    // and conditions mixed together
    const isUpdate = this.contactMap.has(data.id);

    let promise = Promise.resolve();
    if (this.isSIMContact(data)) {
      promise = simStore.saveContactToSim(data);
    }

    return new Promise(resolve => {
      return promise
        .then(async simContact => {
          const toRemoteContact = await convertContactToRemote(data);
          // SIM card data need sync with DB, so should pass ID and use update.
          if (simContact && simContact.id) {
            toRemoteContact.id = simContact.id;
            toRemoteContact.name = simContact.name;
            toRemoteContact.familyName = simContact.name;
            toRemoteContact.givenName = simContact.name;
          }
          return ContactsManager.save(!toRemoteContact.id, [
            toRemoteContact,
          ]).then(() => {
            this.debug('a contact saved/updated.');
            const result = {
              data,
            };
            result.message = isUpdate ? _('changes-saved') : _('contact-added');
            if (!this._eventEmitting && this.updatedContact) {
              this.updatedContact = false;
            }
            if (!isUpdate && 'manual' === action) {
              this.sendEventLogs();
            }
            resolve(result);
          });
        })
        .catch(e => {
          console.error('Error when saving a contact:', e);
          const result = {
            error: e.message,
          };
          result.message =
            'NoFreeRecordFound' === result.error
              ? _('sim-contacts-limit-exceeded')
              : _('contact-save-error-unknown');
          resolve(result);
        });
    });
  }

  /**
   * @return {promise} Resolved with object: { data, message, error }
   */
  remove({ id }) {
    if (!id) {
      return;
    }
    this.debug('remove: id:', id);
    const data = this.getContactSync(id);
    let promise = Promise.resolve();
    if (this.isSIMContact(data)) {
      promise = simStore.deleteSimContact(data);
    }
    return new Promise(resolve => {
      promise.then(() =>
        ContactsManager.remove(Array.isArray(data.id) ? data.id : [data.id])
          .then(() => {
            this.debug('a contact deleted:', data.id);
            resolve({
              data,
              message: window.api.l10n.get('a-contact-deleted'),
            });
          })
          .catch(e => {
            console.error('Error when deleting a contact:', e);
            const result = {
              error: e,
            };
            resolve(result);
          })
      );
    });
  }

  /**
   * Do `mozContact.save` or `mozContact.remove` one by one.
   * XXX: apply to `contacts_remover.js`, `contact_migrator.js`, `base_importer.js`
   * @return {promise}
   */
  batchOperate = (contacts, options) => {
    const {
      operation, // 'createOrUpdate' or 'remove'
      onContactChanged = () => {},
    } = options;
    this.debug('batchOperate:', operation);

    let p = Promise.resolve();
    contacts.forEach((contact, index) => {
      // chain promise, execute saving after previous one saved
      p = p
        .then(() => this[operation](contact))
        .then(result => {
          const { data, error } = result;
          // break the batch operation immediately
          if (error) throw error;
          onContactChanged(data, index);
          return result;
        })
        .catch(e => {
          console.error('[ContactStore](batchOperate) error:', operation, e);
          throw e;
        });
    });

    return p.then(result => {
      this.debug('(batchOperate) all done:', operation);
      return result;
    });
  };

  clearContacts() {
    this.debug('do ContactsManager.clear():');
    return new Promise(resolve => {
      simStore.clearSimContact().then(() =>
        ContactsManager.clear()
          .then(() => {
            window.ssrHasContacts = false;
            if (accountStore.getAccounts().length > 0) {
              this.fullContacts.forEach(c =>
                operateSync(SYNC_OPERATION.QUEUE_DELETION, { contact: c })
              );
            }
            this.fullContacts = [];
            this.contactMap.clear();
            this.favoriteMap.clear();
            window.localStorage.removeItem('hasFavorites');
            import('ice_store').then(module => {
              module.default.clearAllIce();
              this.emit('changed');
              resolve(true);
            });
          })
          .catch(e => {
            console.error('error when doing mozContacts.clear():', e);
          })
      );
    });
  }

  sendEventLogs() {
    let source = 'Manual';
    if (Service.query('isActivity')) {
      const activityData = Service.query('activityData');
      if (activityData.caller) {
        source = activityData.caller;
      } else {
        source = 'Sender';
      }
    }

    return new Promise(resolve => {
      this.getCount().then(result => {
        const options = {
          event_type: 'contact_add',
          data: {
            contact_source: source,
            contact_count: result,
          },
        };
        const activity = new WebActivity('eventlogger-event', options);

        activity.start().then(() => {
          resolve();
        });
      });
    });
  }

  generateFakeData(count = 70, isSIMContact) {
    require.ensure([], require => {
      require('chance');
      const api = ContactsManager;
      const contacts = [];
      for (let i = 0; i < count; i++) {
        const first = window.chance.first();
        const last = window.chance.last();
        const aContact = {
          givenName: [first],
          familyName: [last],
          name: [`${first} ${last}`],
          tel: [
            {
              type: ['mobile'],
              value: window.chance.phone(),
            },
          ],
        };
        if (isSIMContact) {
          aContact.category = ['SIM', 'SIM0'];
        }
        contacts.push(aContact);
      }

      if (currentContact) {
        const req = api.save(true, [contacts]);
        req
          .then(e => {
            console.log('generateFakeData: saved:', currentContact.name, e);
          })
          .catch(e => {
            console.error('generateFakeData error:', e.target.error.name);
          });
      }
    });
  }

  /**
   * We permit only one active searching.
   * The latest execution will interrupt the previous one.
   * Search the value in current contacts list.
   *
   * @param {string} value The target value to search for.
   * @param {object} contacts list
   * @return {promise} Will resolve all the matched contacts in the end.
   */
  search({ contacts = this.currentContacts, value }) {
    if (!value) {
      return Promise.resolve([]);
    }

    return new Promise(resolve => {
      const filter = {
        filterBy: ['name', 'familyName', 'givenName', 'tel', 'email'],
        filterValue: value,
        filterOp: 'startsWith',
      };

      const searchResult = [];
      if (Service.query('isActivity')) {
        const activityData = Service.query('activityData');
        if (activityData.type) {
          if (activityData.type.includes('webcontacts/email')) {
            filter.filterBy = ['email', 'name', 'familyName', 'givenName'];
          } else if (activityData.type.includes('webcontacts/tel')) {
            filter.filterBy = ['tel', 'name', 'familyName', 'givenName'];
          }
        }
      }

      const filterMatchFieldValue = (words, field) => {
        if (!words) {
          return false;
        }
        const _value = String(words);
        if ('tel' === field) {
          return _value
            .toLocaleLowerCase()
            .includes(filter.filterValue.toLocaleLowerCase());
        }

        // Other field except tel needs filter by startsWith.
        return _value
          .toLocaleLowerCase()
          [filter.filterOp](filter.filterValue.toLocaleLowerCase());
      };

      contacts.forEach(contact => {
        const {
          name,
          familyName,
          givenName,
          tel,
          email,
          id,
          photo,
          category,
        } = contact;
        const newContact = {
          id,
          photo,
          category,
          name: [name && name[0]],
          familyName: [(familyName && familyName[0]) || ''],
          givenName: [(givenName && givenName[0]) || ''],
          tel,
          email,
        };

        // Tel, email should be first check.
        let isContainsByTelOrEmail = false;
        let isContainsByOthers = false;
        filter.filterBy.forEach(field => {
          if (
            ['tel', 'email'].includes(field) &&
            newContact[field] &&
            newContact[field].length > 0
          ) {
            const arr = newContact[field]
              .filter(v => v.value)
              .map(({ value: v }) => v);
            Array.from(new Set(arr)).forEach(v => {
              if (filterMatchFieldValue(v, field)) {
                isContainsByTelOrEmail = true;
              }
            });
            return;
          }

          if (
            filterMatchFieldValue(
              newContact[field] && newContact[field][0],
              field
            )
          ) {
            isContainsByOthers = true;
          }
        });

        if (isContainsByOthers || isContainsByTelOrEmail) {
          searchResult.push(newContact);
        }
      });

      console.log('--result contacts--', searchResult);
      resolve(searchResult);
    });
  }

  isBlockContact(phone) {
    return this.fullBlockContacts.has(phone);
  }

  addBlockContact(phone) {
    return new Promise((resolve, reject) => {
      ContactsManager.addBlockedNumber(phone)
        .then(() => resolve())
        .catch(error => {
          reject(error.name);
        });
    });
  }

  removeBlockContact(phone) {
    return new Promise((resolve, reject) => {
      ContactsManager.removeBlockedNumber(phone)
        .then(() => resolve())
        .catch(error => {
          reject(error.name);
        });
    });
  }

  toogleBlock(contact) {
    this.createOrUpdate(contact, true);
  }

  // add group and rename group, distinguish by param id
  saveGroup(groupName, id) {
    const name = groupName.trim();
    if (!name) {
      return;
    }
    return new Promise((resolve, reject) => {
      if (this.groupNameIsExist(name, id)) {
        reject('duplicate');
        return;
      }
      if (this.groupMap.size >= MAX_GROUP_NUMBER && !id) {
        reject('too-many');
        return;
      }

      ContactsManager.saveGroup(!id, { id, name })
        .then(() => {
          resolve();
        })
        .catch(() => {
          reject(req.error.name);
        });
    });
  }

  removeGroup(groupID) {
    if (!groupID) {
      return;
    }
    const groupContacts = this.getContactsByGroupID(groupID);
    const promises = groupContacts.map(contact =>
      this.contactRemoveGroup(contact, groupID)
    );
    return Promise.all(promises).then(() =>
      ContactsManager.removeGroup(groupID)
    );
  }

  groupNameIsExist(name, groupId) {
    if (!name || 'string' !== typeof name) {
      return;
    }
    return [...this.groupMap.values()]
      .filter(value => value.id !== groupId)
      .map(value => value.name.toLowerCase())
      .includes(name.toLowerCase());
  }

  hasGroups() {
    if (this.source !== 'sim') {
      if (window.localStorage.getItem('hasGroups')) {
        return true;
      }
      this.updateGroupCache();
      return this.groupMap.size > 0;
    }
    window.localStorage.removeItem('hasGroups');
    return false;
  }

  getContactsByGroupID(groupID) {
    const contacts = [];
    this.fullContacts.forEach(contact => {
      if (contact.group && contact.group.some(id => id === groupID)) {
        contacts.push(contact);
      }
    });
    return contacts;
  }

  getGroupNameByID(id) {
    if (!id) {
      return;
    }
    return this.groupMap.get(id).name;
  }

  /*
   * @param contact instance of mozContact
   * @return GroupsArray e.g [{name, id}...]
   * @method get the remain groups of this contact that has not added.
   * */
  getContactRemainGroups(contact) {
    const groupsArr = [...this.groupMap.values()];
    if (!contact.group || !contact.group.length) {
      return groupsArr.map(group => group.id);
    }
    return groupsArr
      .map(group => group.id)
      .filter(groupID => {
        return !contact.group.some(id => id === groupID);
      });
  }

  contactAddGroup(contact, groupID) {
    if (!contact || !groupID) {
      return '';
    }
    if (!contact.group) {
      contact.group = [];
      contact.group.push(groupID);
    } else {
      if (contact.group.some(id => id === groupID)) {
        return 'duplicate';
      }
      contact.group.push(groupID);
    }
    this.createOrUpdate(contact, true);
  }

  contactRemoveGroup(contact, groupID) {
    if (!contact || !contact.group || !groupID) {
      return;
    }
    let pos = -1;
    contact.group.some((id, index) => {
      if (id === groupID) {
        pos = index;
        return true;
      }
      return false;
    });
    if (pos > -1) {
      contact.group.splice(pos, 1);
      return this.createOrUpdate(contact, true);
    }
  }

  contactHasNotAddAllGroup(contact) {
    if (!contact.group || !contact.group.length) {
      return true;
    }
    const groupArr = [...this.groupMap.values()];
    const contactHasAddAllGroup = groupArr.every(group => {
      return contact.group.some(id => id === group.id);
    });
    return !contactHasAddAllGroup;
  }

  getGroups() {
    return [...this.groupMap.values()].sort((a, b) => a.name > b.name);
  }

  interceptContact(contacts) {
    // 1. If deleted a contact when fetcheing, not show it again during fetch progress.
    // 2. After all fetched, delete the contact from source contacts.
    if (this.contactMap.size !== contacts.length) {
      const indexes = [];
      contacts.forEach((value, index) => {
        if (!Array.from(this.contactMap.keys()).includes(value.id)) {
          indexes.push(index);
        }
      });
      indexes.forEach(value => contacts.splice(value, 1));
    }
    return contacts;
  }

  isFavorite(contact) {
    if (!contact || !contact.category) {
      return false;
    }
    return contact.category.indexOf('favorite') >= 0;
  }

  toggleFavorite(contact) {
    const favorite = !this.isFavorite(contact);
    if (favorite) {
      contact.category = contact.category || [];
      contact.category.push('favorite');
    } else {
      if (!contact.category) {
        return Promise.reject();
      }
      const pos = contact.category.indexOf('favorite');
      if (pos > -1) {
        contact.category.splice(pos, 1);
      }
    }
    return this.createOrUpdate(contact, true);
  }

  export(ids, target) {
    let index;
    switch (target) {
      case 'sim/0':
      case 'sim/1':
        index = +target.split('/')[1];
        import('./sim_exporter').then(module => {
          const SimExporter = module.default;
          this.exporter = new SimExporter(index, ids);
          Service.request('popup', '/exporting');
        });
        break;
      case 'sdcard':
        import('./sdcard_exporter').then(module => {
          const SdcardExporter = module.default;
          this.exporter = new SdcardExporter(ids);
          Service.request('popup', '/exporting');
        });
        break;
      case 'bluetooth':
        import('./bt_exporter').then(module => {
          const BtExporter = module.default;
          this.exporter = new BtExporter(ids);
          Service.request('popup', '/exporting');
        });
        break;
      default:
        break;
    }
  }

  getExporter() {
    return this.exporter;
  }
}

const contactStore = new ContactStore();
contactStore.start();

window.cs = contactStore;

export const { batchOperate } = contactStore;
export default contactStore;
