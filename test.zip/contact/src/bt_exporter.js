import BaseExporter from './base_exporter';
import Utils from './vcard_utils';

export default class BtExporter extends BaseExporter {
  contacts = [];

  name = 'BtExporter';

  hasDeterminativeProgress = false;

  title = 'btExport-title';

  temVcardPatch = '.contacts/';

  continue() {
    const req = Utils.ContactToVcard(this.contacts, {
      // Set batchSize to 500K, will update vcard file using append-to-file
      batchSize: 500 * 1024,
    });

    this.on('canceled', () => {
      req.cancel();
    });

    req.onbatch = (vcards, nCards, done) => {
      this.debug('ready to append a batch to the storage:', nCards);
      if (this.aborted) {
        this.emit('canceled');
        return;
      }
      const blob = new Blob([vcards], { type: 'text/vcard' });
      this.pendingBatches.push({
        blob,
        bDone: done,
      });
      if (!this.storedFileName) {
        this.storedFileName = this.temVcardPatch + this.getFileName();
        this.clearContactsFolder().then(() => {
          this.saveVcardFile(this.storedFileName, false, true);
        });
      } else if (this.append) {
        this.saveVcardFile(this.storedFileName, true, true);
      }
    };

    req.onsuccess = () => {
      this.debug('all batches processed success');
    };
  }

  clearContactsFolder() {
    return new Promise(resolve => {
      const storage = navigator.b2g.getDeviceStorage('sdcard');
      const req = storage.delete(this.temVcardPatch);
      req.onsuccess = () => {
        resolve();
      };
    });
  }
}
