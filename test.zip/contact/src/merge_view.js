import React from 'react';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import ContactStore from 'contact_store';
import Utils from 'contact_utils';
import { findDup, merge } from 'modules/merge_helper';
import { operateSync, SYNC_OPERATION } from 'account/account_manager';

export default class MergeView extends BaseComponent {
  name = 'MergeView';
  DEBUG = false;

  FOCUS_SELECTOR = '.list-item.navigable';

  _contactMap = {};

  static defaultProps = {
    id: '',
  };

  constructor(props) {
    super(props);
    this.state = {
      contacts: null,
      selectedId: '',
    };
  }

  componentDidMount() {
    this.debug('did mount');
    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element
    );
    this._softKey = SoftKeyManager.create(this.element, {
      left: 'cancel',
    });

    // in case of new contact, the unsaved contact is stored as a wrappedContact with id `new`
    ContactStore.getWrappedContact(this.props.id).then(wrappedContact => {
      this._contact = wrappedContact.contact;
      findDup(this._contact).then(contacts => {
        this.setState({
          contacts,
        });
        contacts.forEach(c => {
          this._contactMap[c.id] = c;
        });
      });
    });
  }

  componentDidUpdate() {
    this.debug('did update');
    'found' === this._status && this._updateItemSoftKey();
    'noFound' === this._status &&
      this._softKey.update({
        left: '',
        center: 'ok',
      });
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  _updateItemSoftKey() {
    const id = document.activeElement.dataset.id;
    const selected = id === this.state.selectedId;
    this._softKey.update({
      left: 'cancel',
      center: selected ? 'deselect' : 'select',
      right: selected ? 'merge' : '',
    });
  }

  onKeyDown = evt => {
    switch (evt.key) {
      case 'Backspace':
        Service.request('back', {
          action: 'cancel',
        });
        break;
      case 'SoftLeft':
        'noFound' !== this._status &&
          Service.request('back', {
            action: 'cancel',
          });
        break;
      case 'Enter':
        'noFound' === this._status &&
          Service.request('back', { action: 'cancel' });
        break;
      default:
        return;
    }
    evt.stopPropagation();
    evt.preventDefault();
  };

  onItemKeyDown = evt => {
    const id = document.activeElement.dataset.id;
    const selected = id === this.state.selectedId;
    switch (evt.key) {
      case 'Enter':
        this.setState({
          selectedId: selected ? '' : id,
        });
        break;
      case 'SoftRight':
        const _ = window.api.l10n.get;
        selected &&
          merge({
            fromContact: this._contactMap[id],
            toContact: this._contact,
            onConflict: (resolve, dirtyFields) => {
              const content = [
                _('merge-conflict-warn', {
                  name: Utils.getDisplayName(this._contact),
                }),
                dirtyFields.map(n => _(n)).join(', '),
                ' ',
                _('merge-conflict-confirm'),
              ].join('\n');

              Service.request('showDialog', {
                type: 'confirm',
                header: _('confirm'),
                content,
                translated: true,
                ok: 'merge',
                onOk: resolve,
              });
            },
          }).then(result => {
            operateSync(SYNC_OPERATION.PUSH, { contact: result.data });
            Service.request('ToastManager:show', { text: _('contact-merged') });
            Service.request('back', {
              action: 'merge',
            });
          });
        break;
      default:
        return;
    }
    evt.stopPropagation();
    evt.preventDefault();
  };

  onItemFocus = () => {
    this._updateItemSoftKey();
  };

  get _status() {
    if (!this.state.contacts) {
      return 'finding';
    }
    if (0 === this.state.contacts.length) {
      return 'noFound';
    }
    return 'found';
  }

  _listItemFactory = item => {
    const checked = item.id === this.state.selectedId;

    const numberDOM =
      item.tel &&
      item.tel.map(t => {
        const typeL10n = t.type && t.type.length ? t.type[0] : 'other';
        const key = Math.random()
          .toString(36)
          .substr(2);
        return (
          <div className="secondary" key={`tel-${key}`}>
            <div>
              <span data-l10n-id={typeL10n} />
              &nbsp;{t.value}
            </div>
          </div>
        );
      });
    return (
      <div
        className="list-item navigable"
        tabIndex="-1"
        key={item.id}
        onKeyDown={this.onItemKeyDown}
        onFocus={this.onItemFocus}
        data-id={item.id}
      >
        <div className="content">
          <div className="primary">{Utils.getDisplayName(item)}</div>
          {numberDOM}
        </div>
        <i
          className="icon control"
          data-icon={checked ? 'radio-on' : 'radio-off'}
        />
      </div>
    );
  };

  render() {
    this.debug('render');
    let title = 'find-dup-title';
    const message = {
      finding: 'finding-dup-message',
      noFound: 'no-dup-found',
      found: 'dup-found-message',
    }[this._status];

    let progressDOM = null;
    if ('finding' === this._status) {
      progressDOM = (
        <div className="progress" data-infinite="true">
          <div className="progress-active" />
        </div>
      );
    }

    let listDOM = null;
    if ('found' === this._status) {
      title = 'dup-found-title';
      listDOM = this.state.contacts.map(this._listItemFactory);
    }
    return (
      <div
        ref={e => {
          this.element = e;
        }}
        className="merge-view"
        tabIndex="-1"
        onKeyDown={this.onKeyDown}
      >
        <div className="header h1" data-l10n-id={title} />
        <div className="body">
          <div className="list-item" data-multi-line="true">
            <div className="content">
              <div className="primary" data-l10n-id={message} />
              {progressDOM}
            </div>
          </div>
          {listDOM}
        </div>
      </div>
    );
  }
}
