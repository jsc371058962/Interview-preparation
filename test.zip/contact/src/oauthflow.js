/*
 *  Module: Facebook integration
 *
 *  This script file contains all the logic that allows to obtain an access
 *  token through an OAuth 2.0 implicit grant flow
 *
 *
 *
 */

import BaseModule from 'base-module';
import parameters from './parameters';

const OAUTH_REDIRECT = 'redirectURI';
const ENDPOINT = 'loginPage';
const APP_ID = 'applicationId';
const SCOPE = 'scope';

const APP_ORIGIN = window.location.origin;

class Oauthflow extends BaseModule {
  name = 'Oauthflow';
  DEBUG = false;

  start() {
    this.channel = new BroadcastChannel('contact-oauth2-result');
    this.channel.addEventListener('message', this._handle_message);
  }

  _handle_message = e => {
    this.channel.removeEventListener('message', this._handle_message);
    const param = e.data;
    if (!param || !param.access_token) {
      return;
    }
    if (e.origin !== APP_ORIGIN) {
      return;
    }

    // XXX: notify
    window.setTimeout(() => {
      this.resolve && this.resolve(param);
      this.resolve = null;
      this.reject = null;
      this.channel = null;
    }, 0);
  };

  startFlow(service) {
    return new Promise((resolve, reject) => {
      const params = parameters[service];

      const redirect_uri = encodeURIComponent(params[OAUTH_REDIRECT]);

      const scope = params[SCOPE].join(',');
      const scopeParam = encodeURIComponent(scope);

      const queryParams = [
        `client_id=${params[APP_ID]}`,
        `redirect_uri=${redirect_uri}`,
        'response_type=token',
        `scope=${scopeParam}`, // Only needed for Gmail (see Bug 962377)
        'approval_prompt=force',
        'state=friends',
      ]; // Query params

      this.resolve = resolve;
      this.reject = reject;

      const query = queryParams.join('&');
      const url = params[ENDPOINT] + query;
      console.info(url);
      const oauth2Window = window.open(url, '', 'dialog');
      const self = this;
      if (oauth2Window) {
        window.addEventListener('focus', function onChildClosed() {
          window.removeEventListener('focus', onChildClosed);
          self.reject && self.reject();
          self.resolve = null;
          self.reject = null;
          self.channel = null;
        });
      } else {
        console.error('oauth2Window is null');
      }
    });
  }
}

const oauthflow = new Oauthflow();
oauthflow.start();
window.oaf = oauthflow;

export default oauthflow;
