import React from 'react';
import { render } from 'react-dom';
import BaseComponent from 'base-component';
import 'common-scss';
import ReactSoftKey from 'react-soft-key';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import ReactWindowManager from 'react-window-manager';
import Utils from 'contact_utils';
import Routes from './routes_split';
import Sideview from './side_view';
import './system_message_handler';
import '../scss/app.scss';

class App extends BaseComponent {
  name = 'App';

  constructor(props) {
    super(props);

    SimpleNavigationHelper.onBeforeKeyDown = evt => {
      if ('EndCall' === evt.key && Service.query('isSyncingContacts')) {
        Service.request('showDialog', {
          type: 'confirm',
          header: 'stop-syncing-warn-title',
          content: 'stop-syncing-warn',
          ok: 'close',
          onOk: () => {
            window.close();
          },
        });
        evt.preventDefault();
        evt.stopPropagation();
      }

      if (Service.query('isTransitioning') && evt.key !== 'MicrophoneToggle') {
        evt.preventDefault();
        evt.stopPropagation();
      }
    };

    DeviceCapabilityManager.get('hardware.memory').then(memOnDevice => {
      this.isLowMemoryDevice = memOnDevice <= 256;
      Service.registerState('isLowMemoryDevice', this);
    });
    if (navigator.connection) {
      navigator.connection.ontypechange = event => {
        window.dispatchEvent(
          new CustomEvent('network-changed', {
            detail: Utils.getType(event.target.type),
          })
        );
      };
    }

    Service.register('offlineCallback', this);
    Service.registerState('offlineCallback', this);
  }

  componentDidMount() {
    window.appInstance = this; // For debugging purpose
  }

  offlineCallback = () => {
    Service.request('ToastManager:show', {
      text: window.api.l10n.get('no-network-warn'),
    });
  };

  render() {
    return (
      <div id="app" tabIndex="-1">
        <div className="statusbar-placeholder" />
        <ReactWindowManager ref="history" routes={Routes} />
        <ReactSoftKey ref="softkey" />
        <Sideview />
      </div>
    );
  }
}

render(<App />, document.getElementById('root'));

window.service = Service;
export default App;
