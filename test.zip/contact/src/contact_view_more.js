import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Utils from './contact_utils';

export default class ContactViewMore extends BaseComponent {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    const config = {
      left: '',
      center: 'ok',
      right: '',
    };
    this.element = ReactDOM.findDOMNode(this);
    this._softKey = SoftKeyManager.create(this.element, config);
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  onKeyDown(evt) {
    switch (evt.key) {
      case 'Backspace':
      case 'Enter':
        evt.preventDefault();
        evt.stopPropagation();
        Utils.backOrClose();
        break;
      default:
        break;
    }
  }

  render() {
    return (
      <div
        className="primary more-detail"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
      >
        {this.props.value}
      </div>
    );
  }
}
