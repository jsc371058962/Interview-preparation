import React from 'react';
import EnhanceAnimation from 'enhance-animation';
import Service from 'service';
import AccountChangePassword from 'account/pages/change_password';
import ContactListView from './list';

const panelCache = new Map();

window.compCache = panelCache;

function getPanel(original, ...args) {
  const subIndex = args.join();
  const subHash = panelCache.get(original) || {};
  if (!subHash[subIndex]) {
    subHash[subIndex] = EnhanceAnimation.call(
      EnhanceAnimation,
      original,
      ...args
    );
  }
  if (!panelCache.has(original)) {
    panelCache.set(original, subHash);
  }
  return subHash[subIndex];
}

const routes = [
  {
    path: '/',
    action: () => {
      const Composed = getPanel(
        ContactListView,
        'left-to-center',
        'center-to-left'
      );
      return <Composed ref="list" />;
    },
  },
  {
    path: '/move/from/:source',
    action(params) {
      params.selectMode = 'move';
      const Composed = getPanel(
        ContactListView,
        'left-to-center',
        'center-to-left'
      );
      return <Composed ref="pickfrom" {...params} />;
    },
  },
  {
    path: '/copy/from/:source',
    action(params) {
      params.selectMode = 'copy';
      const Composed = getPanel(
        ContactListView,
        'left-to-center',
        'center-to-left'
      );
      return <Composed ref="pickfrom" {...params} />;
    },
  },
  {
    path: '/pick/:target',
    action(params) {
      if ('export' === params.target) {
        params.selectMode = 'export';
      }
      if ('group' === params.target) {
        params.selectMode = 'group';
      }
      const Composed = getPanel(ContactListView, '', 'center-to-right');
      return <Composed ref="picker" {...params} />;
    },
  },
  // From pick activity.
  {
    path: '/pick',
    action() {
      return new Promise(resolve => {
        const Composed = getPanel(
          ContactListView,
          'left-to-center',
          'center-to-left'
        );
        Service.request('SystemMessageHandler:ready').then(() => {
          const activityData = Service.query('activityData');
          const params = {
            target: '',
            selectMode: activityData.selectMode || '',
          };

          if (activityData.type) {
            params.noSimContact = !!Service.query('activityParams')
              .typeOfContact;
            const targetMap = {
              'webcontacts/contact': 'contact',
              'webcontacts/select': 'tel,email',
              'webcontacts/tel': 'tel',
              'webcontacts/email': 'email',
              'webcontacts/ice': 'ice',
              'text/x-vcard': 'vcard',
              'text/vcard': 'vcard',
              'text/directory': 'vcard',
            };
            Object.keys(targetMap).some(t => {
              if (activityData.type.includes(t)) {
                params.target = targetMap[t];
                return true;
              }
              return false;
            });
          }
          resolve(<Composed ref="picker" {...params} />);
        });
      });
    },
  },
  // From pick activity.
  {
    path: '/update',
    action() {
      return new Promise(resolve => {
        const Composed = getPanel(
          ContactListView,
          'left-to-center',
          'center-to-left'
        );
        Service.request('SystemMessageHandler:ready').then(() => {
          const params = Service.query('activity').source.data.params
            ? Service.query('activity').source.data.params
            : Service.query('activity').source.data;
          params.target = 'update';
          resolve(<Composed ref="picker" {...params} />);
        });
      });
    },
  },
  // from open activity
  {
    path: '/open',
    action() {
      return new Promise(resolve => {
        Service.request('SystemMessageHandler:ready').then(() => {
          const params = { target: '' };
          switch (Service.query('activitySubType')) {
            case 'webcontacts/contact':
              params.target = 'contact';
              break;
            case 'text/x-vcard':
            case 'text/vcard':
            case 'text/directory':
              params.target = 'vcard';
              break;
            default:
              break;
          }
          if (
            Service.query('activityParams') &&
            Service.query('activityParams').id
          ) {
            params.id = Service.query('activityParams').id;
            const ContactView = require('./contact_view.js');
            const Composed = getPanel(
              ContactView.default,
              'right-to-center',
              'center-to-right'
            );
            // Everything needed by require() goes into a separate bundle
            // require(deps, cb) is asynchronous. It will async load and evaluate
            // modules, calling cb with the exports of your deps.
            resolve(
              <Composed {...params} ref={`detail/${params.id}`} exitOnClose />
            );
          } else if ('vcard' === params.target) {
            params.blob = Service.query('activity').source.data.blob;
            require.ensure([], () => {
              let aView;
              if ('import' === Service.query('activity').source.name) {
                params.filename =
                  params.blob.name ||
                  Service.query('activity').source.data.filename;
                params.filename = params.filename.split('/').pop();
                aView = require('./activity/import_vcard_view.js');
              } else if (
                true === Service.query('activity').source.data.forEditing
              ) {
                aView = require('./edit_view.js');
              } else {
                aView = require('./contact_view.js');
                params.viewOnly = true;
              }
              const Composed = getPanel(
                aView.default,
                'right-to-center',
                'center-to-right'
              );
              resolve(<Composed {...params} ref="open" exitOnClose />);
            });
          } else {
            params.blob = Service.query('activity').source.data.blob;
            require.ensure([], () => {
              const EditView = require('./edit_view.js');
              const Composed = getPanel(
                EditView.default,
                'right-to-center',
                'center-to-right'
              );
              resolve(<Composed {...params} ref="open" exitOnClose />);
            });
          }
        });
      });
    },
  },
  {
    path: '/contacts/:id',
    action(params) {
      return new Promise(resolve => {
        require.ensure([], () => {
          const ContactView = require('./contact_view.js');
          const Composed = getPanel(
            ContactView.default,
            'right-to-center',
            'center-to-right'
          );
          // Everything needed by require() goes into a separate bundle
          // require(deps, cb) is asynchronous. It will async load and evaluate
          // modules, calling cb with the exports of your deps.
          resolve(
            <Composed {...params} ref={`detail/${params.id}`} exitOnClose />
          );
        });
      });
    },
  },
  {
    path: '/view/:id',
    action(params) {
      return new Promise(resolve => {
        require.ensure([], () => {
          const ContactView = require('./contact_view.js');
          const Composed = getPanel(
            ContactView.default,
            'right-to-center',
            'center-to-right'
          );
          // Everything needed by require() goes into a separate bundle
          // require(deps, cb) is asynchronous. It will async load and evaluate
          // modules, calling cb with the exports of your deps.
          resolve(
            <Composed
              {...params}
              ref={`detail/${params.id}`}
              exitOnClose
              viewOnly
            />
          );
        });
      });
    },
  },
  {
    path: '/view-more',
    action(params) {
      return new Promise(resolve => {
        require.ensure([], () => {
          const MoreView = require('./contact_view_more.js');
          const Composed = getPanel(
            MoreView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed {...params} ref="viewmore" exitOnClose />);
        });
      });
    },
  },
  {
    path: '/edit/:id?',
    action: params => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const EditView = require('./edit_view.js');
          const Composed = getPanel(
            EditView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(
            <Composed {...params} ref={`edit/${params.id}`} exitOnClose />
          );
        });
      });
    },
  },
  {
    path: '/new',
    action: params => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const NewView = require('./edit_view');
          const Composed = getPanel(
            NewView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed {...params} ref="new" id="new" exitOnClose />);
        });
      });
    },
  },
  {
    path: '/new/:target',
    action: params => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const NewView = require('./edit_view');
          const Composed = getPanel(
            NewView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed {...params} ref="new" id="new" exitOnClose />);
        });
      });
    },
  },
  {
    path: '/new-activity',
    action: () => {
      return new Promise(resolve => {
        Service.request('SystemMessageHandler:ready').then(() => {
          if (Service.query('isActivity')) {
            const params = Service.query('activityParams');
            require.ensure([], () => {
              const NewView = require('./edit_view');
              const Composed = getPanel(
                NewView.default,
                'right-to-center',
                'center-to-right'
              );
              resolve(<Composed ref="new" {...params} id="new" exitOnClose />);
            });
          }
        });
      });
    },
  },
  {
    path: '/add/:id',
    action: params => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const AddView = require('./add_view');
          const Composed = getPanel(
            AddView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="add" {...params} exitOnClose noKill />);
        });
      });
    },
  },
  {
    path: '/type/:id/:field/:index/:active',
    action: params => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const TypeView = require('./add_view');
          const Composed = getPanel(
            TypeView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(
            <Composed
              {...params}
              ref={`type/${params.field}/${params.index}`}
              exitOnClose
            />
          );
        });
      });
    },
  },
  {
    path: '/type/:id/:field',
    action: params => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const TypeView = require('./add_view');
          const Composed = getPanel(
            TypeView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(
            <Composed {...params} ref={`type/${params.field}`} exitOnClose />
          );
        });
      });
    },
  },
  {
    path: '/setting',
    action: () => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const SettingView = require('./setting_view');
          const Composed = getPanel(
            SettingView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="setting" exitOnClose />);
        });
      });
    },
  },
  {
    path: '/ice',
    action: () => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const IceView = require('./ice_editor_view');
          const Composed = getPanel(
            IceView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="ice" exitOnClose />);
        });
      });
    },
  },
  {
    path: '/icelist',
    action: () => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const IceViewList = require('./ice_list_view');
          const Composed = getPanel(
            IceViewList.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="icelist" exitOnClose />);
        });
      });
    },
  },
  {
    path: '/block',
    action: () => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const BlockView = require('./block_view');
          const Composed = getPanel(
            BlockView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="import" exitOnClose />);
        });
      });
    },
  },
  {
    path: '/group-list',
    action: () => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const GroupList = require('./group_list');
          const Composed = getPanel(
            GroupList.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="group-list" exitOnClose />);
        });
      });
    },
  },
  {
    path: '/group/:name/:id',
    action: params => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const GroupView = require('./group_view');
          const Composed = getPanel(
            GroupView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(
            <Composed {...params} ref={`group${params.name}`} exitOnClose />
          );
        });
      });
    },
  },
  {
    path: '/import',
    action: () => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const ImportView = require('./import_view');
          const Composed = getPanel(
            ImportView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="import" exitOnClose />);
        });
      });
    },
  },
  {
    path: '/export',
    action: () => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const ExportView = require('./export_view');
          const Composed = getPanel(
            ExportView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="export" exitOnClose />);
        });
      });
    },
  },
  {
    path: '/exporting',
    action: () => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const ExportProgressView = require('./export_progress_view');
          const Composed = getPanel(
            ExportProgressView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="exporting" exitOnClose />);
        });
      });
    },
  },
  {
    path: '/move/to/:target',
    action: params => {
      params.isMove = true;
      return new Promise(resolve => {
        require.ensure([], () => {
          const MigrateView = require('./migrate_view');
          const Composed = getPanel(
            MigrateView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="migrate" exitOnClose {...params} />);
        });
      });
    },
  },
  {
    path: '/copy/to/:target',
    action: params => {
      params.isMove = false;
      return new Promise(resolve => {
        require.ensure([], () => {
          const MigrateView = require('./migrate_view');
          const Composed = getPanel(
            MigrateView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="migrate" exitOnClose {...params} />);
        });
      });
    },
  },
  {
    path: '/import/sdcard',
    action: () => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const ISView = require('./import_sdcard_view');
          const Composed = getPanel(
            ISView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="import/sdcard" exitOnClose />);
        });
      });
    },
  },
  {
    path: '/import/sim/:index',
    action: params => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const ISView = require('./import_sim_view');
          const Composed = getPanel(
            ISView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="import/sim" {...params} exitOnClose />);
        });
      });
    },
  },
  {
    path: '/import/service/:service',
    action: params => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const SSIView = require('./social_service_importer');
          const Composed = getPanel(
            SSIView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="import/service" {...params} exitOnClose />);
        });
      });
    },
  },
  {
    path: '/deletes',
    action: params => {
      return new Promise(resolve => {
        require.ensure([], () => {
          const dView = require('./delete_contacts_view');
          const Composed = getPanel(
            dView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="deletes" {...params} exitOnClose />);
        });
      });
    },
  },
  {
    path: '/sort',
    action() {
      return new Promise(resolve => {
        require.ensure([], () => {
          const sView = require('./sort_view');
          const Composed = getPanel(
            sView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="sort" exitOnClose />);
        });
      });
    },
  },
  {
    path: '/memory',
    action() {
      return new Promise(resolve => {
        require.ensure([], () => {
          const sView = require('./memory_view');
          const Composed = getPanel(
            sView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="memory" exitOnClose />);
        });
      });
    },
  },
  {
    path: '/speeddial',
    action() {
      return new Promise(resolve => {
        require.ensure([], () => {
          const sView = require('./speed_dial_view');
          const Composed = getPanel(
            sView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="speeddial" />);
        });
      });
    },
  },
  {
    path: '/merge/:id',
    action(params) {
      return new Promise(resolve => {
        require.ensure([], () => {
          const mView = require('./merge_view');
          const Composed = getPanel(
            mView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="merge" exitOnClose {...params} />);
        });
      });
    },
  },
  {
    path: '/favorite',
    action() {
      return new Promise(resolve => {
        require.ensure([], () => {
          const mView = require('./favorite_view');
          const Composed = getPanel(
            mView.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="favorite" exitOnClose />);
        });
      });
    },
  },
  {
    path: '/sdn/:index',
    action(params) {
      return new Promise(resolve => {
        require.ensure([], () => {
          const view = require('./sdn_view');
          const Composed = getPanel(
            view.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="sdn" {...params} />);
        });
      });
    },
  },
  {
    // may be invoked from WebActivity
    // but no need to seperate another WebActivity routing currently
    path: '/voicemail',
    action() {
      return new Promise(resolve => {
        require.ensure([], () => {
          const VoicemailEditor = require('./voicemail_editor');
          const Composed = getPanel(
            VoicemailEditor.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="voicemail" />);
        });
      });
    },
  },
  {
    path: '/account/adding',
    action() {
      return new Promise(resolve => {
        require.ensure([], () => {
          const page = require('./account/pages/adding');
          const Composed = getPanel(
            page.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="account/adding" exitOnClose />);
        });
      });
    },
  },
  {
    path: '/account/info',
    action(params) {
      return new Promise(resolve => {
        require.ensure([], () => {
          const page = require('./account/pages/info');
          const Composed = getPanel(
            page.default,
            'right-to-center',
            'center-to-right'
          );
          resolve(<Composed ref="account/info" {...params} exitOnClose />);
        });
      });
    },
  },
  {
    path: '/account/change-password',
    action(params) {
      return new Promise(resolve => {
        require.ensure([], () => {
          // let page = require('./account/pages/change_password');
          const Composed = getPanel(
            AccountChangePassword,
            'right-to-center',
            'center-to-right'
          );
          resolve(
            <Composed ref="account/change-password" {...params} exitOnClose />
          );
        });
      });
    },
  },
];

export default routes;
