import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import { findDup } from 'modules/merge_helper';
import { operateSync, SYNC_OPERATION } from 'account/account_manager';
import { FIELDS, MAX_TEL_LENGTH, MAX_TEXT_LENGTH } from './contact_wrapper';
import ContactStore, { TAG_INDEX } from './contact_store';
import Utils from './contact_utils';
import ContactDraftManager from './contact_draft_manager';
import '../scss/new_contact_view.scss';

const DEFAULT_TYPE = {
  email: 'personal',
  tel: 'mobile',
  adr: 'home',
};

export default class ContactEditor extends BaseComponent {
  name = 'ContactEditor';
  DEBUG = false;
  FOCUS_SELECTOR = '.navigable:not(.hidden),.button';

  SCROLL_SELECTOR = '.list-item';

  blobs = new Map();

  constructor(props) {
    super(props);
    this.state = {
      fields: this.props.contact.dataMap,
    };
    window.editor = this;
    this.utils = Utils;

    this._onFieldChanged = this._onFieldChanged.bind(this);
    this.isEditFiledType = false;
  }

  componentDidMount() {
    this.debug('did mount');
    window.editor = this;
    this.element = ReactDOM.findDOMNode(this);
    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element,
      this.SCROLL_SELECTOR
    );
    this.updateSoftKeys();
    this.props.contact.on('fieldchanged', this._onFieldChanged);

    this.defaultRingtone = '';
    SettingsObserver.getValue('dialer.ringtone.id').then(value => {
      this.defaultRingtone = value;
    });

    const ringTone = this.props.contact.contact.ringtone;
    Utils.checkRingTone(ringTone).then(bExist => {
      if (!bExist) {
        this.props.contact.removeField('ringtone', 0);
      }
    });
    this.saveDraft();
  }

  componentDidUpdate() {
    this.saveDraft();
  }

  _onFieldChanged(type, field) {
    this.debug('_onFieldChanged:', type, field);
    this.setState({ fields: this.props.contact.dataMap }, () => {
      // XXX: handle in componentDidUpdate?
      if ('add' === type) {
        if ('photo' === field) {
          this.pickImage();
        } else if ('ringtone' === field) {
          this.changeRingtone();
        } else {
          // bug-30202: to execute after render, onFocus
          window.setTimeout(() => {
            const ref = `${field}-${this.state.fields.get(field).length -
              1}-input`;
            this.debug('to focus the input ref:', ref);
            this.navigator.setFocus(
              ReactDOM.findDOMNode(this.refs[ref]),
              this.isEditFiledType
            );
            this.isEditFiledType = false;
          });
        }
      } else if ('photo' === field) {
        URL.revokeObjectURL(this.blobs.get('photo-url'));
        this.blobs.delete('photo-0');
      }
      this.updateSoftKeys();
    });
  }

  changeRingtone() {
    const activity = new window.WebActivity('pick', {
      type: ['audio/*', 'ringtone'],
      allowNone: false,
      currentToneID: this.currentRingtone || this.defaultRingtone,
    });

    activity.start().then(
      result => {
        if ((result && !result.id && !result.blob) || !result) {
          this._resetField('ringtone');
          return;
        }
        const dom = ReactDOM.findDOMNode(this.refs['ringtone-0']);
        dom.querySelector('.primary').textContent = result.name;
        dom.classList.remove('hidden');
        dom.dataset.value = result.id || result.blob.name;
        dom.dataset.filename = result.blob.name || result.filename;
        this.navigator.setFocus(dom);
      },
      err => {
        console.error('activity error - pick ringtone', err);
        Service.request('ToastManager:show', {
          text: window.api.l10n.get('select-ringtone-failed'),
        });
        this._resetField('ringtone');
      }
    );
  }

  _resetField(fieldName) {
    this.debug('_resetField:', fieldName);
    const data = this.getInputData();
    if (data[fieldName]) {
      // input but not saved
      return;
    }
    this.props.contact.removeField(fieldName, 0);
  }

  componentWillUnmount() {
    this.navigator.destroy();
    this._softKey.destroy();
    this.props.contact.off('fieldchanged', this._onFieldChanged);
    URL.revokeObjectURL(this.blobs.get('photo-url'));
  }

  pickImage() {
    const activity = new window.WebActivity('pick', {
      type: 'image/jpeg',
    });

    activity.start().then(
      result => {
        if (!result) {
          return this._resetField('photo');
        }
        const { blob } = result;
        if (blob) {
          // There's at most 1 photo.
          const dom = ReactDOM.findDOMNode(this.refs['photo-0']);
          dom.classList.remove('hidden');
          this.navigator.setFocus(dom);
          const size = Math.min(dom.clientWidth, dom.clientHeight);
          Utils.drawPhoto(blob, null, size, newBlob => {
            const photoUrl = URL.createObjectURL(blob);
            dom.style.backgroundImage = `url(${photoUrl}`;
            this.blobs.set('photo-0', newBlob);
            this.blobs.set('photo-url', photoUrl);
          });
        } else if (blob !== undefined) {
          this.navigator.setFocus(
            this.navigator.findNext(document.activeElement)
          );
          this.props.contact.removeField('photo', 0);
        } else if (!document.activeElement.classList.contains('photo')) {
          this._resetField('photo');
        }
      },
      err => {
        console.error('activity error - pick image', err);
        Service.request('ToastManager:show', {
          text: window.api.l10n.get('select-picture-failed'),
        });
        this._resetField('photo');
      }
    );
  }

  clear() {
    if (Service.query('isActivity')) {
      // Don't clear fields if we are requested by activity.
      return;
    }
    Array.from(this.element.querySelectorAll('input')).forEach(input => {
      input.value = '';
      // Hide label
      const label = input.previousElementSibling.classList;
      label.contains('visible') && label.remove('visible');
    });
    this.navigator.setFocus(this.element.querySelector('input'), true);
    this.blobs.clear();
  }

  updateSoftKeys() {
    const savable = this.isChanged() && !this.isEmpty();
    const config = {
      left: 'cancel',
      right: 'options',
    };
    if (savable) {
      config.center = 'save';
    }
    if (
      Service.query('isLowMemoryDevice') &&
      'tel' !== document.activeElement.dataset.field
    ) {
      config.right = '';
    }
    if (document.activeElement === ReactDOM.findDOMNode(this.refs.add)) {
      config.center = 'select';
      config.right = '';
    }
    this._softKey = SoftKeyManager.create(this.element, config);
  }

  backOrClose() {
    this.debug('back');
    this._isGoingBack = true;
    let p = Promise.resolve();
    if (ContactDraftManager.hasCache) {
      const id = this.props.contact.id;
      const data = ContactStore.getContactSync(id);
      // remove data of draft from wrappedContactMap
      data && ContactStore.wrappedContactMap.get(id).update(data);
      p = ContactDraftManager.removeItem();
    }
    if (Service.query('isActivity')) {
      // Need time to let IAC built. set 0ms to let activity exit in next macro task
      setTimeout(() => {
        p.then(() => {
          Service.request('leaveActivity');
        });
      }, 0);
    } else {
      this.clear();
      Service.request('back');
    }
  }

  onKeyDown(evt) {
    const dom = document.activeElement;
    const labelDOM = dom.querySelector('label') || dom.previousElementSibling;
    let label = labelDOM ? labelDOM.textContent : '';
    const _ = window.api.l10n.get;
    const options = [];
    if (this._isGoingBack) {
      return;
    }
    switch (evt.key) {
      case 'Enter':
        if (document.activeElement === ReactDOM.findDOMNode(this.refs.add)) {
          if (Service.query('isLowMemoryDevice')) {
            this.props.contact.addField('tel', DEFAULT_TYPE.tel);
          } else {
            Service.request('popup', `/add/${this.props.contact.id}`).catch(e =>
              console.error(e)
            );
          }
          return;
        }
        if (!this.isChanged() || this.isEmpty()) {
          return;
        }
        this.save();
        break;
      case 'Backspace':
      case 'EndCall':
      case 'SoftLeft': // eslint-disable-line
        evt.preventDefault();
        evt.stopPropagation();
        let shouldClose;
        if ('EndCall' === evt.key) {
          shouldClose = true;
        }
        const handleEndKey = () => {
          shouldClose && window.close();
        };

        if ('Backspace' === evt.key) {
          if ('INPUT' === dom.tagName && '' !== dom.value) {
            return;
          }
        }
        if (this.isChanged()) {
          if (this.isEmpty()) {
            Service.request('showDialog', {
              header: 'confirm',
              content: 'discard-contact-data',
              ok: 'discard',
              onOk: () => {
                this._isGoingBack = true;
                this.props.contact.normalize();
                handleEndKey();
                this.backOrClose();
              },
            });
            return;
          }
          const content =
            'new' === this.props.contact.id
              ? 'confirm-discard-contact-data'
              : 'confirm-discard-contact-update-data';
          Service.request('showDialog', {
            header: 'confirm',
            content,
            type: 'custom',
            buttons: [
              {
                message: 'cancel',
              },
              {
                message: 'save',
              },
              {
                message: 'discard',
              },
            ],
            onOk: value => {
              if (2 === value.selectedButton) {
                // XXX: to avoid option menu shows
                this._isGoingBack = true;
                this.props.contact.normalize();
                handleEndKey();
                this.backOrClose();
              } else if (1 === value.selectedButton) {
                this.save().then(handleEndKey);
              }
            },
          });
          return;
        }
        handleEndKey();
        this.backOrClose();
        break;
      case 'SoftRight':
        evt.preventDefault();
        evt.stopPropagation();
        if (document.activeElement === ReactDOM.findDOMNode(this.refs.add)) {
          break;
        }
        if (dom.classList.contains('photo')) {
          options.push({
            id: 'replace-photo',
            callback: () => {
              this.pickImage();
            },
          });
          options.push(
            this._createDeletionOption('photo', _('delete-photo-msg'))
          );
        }
        if (dom.classList.contains('ringtone')) {
          options.push({
            id: 'replace-ringtone',
            callback: () => {
              this.changeRingtone();
            },
          });
          options.push(
            this._createDeletionOption(
              'ringtone',
              _(`delete-${label.toLowerCase()}-msg`)
            )
          );
        }
        if ('INPUT' === dom.tagName || 'bday' === dom.dataset.field) {
          const index = dom.dataset.index;
          const field = dom.dataset.field;
          if (dom.dataset.type) {
            options.push({
              id: `edit-${field}-type`,
              callback: () => {
                if ('bday' === field) {
                  this.navigator.setFocus(dom.querySelector('input'));
                } else {
                  this.isEditFiledType = true;
                  Service.request(
                    'popup',
                    `/type/${this.props.contact.id}/${field}/${index}/${dom.dataset.type}`
                  );
                }
              },
            });
          }
          if (dom.dataset.removable !== 'false') {
            const specialDeleteMsgArr = ['bday', 'note', 'org'];
            if ('adr' === field) {
              if (Utils.isCustomTag(field, dom.dataset.type)) {
                label = _(`custom-${field}`, { type: dom.dataset.type });
              } else {
                label = _(`${dom.dataset.type}-${field}`, {
                  type: dom.dataset.type,
                });
              }
            }
            if (specialDeleteMsgArr.includes(field)) {
              label = _(`delete-${field}-msg`);
            }
            options.push(this._createDeletionOption(field, label, index));
          }
          // TODO: add the same field implementation
          if (
            'bday' !== field &&
            'ringtone' !== field &&
            'givenName' !== field &&
            'familyName' !== field &&
            'note' !== field
          ) {
            options.push({
              id: 'tel' === field ? `add-${field}-number` : `add-${field}`,
              callback: () => {
                if ('org' !== field && 'note' !== field) {
                  const type = DEFAULT_TYPE[field];
                  if (!type) {
                    Service.request(
                      'popup',
                      `/type/${this.props.contact.id}/${field}`
                    );
                  } else {
                    this.props.contact.addField(field, type);
                  }
                } else {
                  this.props.contact.addField('org');
                }
              },
            });
          }
        }

        if (!Service.query('isLowMemoryDevice')) {
          options.push({
            id: 'add-others',
            callback: () => {
              Service.request('popup', `/add/${this.props.contact.id}`);
            },
          });
        }
        options.length &&
          Service.request('showOptionMenu', {
            options,
            onCancel: () => {
              // lastFocus && lastFocus.focus();
            },
          });
        break;
      default:
        break;
    }
  }

  /**
   * @param {string} field - key name in ContactWrapper.dataMap
   * @param {string} label - translated string
   * @param {number} index - there may be multiple records for a field
   */
  _createDeletionOption(field, label, index = 0) {
    const _ = window.api.l10n.get;
    // if item is deleted, should focus prev item.
    // if first item is deleted, should focus next item.
    const listItems = Array.from(
      this.element.querySelectorAll(this.FOCUS_SELECTOR)
    );
    const currentItemIndex = this.navigator.getElementIndex(
      document.activeElement
    );
    let focusItem =
      0 === currentItemIndex
        ? listItems[1]
        : this.navigator.findPrev(document.activeElement);
    if ('adr' === document.activeElement.dataset.field) {
      let _index = Number(document.activeElement.dataset.index);
      if (_index > 0) {
        focusItem = this.element.querySelectorAll(
          `[data-index='${--_index}'][data-field='adr']`
        )[0];
      } else {
        while ('adr' === focusItem.dataset.field) {
          focusItem = this.navigator.findPrev(focusItem);
        }
      }
    }
    return {
      id: `delete-${field}`,
      callback: () => {
        Service.request('showDialog', {
          header: _('confirm'),
          content: _('delete-prompt-message', { field: label }),
          ok: 'delete',
          type: 'confirm',
          translated: true,
          onOk: () => {
            this.props.contact.removeField(field, index);
            this.navigator.setFocus(focusItem);
          },
        });
      },
    };
  }

  isSIMcontact() {
    return this.props.target && this.props.contact.startsWith('sim');
  }

  onFocus() {
    this.debug('onFocus:');
    // XXX: better way?
    this._isGoingBack = false;
    this._processingSave = false;
    this.updateSoftKeys();
    if (
      this.element.contains(document.activeElement) &&
      document.activeElement !== this.element
    ) {
      const prev = this.element.querySelector('.focus');
      if (
        prev &&
        prev.nextElementSibling.firstElementChild &&
        !prev.nextElementSibling.firstElementChild.lastElementChild.value
      ) {
        // If the nextElementSibling has value, remove disvisibile
        const prevChild =
          prev.nextElementSibling.firstElementChild.firstElementChild;
        prevChild.classList.remove('visibile');
        if (
          typeof prev.nextElementSibling.firstElementChild.lastElementChild
            .value !== 'undefined'
        ) {
          prevChild.classList.add('disvisibile');
        }
      }
      if (prev) {
        prev.classList.remove('focus');
        prev.firstElementChild.lastElementChild.placeholder =
          prev.firstElementChild.firstElementChild.textContent;
        // If the previous input has no value, add disvisibile
        if (
          !prev.firstElementChild.lastElementChild.value &&
          !prev.firstElementChild.lastElementChild.innerText
        ) {
          const prevFirst = prev.firstElementChild.firstElementChild;
          prevFirst.classList.remove('visibile');
          prevFirst.classList.add('disvisibile');
        }
      }
      if ('INPUT' === document.activeElement.tagName) {
        const docActPrev = document.activeElement.previousElementSibling;
        document.activeElement.parentNode.parentNode.classList.add('focus');
        docActPrev.classList.remove('disvisibile');
        docActPrev.classList.add('visibile');
        Utils.setCursorToEnd(document.activeElement);
      } else if (
        'bday' === document.activeElement.dataset.field ||
        'ringtone' === document.activeElement.dataset.field
      ) {
        document.activeElement.classList.add('focus');
      }
    }
  }

  getInputData() {
    const config = {};
    for (const key in this.refs) {
      const dom = ReactDOM.findDOMNode(this.refs[key]);
      const field = dom.dataset.field;
      if (dom.tagName !== 'INPUT') {
        if ('photo' === field) {
          const blob = this.blobs.get(key);
          if (blob) {
            config.photo = [blob];
          }
        } else if ('ringtone' === field) {
          const isBuiltin =
            dom.dataset.value &&
            dom.dataset.value.indexOf('builtin:ringtone/') > -1;
          const data = isBuiltin ? dom.dataset.value : dom.dataset.filename;
          if (data) {
            this.currentRingtone = data;
            config.ringtone = data;
          } else {
            this.currentRingtone = null;
          }
        }
        continue;
      }
      const value = dom.value.trim();
      if ('email' === field) {
        if (value.length && !dom.validity.valid) {
          dom.parentElement.classList.add('invalidMail');
        } else {
          dom.parentElement.classList.remove('invalidMail');
        }
      }
      if ('' === value) {
        continue;
      }

      if ('bday' === field) {
        config[field] = new Date(value);
      } else if (
        'givenName' === field ||
        'familyName' === field ||
        'name' === field
      ) {
        config[field] = [value];
      } else if ('adr' === field) {
        const index = +dom.dataset.index;
        if (!config.adr) {
          config.adr = [];
        }
        const subfield = dom.name;
        if (!config.adr[index]) {
          const data = {
            type: [dom.dataset.type],
          };
          data[subfield] = value;
          config.adr[index] = data;
        } else {
          config.adr[index][subfield] = value;
        }
        const type = dom.dataset.type;
        config.adr[index].type = [type];

        // bug-28235: to have correct isChange() comparison since mozContact stored sorted data
        const sorted = {};
        Object.keys(config.adr[index])
          .sort()
          .forEach(aField => {
            sorted[aField] = config.adr[index][aField];
          });
        config.adr[index] = sorted;
      } else {
        const type = dom.dataset.type;
        let data = {
          type: [type],
          value,
        };
        if ('note' === field || 'org' === field) {
          data = value;
        }
        if (config[field]) {
          config[field].push(data);
        } else {
          config[field] = [data];
        }
      }
    }
    for (const key in config) {
      if ('bday' !== key && 'ringtone' !== key) {
        config[key] = config[key].filter(c => c);
      }
    }
    return config;
  }

  save() {
    if (this._processingSave) {
      return;
    }
    this._processingSave = true;
    let config = this.getInputData();

    if (
      Utils.isChinese(config.familyName) &&
      Utils.isChinese(config.givenName)
    ) {
      config.name = [
        `${config.familyName || ''}${config.givenName || ''}`.trim(),
      ];
    } else {
      config.name = [
        `${config.givenName || ''} ${config.familyName || ''}`.trim(),
      ];
    }

    if (this.props.contact) {
      FIELDS().forEach(field => {
        if ('group' !== field) {
          this.props.contact.contact[field] = config[field] || null;
        }
      });
      config = this.props.contact.contact;
    }

    return new Promise(resolves => {
      findDup(config)
        .then(contacts => {
          if (!contacts.length) {
            return Promise.reject();
          }

          const id = config.id || 'new';
          return Service.request('popup', `/merge/${id}`).then(result => {
            if ('cancel' === result[0].action) {
              return Promise.reject();
            } else if ('merge' === result[0].action) {
              this.backOrClose();
              resolves();
            }
          });
        })
        .catch(() => {
          // no dup found or cancel from merge_view
          if (!config.category || 0 === config.category.length) {
            config.category = [TAG_INDEX.phone, TAG_INDEX.kaiContact];
          }
          ContactStore.createOrUpdate(config, !!config.id, 'manual').then(
            result => {
              Service.request('ToastManager:show', { text: result.message });
              operateSync(SYNC_OPERATION.PUSH, { contact: result.data });
              this.backOrClose();
              resolves();
            }
          );
        });
    });
  }

  onInput() {
    this.updateSoftKeys();
    this.saveDraft();
  }

  saveDraft() {
    if (Service.query('isActivity')) {
      if (this.isEmpty()) {
        return ContactDraftManager.removeItem();
      }
      const data = this.getInputData();
      if (!data.category || 0 === data.category.length) {
        data.category = [TAG_INDEX.phone, TAG_INDEX.kaiContact];
      }
      data.id = 'new' !== this.props.contact.id ? this.props.contact.id : '';
      if (Utils.isChinese(data.familyName) && Utils.isChinese(data.givenName)) {
        data.name = [`${data.familyName || ''}${data.givenName || ''}`.trim()];
      } else {
        data.name = [`${data.givenName || ''} ${data.familyName || ''}`.trim()];
      }
      ContactDraftManager.setItem(data);
    }
  }

  getInputType(field) {
    switch (field) {
      case 'email':
        return 'email';
      case 'tel':
      case 'postalCode':
        return 'tel';
      case 'bday':
        return 'date';
      default:
        return 'text';
    }
  }

  onBlur(evt) {
    const dom = evt.target;
    this.debug('onBlur: type, value:', dom.type, dom.value);
    if ('date' === dom.type) {
      const value = dom.value;
      if (!value) {
        this._resetField('bday');
        this.navigator.setFocus(ReactDOM.findDOMNode(this.refs.add));
        this.element.focus();
      } else {
        // XXX: need better way to locate the container
        const bdayTextDom = ReactDOM.findDOMNode(this.refs['bday-text']);
        if (bdayTextDom) {
          bdayTextDom.textContent = Utils.unifyDateString(new Date(value));
        }
        this.navigator.setFocus(evt.target.parentNode.parentNode);
        evt.target.parentNode.parentNode.focus();
      }
    }
  }

  isTheSame(fieldA, fieldB) {
    return JSON.stringify(fieldA) === JSON.stringify(fieldB);
  }

  isEmpty() {
    const data = this.getInputData();
    for (const key in data) {
      if (data[key]) {
        return false;
      }
    }
    return true;
  }

  isChanged() {
    if (
      'open' === Service.query('activityType') ||
      ContactDraftManager.hasCache
    ) {
      return true;
    }
    let changed = false;
    const data = this.getInputData();
    FIELDS().some(field => {
      if ('group' === field) {
        return false;
      }
      let current = this.props.contact.contact[field];
      let next = data[field];
      if (!Array.isArray(current)) {
        current = [current];
      }
      if (!Array.isArray(next)) {
        next = [next];
      }
      if (
        (!current.length || (1 === current.length && !current[0])) &&
        (!next.length || (1 === next.length && !next[0]))
      ) {
        return false;
      }

      if ('photo' === field && this.blobs.get('photo-0') !== current[0]) {
        changed = true;
        return true;
      }
      // XXX: This logic does not work for blob.
      if (!this.isTheSame(next, current) && 'name' !== field) {
        changed = true;
        return true;
      }
      return false;
    });
    return changed;
  }

  render() {
    this.debug('render');
    const dom = [];
    const photoDom = [];
    let data = [];
    this.state.fields.forEach(array => {
      if (array.length && 'familyName' === array[0].field) {
        const givenName = data.pop();
        if (!array[0].value.length && !givenName.value.length) {
          if (navigator.language.indexOf('zh-') > -1) {
            data = data.concat(array);
            data.push(givenName);
          } else {
            data.push(givenName);
            data = data.concat(array);
          }
        } else if (
          Utils.isChinese(array[0].value) &&
          Utils.isChinese(givenName.value)
        ) {
          data = data.concat(array);
          data.push(givenName);
        } else {
          data.push(givenName);
          data = data.concat(array);
        }
      } else {
        data = data.concat(array);
      }
    });
    data.forEach(content => {
      const field = content.field;
      const index = content.index;
      const type = content.type;
      const containerKey = content.key || `${field}-${index}`;
      const refKey = `${field}-${index}`;
      const value = content.value;
      const style = {};
      switch (field) {
        case 'photo':
          if (value) {
            const photoUrl = URL.createObjectURL(value);
            style.backgroundImage = `url('${photoUrl}')`;
            this.blobs.set('photo-0', value);
            this.blobs.set('photo-url', photoUrl);
          }
          photoDom.push(
            <div
              className={`list-item photo navigable ${value ? '' : 'hidden'}`}
              tabIndex="-1"
              ref={`photo-${index}`}
              data-index={index}
              data-field={field}
              style={style}
            />
          );
          break;
        case 'adr':
          dom.push(
            <div
              className="separator secondary"
              key={`${containerKey}-separator`}
              {...Utils.getFieldL10nConfig(field, type)}
            />
          );
          for (const key in value) {
            let id = '';
            if ('streetAddress' === key) {
              id = `${field}-${index}`;
              // this is to focus the last added address' first row.
            } else {
              id = `${field}-${index}-${key}`;
            }
            dom.push(
              <div
                className="list-item"
                tabIndex="-1"
                data-type="input"
                data-field={field}
                key={id}
              >
                <div className="content">
                  <label
                    className="secondary"
                    htmlFor={id}
                    data-l10n-id={key}
                  />
                  <input
                    type={this.getInputType(key)}
                    data-index={index}
                    data-field={field}
                    data-type={type}
                    data-subfield={key}
                    defaultValue={value[key]}
                    className="navigable"
                    name={key}
                    ref={`${id}-input`}
                    id={`${id}-input`}
                    maxLength={100}
                  />
                </div>
              </div>
            );
          }
          break;
        case 'ringtone':
          dom.push(
            <div
              className={`ringtone list-item navigable ${
                value ? '' : 'hidden'
              }`}
              tabIndex="-1"
              data-field={field}
              data-value={value}
              data-filename={value}
              data-removable
              key={containerKey}
              ref={`ringtone-${index}`}
            >
              <div className="content">
                <label
                  className="secondary"
                  htmlFor={`new-${containerKey}`}
                  {...Utils.getFieldL10nConfig(field, type)}
                />
                <div className="primary">{Utils.guessRingtoneName(value)}</div>
              </div>
            </div>
          );
          break;
        default:
          if (
            'name' === field ||
            (Service.query('isLowMemoryDevice') && 'email' === field)
          ) {
            break;
          }
          dom.push(
            <div
              className={`list-item ${'bday' === field ? 'navigable' : ''}`}
              tabIndex="-1"
              data-type="input"
              data-field={field}
              key={containerKey}
            >
              <div className="content">
                <label
                  id={`new-${containerKey}`}
                  className={`secondary ${
                    '' === value ? 'disvisibile' : 'visibile'
                  }`}
                  htmlFor={`new-${containerKey}`}
                  {...Utils.getFieldL10nConfig(field, type)}
                />
                <input
                  aria-label={this.props.heading}
                  aria-describedby={`new-${containerKey}`}
                  type={this.getInputType(field)}
                  data-index={index}
                  data-field={field}
                  data-type={type}
                  id={`new-${field}-${index}`}
                  className={'bday' === field ? '' : 'navigable'}
                  name={'bday' === field ? '' : field}
                  data-removable={
                    field.indexOf('Name') >= 0 ||
                    (['tel', 'email'].includes(field) && 0 === index)
                      ? 'false'
                      : 'true'
                  }
                  onBlur={e => this.onBlur(e)}
                  defaultValue={value}
                  {...Utils.getPlaceholderConfig(field, type)}
                  ref={`${refKey}-input`}
                  maxLength={'tel' === field ? MAX_TEL_LENGTH : MAX_TEXT_LENGTH}
                  // #42776, show desired date format, keep 'input' component to pop date picker +
                  style={
                    'bday' === field
                      ? { width: '0px', height: '0px', border: '0px' }
                      : {}
                  }
                />
                {'bday' === field && (
                  <div ref="bday-text" className="primary">
                    {value && Utils.unifyDateString(new Date(value))}
                  </div>
                )
                // #42776, show desired date format, keep 'input' component to pop date picker -
                }
              </div>
            </div>
          );
          break;
      }
    });
    let add = null;
    if (!this.isSIMcontact()) {
      add = (
        // In add phone section, Use the internal button style of contacts
        <div className="list-item">
          <div className="content" data-add-content="add-content">
            <div
              className="button primary"
              tabIndex="-1"
              ref="add"
              data-l10n-id={
                Service.query('isLowMemoryDevice') ? 'add-phone' : 'add'
              }
            />
          </div>
        </div>
      );
    }
    return (
      <div
        role="form"
        className="contact-editor"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onFocus={e => this.onFocus(e)}
        onInput={e => this.onInput(e)}
      >
        {photoDom}
        {dom}
        {add}
      </div>
    );
  }
}

ContactEditor.propTypes = {
  contact: React.PropTypes.object,
};
