import BaseModule from 'base-module';
import Service from 'service';

class SystemMessageHandler extends BaseModule {
  name = 'SystemMessageHandler';
  DEBUG = false;
  isActivity = false;
  activityType = '';
  activityParams = {};
  activityData = {};
  pickType = '';
  pickProperties = [];
  start() {
    window._SWObserver.on('swMessage', _data => {
      const { category, type, data } = _data;
      console.log('sys message handle', _data, this);
      if ('systemmessage' === category) {
        if ('activity' === type) {
          this.handleActivity(data);
          window.dispatchEvent(new CustomEvent('fullyloaded'));
        } else {
          window.dispatchEvent(new CustomEvent(type), { detail: data });
        }
      }
    });

    this.keepSWStateInterval = setInterval(() => {
      // service worker alive -> idle timeout is 30000ms,
      // and 'dom.serviceWorkers.idle_extended_timeout' is 300000ms (5mins),
      // so the max-timeout is 3000ms + 300000ms
      // post a dummy message to keep service worker alive
      if (navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage({ isDummy: true });
      }
    }, 200000); // less than 3000ms + 300000ms

    Service.registerState('isActivity', this);
    Service.registerState('activityType', this);
    Service.registerState('activitySubType', this);
    Service.registerState('pickType', this);
    Service.registerState('pickProperties', this);
    Service.registerState('activity', this);
    Service.registerState('activityParams', this);
    Service.registerState('activityData', this);
    Service.registerState('blob', this);
    Service.register('postResult', this);
    Service.register('leaveActivity', this);
    Service.register('ready', this);
  }

  ready() {
    return new Promise(resolve => {
      this.debug('activity ready');
      if (this.isReady) {
        resolve();
      } else {
        this.resolve = resolve;
      }
    });
  }

  activity() {
    return this._activity;
  }

  handleActivity(activity) {
    this.debug('activity invoked:', activity.source.name);
    this.isActivity = true;
    this.activityType = activity.source.name;
    this.activitySubType = activity.source.data && activity.source.data.type;
    this._activity = activity;
    this.activityData = activity.source.data || {};
    this.activityParams = this.activityData.params || {};
    switch (activity.source.name) {
      case 'pick':
        this.pickType = activity.source.data.type;
        this.pickProperties = activity.source.data.pickProperties;
        break;
      case 'open':
        this.blob = activity.source.data.blob;
        break;
      default:
        break;
    }
    this.resolve && this.resolve();
    this.resolve = null;
    this.isReady = true;
    this.debug('activity resolved');
  }

  postResult(data) {
    if (navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({ result: data });
    } else {
      console.error('send data but navigator.serviceWorker.controller is null');
    }

    this._activity = null;
    // clear dummy message interval
    clearInterval(this.keepSWStateInterval);
    window.close();
  }

  leaveActivity(errorReason) {
    this.debug('leaveActivity: errorReason:', errorReason);
    if (this._activity) {
      if (navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage({
          error: errorReason,
        });
      }
      this._activity = null;
      window.close();
    }
  }
}

const systemMessageHandler = new SystemMessageHandler();
systemMessageHandler.start();

window.smh = systemMessageHandler;

export default systemMessageHandler;
