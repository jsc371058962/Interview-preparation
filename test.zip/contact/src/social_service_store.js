import BaseModule from 'base-module';

import GmailConnector from './gmail_connector';
import LiveConnector from './live_connector';

import oauth2 from './oauth2';

const TOKEN_EXPIRED_STR = 'request_token_expired';
const TOKEN_EXPIRED_CODE = 190;

class SocialServiceStore extends BaseModule {
  name = 'SocialServiceStore';
  DEBUG = false;

  start() {
    window.sss = this;
    this.oauth2 = oauth2;
  }
  tokenExpired(error) {
    return error.code === TOKEN_EXPIRED_CODE || error === TOKEN_EXPIRED_STR;
  }

  contactsReady() {}

  ensureConnector(service) {
    this.connector = null;
    if ('gmail' === service) {
      this.connector = GmailConnector;
    } else if ('live' === service) {
      this.connector = LiveConnector;
    }
  }

  getFriends(service) {
    this.debug(`getting friends for ${service}`);
    return oauth2
      .getAccessToken(service)
      .then(access_token => {
        this.debug(`access_token=${access_token}`);
        return new Promise((resolve, reject) => {
          this.resolve = resolve;
          this.reject = reject;
          this.ensureConnector(service);
          this.connector.listAllContacts(access_token, {
            success: this._listAllContactsSuccess.bind(this),
            error: e => this.reject(e),
            timeout: () => {},
          });

          // In the meantime we obtain the Service Contacts
          // already on the Address Book
          if (!ContactsManager) {
            return;
          }

          const callbacks = {
            success: this.contactsReady.bind(this),
            error: errorName => {
              window.console.error(
                'Error while retrieving existing dev contacts: ',
                errorName
              );
            },
          };

          this.connector.listDeviceContacts(callbacks);
        });
      })
      .catch(e => {
        throw e;
      });
  }

  _listAllContactsSuccess(response) {
    this.debug('_listAllContactsSuccess:');
    if ('undefined' === typeof response.error) {
      const friends = response.data || response.value;
      this.debug('friends length:', friends.length);

      const friendsHash = {};
      friends.forEach(aFriend => {
        const id = aFriend.id || aFriend.uid;
        friendsHash[id] = aFriend;
      });

      this.resolve(friendsHash);
    } else {
      console.error('listAllContacts response error:', response.error);
    }
  }
}

const socialServiceStore = new SocialServiceStore();
socialServiceStore.start();

export default socialServiceStore;
