import BaseModule from 'base-module';
import Service from 'service';
import ContactStore from './contact_store';
import Utils from './vcard_utils.js';

export default class BaseExporter extends BaseModule {
  name = 'BaseExporter';
  DEBUG = false;

  constructor(ids) {
    super();
    this.ids = ids;
  }

  _done = false;
  ids = [];
  contacts = [];
  pendingBatches = [];
  append = false;
  storage = null;
  storedFileName = null;
  exportNum = 0;
  total = 0;

  ERRORS = {
    CannotAccessPhoneBook: true,
    NoFreeSpace: 'NoFreeSpace',
  };

  hasDeterminativeProgress = true;

  title = 'Export-title';

  done() {
    if (this._done) {
      return;
    }

    this._done = true;
    this.emit('finished');
    if (this.error) {
      return;
      // No show toast if error happens
    }
    this.showToast();
  }

  showToast() {
    const _ = window.api.l10n.get;
    Service.request('ToastManager:show', {
      text: this.aborted
        ? _('contact-export-canceled')
        : _('contact-exported2', { exported: this.exportNum || this.total }),
    });
  }

  getContacts() {
    this.contacts = [];
    ContactStore.fullContacts.forEach(contact => {
      if (this.ids && this.ids.indexOf(contact.id) >= 0) {
        this.contacts.push(contact);
      }
    });
  }

  export() {
    this.current = 0;
    this.pendingBatches = [];
    this.append = false;
    this.storedFileName = null;
    this.exportNum = 0;
    this.getContacts();
    this.total = this.contacts.length;
    this.emit('ready');
    this.continue();
  }

  cancel() {
    this.debug('exporting canceled');
    this.aborted = true;
    this.done();
    this.emit('canceled');
  }

  continue() {
    // Override
  }

  // for debugging, override if need
  _mock_continue() {
    setTimeout(() => {
      if (this.aborted) {
        console.log('_mock_continue: aborted.');
        this.done();
        return;
      }

      this.current += Math.ceil((this.total - this.current) / 3);
      if (this.hasDeterminativeProgress) {
        this.emit('exported');
      }

      console.log('_mock_continue: current, total:', this.current, this.total);
      if (this.current === this.total) {
        this.done();
      } else {
        this._mock_continue();
      }
    }, 500);
  }

  hasGivenName(contact) {
    return (
      Array.isArray(contact.givenName) &&
      contact.givenName[0] &&
      contact.givenName[0].trim()
    );
  }

  hasFamilyName(contact) {
    return (
      Array.isArray(contact.familyName) &&
      contact.familyName[0] &&
      contact.familyName[0].trim()
    );
  }

  getFileName() {
    const _ = window.api.l10n.get;
    const filename = [];
    const contacts = this.contacts;
    if (contacts && 1 === contacts.length) {
      const contact = contacts[0];
      let hasName = false;
      if (this.hasGivenName(contact)) {
        filename.push(contact.givenName[0]);
        hasName = true;
      }
      if (this.hasFamilyName(contact)) {
        filename.push(contact.familyName[0]);
        hasName = true;
      }
      if (!hasName) {
        if (contact.org && contact.org.length > 0) {
          filename.push(contact.org[0]);
        } else if (contact.tel && contact.tel.length > 0) {
          filename.push(contact.tel[0].value);
        } else if (contact.email && contact.email.length > 0) {
          filename.push(contact.email[0].value);
        } else {
          filename.push(_('noName'));
        }
      }
    } else {
      const today = new Date();
      filename.push(
        today.getFullYear(),
        today.getMonth() + 1,
        today.getDate(),
        contacts.length
      );
    }

    return `${filename
      .join('_')
      .replace(/[\s#&?\$]/g, '')
      .toLowerCase()}.vcf`;
  }

  getFile(storage, filename) {
    return new Promise((resolve, reject) => {
      const request = storage.get(filename);
      request.onsuccess = () => {
        resolve(request.result); // returns a File object
      };
      request.onerror = reject;
    });
  }

  saveVcardFile(fileName, append, bShare) {
    const vData = this.pendingBatches.pop();
    const _blob = vData.blob;
    Utils.getStorage(fileName, _blob, bShare, append)
      .then(({ storage, name, blob }) => {
        if (this.aborted) {
          this.debug('aborted after getStorage');
          this.emit('canceled');
          return;
        }

        let request;
        if (!append) {
          request = storage.addNamed(blob, name);
        } else {
          request = storage.appendNamed(blob, name);
        }
        request.onsuccess = evt => {
          if (!append) {
            this.storage = storage;
            this.storedFileName = name;
          }
          this.savedNum = this.current;
          request = null;
          if (vData.bDone) {
            if (bShare) {
              this.shareVcard(storage, evt.target.result, name);
            } else {
              this.done();
            }
          } else if (this.pendingBatches.length) {
            this.saveVcardFile(name, true);
          } else {
            this.append = true;
          }
        };
        request.onerror = e => {
          const error = e.target.error;
          const errorName = this.ERRORS[error.name] || error.name;
          this.emit('error', e);
          this.error = errorName;
          this.done();
        };
      })
      .catch(error => {
        let errorName = error;
        // numeric error means not enough space available
        if (parseInt(error, 10) >= 0) {
          errorName = this.ERRORS.NoFreeSpace;
        }
        this.emit('error', error);
        this.error = errorName;
        this.done();
      });
  }

  shareVcard(storage, filePath, name) {
    this.getFile(storage, filePath).then(file => {
      const a = new window.WebActivity('share-via-bluetooth-only', {
        type: 'text/vcard',
        number: 1,
        blobs: [file],
        filenames: [name],
        filepaths: [filePath],
      });

      a.start().then(
        () => {
          this.current = this.total;
          this.emit('finished');
        },
        () => {
          const error = a.error;
          const errorName = this.ERRORS[error.name] || error.name;
          this.emit('error', error);
          this.error = errorName;
          this.done();
        }
      );
    });
  }
}
