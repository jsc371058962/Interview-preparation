import React from 'react';
import ReactDOM from 'react-dom';
import Service from 'service';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import ContactStore from './contact_store';

export default class ExportProgessView extends BaseComponent {
  name = 'ExportProgressView';

  constructor(props) {
    super(props);
    this.state = {
      progress: 0,
      total: 0,
    };
  }

  componentDidMount() {
    const config = {
      left: 'cancel',
      center: '',
    };
    window.addEventListener('blur', function blur() {
      window.removeEventListener('blur', blur);
      Service.request('back');
    });
    this.export();
    this.element = ReactDOM.findDOMNode(this);
    this._softKey = SoftKeyManager.create(this.element, config);
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  export() {
    const exporter = ContactStore.getExporter();
    this.exporter = exporter;
    exporter.on('exported', () => {
      this.setState({
        progress: exporter.current,
        total: exporter.total,
      });
    });
    exporter.on('finished', () => {
      // XXX: Workaround done will be fired twice.
      if (!this.element.contains(document.activeElement)) {
        return;
      }
      if (exporter.error) {
        let content = '';
        const _ = window.api.l10n.get;
        content =
          'NoFreeSpace' === exporter.error
            ? _('contact-export-error-sd-full')
            : _('contact-export-error-unknown');
        if (exporter.savedNum) {
          content += _('contact-exported2', { exported: exporter.savedNum });
        }
        // finish with error
        Service.request('showDialog', {
          header: _('export-contact-failed'),
          type: 'alert',
          content,
          translated: true,
          onOk: () => {
            Service.request('back');
          },
        });
        return;
      }
      if (this.state.total <= 2) {
        // too quick.
        setTimeout(() => {
          Service.request('back');
        }, 500);
      } else {
        Service.request('back');
      }
    });
    exporter.on('ready', () => {
      this.setState({
        total: exporter.total,
      });
    });

    setTimeout(() => {
      // XXX: Prevent the export too fast.
      exporter.export();
    }, 500);
  }

  onKeyDown(e) {
    switch (e.key) {
      case 'SoftLeft':
      case 'Backspace':
      case 'EndCall':
        e.preventDefault();
        e.stopPropagation();
        this.exporter && this.exporter.cancel();
        Service.request('back');
        break;
      default:
        break;
    }
  }

  render() {
    let progressDOM = null;
    let divider = null;
    if (this.state.total) {
      const infinite = this.exporter && !this.exporter.hasDeterminativeProgress;
      const progress = 100 * (this.state.progress / this.state.total);
      if (infinite) {
        progressDOM = (
          <div className="progress" data-infinite="true">
            <div className="progress-active" />
          </div>
        );
      } else {
        const activeStyle = { width: `${progress}%` };
        const inactiveStyle = { width: `calc(100% - ${progress}% - 0.3rem)` };
        progressDOM = (
          <div className="progress" data-infinite={infinite ? 'true' : 'false'}>
            <div className="progress-active" style={activeStyle} />
            <div className="progress-inactive" style={inactiveStyle} />
          </div>
        );
        divider = (
          <div className="secondary">
            {this.state.progress}/{this.state.total}
          </div>
        );
      }
    }
    return (
      <div
        className="export-progress-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
      >
        <div
          className="header h1"
          ref="header"
          data-l10n-id="export-contacts"
        />
        <div className="body">
          <div className="list-item">
            <div className="content">
              <div
                className="primary"
                data-l10n-id={this.exporter && this.exporter.title}
              />
              {divider}
              {progressDOM}
            </div>
          </div>
        </div>
      </div>
    );
  }
}
