/* global window, TelephonyCall, WebActivity */

import BaseModule from 'base-module';
import Service from 'service';
import perf from 'modules/perf';

function toL10n(id = '', args = {}) {
  id += '';
  return window.api.l10n.get(id, args) || id;
}

// As defined in 3GPP TS 22.030 version 10.0.0 Release 10 standard
// USSD code used to query call barring supplementary service status
const CALL_BARRING_STATUS_MMI_CODE = '*#33#';
// USSD code used to query call waiting supplementary service status
const CALL_WAITING_STATUS_MMI_CODE = '*#43#';

class DialHelper extends BaseModule {
  isDialing = false;

  constructor(props) {
    super(props);
    this.validExp = /^(?!,)([0-9#+*,]){1,50}$/;
    this.extraCharExp = /(\s|-|\.|\(|\))/g;
    this.instantDialNumbers = ['*#06#', '*#07#', '*#2886#', '*#*#0574#*#*'];
    window.addEventListener('ussd-received', this.onUssdReceived);
  }

  onUssdReceived = () => {
    Service.request('hideDialog');
    this.mmiloading = false;
  };

  errorCases = {
    BadNumber: {
      header: 'invalidNumberToDialTitle',
      content: 'invalidNumberToDialMessage',
    },
    NoNetwork: {
      header: 'emergencyDialogTitle',
      content: 'emergencyDialogBodyBadNumber',
    },
    EmergencyCallOnly: {
      header: 'emergency-call-only',
      content: 'emergency-call-error',
      containNumber: true,
    },
    RadioNotAvailable: {
      header: 'callAirplaneModeTitle',
      content: 'callAirplaneModeMessage',
    },
    DeviceNotAccepted: {
      header: 'emergencyDialogTitle',
      content: 'emergencyDialogBodyDeviceNotAccepted',
    },
    Busy: {
      header: 'numberIsBusyTitle',
      content: 'numberIsBusyMessage',
    },
    FDNBlocked: {
      header: 'fdnIsActiveTitle',
      content: 'fdnIsActiveMessage',
      containNumber: true,
    },
    FdnCheckFailure: {
      header: 'fdnIsActiveTitle',
      content: 'fdnIsActiveMessage',
      containNumber: true,
    },
    OtherConnectionInUse: {
      header: 'otherConnectionInUseTitle',
      content: 'otherConnectionInUseMessage',
    },
  };

  listDeviceInfos(type) {
    const promises = [...navigator.b2g.mobileConnections].map(
      (conn, simSlotIndex) => {
        return conn.getDeviceIdentities().then(deviceInfo => {
          if (deviceInfo[type]) {
            return deviceInfo[type];
          }
          const errorMsg = `Could not retrieve the ${type.toUpperCase()} code for SIM ${simSlotIndex}`;
          console.error(errorMsg);
          return Promise.reject(new Error(errorMsg));
        });
      }
    );

    Promise.all(promises).then(
      items => {
        Service.request('showDialog', {
          type: 'alert',
          header: type.toUpperCase(),
          content: items.join('\n'),
          translated: true,
          noClose: false,
        });
      },
      msg => {
        Service.request('showDialog', {
          type: 'alert',
          header: type.toUpperCase(),
          content: msg.message,
          translated: true,
          noClose: false,
        });
      }
    );
  }

  instantDialIfNecessary(telNum) {
    return this.instantDialNumbers.includes(telNum);
  }

  mmiHandler(promise, sentMMI) {
    this.mmiloading = true;
    this.emit('mmiloading');
    promise.then(mmiResult => {
      if (!mmiResult) {
        const message = toL10n('GenericFailure');
        this.emit('mmiloaded', '!', message);
        return;
      }

      const title = toL10n(mmiResult.serviceCode);
      let message = mmiResult.statusMessage;
      const additionalInformation = mmiResult.additionalInformation;

      switch (mmiResult.serviceCode) {
        case 'scCall':
          return;
        case 'scUssd':
          if (!message) {
            return;
          }
          message = toL10n(message);
          break;
        case 'scCallForwarding':
          if (!message) {
            message = toL10n('GenericFailure');
          } else if (additionalInformation) {
            // Call forwarding requests via MMI codes might return an array of
            // nsIDOMMozMobileCFInfo objects. In that case we serialize that array
            // into a single string that can be shown on the screen.
            message = this.processCf(additionalInformation);
          }
          break;
        case 'scCallBarring':
        case 'scCallWaiting':
          // If we are just querying the status of the service, we show a different message,
          // so the user knows she hasn't change anything
          if (
            sentMMI === CALL_BARRING_STATUS_MMI_CODE ||
            sentMMI === CALL_WAITING_STATUS_MMI_CODE
          ) {
            let additionalInfor = [];
            const msgCase = {
              smServiceEnabled: 'ServiceIsEnabled',
              smServiceDisabled: 'ServiceIsDisabled',
              smServiceEnabledFor: 'ServiceIsEnabledFor',
            };
            // Call barring and call waiting requests via MMI codes might return an
            // array of strings indicating the service it is enabled for or just
            // the disabled status message.
            if (
              additionalInformation &&
              'smServiceEnabledFor' === message &&
              Array.isArray(additionalInformation)
            ) {
              additionalInfor = additionalInformation.map(toL10n);
            }
            additionalInfor.unshift(toL10n(msgCase[message]) || message);
            message = additionalInfor.join('\n');
          }
          break;
        default:
          break;
      }

      this.mmiloading = false;
      this.emit('mmiloaded', title, message);
    });
  }

  // Helper function to compose an informative message about a successful
  // request to query the call forwarding status.
  processCf(result) {
    const inactive = toL10n('call-forwarding-inactive');
    let voice = inactive;
    let data = inactive;
    let fax = inactive;
    let sms = inactive;
    let sync = inactive;
    let async = inactive;
    let packet = inactive;
    let pad = inactive;

    for (let i = 0; i < result.length; i++) {
      if (!result[i].active) {
        continue; // eslint-disable-line no-continue
      }

      for (
        let serviceClassMask = 1;
        serviceClassMask <= this._conn.ICC_SERVICE_CLASS_MAX;
        serviceClassMask <<= 1
      ) {
        if ((serviceClassMask & result[i].serviceClass) !== 0) {
          switch (serviceClassMask) {
            case this._conn.ICC_SERVICE_CLASS_VOICE:
              voice = result[i].number;
              break;
            case this._conn.ICC_SERVICE_CLASS_DATA:
              data = result[i].number;
              break;
            case this._conn.ICC_SERVICE_CLASS_FAX:
              fax = result[i].number;
              break;
            case this._conn.ICC_SERVICE_CLASS_SMS:
              sms = result[i].number;
              break;
            case this._conn.ICC_SERVICE_CLASS_DATA_SYNC:
              sync = result[i].number;
              break;
            case this._conn.ICC_SERVICE_CLASS_DATA_ASYNC:
              async = result[i].number;
              break;
            case this._conn.ICC_SERVICE_CLASS_PACKET:
              packet = result[i].number;
              break;
            case this._conn.ICC_SERVICE_CLASS_PAD:
              pad = result[i].number;
              break;
            default:
              return toL10n('call-forwarding-error');
          }
        }
      }
    }

    const msg = [
      toL10n('call-forwarding-status'),
      toL10n('call-forwarding-voice', { voice }),
      toL10n('call-forwarding-data', { data }),
      toL10n('call-forwarding-fax', { fax }),
      toL10n('call-forwarding-sms', { sms }),
      toL10n('call-forwarding-sync', { sync }),
      toL10n('call-forwarding-async', { async }),
      toL10n('call-forwarding-packet', { packet }),
      toL10n('call-forwarding-pad', { pad }),
    ].join('\n');

    return msg;
  }

  dialForcely(number, serviceId) {
    console.log('dialForcely', number);
    navigator.b2g.telephony.dial(number, serviceId);
  }

  dial(number, isVideo, isRTT) {
    if (this.isDialing) {
      return Promise.reject();
    }

    // For voicemail of DSDS.
    const voicemailArr = [];
    if (Array.isArray(number)) {
      number.forEach(element => {
        voicemailArr.push(String(element).replace(this.extraCharExp, ''));
      });
      if (voicemailArr.every(num => this.checkSpecialNumber(num))) {
        return Promise.resolve();
      }
    } else {
      // sanitization number
      number = String(number).replace(this.extraCharExp, '');

      if (this.checkSpecialNumber(number)) {
        return Promise.resolve();
      }

      if (!this.isValid(number)) {
        this.errorHandler({ errorName: 'BadNumber' });
        return Promise.reject();
      }
    }

    return new Promise((resolve, reject) => {
      Service.request('chooseSim', 'call')
        .then(cardIndex => {
          if (Array.isArray(number)) {
            number = voicemailArr[cardIndex];
            if (!number) {
              Service.request('ToastManager:show', {
                text: navigator.mozL10n.get('no-phone-number-to-dial'),
              });
              return reject();
            }
            if (!this.isValid(number)) {
              this.errorHandler({ errorName: 'BadNumber' });
              return reject();
            }
          }

          const conn =
            navigator.b2g.mobileConnections &&
            navigator.b2g.mobileConnections[cardIndex];
          const self = this;
          let callPromise;
          const originNumber = number;
          number = this.getNumberAsDtmfToneGroups(originNumber)[0];
          this._conn = conn;

          // No voice connection, the call won't make it
          if (!conn || !conn.voice) {
            reject();
            this.errorHandler({ errorName: 'NoNetwork' });
            return;
          }

          const telephony = navigator.b2g.telephony;
          if (!telephony) {
            reject();
            return;
          }
          this.isDialing = true;

          const imsCapability = conn.imsHandler && conn.imsHandler.capability;
          const emergencyOnly = !imsCapability && conn.voice.emergencyCallsOnly;
          if (emergencyOnly) {
            callPromise = telephony.dialEmergency(number, isRTT);
          } else if (isVideo) {
            callPromise = telephony.dial(number, 4, isRTT, cardIndex);
          } else {
            callPromise = telephony.dial(number, 1, isRTT, cardIndex);
          }

          callPromise
            .then(callObj => {
              if (callObj instanceof TelephonyCall) {
                // regular call
                perf.measure('enter-callscreen');
                telephony.addEventListener(
                  'callschanged',
                  function callschangedOnce() {
                    self.isDialing = false;
                    resolve();
                    telephony.removeEventListener(
                      'callschanged',
                      callschangedOnce
                    );
                  }
                );

                const dtmfToneGroups = this.getNumberAsDtmfToneGroups(
                  originNumber
                );
                if (dtmfToneGroups.length > 1) {
                  callObj.addEventListener(
                    'connected',
                    function dtmfToneGroupPlayer() {
                      callObj.removeEventListener(
                        'connected',
                        dtmfToneGroupPlayer
                      );
                      self.playDtmfToneGroups(dtmfToneGroups, cardIndex);
                    }
                  );
                }
              } else {
                // MMI call
                self.isDialing = false;
                resolve();
                this.mmiHandler(callObj.result, number);
              }
            })
            .catch(errorName => {
              self.isDialing = false;
              reject();
              self.errorHandler({
                errorName,
                number,
                isEmergencyOnly: emergencyOnly,
              });
            });
        })
        .catch(() => {
          // for cancel sim card choosing
          reject();
        });
    });
  }

  checkSpecialNumber(number) {
    let isSpecialNumber = true;

    switch (number) {
      case '*#06#': {
        this.listDeviceInfos('imei');
        break;
      }

      case '*#2886#': {
        const activity = new WebActivity('mmitest');
        activity.start().then(
          () => {},
          () => {
            console.warn('Could not launch mmitest');
          }
        );

        break;
      }

      case '*#*#0574#*#*': {
        const activity = new WebActivity('logmanager');
        activity.start().then(
          () => {},
          () => {
            console.warn('Could not launch logmanager');
          }
        );

        break;
      }

      default: {
        if (this.debuggerRemoteMode) {
          switch (number) {
            case '*#*#2637643#*#*':
            case '*#8378269#': {
              const activity = new WebActivity('engmode');
              activity.start().then(
                () => {},
                () => {
                  console.warn('Could not launch eng mode');
                }
              );

              break;
            }

            case '*#0606#': {
              this.listDeviceInfos('meid');
              break;
            }

            default: {
              isSpecialNumber = false;
              break;
            }
          }
        } else {
          isSpecialNumber = false;
        }
        break;
      }
    }

    return isSpecialNumber;
  }

  playDtmfToneGroups(dtmfToneGroups, cardIndex) {
    const self = this;

    // Remove the dialed number from the beginning of the array.
    dtmfToneGroups = dtmfToneGroups.slice(1);
    let length = dtmfToneGroups.length;

    // Remove the latest entries
    // from dtmfToneGroups corresponding to ',' characters not to play those pauses.
    let lastCommaIndex = length - 1;
    while ('' === dtmfToneGroups[lastCommaIndex]) {
      lastCommaIndex--;
    }
    dtmfToneGroups = dtmfToneGroups.slice(0, ++lastCommaIndex);
    length = dtmfToneGroups.length;

    let promise = Promise.resolve();
    let counter = 0;
    let pauses;

    // Traverse the dtmfToneGroups array.
    while (counter < length) {
      // Reset the number of pauses before each group of tones.
      pauses = 1;
      while ('' === dtmfToneGroups[counter]) {
        // Add a new pause for each '' in the dtmfToneGroups array.
        pauses++;
        counter++;
      }

      // Send a new group of tones as well as the pauses to play before it.
      promise = promise.then(
        self.playDtmfToneGroup.bind(
          null,
          dtmfToneGroups[counter++],
          pauses,
          cardIndex
        )
      );
    }
    return promise;
  }

  playDtmfToneGroup(toneGroup, pauses, cardIndex, pausesDuration = 3000) {
    return navigator.b2g.telephony.sendTones(
      toneGroup,
      pausesDuration * pauses, // DTMF_SEPARATOR_PAUSE_DURATION = 3000ms
      null, //  tone duration
      cardIndex
    );
  }

  errorHandler({ errorName, number, isEmergencyOnly } = {}) {
    console.warn(`Dialer error handler: ${errorName}`);

    if ('BadNumberError' === errorName) {
      // TODO: in emergency app, the errorName should change to use 'EmergencyCallOnly'
      errorName = isEmergencyOnly ? 'NoNetwork' : 'RegularCall';
    }

    let _case = this.errorCases[errorName];

    if (!_case) {
      console.warn(`Unexpected dialer error: ${errorName}`);
      // default error message
      _case = {
        content: 'CallFailed',
      };
    }

    const dialogOption = Object.assign(
      {
        type: 'alert',
        translated: false,
        noClose: false,
      },
      _case
    );

    if (dialogOption.containNumber) {
      dialogOption.header = toL10n(dialogOption.header, { number });
      dialogOption.content = toL10n(dialogOption.content, { number });
      dialogOption.translated = true;
    }

    Service.request('showDialog', dialogOption);
  }

  isValid(number) {
    return this.validExp.test(number);
  }

  getNumberAsDtmfToneGroups(number) {
    return number.split(',');
  }
}

const dialHelper = new DialHelper();
window.dh = dialHelper;

export default dialHelper;
