import BaseModule from 'base-module';
import ContactStore from 'contact_store';
import Service from 'service';

export default class ContactsRemover extends BaseModule {
  constructor(ids) {
    super();
    this._ids = [].concat(ids);
    this._processed = 0;
    this._failed = 0;
  }

  cancel() {
    this._aborted = true;
  }

  start() {
    ContactStore.getCount().then(result => {
      if (this._ids.length === result) {
        this.emit('processed', -1);
        ContactStore.clearContacts().then(() => {
          this.emit('finished', this._ids.length);
        });
      } else {
        ContactStore.setEventEmittingState(false);
        this._process(this._ids);
      }
    });
  }

  _process(ids) {
    const id = ids.shift();

    if (!id || this._aborted) {
      ContactStore.setEventEmittingState(true);
      setTimeout(() => {
        this.emit('finished', this._processed);
      });
      Service.request('List:reload');
      return;
    }

    ContactStore.remove({ id }).then(result => {
      if (result.error) {
        this._failed++;
        this._process(ids);
      } else {
        this._processed++;
        this.emit('processed', this._processed);
        this._process(ids);
      }
    });
  }
}
