import React from 'react';
import Service from 'service';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import VCardReader, { MAX_BLOB_SIZE } from 'vcard_reader';
import ContactStore from 'contact_store';

const _ = window.api.l10n.get;

export default class ImportVcardView extends BaseComponent {
  name = 'ImportVcardView';
  DEBUG = false;

  static defaultProps = {
    blob: null,
    filename: '',
  };

  constructor(props) {
    super(props);
    this.state = {
      saved: '',
      progress: -1,
      total: 0,
    };
    this.delayImport = false;
    this.isImporting = false;
    this.preventImportDialog = false;
    if (!ContactStore._cached) {
      ContactStore.on('loaded', () => {
        if (this.delayImport) {
          this._showImportDialog();
        }
      });
    }
  }

  componentDidMount() {
    this.debug('did mount');
    window.isv = this;
    this._softKey = SoftKeyManager.create(this.element, { left: 'cancel' });
    if (this.props.blob.size > MAX_BLOB_SIZE) {
      this._showDisImportDialog();
    } else {
      ContactStore.isDiskFull().then(fullDisk => {
        if (!fullDisk) {
          this._read();
        } else {
          Service.request('ToastManager:show', {
            text: _('fullDiskSpace-error'),
          });
          Service.request('leaveActivity');
        }
      });
    }
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  updateSoftKeys() {
    const config = {
      left: 'cancel',
    };
    this._softKey.update(config);
  }

  _read() {
    // #open from activity
    const fileReader = new FileReader();
    fileReader.readAsText(this.props.blob);
    fileReader.onloadend = () => {
      if ('null' === fileReader.result) {
        Service.request('showDialog', {
          header: _('import-contact-failed'),
          content: _('invalid-vcf-file'),
          type: 'alert',
          translated: true,
          onOk: () => {
            Service.request('leaveActivity');
          },
        });
      } else {
        this._reader = new VCardReader(fileReader.result);
        if (!ContactStore._cached) {
          this.delayImport = true;
        } else {
          this._showImportDialog();
        }
      }
    };
  }

  _showDisImportDialog() {
    const content = [
      _('activity-import-limit-contact'),
      _('activity-import-limit-additional'),
    ].join('\n\n');
    Service.request('showDialog', {
      header: _('import-limit-header'),
      content,
      type: 'alert',
      translated: true,
      onOk: () => {
        Service.request('leaveActivity');
      },
      onBack: () => {
        Service.request('leaveActivity');
      },
    });
  }

  _showImportDialog() {
    if (this.preventImportDialog) {
      this.preventImportDialog = false;
      return;
    }
    Service.request('showDialog', {
      header: _('confirm'),
      content: _('importing-confirm', {
        n: this._reader.total,
        fileName: this.props.filename,
      }),
      type: 'confirm',
      translated: true,
      ok: 'import',
      onOk: () => {
        this.isImporting = true;
        const config = {
          left: 'cancel',
        };
        this._import();
        this._softKey.update(config);
      },
      onCancel: () => {
        Service.request('leaveActivity');
      },
      onBack: () => {
        Service.request('leaveActivity');
      },
    });
  }

  _showCancelProcessDialog() {
    Service.request('showDialog', {
      header: 'confirm',
      content: 'importing-cancel-confirm',
      type: 'confirm',
      ok: 'close',
      onOk: () => {
        this.isImporting && this._reader.cancel();
        Service.request('leaveActivity');
        Service.request('ToastManager:show', {
          text: _('import-contacts-canceled'),
        });
      },
      onCancel: () => {
        this.continueImport();
        this.updateSoftKeys();
      },
      onBack: () => {
        this.continueImport();
        this.updateSoftKeys();
      },
    });
  }

  continueImport() {
    this.preventImportDialog = false;
    this.isImporting ? this._reader.resume() : this._read();
  }

  _import() {
    const reader = this._reader;
    reader.on('imported', name => {
      this.setState({
        saved: name,
        progress: reader.imported,
        total: reader.total,
      });
    });

    reader.on('finished', this._leave);
    reader.on('aborted', this._leave);

    this.setState(
      {
        progress: 0,
        total: reader.total,
      },
      () => {
        setTimeout(() => {
          reader.import();
        });
      }
    );
  }

  _leave = () => {
    this.isImporting = false;
    Service.request('leaveActivity');
  };

  onKeyDown = e => {
    if (!this._reader) {
      this.debug('reader not yet ready, skip keydown.');
      return;
    }

    switch (e.key) {
      case 'SoftLeft':
      case 'EndCall':
      case 'Backspace':
        e.preventDefault();
        if ('SoftLeft' === e.key && !this._softKey.getSoftKeyValue('left')) {
          break;
        }
        if (this.isImporting) {
          this._reader.pause();
        } else {
          this.preventImportDialog = true;
        }
        this._showCancelProcessDialog();
        break;

      default:
        break;
    }
  };

  render() {
    let progressDOM = null;
    let divider = null;
    let importStatus = null;
    if (this.state.total) {
      const progress = 100 * (this.state.progress / this.state.total);
      const activeStyle = { width: `${progress}%` };
      const inactiveStyle = { width: `calc(100% - ${progress}% - 0.3rem)` };
      progressDOM = (
        <div className="progress">
          <div className="progress-active" style={activeStyle} />
          <div className="progress-inactive" style={inactiveStyle} />
        </div>
      );
      divider = (
        <div className="secondary">
          {this.state.progress}/{this.state.total}
        </div>
      );
      importStatus = (
        <div className="primary" data-l10n-id="importing-contacts-from-vcard" />
      );
    } else {
      importStatus = (
        <div
          className="primary"
          key="import-vcard-reading"
          data-l10n-id="reading-contacts-from-vcard"
        />
      );
    }
    return (
      <div
        className="import-vcard-view"
        ref={e => {
          this.element = e;
        }}
        tabIndex="-1"
        onKeyDown={this.onKeyDown}
      >
        <div
          className="header h1"
          ref="header"
          data-l10n-id="importContactsTitle"
        />
        <div className="body">
          <div className="list-item" data-multi-line="true">
            <div className="content">
              {importStatus}
              {divider}
              {progressDOM}
            </div>
          </div>
        </div>
      </div>
    );
  }
}
