import ContactStore from 'contact_store';
import { FIELDS, CLOUD_TAG } from 'contact_wrapper';
import { TAG_INDEX } from '../contact_store';

/**
 * Find duplicate phone contacts for a specified contact.
 * The `targetContact` may be a not saved mozContact instance(i.e. no contact id)
 * Duplicate criteria is name and tel.
 */
const findDup = targetContact => {
  if (targetContact.category && targetContact.category.includes(CLOUD_TAG)) {
    return Promise.resolve([]);
  }
  return new Promise(resolve => {
    const contacts = [];
    const targetName = targetContact.name && targetContact.name[0];
    const targetTels = targetContact.tel && targetContact.tel.map(t => t.value);
    ContactStore.getSourceContacts('phone')
      .filter(item => item.category && !item.category.includes(CLOUD_TAG))
      .forEach(source => {
        if (source.id === targetContact.id) {
          return;
        }
        if (targetName && source.name && source.name[0] === targetName) {
          contacts.push(source);
        } else if (targetTels && source.tel) {
          const telMatched = source.tel.some(t => targetTels.includes(t.value));
          telMatched && contacts.push(source);
        }
      });
    resolve(contacts);
  });
};

/**
 * To merge two contacts.
 * There are some fields only allows to have one value(i.e. cannot merge),
 * invoke `onConflict` in this case.
 * Users can handle conflict by himself and do `resolve` to continue, otherwise stop merging.
 * If no conflict or user resolved the conflict then actually do merge.
 */
const merge = ({ fromContact, toContact, onConflict } = {}) => {
  const dirtyFields = ['name', 'photo', 'note', 'bday', 'ringtone'].filter(
    field => {
      if (
        toContact[field] &&
        toContact[field].toString() &&
        fromContact[field] &&
        fromContact[field].toString()
      ) {
        if ('photo' === field) {
          return (
            !toContact[field][0].name ||
            !fromContact[field][0].name ||
            (toContact[field][0].name !== fromContact[field][0].name &&
              toContact[field][0].size !== fromContact[field][0].size)
          );
        }
        return toContact[field].toString() !== fromContact[field].toString();
      }
      return false;
    }
  );

  return new Promise(resolve => {
    if (dirtyFields.length && onConflict) {
      onConflict(resolve, dirtyFields);
    } else {
      resolve(true);
    }
  })
    .then(() => {
      return ContactStore.remove(fromContact);
    })
    .then(() => {
      const mergedContact = _mergeContacts(fromContact, toContact);
      return ContactStore.createOrUpdate(mergedContact, true);
    });
};

/**
 * Merge by appending data to `toContact`.
 * That is to say, the result has id equals to `toContact.id`.
 */
const _mergeContacts = (fromContact, toContact) => {
  const singleValueFields = [
    'name',
    'givenName',
    'familyName',
    'photo',
    'note',
    'bday',
    'ringtone',
  ];
  // extract non-empty values
  const values = {};
  FIELDS().forEach(field => {
    if (singleValueFields.includes(field)) {
      values[field] =
        toContact[field] && toContact[field].toString()
          ? toContact[field]
          : fromContact[field];
      return;
    }

    values[field] = [];
    if (toContact[field]) {
      values[field] = values[field].concat(toContact[field]);
    }

    if (fromContact[field]) {
      if ('tel' !== field) {
        values[field] = values[field].concat(fromContact[field]);
      } else {
        // skip duplicated phone number
        const tels = toContact.tel ? toContact.tel.map(t => t.value) : [];
        fromContact.tel.forEach(t => {
          !tels.includes(t.value) && values.tel.push(t);
        });
      }
    }
  });

  values.category = [TAG_INDEX.phone, TAG_INDEX.kaiContact];

  Object.keys(values).forEach(field => {
    toContact[field] =
      values[field] && values[field].toString() ? values[field] : null;
  });
  return toContact;
};

export { findDup, merge, _mergeContacts };
