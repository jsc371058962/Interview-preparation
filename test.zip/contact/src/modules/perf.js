const perf = {
  mark: name => {
    if (!window.performance.mark) {
      return;
    }
    window.performance.mark(`${name}-start`);
  },
  measure: name => {
    if (!window.performance.mark) {
      return;
    }
    try {
      window.performance.mark(`${name}-end`);
      window.performance.measure(
        `performance-${name}`,
        `${name}-start`,
        `${name}-end`
      );
      window.performance.clearMarks(`${name}-start`);
      window.performance.clearMarks(`${name}-end`);
      window.performance.clearMeasures(`performance-${name}`);
    } catch (e) {
      console.error('something wrong at perf.measure:', e);
    }
  },
};

export default perf;
