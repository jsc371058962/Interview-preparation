import SoftKeyStore from 'soft-key-store';

class SoftKeyManager {
  _softKeyState = {};

  constructor(element, config = {}) {
    this._element = element;
    this.update(config);
  }

  update(config) {
    this._softKeyState = config;
    SoftKeyStore.register(this._softKeyState, this._element);
  }

  getSoftKeyValue(key) {
    switch (key) {
      case 'left':
        return this._softKeyState.left;
      case 'center':
        return this._softKeyState.center;
      case 'right':
        return this._softKeyState.right;
      default:
        break;
    }
  }

  destroy() {
    SoftKeyStore.unregister(this._element);
  }
}

SoftKeyManager.create = (element, config) => {
  return new SoftKeyManager(element, config);
};

export default SoftKeyManager;
