import BaseEmitter from 'base-emitter';
import { convertContactToLocal } from 'contact_wrapper';

class ContactStoreCache extends BaseEmitter {
  _contacts = [];
  _blockContacts = new Set();
  _groupMap = new Map();
  _status = '';

  BATCH_SIZE = 10;

  constructor() {
    super();

    this._traverse();
  }

  get length() {
    return this._contacts.length;
  }

  _getCategoryContacts(contacts, category) {
    return category
      ? contacts.filter(c => c.category && c.category.includes(category))
      : [].concat(contacts);
  }

  /**
   * Access current fetched contacts on the fly.
   */
  get({ category, limit, onBatch = () => {} }) {
    return new Promise(resolve => {
      console.log(
        '[ContactStoreCache] get: _status,category:',
        this._status,
        category
      );
      if ('fetched' === this._status) {
        resolve(this._contacts);
      } else {
        const currentContacts = this._getCategoryContacts(
          this._contacts,
          category
        );

        let batch = this.BATCH_SIZE;
        const startLength = currentContacts.length;
        const fetchingCallback = c => {
          if (
            (category && c.category && c.category.includes(category)) ||
            !category
          ) {
            currentContacts.push(c);
            if (limit && currentContacts.length >= limit) {
              this.off('_fetching', fetchingCallback);
              resolve(this._contacts);
              return;
            }
          }

          if (currentContacts.length === startLength + batch) {
            console.log(
              '[ContactStoreCache]: got batch: current length, batch:',
              currentContacts.length,
              batch
            );
            batch *= 2;
            onBatch({
              currentContacts,
            });
          }
        };
        this.on('_fetching', fetchingCallback);

        const fetchedCallback = () => {
          console.log('[ContactStoreCache] on _fetched:', Date.now());
          resolve(this._contacts);
        };
        this.on('_fetched', fetchedCallback);

        if (category.includes('SIM')) {
          // assuming it's the general case that phone contacts are much more than SIM contacts,
          // using `ContactsManager.find` will be faster than `getAll`
          setTimeout(() => {
            this._find(category).then(contacts => {
              this.off('_fetching', fetchingCallback);
              this.off('_fetched', fetchedCallback);
              resolve(contacts);
            });
          });
        }
      }
    }).then(contacts => {
      contacts = this._getCategoryContacts(contacts, category);
      return limit ? contacts.slice(0, limit) : contacts;
    });
  }

  getFullContacts({ onFetching = () => {} }) {
    return new Promise(resolve => {
      if ('fetched' === this._status) {
        resolve(this._contacts);
      } else {
        this.on('_fetching', contact => {
          onFetching({
            currentContacts: [].concat(this._contacts),
            contact,
          });
        });
        this.on('_fetched', () => {
          resolve(this._contacts);
        });
      }
    }).then(c => [].concat(c));
  }

  /**
   * Fetch all contacts in db and store in memory.
   * This should be done once at startup, afterward we can use the in-memory data.
   * We should listen to the `contactchange` event and update the in-memory data.
   */
  _traverse() {
    const options = {
      sortBy:
        'familyName' === window.localStorage.getItem('sort')
          ? ContactsManager.SortOption.FAMILY_NAME
          : ContactsManager.SortOption.GIVEN_NAME,
      sortOrder: ContactsManager.Order.ASCENDING,
      sortLanguage: navigator.language,
    };

    const request = ContactsManager.getAll(options, 1, false);
    const requestBlock = ContactsManager.getAllBlockedNumbers();
    const requestGroup = ContactsManager.getAllGroups();
    this._status = 'fetching';

    console.time('[ContactStoreCache] fetched');
    return new Promise(resolves => {
      const getNormalContact = () =>
        new Promise(resolve => {
          request.then(cursor => {
            const fetchData = () => {
              cursor
                .next()
                .then(contacts => {
                  if (this.simContactRefresh) {
                    cursor.release();
                  }
                  this._contacts = this._contacts.concat(
                    contacts.map(c => convertContactToLocal(c))
                  );
                  this.emit('_fetching', convertContactToLocal(contacts[0]));
                  fetchData();
                })
                .catch(error => {
                  console.error('traverse error:', error);
                  this._status = 'fetched';
                  this._contacts = sort(this._contacts);
                  this.emit('_fetched');
                  resolve(this._contacts);
                  cursor.release();
                });
            };
            fetchData();
          });
        });

      const getBlockContact = () =>
        new Promise(resolve => {
          requestBlock.then(blockNumbers => {
            if (!blockNumbers.length) {
              return resolve();
            }
            if (blockNumbers.length) {
              this._blockContacts = new Set(blockNumbers);
              resolve();
            }
          });
        });

      const getGroupContact = () =>
        new Promise(resolve => {
          requestGroup.then(groups => {
            if (!groups.length) {
              return resolve();
            }
            if (groups.length) {
              groups.forEach(group => {
                this._groupMap.set(group.id, group);
              });
              resolve();
            }
          });
        });

      ContactsManager.addEventListener(
        ContactsManager.EventMap.SIM_LOADED_EVENT,
        evt => {
          const { remove_count, update_count } = evt;
          if (remove_count || update_count) {
            this.simContactRefresh = true;
            getNormalContact().then(() => {
              this.emit('simLoaded', this._contacts);
            });
          } else {
            this.emit('simLoaded');
          }
        }
      );
      Promise.all([
        getNormalContact(),
        getBlockContact(),
        getGroupContact(),
      ]).then(() => {
        resolves();
      });
    });
  }

  /**
   *  This is used to speed up the fetching process in some cases.
   *  (e.g. fetching few SIM contacts while there are many phone contacts)
   *  We don't save the result in memory currently.
   *  Need to find a good way to cooporate with _contacts.
   */
  _find(category) {
    console.log('[ContactStoreCache] _find category:', category);
    const options = {
      sortBy:
        'familyname' === window.localStorage.getItem('sort')
          ? ContactsManager.SortOption.FAMILY_NAME
          : ContactsManager.SortOption.GIVEN_NAME,
      sortOrder: ContactsManager.Order.ASCENDING,
      filterBy: ContactsManager.FilterByOption.CATEGORY,
      filterOp: ContactsManager.FilterOption.CONTAINS,
      filterValue: category,
    };

    return new Promise(resolve => {
      ContactsManager.find(options).then(result => {
        resolve(sort(result));
        console.timeEnd('[ContactStoreCache] _find');
      });
      console.time('[ContactStoreCache] _find');
    });
  }
}
export default new ContactStoreCache();

export function sort(contacts, language, index) {
  const sortBy = window.localStorage.getItem('sort') || 'givenName';
  console.log('[ContactStoreCache] sort:', contacts.length, sortBy);
  let lang = language || navigator.language;
  const result = [].concat(contacts);
  let option = {};

  // Using strokes sort for 'Traditional Chinese'
  if ('zh-TW' === lang || 'zh-HK' === lang) {
    lang = 'zh-Hant';
    option = { localeMatcher: 'lookup' };
  }
  const collator = new Intl.Collator(lang, option);

  // Todo: For sorting in Simplified Chinese, we use the "Pinyin" rule of
  // Chinese characters, but 'LocaleCompare' doesn't work with polyphonic
  // characters. May need other methods to solve in the future.

  const getValue = contact => {
    let value = contact.name;
    if ('familyName' === sortBy) {
      value = [contact.familyName, contact.givenName, contact.name]
        .join(' ')
        .trim();
    } else {
      value = [contact.givenName, contact.familyName, contact.name]
        .join(' ')
        .trim();
    }
    if (!value) {
      if (contact.tel && contact.tel[0]) {
        value = contact.tel[0].value;
      } else if (contact.email && contact.email[0]) {
        value = contact.email[0].value;
      }
    }

    return value;
  };

  // If we have index, this indicates that we only need to update the order of
  // contact corresponding to the index.
  if (index) {
    const contact = result[index];
    const s = getValue(contact);
    let bInsert = false;
    result.splice(index, 1);

    for (let i = 0; i < result.length; i++) {
      const r = getValue(result[i]).toString();
      if (collator.compare(r, s.toString()) > 0) {
        bInsert = true;
        result.splice(i, 0, contact);
        break;
      }
    }
    if (!bInsert) {
      result.push(contact);
    }
  } else {
    result.sort((a, b) => {
      const x = getValue(a);
      const y = getValue(b);

      let sr;
      if (!x) {
        sr = -1;
      } else if (!y) {
        sr = 1;
      } else {
        sr = collator.compare(x.toString(), y.toString());
      }

      return sr;
    });
  }

  return result;
}
