import Requester from 'hawk-requester';
import Utils from '../contact_utils';

function req({ method, url, authorization = '', params = {} }) {
  console.log('[request] ', method, url, params);
  if (!Utils.isOnLine()) {
    console.error('[requester] no network');
    return Promise.reject(new Error('no network'));
  }

  const requester = new Requester();
  return requester
    .send({
      method,
      url,
      authorization,
      params,
    })
    .catch(e => {
      console.error('[requester] error when making request:', e);
      throw e;
    });
}

export default req;
