import Normalizer from './normalizer';

/** Mapping between contact fields and equivalent vCard fields */
const VCARD_MAP = {
  fax: 'FAX',
  'fax-office': 'FAX,WORK',
  'fax-home': 'FAX,HOME',
  'fax-other': 'FAX,OTHER',
  home: 'HOME',
  mobile: 'CELL',
  pager: 'PAGER',
  personal: 'HOME',
  pref: 'PREF',
  text: 'TEXT',
  textphone: 'TEXTPHONE',
  voice: 'VOICE',
  work: 'WORK',
};

const CRLF = '\r\n';

/** Field list to be skipped when converting to vCard */
const VCARD_SKIP_FIELD = [];
const VCARD_VERSION = '3.0';
const HEADER = `BEGIN:VCARD${CRLF}VERSION:${VCARD_VERSION}${CRLF}`;
const FOOTER = `END:VCARD${CRLF}`;

/**
 * ContactToVcard provides the functionality necessary to export from
 * MozContacts to vCard 3.0 (https://www.ietf.org/rfc/rfc2426.txt). The reason
 * to choose the 3.0 standard instead of the 4.0 one is that some systems
 * most notoriously Android 4.x don't seem to be able to import vCard 4.0.
 */

const Utils = {
  // Get a DeviceStorage object for the specified kind of storage and, if it
  // is available, and if the specified number of bytes of storage space are
  // free then asynchronously pass the DeviceStorage object to the success
  // callback. Otherwise, invoke the error callback, if one is specified. If
  // the error callback is called because device storage is not available, the
  // argument will be a DeviceStorage status string like 'unavailable' or
  // 'shared'. If the error callback is called because there is not enough
  // storage space, the argument will be the number of bytes that are available.
  getStorageIfAvailable(kind, size, internal) {
    return new Promise((resolve, reject) => {
      const storages = navigator.b2g.getDeviceStorages(kind);
      let storage = null;
      storages.some(devicestorage => {
        if (internal) {
          storage = devicestorage;
          return true;
        }
        if (
          'sdcard' !== devicestorage.storageName &&
          devicestorage.canBeMounted
        ) {
          storage = devicestorage;
          return true;
        }
        return false;
      });
      if (!storage) {
        reject('nosdcard');
        return;
      }
      storage.available().onsuccess = e => {
        if (e.target.result !== 'available') {
          reject(e.target.result);
        } else {
          storage.freeSpace().onsuccess = evt => {
            if (evt.target.result < size) {
              reject(evt.target.result);
            } else {
              resolve(storage);
            }
          };
        }
      };
    });
  },

  // This utility function helps avoid overwriting existing files.
  // If no file with the specified name exists in the specified storage, pass
  // the name to the callback. Otherwise, add a version number to the name
  // and try again. Once a name is found that does not already exist, pass it
  // to the callback. If the initial name 'base.ext' does not exist, then new
  // names of the form 'base_n.ext', where n is a number are tried.
  getUnusedFilename(storage, name) {
    return new Promise(resolve => {
      const getreq = storage.get(name);
      getreq.onerror = () => {
        // We get this error if the file does not already exist, and that
        // is what we want
        resolve(name);
      };
      getreq.onsuccess = () => {
        let version = 0;
        let p = name.lastIndexOf('/');
        const dir = name.substring(0, p + 1);
        const file = name.substring(p + 1);
        p = file.lastIndexOf('.');
        if (-1 === p) {
          p = file.length;
        }
        const ext = file.substring(p);
        let base = file.substring(0, p);
        const parts = base.match(/^(.*)_(\d{1,2})$/);
        if (parts) {
          base = parts[1];
          version = parseInt(parts[2], 10);
        }

        const newname = `${dir}${base}_${version + 1 + ext}`;
        resolve(this.getUnusedFilename(storage, newname));
      };
    });
  },

  getStorage(fileName, blob, internal, append) {
    return new Promise((resolve, reject) => {
      return this.getStorageIfAvailable('sdcard', blob.size, internal).then(
        storage => {
          if (append) {
            return storage.get(fileName).then(() => {
              resolve({
                storage,
                name: fileName,
                blob,
              });
            });
          }
          // Get the final version of the proposed file name
          return this.getUnusedFilename(storage, fileName).then(name => {
            resolve({
              storage,
              name,
              blob,
            });
          });
        },
        err => {
          reject(err);
        }
      );
    });
  },

  blobToBase64: function blobToBase64(blob) {
    return new Promise(resolve => {
      const reader = new FileReader();

      reader.onload = () => {
        const dataUrl = reader.result;
        const base64 = dataUrl.split(',')[1];
        resolve(base64);
      };

      reader.readAsDataURL(blob);
    });
  },

  uint8arrayToBase64(u8Arr) {
    const CHUNK_SIZE = 0x8000; // arbitrary number
    let index = 0;
    const length = u8Arr.length;
    let result = '';
    let slice;
    while (index < length) {
      slice = u8Arr.subarray(index, Math.min(index + CHUNK_SIZE, length));
      result += String.fromCharCode.apply(null, slice);
      index += CHUNK_SIZE;
    }
    return btoa(result);
  },

  ISODateString: function ISODateString(d) {
    if ('string' === typeof d) {
      d = new Date(d);
    }

    const str = d.toISOString();

    // Remove the milliseconds field
    return `${str.slice(0, str.indexOf('.'))}Z`;
  },

  /**
   * Given an array with contact fields (usually containing only one field),
   * returns the equivalent vcard field
   *
   * @param {Array} sourceField source field from a MozContact
   * @param {String} vcardField vCard field name
   * @return {Array} Array of vCard string entries
   */
  fromContactField: function fromContactField(sourceField, vcardField) {
    if (!sourceField || !sourceField.length) {
      return [];
    }

    // Goes to the entries in the given field (usually only one but potentially
    // more) and transforms them into string-based, vCard ones.
    return sourceField.map(field => {
      let str = vcardField;
      /**
       * If the field doesn't have an equivalent in vcard standard.
       * Incompatible fields are stored in `VCARD_SKIP_FIELD`.
       *
       * @type {boolean}
       */
      let skipField = false;
      let types = [];

      // Checks existing types and converts them to vcard types if necessary
      // and fill `types` array with the final types.
      if (Array.isArray(field.type)) {
        const fieldType = field.type.map(aType => {
          let out = '';
          if (aType) {
            const originalType = aType.trim();
            aType = aType.trim().toLowerCase();
            if (VCARD_SKIP_FIELD.indexOf(aType) !== -1) {
              skipField = true;
            }
            out = VCARD_MAP[aType] || originalType;
          }
          return out;
        });

        types = types.concat(fieldType);
      }

      if (skipField) {
        return '';
      }

      if (field.pref && true === field.pref) {
        types.push('PREF');
      }

      if (types.length) {
        str += `;TYPE=${types.join(',')}`;
      }

      return `${str}:${field.value || ''}`;
    });
  },

  fromStringArray: function fromStringArray(sourceField, vcardField) {
    if (!sourceField) {
      return '';
    }

    return `${vcardField}:${sourceField.join(',')}`;
  },

  joinFields: function joinFields(fields) {
    return fields
      .filter(f => {
        return !!f;
      })
      .join(CRLF);
  },

  /**
   * Convenience function that converts an array of contacts into a text/vcard
   * blob. The blob is passed to the callback once the conversion is done.
   *
   * @param {Array} contacts An array of mozContact objects.
   * @param {Function} callback A function invoked with the generated blob.
   */
  ContactToVcardBlob: function ContactToVcardBlob(contacts, options) {
    return new Promise(resolve => {
      const targetType = (options && options.type) || 'text/vcard';

      let str = '';

      const req = this.ContactToVcard(contacts);
      req.onbatch = vcards => {
        str += vcards;
      };
      req.onsuccess = () => {
        resolve(
          new Blob([str], {
            type: targetType,
          })
        );
      };
    });
  },

  /**
   * Converts an array of contacts to a string of vCards. The conversion is
   * done in batches. For every batch the append callback is invoked with a
   * string of vCards and the number of contacts in the batch. Once all
   * contacts have been processed the success callback is invoked.
   *
   * @param {Array} contactsInput An array of mozContact objects.
   * @param {Number} options.batchSize An optional parameter specifying the maximum
   *        number of characters that should be added to the output string
   *        before invoking the append callback. If this paramter is not
   *        provided a default value of 1MiB will be used instead.
   * @return {Function} req.onbatch A function taking two parameters, the first one
   *        will be passed a string of vCards and the second an integer
   *        representing the number of contacts in the string.
   * @return {Function} req.onprogress Will be invoked everytime when each contacts is processed
   * @return {Function} req.onsuccess A function with no parameters that will be
   *        invoked once all the contacts have been processed.
   */
  ContactToVcard(contactsInput, options = {}) {
    const contacts = Array.from(contactsInput);
    let canceled = false;

    const batchSize = options.batchSize || 1024 * 1024;

    const req = {
      cancel: () => {
        canceled = true;
      },
      onsuccess: () => {},
      onbatch: () => {},
      onprogress: () => {},
    };

    let batchedCards = 0;
    let batchedString = '';
    /**
     * Convert ths contacts the vcard string recursively.
     * Execute user-defined event handlers: onsuccess, onbatch, onprogress
     */
    (function _doNext() {
      if (canceled) {
        return;
      }
      _contactToVcard(contacts.pop()).then(vcard => {
        if (canceled) {
          return;
        }

        if (vcard.length > 0) {
          batchedString += HEADER + vcard + CRLF + FOOTER;
        }

        /* Invoke the user-provided callback if we've filled the current batch or
         * if we don't have more contacts to process. */
        if (batchedString.length > batchSize || 0 === contacts.length) {
          req.onbatch(batchedString, batchedCards, 0 === contacts.length);
          batchedCards = 0;
          batchedString = '';
        }
        batchedCards++;

        req.onprogress(contactsInput.length - contacts.length);

        if (contacts.length > 0) {
          setTimeout(() => {
            _doNext();
          });
        } else {
          req.onsuccess();
        }
      });
    })();

    return req;
  },

  // Generates a name for the contact returned as a vcard
  getVcardFilename: function getVcardFilename(theContact) {
    let out = '';

    const givenName =
      Array.isArray(theContact.givenName) && theContact.givenName[0];
    const familyName =
      Array.isArray(theContact.familyName) && theContact.familyName[0];

    if (givenName) {
      out = givenName;
    }

    if (familyName) {
      if (out) {
        out += '_';
      }
      out += familyName;
    }

    if (theContact.category && theContact.category.includes('SIM')) {
      out = Array.isArray(theContact.name) && theContact.name[0];
    }

    out = out || (Array.isArray(theContact.name) && theContact.name[0]);

    out = out || (Array.isArray(theContact.org) && theContact.org[0]);

    out =
      out ||
      (Array.isArray(theContact.tel) &&
        theContact.tel[0] &&
        theContact.tel[0].value);

    out =
      out ||
      (Array.isArray(theContact.email) &&
        theContact.email[0] &&
        theContact.email[0].value);

    out = out || window.api.l10n.get('noName');

    out = Normalizer.toAscii(out).replace(/[\s#&?\$]/g, '');

    return `${out}.vcf`;
  },
};

/**
 * Convert a Contact to vCard string
 * @param {Object} contacts A Contact object.
 * @return {Promise} Will be resolved with the string of the vCard
 */
function _contactToVcard(ct) {
  /*
   * N TYPE
   * The structured type value corresponds, in
   * sequence, to the Family Name, Given Name, Additional Names, Honorific
   * Prefixes, and Honorific Suffixes. The text components are separated
   * by the SEMI-COLON character (ASCII decimal 59). Individual text
   * components can include multiple text values (e.g., multiple
   * Additional Names) separated by the COMMA character (ASCII decimal
   * 44). This type is based on the semantics of the X.520 individual name
   * attributes. The property MUST be present in the vCard object.
   *
   */
  const n = `N:${[
    // eslint-disable-line
    ct.familyName,
    ct.givenName,
    ct.additionalName,
    ct.honorificPrefix,
    ct.honorificSuffix,
  ]
    .map(f => {
      f = f || [''];
      return f.join(',');
    })
    .join(';')}`;

  const allFields = [
    n,
    Utils.fromStringArray(ct.name, 'FN'),
    Utils.fromStringArray(ct.nickname, 'NICKNAME'),
    Utils.fromStringArray(ct.category, 'CATEGORIES'),
    Utils.fromStringArray(ct.org, 'ORG'),
    Utils.fromStringArray(ct.jobTitle, 'TITLE'),
    Utils.fromStringArray(ct.note, 'NOTE'),
    Utils.fromStringArray(ct.key, 'KEY'),
  ];

  if (ct.bday) {
    allFields.push(`BDAY:${Utils.ISODateString(ct.bday)}`);
  }

  allFields.push(Utils.fromContactField(ct.email, 'EMAIL').join(CRLF));
  allFields.push(Utils.fromContactField(ct.url, 'URL').join(CRLF));
  allFields.push(Utils.fromContactField(ct.tel, 'TEL').join(CRLF));

  const adrs = Utils.fromContactField(ct.adr, 'ADR');
  allFields.push(
    adrs
      .map((adrStr, i) => {
        const orig = ct.adr[i];
        return (
          adrStr +
          [
            '',
            '',
            orig.streetAddress || '',
            orig.locality || '',
            orig.region || '',
            orig.postalCode || '',
            orig.countryName || '',
          ].join(';')
        );
      })
      .join(CRLF)
  );

  /**
   * PHOTO TYPE
   * The encoding MUST be reset to "b" using the ENCODING
   * parameter in order to specify inline, encoded binary data. If the
   * value is referenced by a URI value, then the default encoding of 8bit
   * is used and no explicit ENCODING parameter is needed.

   * Type value: A single value. The default is binary value. It can also
   * be reset to uri value. The uri value can be used to specify a value
   * outside of this MIME entity.

   * Type special notes: The type can include the type parameter "TYPE" to
   * specify the graphic image format type. The TYPE parameter values MUST
   * be one of the IANA registered image formats or a non-standard image
   * format.
  */
  return new Promise(resolve => {
    if (ct.photoBlob && ct.photoBlob.length) {
      const photoMeta = ['PHOTO', 'ENCODING=b'];
      const u8array = ct.photoBlob;
      const b64encoded = Utils.uint8arrayToBase64(u8array);
      if (ct.photoType) {
        photoMeta.push(`TYPE=${ct.photoType}`);
      }
      allFields.push(photoMeta.join(';') + ':' + b64encoded); // eslint-disable-line
      resolve(Utils.joinFields(allFields));
    } else {
      resolve(Utils.joinFields(allFields));
    }
  });
}

export default Utils;
