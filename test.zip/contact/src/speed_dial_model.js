import ContactStore from './contact_store';

export default class SpeedDialModel {
  // refer to backend speedDial object:
  // {
  //  speedDial: number,
  //  contactId: string,
  //  tel: string
  // }

  constructor({ dial = -1, contact = null, telIndex = 0 }) {
    this.dial = dial;
    this.contact = contact;
    this.telIndex = telIndex;
    this.originTel = '';
  }

  updateByRawData(config) {
    if (!config.contactId) {
      this.contact = {
        id: '',
        name: [''],
        tel: [{ value: config.tel }],
      };
      this.telIndex = 0;
      return this;
    }
    return ContactStore.getContact(config.contactId).then(contact => {
      if (!contact || !contact.tel) {
        console.error('[SpeedDialModel] updateByRaw: can not find contact');
        return;
      }
      let telIndex;
      if (1 === contact.tel.length) {
        telIndex = 0;
      } else {
        telIndex = contact.tel.map(t => t.value).indexOf(config.tel);
      }
      if (telIndex < 0) {
        console.error(
          '[SpeedDialModel] updateByRaw: contact does not have the tel'
        );
        return;
      }
      this.contact = contact;
      this.originTel = config.tel;
      this.telIndex = telIndex;
      return this;
    });
  }

  sync() {
    return ContactsManager.getSpeedDials().then(configs => {
      const config = configs.filter(c => +c.dialKey === this.dial)[0];
      if (!config) {
        this.contact = null;
        this.telIndex = 0;
        return Promise.resolve(this);
      }
      return this.updateByRawData(config);
    });
  }

  get tel() {
    return this.contact && this.contact.tel && this.contact.tel[this.telIndex]
      ? this.contact.tel[this.telIndex].value
      : null;
  }
}
