import BaseModule from 'base-module';
import SdcardManager from 'vendor/sdcard-manager';
import VcardReader, { MAX_BLOB_SIZE } from './vcard_reader';

class SdcardStore extends BaseModule {
  hasFilter = false;
  import() {
    return new Promise((resolve, reject) => {
      SdcardManager.retrieveFiles(
        [
          'text/vcard',
          'text/x-vcard',
          'text/directory;profile=vCard',
          'text/directory',
        ],
        ['vcf', 'vcard']
      )
        .then(fileArray => {
          if (fileArray.length) {
            const fileArrayFilter = fileArray.filter(
              file => file.size < MAX_BLOB_SIZE
            );
            this.hasFilter = fileArrayFilter.length < fileArray.length;
            SdcardManager.getTextFromFiles(
              this.hasFilter ? fileArrayFilter : fileArray,
              '',
              this.onFiles.bind(this)
            );
          } else {
            reject('novCardFiles');
          }

          this.resolve = resolve;
          this.reject = reject;
        })
        .catch(err => {
          reject(err);
        });
    });
  }

  onFiles(err, text) {
    if (err) {
      this.reject(err);
      return;
    }

    const importer = new VcardReader(text);
    if (!text || !importer) {
      this.reject('No contacts were found.');
      return;
    }

    importer.import();
    this.resolve(importer);
  }
}

const sdcardStore = new SdcardStore();

export default sdcardStore;
