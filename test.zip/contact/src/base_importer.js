import BaseModule from 'base-module';
import Service from 'service';
import ImportStatusData from './import_status_data';
import ContactStore from './contact_store';

export default class BaseImporter extends BaseModule {
  imported = 0;
  total = 0;
  /**
   * The source of contacts to store as key in ImportStatusData
   * @type {String}
   */
  type = '';
  aborted = false;

  constructor() {
    super();
    ContactStore.setEventEmittingState(false);
  }

  /**
   * This should be override by importers.
   * @return {Object} A promise
   */
  import() {
    return new Promise(() => {
      this.wakeLock = navigator.b2g.requestWakeLock('cpu');
      return this._import();
    });
  }

  _import() {}

  continue() {
    // Need to override if necessary
  }

  pause() {
    this.debug('pause:');
    this.paused = true;
  }

  resume() {
    this.paused = false;
    this.continue();
  }

  cancel() {
    this.importing = false;
    // XXX: Better way to notify CS.
    ContactStore.setEventEmittingState(true);
    this.aborted = true;
    if (this.imported > 0) {
      ImportStatusData.setTimestamp(this.type);
    }
    this.emit('aborted');
  }

  done = () => {
    // XXX: Better way to notify CS.
    ContactStore.setEventEmittingState(true);
    this.finished = true;
    setTimeout(() => {
      this.emit('finished', this);
    });
    if (this.imported > 0) {
      ImportStatusData.setTimestamp(this.type);
    }
    this.wakeLock && this.wakeLock.unlock();
    Service.request('List:reload');
    if (this.imported === this.total || this.aborted) {
      this._showInfo();
    }
  };

  save(contact) {
    this.debug('save: name:', contact.name);

    if (this.aborted) {
      if (!this.finished) {
        this.done();
      }
      return;
    }

    ContactStore.createOrUpdate(contact, false, 'import').then(result => {
      if (result.error) {
        this._showInfo(result).then(this.done);
      } else {
        this.imported++;
        this.emit('imported', contact.name);
        if (this.imported === this.total || this.aborted) {
          this.done();
        } else if (!ContactStore.fullDisk) {
          this.continue();
        } else {
          const error = { error: 'fullDiskSpace' };
          this._showInfo(error).then(this.continue.bind(this), this.done);
        }
      }
    });
  }

  /**
   * Either show toast or dialog to inform user the importing result
   */
  _showInfo(result) {
    const _ = window.api.l10n.get;
    const importedMessage = _('contact-imported2', {
      imported: this.imported,
    });

    if (result && result.error) {
      ContactStore.updateSort(true);
      if ('contacts-limit-exceeded' === result.error) {
        Service.request('ToastManager:show', {
          text: result.message,
        });
      }

      const fullDisk = 'fullDiskSpace' === result.error;
      const suffix = fullDisk ? 'disk-full' : 'unknown';
      const content = [
        _(`contact-import-error-${suffix}`),
        importedMessage,
      ].join('\n\n');

      return new Promise((resolve, reject) => {
        if (fullDisk) {
          Service.request('showDialog', {
            header: _('phone-storage-full'),
            type: 'confirm',
            content,
            translated: true,
            ok: 'settings',
            onOk: () => {
              const activity = new WebActivity('configure', {
                target: 'device',
                section: 'mediaStorage',
              });
              activity.start().then(
                () => {
                  if (ContactStore.fullDisk) {
                    reject();
                  }
                  resolve();
                },
                () => {
                  console.warn(
                    'Configure activity error:',
                    activity.error.name
                  );
                  reject();
                }
              );
            },
            onCancel: reject,
            onBack: reject,
          });
        } else {
          Service.request('showDialog', {
            header: _('import-contact-failed'),
            type: 'alert',
            content,
            translated: true,
            onOk: resolve,
            onBack: resolve,
          });
        }
      });
    }
    Service.request('ToastManager:show', {
      text: this.aborted
        ? [_('import-process-cancel'), importedMessage].join('\n')
        : importedMessage,
    });
    return Promise.resolve();
  }
}
