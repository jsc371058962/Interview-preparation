import React from 'react';
import ReactDOM from 'react-dom';
import Service from 'service';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import ContactsRemover from 'contacts_remover';

export default class DeleteContactsView extends BaseComponent {
  name = 'DeleteContactsView';

  constructor(props) {
    super(props);

    this._remover = new ContactsRemover(this.props.ids);
    this.state = {
      progress: 0,
      total: this.props.ids.length,
    };
  }

  componentDidMount() {
    this.element = ReactDOM.findDOMNode(this);
    this._softKey = SoftKeyManager.create(this.element, {
      left: 'cancel',
      center: '',
      right: '',
    });

    this._remover.on('finished', processed => {
      Service.request('ToastManager:show', {
        text: window.api.l10n.get('contact-deleted', { n: processed }),
      });
      Service.request('back');
    });
    this._remover.on('processed', processed => {
      this.setState(
        {
          progress: processed,
        },
        () => {
          if (this._isClearing) {
            this._softKey.update({
              left: '',
            });
          }
        }
      );
    });
    this._remover.start();
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  get _isClearing() {
    return this.state.progress < 0;
  }

  onKeyDown(e) {
    switch (e.key) {
      case 'SoftLeft':
        e.preventDefault();
        e.stopPropagation();
        if (!this._isClearing) {
          this._remover && this._remover.cancel();
          Service.request('back');
        }
        break;
      case 'EndCall':
      case 'Backspace':
        // XXX: Workaround Bug 26553, if killing app during removing lots of contact, db may break.
        e.preventDefault();
        e.stopPropagation();
        break;
      default:
        break;
    }
  }

  onKeyUp(e) {
    if ('EndCall' === e.key || 'Backspace' === e.key) {
      e.preventDefault();
      e.stopPropagation();
    }
  }

  render() {
    let progressDOM = null;
    let divider = null;
    if (this.state.total) {
      if (this._isClearing) {
        progressDOM = (
          <div className="progress" data-infinite="true">
            <div className="progress-active" />
          </div>
        );
      } else {
        const progress = 100 * (this.state.progress / this.state.total);
        const activeStyle = { width: `${progress}%` };
        const inactiveStyle = { width: `calc(100% - ${progress}% - 0.3rem)` };
        progressDOM = (
          <div className="progress">
            <div className="progress-active" style={activeStyle} />
            <div className="progress-inactive" style={inactiveStyle} />
          </div>
        );
        divider = (
          <div className="secondary">
            {this.state.progress}/{this.state.total}
          </div>
        );
      }
    }
    return (
      <div
        className="delete-contact-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onKeyUp={e => this.onKeyUp(e)}
      >
        <div
          className="header h1"
          ref="header"
          data-l10n-id="DeletingContacts"
        />
        <div className="body">
          <div className="list-item">
            <div className="content">
              <div
                className="primary"
                data-l10n-id="DeletingContactsProgressing"
              />
              {divider}
              {progressDOM}
            </div>
          </div>
        </div>
      </div>
    );
  }
}
