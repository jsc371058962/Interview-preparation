import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import SdcardManager from 'vendor/sdcard-manager';
import Utils from 'contact_utils';
import ImportStatusData from './import_status_data';

export default class ImportView extends BaseComponent {
  FOCUS_SELECTOR = '.list-item.navigable';

  constructor(props) {
    super(props);
    this.state = {
      sd: null,
      sim: null,
      gmail: null,
      live: null,
      'sim-0': null,
      'sim-1': null,
      isOnLine: Utils.isOnLine(),
      isWifiCertified: true,
    };
  }

  componentDidMount() {
    window.iv = this;
    const config = this.getConfig();
    this.element = ReactDOM.findDOMNode(this);
    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element
    );
    this._softKey = SoftKeyManager.create(this.element, config);
    this.isd = ImportStatusData;
    ImportStatusData.getTimestamp('gmail').then(time => {
      this.setState({
        gmail: time,
      });
    });

    ImportStatusData.getTimestamp('live').then(time => {
      this.setState({
        live: time,
      });
    });

    ImportStatusData.getTimestamp('sim-0').then(time => {
      this.setState({
        'sim-0': time,
      });
    });

    ImportStatusData.getTimestamp('sd').then(time => {
      this.setState({
        sd: time,
      });
    });

    ImportStatusData.on('importchanged', (type, time) => {
      const _config = {};
      _config[type] = time;
      this.setState(_config);
    });

    DeviceCapabilityManager.get('device.wifi.certified').then(value => {
      this.setState({
        isWifiCertified: value,
      });
    });

    Utils.handleNetworkEvent.call(this, 'add');
  }

  handleNetwork = evt => {
    if (navigator.connection) {
      this.setState({ isOnLine: evt.detail });
    } else {
      this.setState({ isOnLine: navigator.onLine });
    }
  };

  componentWillUnmount() {
    this._softKey.destroy();
    Utils.handleNetworkEvent.call(this, 'remove');
  }

  getConfig() {
    const config = {
      left: 'cancel',
      center: '',
    };

    if (
      !document.activeElement.classList.contains('disabled') &&
      document.activeElement.dataset.target
    ) {
      config.center = 'select';
    }
    return config;
  }

  updateSoftKeys() {
    this._softKey.update(this.getConfig());
  }

  onKeyDown(evt) {
    switch (evt.key) {
      case 'Enter':
        if (document.activeElement.classList.contains('disabled')) {
          break;
        }
        switch (document.activeElement.dataset.target) {
          case 'gmail':
          case 'live':
            Service.request(
              'push',
              `/import/service/${document.activeElement.dataset.target}`
            );
            break;
          case 'sd':
            Service.request('popup', '/import/sdcard');
            break;
          default:
            break;
        }
        break;
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('back');
        break;
      case 'SoftLeft':
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('back');
        break;
      default:
        break;
    }
  }

  prettyDate(time) {
    let date;
    if (window.api.l10n) {
      date = window.api.l10n.DateTimeFormat().fromNow(time, true, 86400 * 2);
    } else {
      date = time.toLocaleFormat();
    }
    return date;
  }

  render() {
    const sddisabled = !SdcardManager.isAvailable();

    const ConnectToImport = () => (
      <div className="list-item navigable" tabIndex="-1" data-multi-line="true">
        <div className="content">
          <div
            className="primary"
            data-l10n-id={`connect-network-${
              this.state.isWifiCertified ? 'wifi' : 'wlan'
            }-to-import`}
          />
        </div>
      </div>
    );

    return (
      <div
        id="setting-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onFocus={() => this.updateSoftKeys()}
      >
        <div className="header h1" data-l10n-id="import-contacts" />
        <div className="body">
          <div
            className={`list-item navigable ${sddisabled ? 'disabled' : ''}`}
            tabIndex="-1"
            data-target="sd"
            data-multi-line="true"
          >
            <div className="content">
              <div className="primary" data-l10n-id="sdcard" />
              <div className="secondary">
                {sddisabled ? (
                  <span data-l10n-id="noSdcardMsg" /> // eslint-disable-line
                ) : this.state.sd ? (
                  <div>
                    <span data-l10n-id="imported" />{' '}
                    <time>{this.prettyDate(this.state.sd)}</time>
                  </div>
                ) : (
                  <span data-l10n-id="not-imported" />
                )}
              </div>
            </div>
          </div>
          <div
            className={`list-item navigable ${
              !this.state.isOnLine ? 'disabled' : ''
            }`}
            tabIndex="-1"
            data-target="gmail"
            data-multi-line="true"
          >
            <div className="content">
              <div className="primary">Gmail</div>
              <div className="secondary">
                {this.state.gmail ? (
                  <div>
                    <span data-l10n-id="imported" />{' '}
                    <time>{this.prettyDate(this.state.gmail)}</time>
                  </div>
                ) : (
                  <span data-l10n-id="not-imported" />
                )}
              </div>
            </div>
          </div>
          <div
            className={`list-item navigable ${
              !this.state.isOnLine ? 'disabled' : ''
            }`}
            tabIndex="-1"
            data-target="live"
            data-multi-line="true"
          >
            <div className="content">
              <div className="primary">Outlook</div>
              <div className="secondary">
                {this.state.live ? (
                  <div>
                    <span data-l10n-id="imported" />{' '}
                    <time>{this.prettyDate(this.state.live)}</time>
                  </div>
                ) : (
                  <span data-l10n-id="not-imported" />
                )}
              </div>
            </div>
          </div>
          {!this.state.isOnLine ? <ConnectToImport /> : null}
        </div>
      </div>
    );
  }
}
