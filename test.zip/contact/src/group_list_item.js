import React from 'react';
import BaseComponent from 'base-component';

export default class GroupListItem extends BaseComponent {
  render() {
    const { id, name } = this.props.groupItem;
    return (
      <div
        className="list-item navigable"
        tabIndex="-1"
        data-id={id}
        data-name={name}
      >
        <div className="content">
          <div className="primary">
            <span>{name}</span>
          </div>
        </div>
        <i className="icon" data-icon="forward" role="presentation" />
      </div>
    );
  }
}
