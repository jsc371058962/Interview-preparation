import React from 'react';
import BaseComponent from 'base-component';
import Utils from './contact_utils';

export default class SpeedDialListItem extends BaseComponent {
  render() {
    const item = this.props.speeddial;
    const labelId = `speeddial-item-label-${Date.now()}`;
    const _ = window.api.l10n.get;
    const icon = (
      <a
        aria-describedby={labelId}
        className="icon speed-dial-icon"
        role="presentation"
      >
        {item.dial}
      </a>
    );
    const cls = '';
    let name = _('empty');
    if (item.voicemail) {
      name = _('voice-mail');
    } else if (item.contact) {
      if (item.contact.id) {
        name = Utils.hasName(item.contact)
          ? item.contact.name[0]
          : _('no-name');
      } else {
        name = item.contact.name[0];
      }
    }
    return (
      <div
        className={`contact list-item ${cls}`}
        tabIndex="-1"
        data-id={item.contact && item.contact.id}
        data-dial={item.dial}
        data-tel={item.tel}
        data-voicemail={item.voicemail}
        data-name={name}
      >
        {icon}
        <div className="content">
          <div className="primary" id={labelId}>
            <a href={`/contacts/${item.contact && item.contact.id}`}>{name}</a>
          </div>
          {item.tel && !item.voicemail ? (
            <div className="secondary number">{item.tel}</div>
          ) : null}
        </div>
        {Utils.isSIMContact(item.contact) ? (
          <i data-icon="sim" className="icon" />
        ) : null}
      </div>
    );
  }
}
