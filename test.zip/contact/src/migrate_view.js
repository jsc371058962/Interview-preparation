import React from 'react';
import ReactDOM from 'react-dom';
import Service from 'service';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import ContactStore from './contact_store';
import ContactMigrator from './contact_migrator';

export default class MigrateView extends BaseComponent {
  name = 'MigrateView';
  DEBUG = false;

  constructor(props) {
    super(props);
    this.state = {
      progress: 0,
      total: 0,
      type: props.isMove ? 'move' : 'copy',
    };
  }

  componentDidMount() {
    const config = {
      left: 'cancel',
      center: '',
    };
    window.miv = this;
    this.migrate();
    this.element = ReactDOM.findDOMNode(this);
    this._softKey = SoftKeyManager.create(this.element, config);
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  migrate() {
    this.debug('to migrate ids:', this.props.ids);
    const contacts = this.props.ids.map(id => {
      return ContactStore.contactMap.get(id);
    });
    this.migrator = new ContactMigrator(
      this.props.target,
      contacts,
      this.props.isMove
    );

    this.migrator.on('migrated', () => {
      this.setState({
        progress: this.migrator.migrated,
        total: this.migrator.total,
      });
    });
    this.migrator.on('finished', () => {
      // XXX: Workaround done will be fired twice.
      if (!this.element.contains(document.activeElement)) {
        return;
      }
      if (this.migrator.error) {
        const _ = window.api.l10n.get;
        const content = `${this.migrator.error.message}\n${_(
          `contact-${this.state.type}-to-${this.migrator.targetCode}`,
          {
            migrated: this.migrator.migrated,
          }
        )}`;
        // finish with error
        Service.request('showDialog', {
          header: _(`${this.state.type}-contact-failed`),
          type: 'alert',
          content,
          translated: true,
          onOk: () => {
            Service.request('back');
          },
          onBack: () => {
            Service.request('back');
          },
        });
        return;
      }
      if (this.state.total <= 2) {
        // too quick.
        setTimeout(() => {
          Service.request('back');
        }, 500);
      } else {
        Service.request('back');
      }
    });
    this.setState({
      total: contacts.length,
    });

    setTimeout(() => {
      // XXX: Prevent the export too fast.
      this.migrator.migrate();
    }, 500);
  }

  onKeyDown(e) {
    switch (e.key) {
      case 'SoftLeft':
      case 'Backspace':
      case 'EndCall':
        e.preventDefault();
        e.stopPropagation();
        this.migrator && this.migrator.cancel();
        Service.request('back');
        break;
      default:
        break;
    }
  }

  render() {
    let progressDOM = null;
    let divider = null;
    let migrateStatus = null;
    const progress = 100 * (this.state.progress / this.state.total);
    const activeStyle = { width: `${progress}%` };
    const inactiveStyle = { width: `calc(100% - ${progress}% - 0.3rem)` };
    progressDOM = (
      <div className="progress">
        <div className="progress-active" style={activeStyle} />
        <div className="progress-inactive" style={inactiveStyle} />
      </div>
    );
    divider = (
      <div className="secondary">
        {this.state.progress}/{this.state.total}
      </div>
    );
    migrateStatus = (
      <div
        className="primary"
        data-l10n-id={`${this.state.type}-contacts-progressing`}
      />
    );
    return (
      <div
        className="migrate-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
      >
        <div
          className="header h1"
          ref="header"
          data-l10n-id={`${this.state.type}-contacts`}
        />
        <div className="body">
          <div className="list-item">
            <div className="content">
              {migrateStatus}
              {divider}
              {progressDOM}
            </div>
          </div>
        </div>
      </div>
    );
  }
}
