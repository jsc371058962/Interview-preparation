import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import ContactList from 'components/contact_list';
import ContactStore from './contact_store';

export default class FavoriteList extends BaseComponent {
  FOCUS_SELECTOR = '.list-item';

  constructor(props) {
    super(props);
    this.state = {
      contacts: ContactStore.getFavorites(),
    };
    this.store = ContactStore;
  }

  updateSoftKeys() {
    const config = {};
    config.center = 'select';
    config.right = 'options';
    this._softKey.update(config);
  }

  componentDidMount() {
    const config = {
      center: 'select',
      right: 'options',
    };
    window.flist = this;
    this.element = ReactDOM.findDOMNode(this);
    this._softKey = SoftKeyManager.create(this.element, config);

    this.onContactChanged = () => {
      this.setState({
        contacts: ContactStore.getFavorites(),
      });
    };

    ContactStore.on('changed', this.onContactChanged);

    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element
    );
  }

  componentWillUnmount() {
    this._softKey.destroy();
    ContactStore.off('changed', this.onContactChanged);
  }

  onKeyDown(evt) {
    Service.request('onContactKeyDown', evt);
  }

  componentDidUpdate() {
    this.updateSoftKeys();
  }

  onFocus() {
    this.updateSoftKeys();
    if (0 === this.state.contacts.length) {
      Service.request('back');
    } else {
      Service.request('ensureDialog');
    }
  }

  render() {
    return (
      <div
        className="favorite-view list-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onFocus={e => this.onFocus(e)}
      >
        <div className="header h1" data-l10n-id="favorite-contacts" />
        <div className="body">
          <ContactList contacts={this.state.contacts} />
        </div>
      </div>
    );
  }
}
