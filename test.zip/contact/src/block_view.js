import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import ContactStore from './contact_store';
import BlockNumberList from './block_number_list_item';

export default class BlockView extends BaseComponent {
  FOCUS_SELECTOR = '.list-item.navigable';
  change_item = false;

  constructor(props) {
    super(props);
    this.state = {
      block: ContactStore.fullBlockContacts,
    };
  }

  componentDidMount() {
    window.bv = this;
    this.element = ReactDOM.findDOMNode(this);
    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element
    );
    this.updateSoftKeys();

    ContactsManager.addEventListener(
      ContactsManager.EventMap.BLOCKED_NUMBER_CHANGE,
      this._handle_blockednumberchange
    );
  }

  componentDidUpdate() {
    this.element.focus();
    if (this.change_item) {
      this.change_item = false;
      const elementList = this.element.querySelectorAll(this.FOCUS_SELECTOR);
      const element = elementList[elementList.length - 1];
      this.navigator.setFocus(element);
    }
  }

  _handle_blockednumberchange = () => {
    this.setState({
      block: ContactStore.fullBlockContacts,
    });
  };

  componentWillUnmount() {
    ContactsManager.removeEventListener(
      ContactsManager.EventMap.BLOCKED_NUMBER_CHANGE,
      this._handle_blockednumberchange
    );
    this._softKey.destroy();
  }

  updateSoftKeys() {
    let config = {
      left: 'add',
    };

    if (this.state.block.size > 0) {
      config = {
        left: 'add',
        right: 'unblock',
      };
    }

    this._softKey = SoftKeyManager.create(this.element, config);
  }

  onKeyDown(evt) {
    switch (evt.key) {
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('back');
        break;
      case 'SoftRight':
        evt.preventDefault();
        evt.stopPropagation();
        const blockedNumber = document.activeElement
          .querySelector('.primary')
          .getAttribute('data-name');
        ContactStore.removeBlockContact(blockedNumber).then(() => {
          Service.request('ToastManager:show', {
            text: window.api.l10n.get('remove-block-alert'),
          });

          // Need handle the last element removed situation.
          const elementList = this.element.querySelectorAll(
            this.FOCUS_SELECTOR
          );
          const element = elementList.item(elementList.length - 1);
          if (element === document.activeElement) {
            this.change_item = true;
          }
        });
        break;
      case 'SoftLeft':
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('showDialog', {
          type: 'prompt',
          header: 'add-block-header',
          inputType: 'tel',
          maxLength: 20,
          hideOkWhenNoInputValue: true,
          ok: 'save',
          onOk: value => {
            if (this.state.block.has(value)) {
              Service.request('ToastManager:show', {
                text: window.api.l10n.get('duplicate-block-number'),
              });
              return;
            }
            ContactStore.addBlockContact(value).then(() => {
              this.change_item = true;
            });
          },
        });
        break;
      default:
        break;
    }
  }

  onFocus() {
    this.updateSoftKeys();
  }

  render() {
    const dom = [];
    this.state.block.forEach((tag, value) => {
      dom.push(<BlockNumberList blockitem={value} />);
    });

    return (
      <div
        id="setting-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onFocus={() => this.onFocus()}
      >
        <div className="header h1" data-l10n-id="block-contacts" />
        <div className="body">{dom}</div>
      </div>
    );
  }
}
