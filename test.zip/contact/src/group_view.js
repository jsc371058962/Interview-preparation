import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import ContactList from 'components/contact_list';
import OptionMenuHelper from 'option_menu_helper';
import ContactStore from './contact_store';
import Utils from './contact_utils';

export default class GroupView extends BaseComponent {
  FOCUS_SELECTOR = '.list-item';

  constructor(props) {
    super(props);
    const name = this.props.name;
    const id = this.props.id;
    this.group = { id, name };
    this.state = {
      contacts: ContactStore.getContactsByGroupID(id),
    };
    this.isPicker = Service.query('isActivity');
    this.activityData = Service.query('activityData');
  }

  componentDidMount() {
    const config = this.getConfig();
    this.element = ReactDOM.findDOMNode(this);
    this._softKey = SoftKeyManager.create(this.element, config);

    this.onContactChanged = () => {
      this.setState({
        contacts: ContactStore.getContactsByGroupID(this.group.id),
      });
    };

    ContactStore.on('changed', this.onContactChanged);

    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element
    );
  }

  componentDidUpdate() {
    this.updateSoftKeys();
  }

  componentWillUnmount() {
    this._softKey.destroy();
    ContactStore.off('changed', this.onContactChanged);
  }

  getConfig() {
    let config = {};
    const hasContact = !!this.state.contacts.length;
    if (this.isPicker) {
      config = {
        left: '',
        center: hasContact ? 'select' : '',
        right: hasContact ? 'view' : '',
      };
    } else {
      config = {
        left: 'add',
        center: hasContact ? 'select' : '',
        right: hasContact ? 'options' : '',
      };
    }
    return config;
  }

  updateSoftKeys() {
    this._softKey.update(this.getConfig());
  }

  updateGroupContacts(items) {
    const contacts = items ? items.map(item => item) : [];
    let duplicateNum = 0;
    contacts.forEach(contact => {
      if (
        'duplicate' === ContactStore.contactAddGroup(contact, this.group.id)
      ) {
        duplicateNum++;
      }
    });
    if (duplicateNum) {
      Service.request('ToastManager:show', {
        text: window.api.l10n.get('duplicate-removed'),
      });
    }
  }

  onKeyDown(evt) {
    const id = document.activeElement.dataset.id;
    let contact = null;
    if (id) {
      contact = ContactStore.getContactSync(id);
    }
    let anchor;
    let location = '';
    let options = [];
    switch (evt.key) {
      case 'Call':
        if (!contact) {
          break;
        }
        if (this.isPicker) {
          break;
        }
        Service.request('pickANumber', contact).then(tel => {
          Utils.dial(tel);
        });
        break;
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('back');
        break;
      case 'SoftRight':
        evt.preventDefault();
        evt.stopPropagation();
        if (!contact) {
          break;
        }
        if (this.isPicker) {
          anchor = evt.target.querySelector('a');
          location = anchor.pathname;
          Service.request('push', location);
          break;
        }
        options = options.concat(
          OptionMenuHelper.optionsForContact(contact),
          {
            id: 'massive-delete',
            callback: () => {
              Service.request('back');
              Service.request('back');
              Service.request('setEditMode', 'delete');
            },
          },
          {
            id: 'settings',
            callback: () => {
              Service.request('push', '/setting');
            },
          }
        );
        Service.request('showOptionMenu', {
          options,
        });
        break;
      case 'Enter':
        if (!id) {
          break;
        }
        anchor = evt.target.querySelector('a');
        location = anchor.pathname;
        if (this.isPicker) {
          Service.request('pick', id);
        } else {
          Service.request('push', location);
        }
        evt.preventDefault();
        evt.stopPropagation();
        break;
      case 'SoftLeft':
        evt.preventDefault();
        evt.stopPropagation();
        if (this.isPicker) {
          break;
        }
        Service.request('push', '/pick/group', {
          id: this.group.id,
          name: this.group.name,
          noSimContact: true,
          source: 'phone',
        }).then(items => {
          this.updateGroupContacts(...items);
        });
        break;
      default:
        break;
    }
  }

  onFocus() {
    this.updateSoftKeys();
  }

  render() {
    let header = this.group.name;
    if (this.isPicker) {
      header = window.api.l10n.get('select-a-contact');
    }
    let contacts = this.state.contacts;
    // when in pick activity, show the contact contains that match type.
    if (this.activityData.type) {
      switch (this.activityData.type) {
        case 'webcontacts/select':
          contacts = this.state.contacts.filter(
            item =>
              (item.tel && item.tel.length) || (item.email && item.email.length)
          );
          break;
        case 'webcontacts/ice':
          contacts = this.state.contacts.filter(
            item => item.tel && item.tel.length
          );
          break;
        case 'webcontacts/email':
          contacts = this.state.contacts.filter(
            item => item.email && item.email.length
          );
          break;
        default:
          break;
      }
    }

    return (
      <div
        className="group-view list-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onFocus={e => this.onFocus(e)}
      >
        <div className="header h1 group-view-header">{header}</div>
        <div className="body">
          <ContactList contacts={contacts} />
        </div>
      </div>
    );
  }
}
