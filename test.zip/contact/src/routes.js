import React from 'react';
import EnhanceAnimation from 'enhance-animation';
import ContactListView from './contact_list_view';
import EditView from './edit_view';

const routes = [
  {
    path: '/contacts',
    action: () => {
      const Composed = EnhanceAnimation(
        ContactListView,
        'left-to-center',
        'center-to-left'
      );
      return <Composed ref="list" />;
    },
  },
  {
    path: '/edit/:id',
    action: params => {
      const Composed = EnhanceAnimation(
        EditView,
        'right-to-center',
        'center-to-right'
      );
      return <Composed {...params} ref={`edit/${params.id}`} exitOnClose />;
    },
  },
];

export default routes;
