import MimeMapper from 'mime-mapper';
import { TAG_INDEX } from 'contact_store';
import Rest from './rest';
import BaseImporter from './base_importer';

const ReBasic = /^([^:]+):(.+)$/;
const ReTuple = /([a-zA-Z]+)=(.+)/;
const WHITE_SPACE = ' ';

// Default tel type class
const DEFAULT_PHONE_TYPE = 'other';

//  basic type vcard to mobile type
const VCARD_SIMPLE_TYPES = {
  fax: 'fax-other',
  faxother: 'fax-other',
  home: 'home',
  internet: 'internet',
  cell: 'mobile',
  pager: 'pager',
  personal: 'personal',
  pref: 'pref',
  text: 'text',
  textphone: 'textphone',
  voice: 'voice',
  work: 'work',
  other: 'other',
};

// complex type vcard to mobile type
const VCARD_COMPLEX_TYPES = {
  'fax,work': 'fax-office',
  'fax,home': 'fax-home',
  'voice,work': 'work',
  'voice,home': 'home',
  'voice,other': 'other',
};

const REST_TIMEOUT = 5000;

function parseDataUri(str) {
  const re = /^data:(.+);(charset=([^;]+))?;?base64,(.*)$/;
  const matches = re.exec(str);

  if (matches) {
    return {
      mime: matches[1],
      charset: matches[3],
      value: matches[4],
    };
  }
  return null;
}

function ensureMimeType(type) {
  type = type.toLowerCase();
  if (!MimeMapper.isSupportedType(type)) {
    type = MimeMapper.guessTypeFromExtension(type) || type;
  }
  return type || '';
}

/**
 * Decodes a string encoded in Quoted-Printable format.
 * @param {string} str String to be decoded.
 * @return {string}
 */
function _decodeQuoted(str) {
  let decodeRes;
  try {
    decodeRes = decodeURIComponent(str.replace(qpRegexp, '%$1'));
  } catch (error) {
    decodeRes = '';
  }
  return decodeRes;
}

/**
 * Given a string, expected to be in base64 format, an a
 * content type, returns the corresponding Blob.
 * If cannot be parsed, will return undefined.
 *
 * @param {string} data as a string.
 * @param {string} content type of the expected blob. Can be null.
 * @param {int} size of the slice to be parsed.
 */
function b64toBlob(b64Data, contentType, sliceSize) {
  if (!b64Data) {
    console.error('No b64 data provided to convert to blob.');
    return;
  }

  contentType = contentType || '';
  sliceSize = sliceSize || 1024;

  function charCodeFromCharacter(c) {
    return c.charCodeAt(0);
  }

  let blob;
  try {
    const byteCharacters = atob(b64Data);
    const byteArrays = [];

    for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      const slice = byteCharacters.slice(offset, offset + sliceSize);
      const byteNumbers = [];
      for (let i = 0, l = slice.length; i < l; i++) {
        byteNumbers.push(charCodeFromCharacter(slice[i]));
      }
      const byteArray = new Uint8Array(byteNumbers);

      byteArrays.push(byteArray);
    }

    blob = new Blob(byteArrays, { type: contentType });
  } catch (e) {
    console.error('Error parsing base64 data');
  }
  return blob;
}

function _parseTuple(p) {
  const match = p.match(ReTuple);
  return match ? [match[1].toLowerCase(), match[2]] : ['type', p];
}

/**
 * Parses a line and creates an object with the line type (name), its meta
 * properties and its actual value.
 *
 * @param {string} line Line to be parsed from a VCF.
 * @return {{key: string, data: {meta, value}}}
 * @private
 */
function _parseLine(line) {
  const parsed = ReBasic.exec(line);
  if (!parsed) {
    return null;
  }

  // `tuples` is an array containing all the extra properties
  const tuples = parsed[1].split(/[;,]/);
  const fieldName = tuples.shift().toLowerCase();
  // Value will be an empty array if there is only whitespace and
  // semi-colons.
  let fieldValue = /[^\s;]/.test(parsed[2]) ? parsed[2].split(';') : [];
  const meta = {
    type: [],
  };

  const len = tuples.length;
  for (let i = 0; i < len; i++) {
    const tuple = _parseTuple(tuples[i]);
    if ('type' === tuple[0]) {
      meta.type.push(tuple[1]);
    } else {
      meta[tuple[0]] = tuple[1];
    }
  }

  // If this is a photo, we correct the value and type
  if ('photo' === fieldName) {
    if (meta.type.length) {
      meta.type = ensureMimeType(meta.type[0]);
    }

    fieldValue = parsed[2];
    // vCard 3.0 expects a mandatory encoding = 'b' parameter for base64
    // encoded images, and vCard 2.1 expects a 'BASE64' one.
    if (
      meta.encoding &&
      ('b' === meta.encoding.toLowerCase() ||
        'base64' === meta.encoding.toLowerCase())
    ) {
      meta.encoding = 'base64';
    } else {
      const parsedUri = parseDataUri(fieldValue);
      if (parsedUri) {
        meta.type = ensureMimeType(parsedUri.mime);
        meta.encoding = 'base64';
        fieldValue = parsedUri.value;
      }
    }
  }

  return {
    key: fieldName,
    data: {
      meta,
      value: fieldValue,
    },
  };
}

/**
 * Takes an object with vCard properties and a mozContact object and returns
 * the latter with the computed address fields properly filled, inferred from
 * `vcardObj`.
 *
 * @param {Object} vcardObj
 * @param {Object} contactObj a mozContact to be filled with name fields.
 * @return {Object}
 */
function _processAddr(vcardObj, contactObj) {
  if (!vcardObj.adr) {
    return contactObj;
  }

  contactObj.adr = [];
  for (let i = 0; i < vcardObj.adr.length; i++) {
    const cur = {};
    const adr = vcardObj.adr[i];
    if (adr.meta && adr.meta.type) {
      const type =
        adr.meta.type.length > 0
          ? VCARD_SIMPLE_TYPES[adr.meta.type[0].toLowerCase()]
          : null;
      cur.type = type ? [type] : adr.meta.type;
    }

    for (let j = 2; j < adr.value.length; j++) {
      const decoded = _decodeQP(adr.meta, adr.value[j]);
      // Because of adding empty fields while parsing the vCard
      // merging contacts sometimes doesn't work as expected
      // Check Bug 935636 for reference
      if (decoded !== '') {
        cur[ADDR_PARTS[j]] = decoded;
      }
    }

    contactObj.adr.push(cur);
  }
  return contactObj;
}

/**
 * Takes an object with vCard properties and a mozContact object and returns
 * the latter with the computed phone, email and url fields properly filled,
 * inferred from `vcardObj`.
 *
 * @param {Object} vcardObj
 * @param {Object} contactObj a mozContact to be filled with name fields.
 * @return {Object}
 */
function _processComm(vcardObj, contactObj) {
  contactObj.tel = [];

  ['tel', 'email', 'url'].forEach(field => {
    if (!vcardObj[field]) {
      return;
    }

    const len = vcardObj[field].length;
    const hasTypeMapper = x => {
      return x.trim().toLowerCase();
    };
    const notTypeMapper = (v, key) => {
      return v.meta[key].trim().toLowerCase();
    };
    const noType = () => {
      return 'type' !== field;
    };
    const noPref = () => {
      return 'pref' !== field;
    };
    const typeFilter = metaValue => {
      return !!VCARD_SIMPLE_TYPES[metaValue];
    };

    for (let i = 0; i < len; i++) {
      const v = vcardObj[field][i];
      let metaValues;
      const cur = {};

      if (v.meta) {
        if (v.value) {
          cur.value = _decodeQP(v.meta, v.value[0]);
          cur.value = cur.value.replace(/^tel:|-/gi, '');
        }

        if (v.meta.type) {
          const metaType = Array.from(v.meta.type);
          if (1 === metaType.length) {
            // No match anything, use itself.
            const typeItemLowerCase = metaType[0].trim().toLowerCase();
            metaValues = [
              VCARD_SIMPLE_TYPES[typeItemLowerCase]
                ? typeItemLowerCase
                : metaType[0].trim(),
            ];
            if ('email' === field && 'home' === typeItemLowerCase) {
              metaValues = ['personal'];
            }
          } else {
            metaValues = metaType.map(hasTypeMapper);
          }
        } else {
          metaValues = Object.keys(v.meta)
            .filter(noType)
            .map(notTypeMapper.bind(null, v));
        }

        if (metaValues.indexOf('pref') !== -1) {
          cur.pref = true;
          metaValues = metaValues.filter(noPref);
        }

        /*
         * metaValues is an array of types. If metaValues length is:
         *   0: it returns the default type (No type was defined),
         *   1: If the element matches a simple type, returns the simple type,
         *     if not, it returns the default type
         *   2: If the elements match a complex type, it returns the complex
         *    type. If not, then try to match the elements with a simple type,
         *    in order. If one of the elements matches a simple type, it
         *    returns the first element that matches a simple type or if there
         *    exists no matching, it returns the default type value.
         *   otherwise --> Returns the first element that matches a simple type
         *    or if there exists no matching, it returns the default type value
         * */
        let complexType1;
        let complexType2;
        switch (metaValues.length) {
          case 0:
            cur.type = [DEFAULT_PHONE_TYPE];
            break;
          case 1:
            cur.type = [
              VCARD_SIMPLE_TYPES[metaValues[0]] ||
                (field !== 'tel' && metaValues[0]) ||
                DEFAULT_PHONE_TYPE,
            ];
            break;
          case 2:
            complexType1 = `${metaValues[0]},${metaValues[1]}`;
            complexType2 = `${metaValues[1]},${metaValues[0]}`;
            cur.type = [
              VCARD_COMPLEX_TYPES[complexType1] ||
                VCARD_COMPLEX_TYPES[complexType2] ||
                VCARD_SIMPLE_TYPES[metaValues[0]] ||
                VCARD_SIMPLE_TYPES[metaValues[1]] ||
                DEFAULT_PHONE_TYPE,
            ];
            break;
          default:
            cur.type = [
              VCARD_SIMPLE_TYPES[metaValues.filter(typeFilter).shift()] ||
                DEFAULT_PHONE_TYPE,
            ];
        }
      }

      if (!contactObj[field]) {
        contactObj[field] = [];
      }

      contactObj[field].push(cur);
    }
  });
  return contactObj;
}

function _isValidDate(dateValue) {
  return !isNaN(Date.parse(dateValue));
}

function _processFields(vcardObj, contactObj) {
  ['org', 'title', 'bday', 'anniversary', 'note'].forEach(field => {
    if (!vcardObj[field]) {
      return;
    }

    const v = vcardObj[field][0];

    let dateValue;
    if ('bday' === field) {
      dateValue = v.value[0];
      if (_isValidDate(dateValue)) {
        contactObj.bday = new Date(dateValue);
      }
      return;
    }

    if ('anniversary' === field) {
      dateValue = v.value[0];
      if (_isValidDate(dateValue)) {
        contactObj.anniversary = new Date(dateValue);
      }
      return;
    }

    if (!v) {
      return;
    }

    if ('title' === field) {
      field = 'jobTitle';
    }

    switch (typeof v) {
      case 'object':
        contactObj[field] = [_decodeQP(v.meta, v.value[0])];
        break;
      case 'string':
        contactObj[field] = [v];
        break;
      default:
        break;
    }
  });
  return contactObj;
}

function _processPhoto(vcardObj, contactObj, cb) {
  if (
    !Array.isArray(vcardObj.photo) ||
    0 === vcardObj.photo.length ||
    !vcardObj.photo[0] ||
    !vcardObj.photo[0].value
  ) {
    return cb(contactObj);
  }

  const photo = vcardObj.photo[0];
  const photoContents = photo.value.trim();
  if (!photoContents) {
    return cb(contactObj);
  }
  if (photoContents && photo.meta && 'base64' === photo.meta.encoding) {
    const blob = b64toBlob(photoContents, photo.meta.type);
    if (blob) {
      // XXX: thumbnail
      contactObj.photo = [blob];
      cb(contactObj);
    } else {
      cb(contactObj);
    }
  } else {
    // Else we assume it is a http url
    const callbacks = {
      success: blobPic => {
        if (blobPic) {
          contactObj.photo = [blobPic];
        }
        cb(contactObj);
      },
      error: () => {
        console.error('Error getting photo for contact');
        cb(contactObj);
      },
      timeout: () => {
        console.error('Timeout getting photo for contact');
        cb(contactObj);
      },
    };
    Rest.get(photoContents, callbacks, {
      responseType: 'blob',
      operationsTimeout: REST_TIMEOUT,
    });
  }
}

/**
 * Converts a parsed vCard to a mozContact.
 *
 * @param {Object} vcard JSON representation of an vCard.
 * @param {Function} cb Function to call with the resulting moxContact object
 * @return {Object, null} An object implementing mozContact interface.
 */
function vcardToContact(vcard, cb) {
  if (!vcard) {
    return null;
  }

  const obj = {};
  _processName(vcard, obj);
  _processAddr(vcard, obj);
  _processComm(vcard, obj);
  _processFields(vcard, obj);

  _processPhoto(vcard, obj, contactObj => {
    cb(contactObj);
  });
}

/**
 * Parse vCard entries split by lines and pass the converted object back to
 * the main thread.
 *
 * @param {string[][]} cardArray Array of array of strings representing vcard.
 * @param {function} cb Callback to call on finishe.
 */
function _parseEntries(cardArray, cb) {
  console.log('[VcardReader] _parseEntries:');
  const parsedCards = [];

  function sendIfFinished(contactObj) {
    parsedCards.push(contactObj);
    if (parsedCards.length === cardArray.length) {
      cb(parsedCards);
    }
  }

  for (let i = 0; i < cardArray.length; i++) {
    const lines = cardArray[i];
    // If there is no array of strings at cardArray[i] (representing a single
    // vcard), push a null value to account for a processed card.
    if (!lines) {
      sendIfFinished(null);
      continue;
    }

    const fields = {};
    const len = lines.length;

    for (let j = 0; j < len; j++) {
      const line = lines[j];
      const parsedLine = _parseLine(line);
      if (!parsedLine) {
        continue;
      }

      if (!fields[parsedLine.key]) {
        fields[parsedLine.key] = [];
      }

      fields[parsedLine.key].push(parsedLine.data);
    }

    vcardToContact(fields, sendIfFinished);
  }
}

/**
 * Matches Quoted-Printable characters in a string
 * @type {RegExp}
 */
const qpRegexp = /=([a-zA-Z0-9]{2})/g;

/**
 * Decodes Quoted-Printable encoding into UTF-8
 * http://en.wikipedia.org/wiki/Quoted-printable
 *
 * @param {object} metaObj Checks for 'encoding' key to be quoted printable.
 * @param {string} value String to be decoded.
 * @return {string}
 */
function _decodeQP(metaObj, value) {
  const isQP =
    metaObj && metaObj.encoding && /quoted-printable/i.test(metaObj.encoding);

  if (isQP) {
    value = _decodeQuoted(value);
  }

  return value;
}

const NAME_PARTS = [
  'familyName',
  'givenName',
  'additionalName',
  'honorificPrefix',
  'honorificSuffix',
];

/**
 * Takes an object with vCard properties and a mozContact object and returns
 * the latter with the computed name fields properly filled, inferred from
 * `vcardObj`.
 *
 * @param {Object} vcardObj
 * @param {Object} contactObj a mozContact to be filled with name fields.
 * @return {Object}
 */
function _processName(vcardObj, contactObj) {
  // Set First Name right away as the 'name' property
  if (vcardObj.fn && vcardObj.fn.length) {
    const fnMeta = vcardObj.fn[0].meta;
    const fnValue = vcardObj.fn[0].value[0];
    // For the name field, we want the data as it is
    contactObj.name = [_decodeQP(fnMeta, fnValue)];
  }

  if (vcardObj.n && vcardObj.n.length) {
    const values = vcardObj.n[0].value;
    const meta = vcardObj.n[0].meta;

    for (let i = 0; i < values.length; i++) {
      const namePart = values[i];
      if (namePart && NAME_PARTS[i]) {
        // For the rest of the fields, we want to keep the merged data
        // separated the same way, in different positions of the array.
        // see bug 981674
        contactObj[NAME_PARTS[i]] = _decodeQP(meta, namePart).split(',');
      }
    }

    // If we don't have a contact name at this point, make `name` be the
    // unification of all the name parts.
    if (!contactObj.name) {
      contactObj.name = [_decodeQP(meta, values.join(' ').trim())];
    }
  }
  contactObj.givenName = contactObj.givenName || contactObj.name;
  return contactObj;
}

const ADDR_PARTS = [
  null,
  null,
  'streetAddress',
  'locality',
  'region',
  'postalCode',
  'countryName',
];

const reBeginCard = /begin:vcard$/i;
const reEndCard = /end:vcard$/i;
const reVersion = /^VERSION:([\d\.]*)/i;

export const MAX_BLOB_SIZE = 1024 * 1024 * 10;

export default class VcardReader extends BaseImporter {
  name = 'VcardReader';
  DEBUG = false;

  /**
   * Class used to parse vCard files (http://tools.ietf.org/html/rfc6350).
   *
   * @param {String} contents vCard formatted text.
   * @constructor
   */
  constructor(contents) {
    super();
    this.currentChar = 0;
    this.total = 0;
    this.type = 'sd';
    this.cursor = -1;
    if (!contents) {
      return;
    }
    this.contents = contents;

    const match = this.contents.match(/end:vcard/gi);
    // If there are no matches, then this probably isn't a vcard and we should
    // stop processing.
    if (!match) {
      return;
    }
    this._importedContacts = [];
    this.total = match.length;
  }

  // Number of contacts processed at a given time.
  CONCURRENCY = 5;

  /**
   * Starting point of vcard processing.
   * @param {function} cb Function to call after the process is finished.
   */
  import(noSave) {
    this.noSave = noSave;

    if (!this.total) {
      return;
    }
    this.wakeLock = navigator.b2g.requestWakeLock('cpu');

    // Start processing the text
    // The data pump flows as follows:
    //  1) splitlines() reads char-by-char to split the text into lines
    //  2) each line is parsed to parseEntries() when we have accumulated
    //     enough lines to represent CONCURRENCY cards.
    //  3) call post() for each contact found by parseEntries()
    //  4) perform matching for each contact
    //  5) save the contact if appropriate
    //  6) call onParsed() which either goes back to (4) for the next contact
    //     or goes back to (1) to get the next set of lines
    //
    // Note: The async callbacks in the matching and mozContacts.save() code
    // prevent this code from being purely recursive.
    this.splitLines();
  }

  continue() {
    this.debug('continue:');
    if (this.paused) {
      return;
    }

    this.cursor += 1;
    if (this.cursor < this.processingContacts.length) {
      const contact = this.processingContacts[this.cursor];
      contact.category = [TAG_INDEX.kaiContact, TAG_INDEX.phone];
      this.noSave ? this.emit('parsed', contact) : this.save(contact);
    } else {
      this.splitLines();
    }
  }

  /**
   * This will be called every time we manage to process a contact
   * @param {object[]} contactObjects Objects with contact structure.
   */
  post(contactObjects) {
    this.debug('post:');
    if (this.aborted) {
      return;
    }
    this.processingContacts = contactObjects;
    this.cursor = -1;

    this.continue();
  }

  /**
   * Splits vcard text into arrays of lines (one for each vcard field) and
   * sends an array of arrays of lines over to process.
   */
  splitLines() {
    this.debug('splitLines:');
    let currentLine = '';
    let currentVersion = 0;
    let inLabel = false;
    let multiline = false;

    const cardArray = [[]];

    /**
     * Number of cards processed. Quite faster than looking at `cardArray`
     * length.
     * @type {number}
     */
    let cardsProcessed = 0;

    // We start at the last cursor position
    let i = this.currentChar;

    const callPost = this.post.bind(this);

    this.debug('to start looping by char:');
    for (let l = this.contents.length; i < l; i++) {
      this.currentChar = i;
      const ch = this.contents[i];
      if (currentVersion >= 4 && '"' === ch) {
        inLabel = !inLabel;
        currentLine += ch;
        continue;
      }

      // Ignore beginning whitespace that indicates multiline field.
      if (true === multiline) {
        if (/[\r\t\s\n]/.test(ch)) {
          continue;
        } else {
          multiline = false;
        }
      }

      const next = this.contents[i + 1];
      if (inLabel || (ch !== '\n' && ch !== '\r')) {
        // If we have a quoted-printable sign for multiline (/=\n/) AND
        // we are not in a data URI field, ignore the character.
        if (
          !/^PHOTO/i.test(currentLine) &&
          !/^URL/i.test(currentLine) &&
          '=' === ch &&
          next &&
          next.search(/(\r|\n)/) !== -1
        ) {
          multiline = true;
          continue;
        }
        currentLine += ch;

        // Continue only if this is not the last char in the string
        if (i !== l - 1) {
          continue;
        }
      }

      // If the field is a photo, the field could be multiline, to know if the
      // following line is part of the photo, we must check if the first char
      // of the following line is a space.
      const firstCharNextLine = this.contents[i + 2];
      if (
        firstCharNextLine === WHITE_SPACE &&
        /[\r\t\s\n]/.test(next) &&
        /^PHOTO/i.test(currentLine)
      ) {
        multiline = true;
        continue;
      }

      // At this point, we know that ch is a newline, and in the vcard format,
      // if we have a space after a newline, it indicates multiline field.
      if (next && (next === WHITE_SPACE || '\t' === next)) {
        multiline = true;
        continue;
      }

      if (reBeginCard.test(currentLine)) {
        currentLine = '';
        currentVersion = 0;
        continue;
      }

      // If the current line indicates the end of a card,
      if (reEndCard.test(currentLine)) {
        this.debug('read end of card: ready to _parseEntries');
        cardsProcessed += 1;

        if (
          cardsProcessed === this.CONCURRENCY ||
          cardsProcessed + this.imported === this.total
        ) {
          _parseEntries(cardArray, callPost);
          break;
        }

        currentLine = '';

        cardArray.push([]);

        continue;
      }

      if (currentLine) {
        const matches = reVersion.exec(currentLine);
        if (null === matches) {
          cardArray[cardArray.length - 1].push(currentLine);
        } else {
          currentVersion = parseFloat(matches[1] || '0');
        }
      }
      currentLine = '';
    }
  }

  _decodeQuoted = _decodeQuoted;
  processAddr = _processAddr;
  processName = _processName;
  vcardToContact = vcardToContact;
}
