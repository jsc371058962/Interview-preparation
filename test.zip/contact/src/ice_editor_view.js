import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import Utils from 'contact_utils';
import ICEStore from './ice_store';
import ContactStore from './contact_store';

export default class ICEView extends BaseComponent {
  FOCUS_SELECTOR = '.list-item.navigable';

  constructor(props) {
    super(props);
    this.state = {
      contacts: ICEStore.getAll(),
    };
  }

  componentDidMount() {
    window.icv = this;
    const config = this.getConfig();
    this.element = ReactDOM.findDOMNode(this);
    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element
    );
    this._softKey = SoftKeyManager.create(this.element, config);
    this.store = ICEStore;
    this.onChanged = () => {
      this.setState({
        contacts: ICEStore.getAll(),
      });
    };
    ICEStore.on('changed', this.onChanged);
  }

  componentWillUnmount() {
    this._softKey.destroy();
    ICEStore.off('changed', this.onChanged);
  }

  componentDidUpdate() {
    this.updateSoftKeys();
  }

  getConfig() {
    const id = document.activeElement.dataset.id;
    const config = {};
    if (id) {
      config.right = 'remove';
    } else if (!Number.isNaN(document.activeElement.dataset.index)) {
      config.center = 'select';
    }
    return config;
  }

  updateSoftKeys() {
    this._softKey.update(this.getConfig());
  }

  onKeyDown(evt) {
    const position = +document.activeElement.dataset.index;
    const id = document.activeElement.dataset.id;
    switch (evt.key) {
      case 'Enter':
        if (!id) {
          const req = new WebActivity('pick', {
            type: 'webcontacts/ice',
            params: { typeOfContact: 'device' },
          });
          req.start().then(result => {
            const contactId = result.id;
            if (!contactId) {
              return;
            }
            ICEStore.setContact(contactId, position);
          });
        }
        break;
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('back');
        break;
      case 'SoftRight':
        if (id) {
          Service.request('showDialog', {
            type: 'confirm',
            header: 'confirm',
            content: 'delete-ice-contact-warning',
            ok: 'remove',
            onOk: () => {
              ICEStore.unsetContact(position, id);
            },
          });
        }
        break;
      default:
        break;
    }
  }

  render() {
    const dom = [];
    this.state.contacts.forEach((item, index) => {
      const arg = JSON.stringify({ n: index + 1 });
      const key = `ice${index}`;
      dom.push(
        <div
          className="separator secondary"
          data-l10n-id="ICEContact"
          data-l10n-args={arg}
          key={`${key}Separator`}
        />
      );
      let content = null;
      if (item.id) {
        const contact = ContactStore.contactMap.get(item.id);
        content = (
          <div className="primary">
            <div className="primary">{Utils.getDisplayName(contact)}</div>
          </div>
        );
      } else {
        content = (
          <div className="content">
            <div className="primary">
              <span data-l10n-id="ICESelectContact" />
            </div>
          </div>
        );
      }
      dom.push(
        <div
          className="list-item navigable"
          tabIndex="-1"
          data-index={index}
          data-id={item.id}
          key={key}
        >
          {content}
        </div>
      );
    });
    return (
      <div
        id="ice-editor-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onFocus={() => this.updateSoftKeys()}
      >
        <div className="header h1" data-l10n-id="ICESettingTitle" />
        <div className="body">
          <div className="list-item" data-multi-line="true">
            <div className="content">
              <div className="primary" data-l10n-id="ICEDescription" />
            </div>
          </div>
          {dom}
        </div>
      </div>
    );
  }
}
