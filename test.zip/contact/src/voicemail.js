import BaseModule from 'base-module';
import Service from 'service';

class Voicemail extends BaseModule {
  name = 'Voicemail';
  DEBUG = false;

  values = [];

  constructor() {
    super();
    SettingsObserver.observe(
      'ril.iccInfo.mbdn',
      undefined,
      this['_observe_ril.iccInfo.mbdn'].bind(this)
    );
  }

  getValues() {
    return [].concat(this.values);
  }

  set(values) {
    SettingsObserver.setValue([
      {
        name: 'ril.iccInfo.mbdn',
        value: Array.isArray(values) ? values : [values],
      },
    ]);

    Service.request('ToastManager:show', {
      text: window.api.l10n.get('voice-mail-number-updated'),
    });
  }

  '_observe_ril.iccInfo.mbdn'(values) {
    this.debug('detect voicemail changed:', values);
    const slotNum = navigator.b2g.mobileConnections.length;
    this.values = Array.isArray(values) ? values : [values];
    this.values = this.values.map((value, index) => {
      if (index >= slotNum) {
        return;
      }
      return value || navigator.b2g.voicemail.getNumber(index);
    });
    this.emit('changed');
  }
}

const voicemail = new Voicemail();

window.vm = voicemail;

export default voicemail;
