import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SoftKeyManager from 'modules/soft_key_manager';
import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';
import ContactList from 'components/contact_list';
import SimStore from './sim_store';
import Utils from './contact_utils';

export default class SdnList extends BaseComponent {
  FOCUS_SELECTOR = '.list-item';

  constructor(props) {
    super(props);
    this.state = {
      contacts: [],
    };
    this.store = SimStore;
  }

  updateSoftKeys() {
    const config = {};
    config.center = 'select';
    this._softKey.update(config);
  }

  componentDidMount() {
    const config = {
      center: 'select',
    };
    this.element = ReactDOM.findDOMNode(this);
    this._softKey = SoftKeyManager.create(this.element, config);

    SimStore.getCardWithSDNList().then(() => {
      this.setState({
        contacts: SimStore.getSDNContacts()[this.props.index],
      });
    });

    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.element
    );
  }

  componentWillUnmount() {
    this._softKey.destroy();
  }

  onKeyDown(evt) {
    const id = document.activeElement.dataset.id;
    const index = +document.activeElement.dataset.index;
    let contact = null;
    if (id) {
      contact = SimStore.getSDNContacts()[this.props.index][index];
    }
    let location = '';
    switch (evt.key) {
      case 'Call':
        if (!contact) {
          break;
        }
        this.pickANumber(contact).then(tel => {
          Utils.dial(tel);
        });
        break;
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('back');
        break;
      case 'Enter':
        location = evt.target.querySelector('a').pathname;
        evt.preventDefault();
        evt.stopPropagation();
        Service.request('push', location, {
          id,
        });
        break;
      default:
        break;
    }
  }

  pickANumber(contact) {
    return new Promise(resolve => {
      if (contact.tel.length > 1) {
        const options = [];
        contact.tel.forEach(tel => {
          options.push({
            label: `(${tel.type[0].toUpperCase()[0]}) ${tel.value}`,
            callback: () => {
              resolve(tel.value);
            },
          });
        });
        Service.request('showOptionMenu', {
          header: 'choose-number',
          options,
          onCancel: () => {},
        });
      } else {
        resolve(contact.tel[0].value);
      }
    });
  }

  componentDidUpdate() {
    this.updateSoftKeys();
  }

  onFocus() {
    this.updateSoftKeys();
    if (0 === this.state.contacts.length) {
      Service.request('back');
    }
  }

  render() {
    return (
      <div
        className="sdn-view list-view"
        tabIndex="-1"
        onKeyDown={e => this.onKeyDown(e)}
        onFocus={e => this.onFocus(e)}
      >
        <div className="header h1" data-l10n-id="service-number" />
        <div className="body">
          <ContactList contacts={this.state.contacts} />
        </div>
      </div>
    );
  }
}
