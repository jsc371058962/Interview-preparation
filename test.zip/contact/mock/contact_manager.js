/* exported ContactManager */
/* window lib_settings taskScheduler */
const _ContactManager = {
  connected: false,
  initFlag: false,
  eventListenerInfo: {},
  onContactChangeCallback: null,
  onSpeedDialChangeCallback: null,
  onContactGroupChangeCallback: null,
  onBlockedNumberChangeCallback: null,
  init: function cm_init() {
    window.api = {
      contactmanager: {
        getAll: () => [],
        getAllBlockedNumbers: () => [],
        getAllGroups: () => [],
        getCount: () => [],
        getRevision: () => [],
        getSpeedDials: () => [],
        find: () => [],
        remove: () => [],
        save: () => [],
        removeBlockedNumber: () => [],
        saveBlockedNumber: () => [],
        findBlockedNumbers: () => [],
        saveGroup: () => [],
        findGroups: () => [],
        setSpeedDial: () => [],
        removeSpeedDial: () => [],
        addEventListener: () => [],
        removeEventListener: () => [],
        onblockednumberchange: () => [],
        oncontactgroupchange: () => [],
        onspeeddialchange: () => [],
        oncontactchange: () => [],
      },
    };
    if (!this.initFlag) {
      this.initFlag = true;
      window.addEventListener('session-disconnected', () => {
        this.connected = false;
      });
      window.addEventListener('services-load-observer', () => {
        if (!this.connected) {
          this.connected = true;
          this.recoverListener();
        }
      });
    }
  },

  /**
   * @return promise, an array of the support fields in contact table
   */
  getSupportFields: function cm_getSupportFields() {
    const args = arguments;
    return taskScheduler.request({
      serverName: taskScheduler.CONTACT,
      funcName: 'getSupportFields',
      args,
    });
  },

  /**
   * @param options
   *  options = {
   *    filterValue: // e.g. "Tom" "123456"
   *    filterOp: // "equals", "contains", "match", "startsWith", "fuzzyMatch"
   *    filterBy: // e.g. ["givenName", "nickname", 'tel']
   *    filterLimit: // default 0
   *    fields; //array
   *  }
   * @return promise
   * return the needed fields contacts, if no fields in options return all fields contact
   */
  find: function cm_find(options) {
    const args = arguments;
    return taskScheduler.request({
      serverName: taskScheduler.CONTACT,
      funcName: 'find',
      args,
    });
  },

  /**
   * @param options: if provide the fields, return the need fields, otherwhise, return all fields
   * @param numbers: only return first numbers of contact after sort
   * @return domcursor
   */
  getAll: function cm_getAll(options, numbers) {
    let data = [];
    const result = contact => {
      return { target: { result: contact } };
    };
    const request = {
      onsuccess: () => {},
      onerror: () => {},
      continue: () => {
        const contact = data.pop();
        request.onsuccess(result(contact));
      },
    };
    fetch('/mock/contacts.json')
      .then(d => d.json())
      .then(datas => {
        console.log('--fetch data--', datas);
        data = datas;
        request.onsuccess(result(data.pop()));
      });
    return request;
  },

  /**
   * @param contactOrIdsArray: array, the contacts objects or ids you are going to remove from db.
   * @return promise
   */
  remove: function cm_remove(contactOrIdsArray) {
    const args = arguments;
    return taskScheduler.request({
      serverName: taskScheduler.CONTACT,
      funcName: 'remove',
      args,
    });
  },

  /**
   * @param contatsArray: array
   */
  save: function cm_save(contatsArray) {
    const args = arguments;
    return taskScheduler.request({
      serverName: taskScheduler.CONTACT,
      funcName: 'save',
      args,
    });
  },

  /**
   * @param contacidsArray: array
   * @param copyOrMOve: {0|1}
   * @return promise
   */
  moveContactsToDevice: function cm_moveContactsToDevice(
    contacidsArray,
    copyOrMOve
  ) {
    const args = arguments;
    return taskScheduler.request({
      serverName: taskScheduler.CONTACT,
      funcName: 'moveContactsToDevice',
      args,
    });
  },

  /**
   * @param contacidsArray: array
   * @param copyOrMOve: {0|1}
   * @return promise
   */
  moveContactsToSim: function cm_moveContactsToSim(contacidsArray, copyOrMOve) {
    const args = arguments;
    return taskScheduler.request({
      serverName: taskScheduler.CONTACT,
      funcName: 'moveContactsToSim',
      args,
    });
  },

  /**
   * To clear all contacts and related data.
   * @param options: the clear options
   */
  clear: function cm_save(options) {
    const args = arguments;
    return taskScheduler.request({
      serverName: taskScheduler.CONTACT,
      funcName: 'clear',
      args,
    });
  },

  getRevision: function cm_getRevision() {
    const args = arguments;
    return taskScheduler.request({
      serverName: taskScheduler.CONTACT,
      funcName: 'getRevision',
      args,
    });
  },

  getCount: function cm_getCount() {
    const args = arguments;
    return taskScheduler.request({
      serverName: taskScheduler.CONTACT,
      funcName: 'getCount',
      args,
    });
  },

  getSpeedDials: function cm_getSpeedDials() {
    const args = arguments;
    return taskScheduler.request({
      serverName: taskScheduler.CONTACT,
      funcName: 'getSpeedDials',
      args,
    });
  },

  removeSpeedDial: function cm_removeSpeedDial(speedDial) {
    const args = arguments;
    return taskScheduler.request({
      serverName: taskScheduler.CONTACT,
      funcName: 'removeSpeedDial',
      args,
    });
  },

  /**
   * @param speedDial: string
   * @param tel: string
   * @param contactId: sring, optional
   */
  setSpeedDial: function cm_setSpeedDial(speedDial, tel, contactId) {
    const args = arguments;
    return taskScheduler.request({
      serverName: taskScheduler.CONTACT,
      funcName: 'setSpeedDial',
      args,
    });
  },

  /**
   * To get all groups with given parameter.
   * @param options: optional
   * @return domcusor, an array of {id, name}.
   */
  getAllGroups: function cm_getAllGroups(options) {
    let data = [];
    const result = contact => {
      return { target: { result: contact } };
    };
    const request = {
      onsuccess: () => {},
      onerror: () => {},
      continue: () => {
        const contact = data.pop();
        request.onsuccess(result(contact));
      },
    };
    fetch('/mock/group.json')
      .then(d => d.json())
      .then(datas => {
        console.log('--fetch group--', datas);
        data = datas;
        request.onsuccess(result(data.pop()));
      });
    return request;
  },

  findGroups: function cm_findGroups(options) {
    const args = arguments;
    return taskScheduler.request({
      serverName: taskScheduler.CONTACT,
      funcName: 'findGroups',
      args,
    });
  },

  /**
   * @param name: string
   * @param id: string, optional
   */
  saveGroup: function cm_saveGroup(name, id) {
    const args = arguments;
    return taskScheduler.request({
      serverName: taskScheduler.CONTACT,
      funcName: 'saveGroup',
      args,
    });
  },

  /**
   * @param options: optional
   * @return domcursor, every entry is a blocked number string
   */
  getAllBlockedNumbers: function cm_getAllBlockedNumbers(options) {
    let data = [];
    const result = contact => {
      return { target: { result: contact } };
    };
    const request = {
      onsuccess: () => {},
      onerror: () => {},
      continue: () => {
        const contact = data.pop();
        request.onsuccess(result(contact));
      },
    };
    fetch('/mock/block-list.json')
      .then(d => d.json())
      .then(datas => {
        console.log('--fetch group--', datas);
        data = datas;
        request.onsuccess(result(data.pop()));
      });
    return request;
  },

  /**
   * @param options: optional
   * @return promise, result is an array of blobked number string
   */
  findBlockedNumbers: function cm_findBlockedNumbers(options) {
    const args = arguments;
    return taskScheduler.request({
      serverName: taskScheduler.CONTACT,
      funcName: 'findBlockedNumbers',
      args,
    });
  },

  /**
   * To save a number as blocked number.
   * If saving number is already exists, event onblocknumberchange wouldn't be triggered.
   * User always get success if saving identical number multiple times.
   * @param number The number to be blocked.
   */
  saveBlockedNumber: function cm_saveBlockedNumber(number) {
    const args = arguments;
    return taskScheduler.request({
      serverName: taskScheduler.CONTACT,
      funcName: 'saveBlockedNumber',
      args,
    });
  },

  removeBlockedNumber: function cm_removeBlockedNumber(number) {
    const args = arguments;
    return taskScheduler.request({
      serverName: taskScheduler.CONTACT,
      funcName: 'removeBlockedNumber',
      args,
    });
  },

  addEventListener: function cm_addEventListener(event, callback, useCapture) {
    window.api.contactmanager.addEventListener(event, callback, useCapture);
    if (this.eventListenerInfo[event]) {
      this.eventListenerInfo[event].push({
        callback,
        useCapture: !!useCapture,
      });
    } else {
      this.eventListenerInfo[event] = [{ callback, useCapture: !!useCapture }];
    }
  },

  removeEventListener: function cm_removeEventListener(event, callback) {
    window.api.contactmanager.removeEventListener(event, callback);
    if (this.eventListenerInfo[event]) {
      this.eventListenerInfo[event].forEach((listener, index) => {
        if (listener.callback === callback) {
          this.eventListenerInfo[event].splice(index, 1);
        }
      });
    }
  },

  recoverListener: function am_recoverListener() {
    for (event in this.eventListenerInfo) {
      const listeners = this.eventListenerInfo[event];
      listeners.forEach(listener => {
        window.api.contactmanager.addEventListener(
          event,
          listener.callback,
          listener.useCapture
        );
      });
    }
    this.onContactChange(this.onContactChangeCallback);
    this.onSpeedDialChange(this.onSpeedDialChangeCallback);
    this.onContactGroupChange(this.onContactGroupChangeCallback);
    this.onBlockedNumberChange(this.onBlockedNumberChangeCallback);
  },

  onContactChange: function cm_onContactChange(callback) {
    this.onContactChangeCallback = callback;
    if (this.connected) {
      window.api.contactmanager.oncontactchange = callback;
    }
  },

  onSpeedDialChange: function cm_onSpeedDialChange(callback) {
    this.onSpeedDialChangeCallback = callback;
    if (this.connected) {
      window.api.contactmanager.onspeeddialchange = callback;
    }
  },

  onContactGroupChange: function cm_onContactGroupChange(callback) {
    this.onContactGroupChangeCallback = callback;
    if (this.connected) {
      window.api.contactmanager.oncontactgroupchange = callback;
    }
  },

  onBlockedNumberChange: function cm_onBlockedNumberChange(callback) {
    this.onBlockedNumberChangeCallback = callback;
    if (this.connected) {
      window.api.contactmanager.onblockednumberchange = callback;
    }
  },
};

_ContactManager.init();
window.ContactManager = _ContactManager;
