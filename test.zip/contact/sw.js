/* global clients */
const SYSTEM_MESSAGE_TYPES = ['ussd-received'];

self.addEventListener('install', event => {
  event.waitUntil(self.skipWaiting());
});

self.addEventListener('activate', event => {
  event.waitUntil(self.clients.claim());
});

let resolveIdleTimeExtension;
self.onsystemmessage = evt => {
  if ('activity' === evt.name || SYSTEM_MESSAGE_TYPES.includes(evt.name)) {
    this.handler = evt.data.webActivityRequestHandler();
    let aName = this.handler.source.name;
    let openType = 'inline';
    const nameHash = {
      import: 'open',
      new: 'new-activity',
      'add-to-call': 'new?add-to-call',
    };

    if (nameHash[aName]) {
      aName = nameHash[aName];
    }

    if ('launch' === aName) {
      openType = 'window';
      aName = '';
    }

    clients.openWindow(`/index.html#${aName}`, { disposition: openType }).then(
      client => {
        aName &&
          client.postMessage({
            category: 'systemmessage',
            data: { source: this.handler.source },
            type: evt.name,
          });
      },
      err => console.log('open window err', err)
    );
  }

  // idleTimeExtension to make service worker timeout longer
  const idleTimeExtension = new Promise(resolve => {
    resolveIdleTimeExtension = resolve;
  });
  evt.waitUntil(idleTimeExtension);
};

self.addEventListener('message', event => {
  // Message received from clients
  const { data } = event;
  console.log('service worker receive message: ', event.data);

  if (data.isDummy) {
    console.log('ignore this dummy message, wait for real result');
    return;
  }

  if (data.error) {
    this.handler.postError(data.result);
  } else {
    this.handler.postResult(data.result);
  }

  // should resolve() our idleTimeExtension promise here,
  // then service worker can be idle after 30000ms
  // or it will be idle after 3000ms + 300000ms
  if (resolveIdleTimeExtension) {
    resolveIdleTimeExtension();
    resolveIdleTimeExtension = null;
  }
});
