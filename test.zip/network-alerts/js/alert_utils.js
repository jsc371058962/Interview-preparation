'use strict';

const Utils = {
  DEBUG: true,
  name: 'alert_utils',

  debug(s) {
    if (this.DEBUG) {
      console.log(`-*- CMAS ${this.name} -*- ${s}`);
    }
  },

  setWakeLock(mode) {
    this.debug(`setWakeLock mode -> ${mode}`);
    switch (mode) {
      case 'cpu':
        this.cpuLock = navigator.b2g.requestWakeLock('cpu');
        break;
      case 'screen':
        this.screenLock = navigator.b2g.requestWakeLock('screen');
        break;
      default:
        this.cpuLock = navigator.b2g.requestWakeLock('cpu');
        this.screenLock = navigator.b2g.requestWakeLock('screen');
        break;
    }
  },

  async servicesInit() {
    const servicesArray = ['settingsService'];
    await window.libSession.initService(servicesArray);
    SettingsObserver.init();
    this.debug('servicesInit success');
  },

  clearWakeLock() {
    this.debug('clearWakeLock.');
    if (null !== this.screenLock) {
      this.screenLock.unlock();
      this.screenLock = null;
    }

    if (null !== this.cpuLock) {
      this.cpuLock.unlock();
      this.cpuLock = null;
    }
  },

  async getSettingsValue(key) {
    const value = await SettingsObserver.getValue(key);
    this.debug('key value is ' + value);
    return value;
  }
};
