'use strict';

(function (exports) {
  let Dialog = function () {
    this.element = document.getElementById('dialog-container');
    this.content = document.getElementById('dialog-content');
  };
  Dialog.prototype.show = function (l10nId, confirm, cancel) {
    this.l10nId = l10nId;
    this.cancelCallback = cancel;
    this.confirmCallback = confirm;
    this.content.setAttribute('data-l10n-id', l10nId);
    SoftkeyHelper.setSoftKey('dialog');
    this.element.classList.remove('hidden');
    this.element.focus();
  };

  Dialog.prototype.hide = function () {
    this.element.classList.add('hidden');
  };

  Dialog.prototype.cancel = function () {
    this.hide();
    this.cancelCallback && this.cancelCallback();
  };

  Dialog.prototype.confirm = function () {
    this.hide();
    this.confirmCallback && this.confirmCallback();
  };

  Dialog.prototype.isActive = function () {
    return !this.element.classList.contains('hidden');
  };

  exports.Dialog = new Dialog();
})(window);
