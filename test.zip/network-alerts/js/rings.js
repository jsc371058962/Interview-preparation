'use strict';

function BufferLoader(context, urlList, callback) {
  this.context = context;
  this.urlList = urlList;
  this.onload = callback;
  this.bufferList = [];
  this.loadCount = 0;
}

BufferLoader.prototype.loadBuffer = function (url, index) {
  // Load buffer asynchronously
  let request = new XMLHttpRequest();
  request.open('GET', url, true);
  request.responseType = 'arraybuffer';

  request.onload = () => {
    // Asynchronously decode the audio file data in request.response
    this.context.decodeAudioData(request.response, (buffer) => {
      if (!buffer) {
        alert(`error decoding file data: ${url}`);
        return;
      }
      this.bufferList[index] = buffer;
      if (++this.loadCount === this.urlList.length) {
        this.onload(this.bufferList);
      }
    });
  };

  request.onerror = () => {
    alert('BufferLoader: XHR error');
  };

  request.send();
};

BufferLoader.prototype.load = function () {
  for (let i = 0; i < this.urlList.length; ++i) {
    this.loadBuffer(this.urlList[i], i);
  }
};


class Rings {
  constructor() {
    this.DEBUG = true;
    this.name = 'Rings';
    this.forbidden_mute = false;
    this.sound_enable = true;
    this.vibrate_enable = true;
    this.volume = 0;
    this.volumeLevel = 15;
    this.audioOneFrequency = 853;
    this.audioTwoFrequency = 960;
    this.audioFrequencyPeriodic = 11;
    this.vibrateFrequencyMagnification = 500;
    this.telephony = window.navigator.b2g.telephony;
    this.ATTENTION_PATTERN = [4, 1, 2, 1, 2, 1, 4, 1, 2, 1, 2, 1];
    this.ATTENTION_CURVE_SCALE = 100;
    this.sound_sources = '../sounds/notifier_bells.opus';
    this.cmas_specifically_ring_key = false;
    this.cmas_sound_key = 'audio.volume.notification';
    this.cmas_vibrate_key = 'vibration.enabled';
    this.cmas_deputy_sound_key = 'cmas.volume.enable';
    this.cmas_deputy_vibrate_key = 'cmas.vibrate.enable';
  }

  debug(s) {
    if (this.DEBUG) {
      console.log(`-*- CMAS ${this.name} -*- ${s}`);
    }
  }

  getAttentionCurveWave() {
    let result = [];
    let currentValue = this.volume || 1;
    let sampleCount = 0;

    this.ATTENTION_PATTERN.forEach((duration) => {
    //  eslint-disable max-len
    /*
     *  Increase the attention curve's sample rate to avoid a gradual change of
     *  the volume, which can be introduced by linear interpolations between
     *  samples. See:
     *  https://developer.mozilla.org/en-US/docs/Web/API/AudioParam/setValueCurveAtTime
     */
      sampleCount = duration * this.ATTENTION_CURVE_SCALE;
      result.push(...Array(sampleCount).fill(currentValue));
      currentValue = this.volume - currentValue;
    });
    return new Float32Array(result);
  }

  ringingRemind(bSingleSound = false) {
    this.stopSoundAndVibrate();
    if (this.sound_enable) {
      if (bSingleSound) {
        this.playSingleSound();
        if (this.vibrate_enable) {
          this.vibrate();
        }
      } else {
        this.ringTone(this.vibrate_enable);
      }
    } else if (this.vibrate_enable) {
      this.vibrate();
    }
  }

  ringTone(synchronousVibrateAndBell) {
    const audioChannelName = this.forbidden_mute
      ? 'publicnotification' : 'notification';
    this.audioCtx = new AudioContext(audioChannelName);
    this.audioCtx.onstatechange = ((event) => {
      if (synchronousVibrateAndBell && 'running' === event.target.state) {
        this.vibrate();
      }
    });
    this.o1 = this.audioCtx.createOscillator();
    this.o2 = this.audioCtx.createOscillator();
    this.gainNode = this.audioCtx.createGain();

    let time = this.audioCtx.currentTime;
    this.o1.type = 'sine';
    this.o2.type = 'sine';
    this.o1.frequency.value = this.audioOneFrequency;
    this.o2.frequency.value = this.audioTwoFrequency;

    this.o1.start();
    this.o2.start();
    // Eventually stop the oscillator to allow garbage collecting.
    this.o1.stop(time + this.audioFrequencyPeriodic);
    this.o2.stop(time + this.audioFrequencyPeriodic);

    this.o2.onended = () => {
      window.dispatchEvent(new CustomEvent('ring-ended'));
    };

    let wave = this.getAttentionCurveWave();
    this.gainNode.gain.setValueCurveAtTime(wave,
      time, this.audioFrequencyPeriodic);
    this.o1.connect(this.gainNode);
    this.o2.connect(this.gainNode);
    this.gainNode.connect(this.audioCtx.destination);
  }

  vibrate() {
    let pattern = this.ATTENTION_PATTERN.map((value) => {
      return (value * this.vibrateFrequencyMagnification);
    });
    navigator.vibrate(pattern);
  }

  clearVibrateInterval() {
    navigator.vibrate(0);
  }

  getVolumeEnable() {
    return Utils.getSettingsValue(this.cmas_sound_key).then((volume) => {
      this.volume = volume / this.volumeLevel;
      if (!this.cmas_specifically_ring_key) {
        return Promise.resolve(volume);
      }

      return Utils.getSettingsValue(this.cmas_deputy_sound_key).then(
        (deputy_volume) => {
          if (volume && deputy_volume) {
            return Promise.resolve(deputy_volume);
          } else {
            return Promise.resolve(false);
          }
        });
    });
  }

  getVibrateEnable() {
    return Utils.getSettingsValue(this.cmas_vibrate_key).then((vibrate) => {
      if (!this.cmas_specifically_ring_key) {
        return Promise.resolve(vibrate);
      }

      return Utils.getSettingsValue(this.cmas_deputy_vibrate_key).then(
        (deputy_vibrate) => {
          if (vibrate && deputy_vibrate) {
            return Promise.resolve(deputy_vibrate);
          } else {
            return Promise.resolve(false);
          }
        });
    });
  }

  playSingleSound() {
    let finishedLoading = (bufferList) => {
      this.source.buffer = bufferList[0];
      this.source.loop = true;
      this.source.connect(this.gainNode);
      this.gainNode.connect(this.audioCtx.destination);
      this.source.start();
    };

    const audioChannelName = this.forbidden_mute
      ? 'publicnotification' : 'notification';
    this.audioCtx = new AudioContext(audioChannelName);
    this.source = this.audioCtx.createBufferSource();
    this.gainNode = this.audioCtx.createGain();
    let bufferLoader = new BufferLoader(this.audioCtx,
      [this.sound_sources], finishedLoading);
    bufferLoader.load();
  }

  stopSingleSound() {
    if (this.source && this.gainNode && this.audioCtx) {
      this.source.stop();
      this.source.disconnect(this.gainNode);
      this.gainNode.disconnect(this.audioCtx.destination);
    }
  }

  startSoundAndVibrate() {
    this.stopSoundAndVibrate();
    return Promise.all([
      this.getVolumeEnable(),
      this.getVibrateEnable()
    ]).then((results) => {
      this.sound_enable = this.forbidden_mute ? true : results[0];
      this.vibrate_enable = results[1];
      this.controlWakeLock();
      if (true === navigator.b2g.audioChannelManager.headphones) {
        this.ringingRemind(true);
      } else {
        this.checkTelephonyState();
      }
      this.handleDeviceStateChange();
    });
  }

  stopSoundAndVibrate() {
    this.stopSingleSound();
    this.clearVibrateInterval();
    if (this.o1 && this.o2 && this.gainNode && this.audioCtx) {
      this.o1.stop(this.audioCtx.currentTime);
      this.o2.stop(this.audioCtx.currentTime);
      this.gainNode.disconnect(this.audioCtx.destination);
      this.o1 = null;
      this.o2 = null;
      this.gainNode = null;
      this.audioCtx = null;
    }
  }

  checkTelephonyState() {
    if (this.telephony &&
        ((this.telephony.calls && this.telephony.calls.length > 0) ||
          (this.telephony.conferenceGroup &&
            this.telephony.conferenceGroup.calls &&
            this.telephony.conferenceGroup.calls.length > 0))) {
      this.debug('device current is telephony calls');
      let bVOLTE = false;
      if (this.telephony.calls.length > 0) {
        this.telephony.oncallschanged = () => {
          if (0 === this.telephony.calls.length) {
            this.ringingRemind();
          }
        };
        bVOLTE = 'Normal' !== this.telephony.calls[0].voiceQuality;
      }

      if (this.telephony.conferenceGroup.calls.length > 0) {
        this.telephony.conferenceGroup.oncallschanged = () => {
          if (0 === this.telephony.conferenceGroup.calls.length) {
            this.ringingRemind();
          }
        };
        bVOLTE =
          'Normal' !== this.telephony.conferenceGroup.calls[0].voiceQuality;
      }

      if (bVOLTE) {
        // VoLTE call state
        this.debug('device current is VoLTE telephony calls state');
        this.ringingRemind(true);
      } else {
        // Not VoLTE call state, temporarily mute the CMAS alert tone
        this.debug('device current is not VoLTE telephony calls state');
      }
    } else { // Not call state
      this.debug('device current is not telephony calls');
      this.handleCallsChanged();
      this.ringingRemind();
    }
  }

  handleCallsChanged() {
    this.telephony.addEventListener('callschanged', (event) => {
      if ('callschanged' !== event.type) {
        return;
      }

      this.telephony.calls.forEach((call) => {
        this.debug(`handleCallsChanged state : ${call.state}`);
        if ('incoming' === call.state) {
          this.stopSoundAndVibrate();
        }
      });
    });
  }

  handleDeviceStateChange() {
    if (navigator.b2g.audioChannelManager) {
      navigator.b2g.audioChannelManager.onheadphoneschange = () => {
        this.ringingRemind(navigator.b2g.audioChannelManager.headphones);
      };
    }
  }

  controlWakeLock() {
    Utils.setWakeLock();
    const delayTime = this.audioFrequencyPeriodic * 1000;
    setTimeout(() => {
      if (this.source && this.source.loop) {
        this.source.loop = false;
      }
      Utils.clearWakeLock();
    }, delayTime);
  }
}
