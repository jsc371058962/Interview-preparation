'use strict';

(function () {
  let messageData = null;
  let isInited = false;

  const doShowMessage = function ({ type, data, activityName }) {
    console.log(`-*- CMAS App -*- init with data: ${JSON.stringify(data)}`);
    Utils.getSettingsValue('locale.hour12').then(() => {
      switch (type) {
        case 'activity': {
          window.api.l10n.once(() => {
            if (activityName === 'alert_inbox') {
              Store.init(data);
              AlertBox.show();
            }
          });
          break;
        }
        case 'notification': {
          window.api.l10n.once(() => {
            AlertDetail.show(data, 'notice');
          });
          break;
        }
        case 'close-window':
          window.close();
          break;
        default:
          break;
      }
    });
  };

  Utils.servicesInit().then(() => {
    console.log('-*- CMAS App -*- services init done.');
    isInited = true;
    if (messageData) {
      doShowMessage(messageData);
    }
  });

  navigator.serviceWorker.addEventListener('message', (evt) => {
    console.log('-*- CMAS App -*- handle message data.');
    messageData = Object.assign({}, evt.data);
    if (isInited) {
      doShowMessage(messageData);
    }
  });
})();
