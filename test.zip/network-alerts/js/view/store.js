'use strict';

(function (exports) {
  let Store = function () {
    this.DEBUG = true;
    this.name = 'Store';
    this.map = new Map();
    this.expireTime = 24 * 60 * 60 * 1000;
  };

  Store.prototype.debug = function (s) {
    if (this.DEBUG) {
      console.log(`-*- CMAS ${this.name} -*- ${s}`);
    }
  };

  Store.prototype.getAllData = function () {
    this.debug(`[Store] this.map.size: ${this.map.size}`);
    return [...this.map.values()];
  };

  // A adta cache for activity to delete or other .
  Store.prototype.init = function (data) {
    if (Array.isArray(data)) {
      data.forEach((item) => {
        this.map.set(item.id, item);
      });
    }
  };

  Store.prototype.getItem = function (id) {
    return new Promise((resolve) => {
      if (this.map.get(+id)) {
        resolve(this.map.get(+id));
      } else {
        resolve();
      }
    });
  };

  exports.Store = new Store();
})(window);
