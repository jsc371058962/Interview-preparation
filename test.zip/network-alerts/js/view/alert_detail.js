'use strict';

(function (exports) {
  const AlertDetail = function () {
    this.name = 'AlertDetail';
    this.screen = document.getElementById('alert-detail');
    this.inboxscreen = document.getElementById('inbox-screen');
    this.content = document.getElementById('alert-content');
    this.content.addEventListener('keydown', this.handleKeyDown.bind(this));
  };

  AlertDetail.prototype.show = function (msg, type) {
    this.screen.classList.remove('hidden');
    let title = document.getElementById('alert-title');
    let date = document.getElementById('alert-date');
    this.id = msg.id;
    title.textContent = window.api.l10n.get(msg.messageType);
    date.textContent = ViewUtils.getDate(msg.timestamp);
    this.content.textContent = msg.body;
    this.showSoftkey(type);
    ViewUtils.linkingContent(this.content);
    this.content.focus();
    this.checkLink();
  };

  AlertDetail.prototype.checkLink = function () {
    let link = this.content.querySelectorAll('.kai-external-link');
    if (link.length > 0) {
      link[0].focus();
      link[0].classList.add('focus');
    }
  };

  AlertDetail.prototype.isShown = function () {
    return !this.screen.classList.contains('hidden');
  };

  AlertDetail.prototype.showPage = function () {
    this.content.focus();
    SoftkeyHelper.setSoftKey('detail');
  };

  AlertDetail.prototype.hide = function () {
    this.screen.classList.add('hidden');
  };

  AlertDetail.prototype.showAlertBox = function () {
    this.hide();
    this.inboxscreen.classList.remove('hidden');
    AlertBox.showBox();
  };

  AlertDetail.prototype.deleteCB = function () {
    AlertBox.deleteMessage([this.id]);
    AlertBox.showBox();
  };

  AlertDetail.prototype.deleteCancelCB = function () {
    this.screen.classList.remove('hidden');
    this.content.focus();
    SoftkeyHelper.setSoftKey(this.softkeyType);
  };

  AlertDetail.prototype.showSoftkey = function (type) {
    if (type === 'notice') {
      SoftkeyHelper.init();
      this.softkeyType = 'notice-detail';
    } else {
      this.softkeyType = 'detail';
    }
    SoftkeyHelper.setSoftKey(this.softkeyType);
  };

  AlertDetail.prototype.handleKeyDown = function (event) {
    switch (event.key) {
      case 'BrowserBack':
      case 'Backspace':
        if (this.softkeyType === 'notice-detail') {
          window.close();
          break;
        }
        event.preventDefault();
        event.stopPropagation();
        this.showAlertBox();
        break;
      case 'ArrowUp':
      case 'ArrowDown':
        ViewUtils.scrollBar(event.key, true);
        break;
      default:
        break;
    }
  };
  exports.AlertDetail = new AlertDetail();
})(window);
