/* eslint-disable max-len */

'use strict';

(function (exports) {
  let ViewUtil = function () {
    this.topOffset = 0;
    this.maxY = 0;
    this.DEBUG = true;
    this.scrollElement = document.getElementById('alert-content');
    this.originPage = true;
    this.URL_PROTOCOL = /(https?:\/\/|rtsp:\/\/)/g;
  };

  ViewUtil.prototype.debug = function (s) {
    if (this.DEBUG) {
      console.log(`-*- CMAS ${this.name} -*- ${s}`);
    }
  };

  ViewUtil.prototype.getDate = function (d) {
    let dateFormat = new Date(d);
    let options = {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: window.api.hour12
    };

    return dateFormat.toLocaleString(navigator.language, options);
  };

  ViewUtil.prototype.linkingContent = function (container) {
    const RE_URL = /(^|[\s(,;])((?:https?:\/\/|www\d{0,3}[.][a-z0-9.-]{2,249}|[a-z0-9.-]{2,250}[.][a-z]{2,4}\/)[-\w.!~*'();,/?:@&=+$#%]*)/im;
    const RE_UN_EAT_LAST_URL_CHARS = /(?:[),;.!?]|[.!?]\)|\)[.!?])$/;
    const RE_MAIL = /(^|[\s(,;<>])([^(,;<>@\s]+@[a-z0-9.-]{2,250}[.][a-z0-9-]{2,32})/im;
    const RE_PHONE = /(?:\+\d{1,4}[ \t.()-]{0,3}|\()?(?:\d{1,4}[ \t.()-]{0,3})?(?:\d[\d \t.()-]{0,12}\d)\b/i;
    const safeStart = /[\s,:;(>\u0080-\uFFFF]/;
    const MINIMUM_DIGITS_IN_PHONE_NUMBER = 5;

    let content = container.textContent;
    let nodes = [];
    let contentStart;
    let link;
    let text;

    while (true) {
      let url = RE_URL.exec(content);
      let email = RE_MAIL.exec(content);
      let phone = RE_PHONE.exec(content);
      Utils.getSettingsValue('accessibility.screenreader').then((value) => {
        value && (url || email || phone) && container.setAttribute('role', 'menuitem');
      });

      if (
        url &&
        (!email || url.index < email.index) &&
        (!phone || url.index < phone.index)
      ) {
        contentStart = url.index + url[1].length;
        if (contentStart > 0) {
          nodes.push(
            document.createTextNode(content.substring(0, contentStart))
          );
        }

        let useUrl = url[2];
        let unEat = RE_UN_EAT_LAST_URL_CHARS.exec(useUrl);
        if (unEat) {
          useUrl = useUrl.substring(0, unEat.index);
        }

        link = document.createElement('a');
        link.className = 'kai-external-link';
        link.setAttribute('ext-tag', 'url');
        text = document.createTextNode(useUrl);
        link.appendChild(text);
        nodes.push(link);
        content = content.substring(url.index + url[1].length + useUrl.length);
      } else if (email && (!phone || email.index < phone.index)) {
        contentStart = email.index + email[1].length;
        if (contentStart > 0) {
          nodes.push(
            document.createTextNode(content.substring(0, contentStart))
          );
        }
        link = document.createElement('a');
        link.className = 'kai-external-link';
        link.setAttribute('ext-tag', 'mail');
        text = document.createTextNode(email[2]);
        link.appendChild(text);
        nodes.push(link);
        content = content.substring(email.index + email[0].length);
      } else if (phone) {
        contentStart = phone.index;
        let createTextNode = (text) => {
          if (text) {
            let pos = contentStart + text.length;
            let nodeText = content.substring(0, pos);
            nodes.push(document.createTextNode(nodeText));
            content = content.substring(pos);
          }
        };

        if (phone[0].length > MINIMUM_DIGITS_IN_PHONE_NUMBER) {
          let rest = content.slice(contentStart + phone[0].length);
          if (
            (rest.length && !safeStart.test(rest.charAt(0))) ||
            (contentStart > 0 &&
              !safeStart.test(content.charAt(contentStart - 1)))
          ) {
            createTextNode(phone[0]);
            continue;
          }
          if (contentStart > 0) {
            nodes.push(
              document.createTextNode(content.substring(0, contentStart))
            );
          }

          link = document.createElement('a');
          link.className = 'kai-external-link';
          link.setAttribute('ext-tag', 'call');
          text = document.createTextNode(phone[0]);
          link.appendChild(text);
          nodes.push(link);
          content = content.substring(phone.index + phone[0].length);
        } else {
          createTextNode(phone[0]);
        }
      } else {
        break;
      }
    }

    let html = '';
    nodes.forEach((node) => {
      html += node.outerHTML ? node.outerHTML : node.textContent;
    });
    if (html.length) {
      container.innerHTML = html;
    }
  };

  ViewUtil.prototype.openLink = function (type, content) {
    let name;
    let data;
    switch (type) {
      case 'call':
        name = 'dial';
        data = {
          type: 'webtelephony/number',
          number: content
        };
        break;
      case 'mail':
        name = 'new';
        data = {
          type: 'mail',
          URI: `mailto:${content}`
        };
        break;
      case 'url':
        let urlHasProtocol = this.URL_PROTOCOL.test(content);
        if (!urlHasProtocol) {
          content = `http://${content}`;
        }
        name = 'view';
        data = {
          type: 'url',
          url: content
        };
        break;
      default:
        break;
    }

    return this.removeAlarm().then(() => {
      const activity = new window.WebActivity(name, data);
      const activityDone = () => {
        if (this.originPage) {
          Optionmenu.hide();
          AlertDetail.showPage();
        }
      };
      activity.start().then(activityDone, activityDone);
    });
  };

  ViewUtil.prototype.removeAlarm = function () {
    return new Promise((resolve) => {
      navigator.b2g.alarmManager
        .getAll()
        .then((value) => {
          let alarms = value;
          if (!alarms) {
            alarms = [];
          }
          alarms.forEach((alarm) => {
            if (
              alarm.data &&
              alarm.data.type === 'remind' &&
              'WEA' === alarm.data.alarmType
            ) {
              navigator.b2g.alarmManager.remove(alarm.id);
            }
          });
          resolve();
        })
        .catch((error) => {
          throw new Error(`${error}`);
        });
    });
  };

  ViewUtil.prototype.dismissFocus = function (container) {
    let focused = container.querySelectorAll('.focus');
    for (let i = 0; i < focused.length; i++) {
      focused[i].classList.remove('focus');
    }
  };

  ViewUtil.prototype.cFocusNodeInVisibleArea = function (
    container,
    direction,
    dValue
  ) {
    let index = 0;
    let sTagElements = container.querySelectorAll('.kai-external-link');

    if (sTagElements.length <= 0) {
      container.focus();
    } else {
      sTagElements.forEach((item, i) => {
        if (item.classList.contains('focus')) {
          index = i;
        }
      });
      if (!this.originPage) {
        SoftkeyHelper.setSoftKey('main');
      }
    }

    // Get visual area offset
    let seeOffsetTop = container.offsetTop;
    // Get the height of the sliding area
    let scrollTop = container.scrollTop ? container.scrollTop : 0;

    this.dismissFocus(container);

    switch (direction) {
      case 'ArrowUp':
        for (let i = index; i >= 0; i--) {
          let offset =
            sTagElements[i].offsetTop - seeOffsetTop - scrollTop + dValue;
          if (offset >= 0 && offset <= seeOffsetTop) {
            if (i > 0) {
              sTagElements[--index].classList.add('focus');
              sTagElements[index].focus();
            } else {
              index = 0;
              sTagElements[index].classList.add('focus');
              sTagElements[index].focus();
            }
            break;
          }
        }
        break;
      case 'ArrowDown':
        for (let i = index; i <= sTagElements.length - 1; i++) {
          let offset =
            sTagElements[i].offsetTop - seeOffsetTop - scrollTop + dValue;
          if (offset >= 0 && offset <= seeOffsetTop) {
            if (i < sTagElements.length - 1) {
              sTagElements[++index].classList.add('focus');
              sTagElements[index].focus();
            } else {
              index = sTagElements.length - 1;
              sTagElements[index].classList.add('focus');
              sTagElements[index].focus();
            }
            break;
          }
        }
        break;
      default:
        break;
    }
  };

  ViewUtil.prototype.operatorMessageExtractionSelectKey = function () {
    let operatorSelectKey = '';
    let focusedElement = this.scrollElement.querySelector('.focus');
    if (focusedElement) {
      let focusedElementName = focusedElement.getAttribute('ext-tag');
      switch (focusedElementName) {
        case 'mail':
          operatorSelectKey = 'open-mailbox';
          break;
        case 'url':
          operatorSelectKey = 'open-web';
          break;
        case 'call':
          operatorSelectKey = 'open-dial';
          break;
        default:
          break;
      }
    }
    return operatorSelectKey;
  };

  ViewUtil.prototype.scrollBar = function (key, notAttention) {
    this.originPage = notAttention;
    this.scrollElement = document.getElementById('alert-content');
    let step = Math.ceil(this.scrollElement.clientHeight / 5);
    switch (key) {
      case 'ArrowUp':
        if (this.topOffset - step >= 0) {
          this.topOffset -= step;
        } else {
          this.topOffset = 0;
        }
        this.scrollElement.scrollTop = this.topOffset;
        break;
      case 'ArrowDown':
        this.maxY =
          this.scrollElement.scrollHeight - this.scrollElement.offsetHeight;
        if (this.topOffset + step <= this.maxY) {
          this.topOffset += step;
        } else {
          this.topOffset = this.maxY;
        }
        this.scrollElement.scrollTop = this.topOffset;
        break;
      default:
        break;
    }
    if (this.scrollElement.contains(document.activeElement)) {
      document.activeElement.scrollIntoView(true);
    }

    this.cFocusNodeInVisibleArea(this.scrollElement, key, step);
  };

  ViewUtil.prototype.showToaster = function (items) {
    Toaster.showToast({ messageL10nId: items.length > 1 ? 'multiple-deleted' : 'single-deleted' });
  };
  exports.ViewUtils = new ViewUtil();
})(window);
