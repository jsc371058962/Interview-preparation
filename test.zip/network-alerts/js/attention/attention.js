'use strict';

(function (exports) {
  let Attentions = function () {
    this.DEBUG = true;
    this.name = 'Attention';
    this.alertContent = document.getElementById('alert-content');
    this.alertBody = document.getElementById('alert-body');
    document.body.classList.toggle('large-text', navigator.largeTextEnabled);
  };

  Attentions.prototype.debug = function (s) {
    if (this.DEBUG) {
      console.log(`-*- CMAS ${this.name} -*- ${s}`);
    }
  };

  Attentions.prototype.startSoundAndVib = function () {
    this.rings.stopSoundAndVibrate();
    this.rings.startSoundAndVibrate();
  };

  Attentions.prototype.init = function (msg, needRing) {
    this.debug(`It's time to lighten screen, vibrate and sound.`);
    if (!this.rings) {
      this.rings = new Rings();
    }
    needRing && this.startSoundAndVib();
    this.id = msg.id;
    this.msgDate = Number.parseInt(msg.timestamp);
    this.debug(`[Attentions][init] init: this.msgDate: ${this.msgDate}`);
    let alertTitle = document.getElementById('alert-title');
    let alertDate = document.getElementById('alert-date');

    window.api.l10n.once(() => {
      SoftkeyHelper.init();
      SoftkeyHelper.setSoftKey('attention-init');
      alertTitle.textContent = window.api.l10n.get(msg.messageType);
      alertDate.textContent = ViewUtils.getDate(this.msgDate);
      this.alertContent.textContent = msg.body;
      // Obtain url, email, dial.
      ViewUtils.linkingContent(this.alertContent);
      window.addEventListener('ring-ended', () => {
        if (document.activeElement === document.body) {
          this.alertContent.focus();
        }
      });
      this.checkLink();
    });
    document.addEventListener('keydown', this.handleKeyDown.bind(this));
  };

  Attentions.prototype.checkLink = function () {
    const link = this.alertContent.querySelectorAll('.kai-external-link');
    if (link.length > 0) {
      link[0].focus();
      link[0].classList.add('focus');
      SoftkeyHelper.setSoftKey('main');
    }
  };

  Attentions.prototype.handleKeyDown = function (e) {
    switch (e.key) {
      case 'BrowserBack':
      case 'Backspace':
        if (Optionmenu.isActive()) {
          Optionmenu.hide();
          SoftkeyHelper.setSoftKey('main');
        } else {
          this.closeAttentionWindow();
        }
        break;
      case 'ArrowUp':
      case 'ArrowDown':
        ViewUtils.scrollBar(e.key, false);
        break;
      default:
        break;
    }
  };

  Attentions.prototype.parseMessage = function (input) {
    const rParams = /([^?=&]+)(?:=([^&]*))?/g;
    input = input || window.location.href;

    let parsed = {};
    input.replace(rParams, ($0, $1, $2) => {
      parsed[decodeURIComponent($1)] = $2 ? decodeURIComponent($2) : $2;
    });

    return parsed;
  };

  Attentions.prototype.closeAttentionWindow = function () {
    this.debug(`closeAttentionWindow timestamp -> ${this.msgDate}`);
    navigator.serviceWorker.controller.postMessage({
      type: 'close-attention-window',
      timestamp: this.msgDate
    });
  };

  exports.Attention = new Attentions();
})(window);
