'use strict';

(function () {
  navigator.serviceWorker.addEventListener('message', async (evt) => {
    await Utils.servicesInit();
    Utils.getSettingsValue('locale.hour12').then(() => {
      const { data, type, needRing = true } = evt.data;
      switch (type) {
        case 'cellbroadcast-received':
        case 'alarm':
          Attention.init(data, needRing);
          break;
        case 'close-window':
          window.close();
          break;
        case 'start-rings':
          Attention.startSoundAndVib();
          break;
        default:
          break;
      }
    });
  });
})();
