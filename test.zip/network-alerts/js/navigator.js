'use strict';

(function (exports) {
  let NavigationHelper = function () {
    this.initialFocusIndex = 0;
    this.preveFocusIndex = 0;
    this.loopable = true;
  };

  NavigationHelper.prototype.init = function (selector, element) {
    this.selector = selector;
    this.element = element;
    this.element.addEventListener('keydown', this.onKeyDown.bind(this));
  };

  NavigationHelper.prototype.setFocus = function (element, noFocus) {
    if (!element) {
      return;
    }
    this.dismissFocus();
    this.currentFocus = element;

    if (noFocus) {
      return;
    }
    this.scrollIntoView(element);
    element.classList.add('focus');
    element.focus();
  };

  NavigationHelper.prototype.dismissFocus = function () {
    let focused = this.element.querySelectorAll('.focus');
    for (let i = 0; i < focused.length; i++) {
      focused[i].classList.remove('focus');
    }
  };

  NavigationHelper.prototype.getpreveFocus = function () {
    for (let i = 0; i < this.candidates.length; i++) {
      if (this.candidates[i].className.indexOf('focus') !== -1) {
        this.preveFocusIndex = i;
        return;
      } else {
        this.preveFocusIndex = this.initialFocusIndex;
      }
    }
  };

  NavigationHelper.prototype.destroy = function () {
    if (!this.element) {
      return;
    }
    this.element.removeEventListener('keydown', this);
    this.element.removeEventListener('focus', this);
    this.candidates = [];
    this.currentFocus = null;
    this.element.activeElement = null;
    this.element = null;
  };

  NavigationHelper.prototype.updateCandidates = function () {
    this.candidates = Array.from(this.element.querySelectorAll(this.selector));

    this.getpreveFocus();
    this.preveFocusIndex !== 0
      ? this.setFocus(this.candidates[this.preveFocusIndex])
      :this.setFocus(this.candidates[this.initialFocusIndex]);
    let i = this.candidates.length;
    while (i--) {
      if (this.isHidden(this.candidates[i])) {
        this.candidates.splice(i, 1);
      }
    }

  };

  NavigationHelper.prototype.isHidden = function (elem) {
    let hidden = false;
    while (elem !== document.body) {
      if (getComputedStyle(elem) &&
          getComputedStyle(elem).display === "none") {
        hidden = true;
        break;
      }
      elem = elem.parentNode;
    }
    return hidden;
  };

  NavigationHelper.prototype.onKeyDown = function (evt) {
    let nextFocus = null;
    let handled = false;

    switch (evt.key) {
      case 'ArrowDown':
        handled = true;
        nextFocus = this.findNext();
        break;
      case 'ArrowUp':
        handled = true;
        nextFocus = this.findPrev();
        break;
      default:
        break;
    }
    if (nextFocus) {
      this.currentFocus = nextFocus;
      if (this.element) {
        this.element.activeElement = nextFocus;
        requestAnimationFrame(() => {
          ViewUtils.dismissFocus(this.element);
          this.setFocus(nextFocus);
          nextFocus.focus();
        });
      }
    } else {
      if (this.element) {
        this.element.activeElement = this.currentFocus;
        requestAnimationFrame(() => {
          ViewUtils.dismissFocus(this.element);
          this.setFocus(this.currentFocus);
          this.currentFocus.focus();
        });
      }
    }

    if (handled) {
      evt.stopPropagation();
      evt.preventDefault();
    }
  };

  NavigationHelper.prototype.scrollIntoView =
  function (element, alignToTop = false) {
    if (!element) {
      return;
    }
    if (this.scrollSelector) {
      let target = element;
      let found = false;
      while (target !== document.body) {
        if (target.matches(this.scrollSelector)) {
          found = true;
          target.scrollIntoView(false);
          break;
        }
        target = target.parentNode;
      }
      if (!found) {
        // In case the parent does no exist.
        element.scrollIntoView(alignToTop);
      }
    } else {
      element.scrollIntoView(alignToTop);
    }
  };

  NavigationHelper.prototype.getInitialFocus = function () {
    let candidates = this.candidates;
    if (!candidates.length) {
      return null;
    }
    return candidates[this.initialFocusIndex];
  };

  NavigationHelper.prototype.getElementIndex = function (element) {
    let candidates = this.candidates;
    if (!candidates || !candidates.length || !element) {
      return 0;
    }
    let elementIndex = 0;
    candidates.some((dom, index) => {
      if (dom === element) {
        elementIndex = index % candidates.length;
        return true;
      } else {
        return false;
      }
    });
    return elementIndex;
  };

  NavigationHelper.prototype.findNext = function (element) {
    if (!this.candidates || !this.candidates.length) {
      return null;
    }
    element = element || document.activeElement;
    let candidates = this.candidates;
    let next = 0;
    candidates.some((dom, index) => {
      if (dom === element) {
        next = (index + 1) % candidates.length;
        return true;
      } else {
        return false;
      }
    });
    if (!candidates[next] && !this.loopable) {
      return null;
    }
    return candidates[next] || candidates[this.initialFocusIndex];
  };

  NavigationHelper.prototype.findPrev = function (element) {
    element = element || document.activeElement;
    let candidates = this.candidates;
    if (!candidates.length) {
      return null;
    }
    let next = null;
    candidates.some((dom, index) => {
      if (dom === element) {
        next = ((candidates.length + index) - 1) % candidates.length;
        if (!this.loopable && 0 === index) {
          next = null;
        }
        return true;
      } else {
        return false;
      }
    });
    if (!candidates[next] && !this.loopable) {
      return null;
    }
    return candidates[next] || candidates[this.initialFocusIndex];
  };
  exports.NavigationHelper = new NavigationHelper();
})(window);
