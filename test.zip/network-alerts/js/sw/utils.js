'use strict';

const GSM_CMAS_LOWER_BOUND = 4370; // 0x1112
const GSM_CMAS_UPPER_BOUND = 4400; // 0x1130
const CDMA_CMAS_LOWER_BOUND = 4096; // 0x1000
const CDMA_CMAS_UPPER_BOUND = 4351; // 0x10FF
const GSM_CMAS_EXTERNAL_LANGUAGE_SUPPORT_LOWER_BOUND = 4383;
const GSM_CMAS_EXTERNAL_LANGUAGE_SUPPORT_UPPER_BOUND = 4395;
const ETWS_WARNINGTYPE_EARTHQUAKE = 4352; // 0x1100 Earthquake warning!
const ETWS_WARNINGTYPE_TSUNAMI = 4353; // 0x1101 Tsunami waring!
const ETWS_WARNINGTYPE_EARTHQUAKE_TSUNAMI = 4354;
// 0x1102 Earthquake-tsunami warning!
const ETWS_WARNINGTYPE_TEST = 4355; // 0x1103 Test emergency warning!
const ETWS_WARNINGTYPE_OTHER = 4356; // 0x1104 Other emergency warning!
const ETWS_WARNINGTYPE_EXTENSION_LOWER_BOUND = 4357;
// 0x1105 Future extension warning
const ETWS_WARNINGTYPE_EXTENSION_UPPER_BOUND = 4359;
// 0x1107 Future extension warning
const MESSAGE_EVENT_TYPES = {
  ACTIVITY: 'activity',
  ALARM: 'alarm',
  NOTIFICATION: 'notification',
  CELLBROADCAST_RECEIVED: 'cellbroadcast-received',
  REMOVE_MESSAGE: 'remove-message',
  CLOSE_ATTENTION_WINDOW: 'close-attention-window'
};

const Utils = {
  DEBUG: true,
  name: 'utils',
  expireTime: 24 * 60 * 60 * 1000,

  // CMAS Type , String Id
  preAlert: 'presidential-alert',
  extremeAlert: 'extreme-alert',
  severeAlert: 'severe-alert',
  amberAlert: 'amber-alert',
  rmtTestAlert: 'rmt-alert',
  exerciseAlert: 'exercise-alert',
  operatorAlert: 'operator-alert',
  safetyAlert: 'public-safety-alert',
  localWEATest: 'wea-test',
  unknownAlert: 'unknown-alert',

  // Settings value, presidential alert always enabled.
  CMAS_ENABLED_KEY: 'cmas.enabled',
  CMAS_PRESIDENTIAL_ENABLED_KEY: 'cmas.presidential.enabled',
  CMAS_EXTREME_ENABLED_KEY: 'cmas.extreme.enabled',
  CMAS_SEVERE_ENABLED_KEY: 'cmas.severe.enabled',
  CMAS_AMBER_ENABLED_KEY: 'cmas.amber.enabled',
  CMAS_RMT_TEST_ENABLED_KEY: 'cmas.monthlytest.enabled',
  CMAS_EXERCISE_ENABLED_KEY: 'cmas.exercise.enabled',
  CMAS_OPERATOR_ENABLED_KEY: 'cmas.operator.enabled',
  CMAS_SAFETY_ENABLED_KEY: 'cmas.safety.enabled',
  CMAS_WEA_TEST_ENABLED_KEY: 'cmas.weatest.enabled',
  CMAS_MULTI_LANGUAGE_SUPPORT_KEY: 'cmas.multi.language.support',

  // GMS messageId, See GSM[1] section 9.4.1.2.2 Message Identifier
  GSM_PRESIDENTIAL_ALERTS: [4370, 4383],
  GSM_EXTREME_THREAT_ALERTS: [4371, 4372, 4384, 4385],
  GSM_SEVERE_THREAT_ALERTS: [
    4373, 4374, 4375, 4376,
    4377, 4378, 4386, 4387,
    4388, 4389, 4390, 4391
  ],
  GSM_CHILD_ABDUCTION_EMERGENCY_ALERTS: [4379, 4392],
  GSM_RMT_TEST_ALERTS: [4380, 4393],
  GSM_EXERCISE_ALERTS: [4381, 4394],
  GSM_OPERATOR_ALERTS: [4382, 4395],
  GSM_SAFETY_ALERTS: [4396, 4397],
  GSM_LOACAL_WEA_TEST: [4398, 4399],

  // CDMA messageId, CDMA[2] section 9.3.3 Commercial Mobile for CMAS alerts
  CDMA_PRESIDENTIAL_ALERTS: 0x1000,
  CDMA_EXTREME_THREAT_ALERTS: 0x1001,
  CDMA_SEVERE_THREAT_ALERTS: 0x1002,
  CDMA_CHILD_ABDUCTION_EMERGENCY_ALERTS: 0x1003,
  CDMA_TEST_ALERTS: 0x1004,

  debug(s) {
    if (this.DEBUG) {
      console.log(`-*- CMAS ${this.name} -*- ${s}`);
    }
  },

  isGSMMsg(message) {
    let serviceCategory = message.cdmaServiceCategory;
    return !serviceCategory || (-1 === serviceCategory);
  },

  isWEAMsg(message) { // WEA
    if (message.cdmaServiceCategory) {
      return (message.cdmaServiceCategory >= CDMA_CMAS_LOWER_BOUND &&
              message.cdmaServiceCategory <= CDMA_CMAS_UPPER_BOUND);
    } else {
      return (message.messageId >= GSM_CMAS_LOWER_BOUND &&
              message.messageId < GSM_CMAS_UPPER_BOUND);
    }
  },

  isETWSAlert(message) { // ETWS
    if (message.etws) {
      return (message.messageId === ETWS_WARNINGTYPE_EARTHQUAKE ||
             message.messageId === ETWS_WARNINGTYPE_TSUNAMI ||
             message.messageId === ETWS_WARNINGTYPE_EARTHQUAKE_TSUNAMI ||
             message.messageId === ETWS_WARNINGTYPE_TEST ||
             message.messageId === ETWS_WARNINGTYPE_OTHER ||
             (message.messageId >= ETWS_WARNINGTYPE_EXTENSION_LOWER_BOUND &&
             message.messageId <= ETWS_WARNINGTYPE_EXTENSION_UPPER_BOUND));
    } else {
      return false;
    }
  },

  isEmergencyAlert(message) {
    return this.isWEAMsg(message) || this.isETWSAlert(message);
  },

  isSupportMultiLanguage(message) {
    let supportMultiLanguage = false;
    if (this.isGSMMsg(message)) {
      supportMultiLanguage =
        message.messageId >= GSM_CMAS_EXTERNAL_LANGUAGE_SUPPORT_LOWER_BOUND &&
        message.messageId <= GSM_CMAS_EXTERNAL_LANGUAGE_SUPPORT_UPPER_BOUND;
    }
    return supportMultiLanguage;
  },

  isPresidentialAlert(message) {
    return this.GSM_PRESIDENTIAL_ALERTS.indexOf(message.messageId) !== -1 ||
           message.cdmaServiceCategory === this.CDMA_PRESIDENTIAL_ALERTS;
  },

  async isCmasEnabled(message) {
    let cardIndex = message.serviceId || 0;
    const result = await this.getSettingsValue(this.CMAS_ENABLED_KEY);
    return !!(result[cardIndex]);
  },

  onlyGetCmasMessageInfo(message) {
    let info = {};
    const messageId = message.messageId;
    const isGSM = this.isGSMMsg(message);
    const cdmaServiceCategory = message.cdmaServiceCategory;
    if (this.isPresidentialAlert(message)) {
      info.type = this.preAlert;
      info.key = this.CMAS_PRESIDENTIAL_ENABLED_KEY;
    } else {
      if (isGSM) {
        if (this.GSM_EXTREME_THREAT_ALERTS.indexOf(messageId) !== -1) {
          info.type = this.extremeAlert;
          info.key = this.CMAS_EXTREME_ENABLED_KEY;
        } else if (this.GSM_SEVERE_THREAT_ALERTS.indexOf(messageId) !== -1) {
          info.type = this.severeAlert;
          info.key = this.CMAS_SEVERE_ENABLED_KEY;
        } else if (
          this.GSM_CHILD_ABDUCTION_EMERGENCY_ALERTS.indexOf(messageId) !== -1) {
          info.type = this.amberAlert;
          info.key = this.CMAS_AMBER_ENABLED_KEY;
        } else if (this.GSM_RMT_TEST_ALERTS.indexOf(messageId) !== -1) {
          info.type = this.rmtTestAlert;
          info.key = this.CMAS_RMT_TEST_ENABLED_KEY;
        } else if (this.GSM_EXERCISE_ALERTS.indexOf(messageId) !== -1) {
          info.type = this.exerciseAlert;
          info.key = this.CMAS_EXERCISE_ENABLED_KEY;
        } else if (this.GSM_OPERATOR_ALERTS.indexOf(messageId) !== -1) {
          info.type = this.operatorAlert;
          info.key = this.CMAS_OPERATOR_ENABLED_KEY;
        } else if (this.GSM_SAFETY_ALERTS.indexOf(messageId) !== -1) {
          info.type = this.safetyAlert;
          info.key = this.CMAS_SAFETY_ENABLED_KEY;
        } else if (this.GSM_LOACAL_WEA_TEST.indexOf(messageId) !== -1) {
          info.type = this.localWEATest;
          info.key = this.CMAS_WEA_TEST_ENABLED_KEY;
        } else {
          info.key = this.unknownAlert;
        }
      } else {
        if (cdmaServiceCategory === this.CDMA_EXTREME_THREAT_ALERTS) {
          info.type = this.extremeAlert;
          info.key = this.CMAS_EXTREME_ENABLED_KEY;
        } else if (cdmaServiceCategory === this.CDMA_SEVERE_THREAT_ALERTS) {
          info.type = this.severeAlert;
          info.key = this.CMAS_SEVERE_ENABLED_KEY;
        } else if (
          cdmaServiceCategory === this.CDMA_CHILD_ABDUCTION_EMERGENCY_ALERTS) {
          info.type = this.amberAlert;
          info.key = this.CMAS_AMBER_ENABLED_KEY;
        } else if (cdmaServiceCategory === this.CDMA_TEST_ALERTS) {
          info.type = this.rmtTestAlert;
          info.key = this.CMAS_RMT_TEST_ENABLED_KEY;
        } else {
          info.key = this.unknownAlert;
        }
      }
    }

    return info;
  },

  async getCmasMessageInfo(message) {
    let info = this.onlyGetCmasMessageInfo(message);
    if (this.isSupportMultiLanguage(message)) {
      let multiLanguageSupportKey = this.CMAS_MULTI_LANGUAGE_SUPPORT_KEY;
      const result = await this.getSettingsValue(multiLanguageSupportKey);
      this.debug(`isSupportExternalLanguage -> ${result}`);
      if (!!result || (result === undefined)) { // True or undefined
        return this.checkSpecificTypeMessage(info);
      } else { // False
        info.receive = false;
        return info;
      }
    } else { // (CMDA, English) (GSM, English)
      return this.checkSpecificTypeMessage(info);
    }
  },

  async checkSpecificTypeMessage(m_info) {
    if (m_info.key !== this.unknownAlert) {
      let result = await this.getSettingsValue(m_info.key);
      if (result === undefined) {
        result = m_info.type !== this.rmtTestAlert &&
          m_info.type !== this.exerciseAlert &&
          m_info.type !== this.operatorAlert &&
          m_info.type !== this.localWEATest;
      }
      m_info.receive = result;
      return m_info;
    } else {
      this.debug('cellbroadcast message type is unknown.');
      return m_info;
    }
  },

  isSameMsgId(message_old, message_new) {
    let isSame = false;
    if (message_new.messageId) {
      isSame = (message_old.messageId === message_new.messageId);
    }
    return isSame;
  },

  isSameMsgSerialNumber(message_old, message_new) {
    let isSame = false;
    if (message_new.messageCode) {
      isSame = (message_old.messageCode === message_new.messageCode);
    }
    return isSame;
  },

  isSameMsg(message_old, message_new, bGsm) {
    if (bGsm) {
      return this.isSameMsgId(message_old, message_new) &&
             this.isSameMsgSerialNumber(message_old, message_new);
    } else {
      return this.isSameMsgId(message_old, message_new);
    }
  },

  setWakeLock(mode) {
    this.debug(`setWakeLock mode -> ${mode}`);
    switch (mode) {
      case 'cpu':
        this.cpuLock = navigator.b2g.requestWakeLock('cpu');
        break;
      case 'screen':
        this.screenLock = navigator.b2g.requestWakeLock('screen');
        break;
      default:
        this.cpuLock = navigator.b2g.requestWakeLock('cpu');
        this.screenLock = navigator.b2g.requestWakeLock('screen');
        break;
    }
  },

  async servicesInit() {
    const servicesArray = ['settingsService'];
    await window.libSession.initService(servicesArray);
    SettingsObserver.init();
    this.debug('servicesInit success');
  },

  clearWakeLock() {
    this.debug('clearWakeLock.');
    if (null !== this.screenLock) {
      this.screenLock.unlock();
      this.screenLock = null;
    }

    if (null !== this.cpuLock) {
      this.cpuLock.unlock();
      this.cpuLock = null;
    }
  },

  async getSettingsValue(key) {
    const value = await SettingsObserver.getValue(key);
    this.debug('key value is ' + value);
    return value;
  },

  setSettingsValue(key, value) {
    SettingsObserver.setValue([{
      name: key,
      value: value
    }]);
  },

  getMessageInfo(data, type) {
    return {
      type: type ? type : MESSAGE_EVENT_TYPES.CELLBROADCAST_RECEIVED,
      data,
      url: '/attention.html',
      mode: { disposition: 'attention' }
    };
  },

  async showClient(info) {
    const { url, data, type, mode, activityName } = info;
    this.debug(`Show client data is: url, data, type: ${url},
      ${JSON.stringify(data)},
      ${type}`);
    try {
      const client = await clients.openWindow(url, mode);
      this.debug('Open client success', client);
      client.postMessage({ type, data, activityName });
    } catch (error) {
      console.error(`Open client failed with error: ${error}`);
    }
  },

  sendNotification(data) {
    this.debug(`sendNotification: ${JSON.stringify(data)}`);
    if (!data.messageType) {
      data.messageType = 'WEA';
    }
    const { body, id, messageType } = data;
    l10n.once(() => {
      const options = {
        body,
        data,
        tag: id,
        type: 'WEA',
        icon: 'messages'
      };
      self.registration.showNotification(l10n.get(messageType), options);
    });
  },

  async removeNotices(ids) {
    const notices = await self.registration.getNotifications();
    if (!ids) {
      notices.forEach((notice) => notice.close());
      return;
    }
    notices.forEach((notice) => {
      if (ids.includes(notice.tag)) {
        notice.close();
      }
    });
  }
};
