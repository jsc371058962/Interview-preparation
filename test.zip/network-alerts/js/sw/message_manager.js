'use strict';

(function (exports) {
  let MessageManagers = function () {
    this.DEBUG = true;
    this.name = 'MessageManager';
    this.screenLock = null;
    this.cpuLock = null;
    this.needDuplicationDetection = true;
    this.periodReminderEnabled = true;
    this.fixedIntervalReminder = false;
    this.periodReminder = null;
  };

  MessageManagers.prototype.debug = function (s) {
    if (this.DEBUG) {
      console.log(`-*- CMAS ${this.name} -*- ${s}`);
    }
  };

  MessageManagers.prototype.checkIfMessageCanShow = async function (message) {
    if (typeof message !== 'object') {
      return false;
    }
    if (Utils.isETWSAlert(message)) {
      let warningType = message.etws.warningType
        ? message.etws.warningType
        : 'other';
      message.messageType = `etws-warningType-${warningType}`;
      this.saveMessage(message);
      return true;
    } else {
      const isShow = await this.isShowMessage(message);
      return isShow;
    }
  };

  MessageManagers.prototype.duplicationDetectionMechanism = async function (
    message
  ) {
    if (!this.needDuplicationDetection) {
      return true;
    }
    let hasDuplicationMsg = false;
    const isGSM = Utils.isGSMMsg(message);
    const result = await DBStorage.getActiveMessages(message);
    const messages = isGSM ? result.gsmMsgArr : result.cdmaMsgArr;

    for (let i = 0; i < messages.length; i++) {
      if (Utils.isSameMsg(messages[i], message, isGSM)) {
        hasDuplicationMsg = true;
        break;
      }
    }

    this.debug(`hasDuplicationMsg -> ${hasDuplicationMsg}`);
    return !hasDuplicationMsg;
  };

  MessageManagers.prototype.isShowMessage = async function (message) {
    const info = await Utils.getCmasMessageInfo(message);
    const result = await this.getCmasMessageInfoCallback(info, message);
    return result;
  };

  MessageManagers.prototype.getCmasMessageInfoCallback = async function (
    info,
    message
  ) {
    if (info.receive) {
      /**
       * If want to ignore check duplicate CMAS in some cases
       * (ex: turn on airplane mode or reboot device),
       * Pls set 'cmas.ignore.dup' to true in system app
       */
      const noDup = await Utils.getSettingsValue('cmas.ignore.dup');
      if (!noDup) {
        const deleteDupResult = await this.duplicationDetectionMechanism(
          message
        );
        if (deleteDupResult) {
          message.messageType = info.type;
          this.saveMessage(message);
        }
        return deleteDupResult;
      } else {
        message.messageType = info.type;
        this.saveMessage(message);
        return true;
      }
    } else {
      return false;
    }
  };

  MessageManagers.prototype.saveMessage = function (msg) {
    Utils.setSettingsValue('cmas.ignore.dup', false);
    msg.isGSM = Utils.isGSMMsg(msg);
    DBStorage.save(msg);
  };

  MessageManagers.prototype.startPeriodReminder = function (bReset = true) {
    if (!this.periodReminderEnabled) {
      return;
    }
    this.debug('startPeriodReminder:: start reminder.');
    if (this.fixedIntervalReminder) {
      const key = 'cmas.remind.period';
      Utils.getSettingsValue(key).then((period) => {
        if (period) {
          AlarmHandler.createAlarms(period);
        }
      });
    } else {
      if (bReset) {
        // Default remind period('1 minute', '3 minutes', '5 minutes')
        this.periodReminder = {
          timeId: 'periodReminder',
          periodArray: [1, 3, 5]
        };
      }
      // Need store this period.
      if (!this.periodReminder) {
        DBStorage.getAllCMASData('period_store').then(
          (values) => {
            if (values.length > 0) {
              this.periodReminder = values[0];
              this.setPeriodData();
            }
          },
          () => {
            this.debug('There is no store the period.');
          }
        );
      } else {
        this.setPeriodData();
      }
    }
  };

  MessageManagers.prototype.setPeriodData = function () {
    const period =
      this.periodReminder.periodArray.length > 1
        ? this.periodReminder.periodArray.shift()
        : this.periodReminder.periodArray[0];
    AlarmHandler.createAlarms(period);
    if (this.periodReminder.periodArray.length > 0) {
      DBStorage.setCMASData(this.periodReminder, 'period_store');
    }
  };

  MessageManagers.prototype.stopPeriodReminder = function () {
    if (!this.periodReminderEnabled) {
      return;
    }
    DBStorage.deleteCMASData('periodReminder', 'period_store');
    this.debug('stopPeriodReminder:: stop reminder.');
    AlarmHandler.removeAlarms();
  };

  exports.MessageManager = new MessageManagers();
})(self);
