'use strict';

(function (exports) {
  let Alarm = function () {
    this.DEBUG = true;
    this.name = 'AlarmHandler';
  };

  Alarm.prototype.debug = function (s) {
    if (this.DEBUG) {
      console.log(`-*- CMAS ${this.name} -*- ${s}`);
    }
  };

  Alarm.prototype.createAlarms = function (alarmTime) {
    if (!alarmTime) {
      return;
    }

    this.removeAlarms().then(() => {
      this.debug(`createAlarms: ${alarmTime}`);
      const date = Date.now() + alarmTime * 60 * 1000;
      const options = {
        date,
        data: {
          type: 'remind',
          alarmType: 'WEA'
        },
        ignoreTimezone: false
      };
      navigator.b2g.alarmManager.add(options).then(
        () => {
          this.debug('Add alarm success.');
        },
        () => {
          this.debug('Add alarm failed.');
        }
      );
    });
  };

  Alarm.prototype.removeAlarms = function () {
    this.debug(`clear all alarms`);
    return new Promise((resolve) => {
      navigator.b2g.alarmManager.getAll().then((value) => {
        let alarms = value;
        if (!alarms) {
          alarms = [];
        }
        alarms.forEach((alarm) => {
          if (
            alarm.data &&
            alarm.data.type === 'remind' &&
            'WEA' === alarm.data.alarmType
          ) {
            navigator.b2g.alarmManager.remove(alarm.id);
          }
        });
        resolve();
      });
    });
  };

  exports.AlarmHandler = new Alarm();
})(self);
