'use strict';

(function (exports) {
  let MessageControllers = function () {
    this.DEBUG = true;
    this.name = 'MessageController';
    this.isChecking = false;
    // Basic support is in order and
    // Reverse order(need set 'this.isCustom = true').
    // If want to customize the message order, need
    // OEM to implement the feature.
    this.isCustom = false;
    this.messageCache = [];
    this.windowHashMap = new Map();
  };

  MessageControllers.prototype.debug = function (s) {
    if (this.DEBUG) {
      console.log(`-*- CMAS ${this.name} -*- ${s}`);
    }
  };

  MessageControllers.prototype.startCheckFlow = async function (data) {
    this.debug(`data info: ${JSON.stringify(data)}`);
    // Save data and judage duplicate.
    if (!this.isChecking) {
      const canShow = await this.onCellBroadcast(data);
      if (canShow) {
        await this.showMessage(data);
        Utils.sendNotification(data);
      }
      this.debug(
        'Start handle cache message ' +
        'while message cache array length greater than 0.'
      );
      // Check incoming messages while checking message.
      this.handleCacheMessage();
    } else {
      this.debug('Cache unchecked message while DUT receive multiple messages');
      this.messageCache.push(data);
    }
  };

  MessageControllers.prototype.onCellBroadcast = function (message) {
    this.isChecking = true;
    return this.checkMessage(message);
  };

  MessageControllers.prototype.checkMessage = async function (message) {
    if (!Utils.isEmergencyAlert(message)) {
      this.debug(`checkMessage it is not a emergency alert.`);
      this.isChecking = false;
      return false;
    } else {
      const isShow = await MessageManager.checkIfMessageCanShow(message);
      this.debug(`checkMessage isShow value -> ${isShow}`);
      this.isChecking = false;
      return isShow;
    }
  };

  MessageControllers.prototype.showMessage = async function (message) {
    if (!this.windowHashMap.size) {
      await this.getMsgHashMap();
    }
    if (!this.isCustom || !this.windowHashMap.size) {
      const info = Utils.getMessageInfo(message);
      try {
        const matchedClients = await self.clients.matchAll();
        const { type, data } = info;
        let hasAttentionWin = false;
        this.debug(`matchedClients length: ${matchedClients.length}`);
        for (const client of matchedClients) {
          if (client.url.includes('attention.html')) {
            hasAttentionWin = true;
            client.postMessage({ data, type });
            break;
          }
        }
        // No attention window, open a new attention window.
        if (!hasAttentionWin) {
          Utils.showClient(info);
        }
      } catch (error) {
        throw new Error(error);
      }
      MessageManager.startPeriodReminder();
    }
    if (this.isCustom && this.windowHashMap.size) {
      this.stopPrevRings();
    }
    this.windowHashMap.set(message.timestamp, message);
    DBStorage.setCMASData(message, 'map_hash_store');
  };

  MessageControllers.prototype.stopPrevRings = async function () {
    const matchedClients = await self.clients.matchAll();
    if (matchedClients.length > 0) {
      for (const client of matchedClients) {
        if (client.url.includes('attention.html')) {
          client.postMessage({ type: 'start-rings' });
          break;
        }
      }
    }
  };

  MessageControllers.prototype.getTargetMsg = function () {
    let tDate;
    let tMsg;
    this.windowHashMap.forEach((msg, date) => {
      if (tDate) {
        if (
          (!this.isCustom && tDate < date) ||
          (this.isCustom && tDate > date)
        ) {
          tDate = date;
          tMsg = msg;
        }
      } else {
        tDate = date;
        tMsg = msg;
      }
    });

    return tMsg;
  };

  MessageControllers.prototype.handleCloseWindowEvent = async function (
    messageTimestamp
  ) {
    if (!this.windowHashMap.size) {
      await this.getMsgHashMap();
    }
    if (this.windowHashMap.size > 0 && messageTimestamp) {
      this.windowHashMap.delete(messageTimestamp);
      DBStorage.deleteCMASData(messageTimestamp, 'map_hash_store');
    }
    const matchedClients = await self.clients.matchAll();
    if (this.windowHashMap.size > 0) {
      const targetMsg = this.getTargetMsg();
      const { type, data } = Utils.getMessageInfo(targetMsg);
      if (matchedClients.length > 0) {
        for (const client of matchedClients) {
          if (client.url.includes('attention.html')) {
            client.postMessage({ type, data, needRing: false });
            break;
          }
        }
      }
      // Set another alarm for prev cmas message.
      MessageManager.startPeriodReminder();
    } else {
      matchedClients.forEach((client) =>
        client.postMessage({ type: 'close-window' })
      );
      MessageManager.stopPeriodReminder();
    }
  };

  MessageControllers.prototype.getMsgHashMap = async function () {
    const arrayValue = await DBStorage.getAllCMASData('map_hash_store');
    if (arrayValue.length > 0) {
      arrayValue.forEach((item) => {
        this.windowHashMap.set(item.timestamp, item);
      });
    }
  };

  MessageControllers.prototype.setPeriodReminder = async function () {
    if (!this.windowHashMap.size) {
      await this.getMsgHashMap();
    }
    const targetMsg = this.getTargetMsg();
    const { type, data } = Utils.getMessageInfo(targetMsg, 'alarm');
    MessageManager.startPeriodReminder(false);
    const matchedClients = await self.clients.matchAll();
    if (matchedClients.length > 0) {
      for (const client of matchedClients) {
        if (client.url.includes('attention.html')) {
          client.postMessage({ type, data });
          break;
        }
      }
    }
  };

  MessageControllers.prototype.handleCacheMessage = function () {
    if (!this.isChecking) {
      if (this.messageCache.length > 0) {
        const cacheMessage = this.messageCache.pop();
        this.onCellBroadcast(cacheMessage);
      }
    }
  };

  exports.MessageController = new MessageControllers();
})(self);
