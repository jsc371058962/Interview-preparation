'use strict';

(function (exports) {
  let DBStorage = function () {
    this.DEBUG = true;
    this.name = 'DBStorage';
    this.db = null;
    this.dbName = 'cmas';
    this.dbStore = 'cmas_store';
    this.dbVersion = 1;
    // Also need cache data for duplicate.
    this.dbCacheStore = 'cache_cmas_store';
    this.mapHashStore = 'map_hash_store';
    this.periodStore = 'period_store';
  };

  DBStorage.prototype.debug = function (s) {
    if (this.DEBUG) {
      console.log(`-*- CMAS ${this.name} -*- ${s}`);
    }
  };

  DBStorage.prototype.initDB = function () {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.dbVersion);
      request.onupgradeneeded = (e) => {
        // Create an empty object store.
        this.debug('[DBStorage][initDB] Onupgradeneeded.');
        const db = request.result;

        // For cmas regular data
        const storeMap = new Map([
          [this.dbStore, 'id'],
          [this.dbCacheStore, 'id'],
          [this.mapHashStore, 'timestamp'],
          [this.periodStore, 'timeId']
        ]);
        for (const [store, id] of storeMap.entries()) {
          if (!db.objectStoreNames.contains(store)) {
            db.createObjectStore(store, { keyPath: id });
          } else {
            e.target.transaction.objectStore(store);
          }
        }
      };
      request.onsuccess = () => {
        this.debug(`[DBStorage][initDB] Get data success.`);
        const result = request.result;
        resolve(result);
      };
      request.onerror = () => {
        console.error(
          `[DBStorage][initDB] Get data failed with error: ${request.error}`
        );
        reject(request.error);
      };
    });
  };

  DBStorage.prototype.getDB = async function () {
    try {
      if (!this.db) {
        this.db = await this.initDB();
      }
    } catch (error) {
      console.error(`[DBStorage][getDB] With error: ${error}`);
    }
    return this.db;
  };

  DBStorage.prototype.handleStore = async function (type, dbStoreName) {
    const db = await this.getDB();
    const transaction = db.transaction(dbStoreName, type);
    return transaction.objectStore(dbStoreName);
  };

  DBStorage.prototype.setCMASData = async function (value, dbStore) {
    this.debug(`setCMASData dbStore is: ${dbStore}`);
    const targetObjectStore = await this.handleStore('readwrite', dbStore);
    return new Promise((resolve) => {
      const request = targetObjectStore.put(value);
      request.onsuccess = () => {
        this.debug(`Set cmas data success.`);
        resolve();
      };
      request.onerror = () => {
        consoe.error(`Set cmas data fail with error: ${request.error}`);
        resolve();
      };
    });
  };

  DBStorage.prototype.deleteCMASData = async function (key, dbStore) {
    this.debug(`deleteCMASData dbStore is: ${dbStore}`);
    const targetObjectStore = await this.handleStore('readwrite', dbStore);
    return new Promise((resolve, reject) => {
      const request = targetObjectStore.delete(key);
      request.onsuccess = () => {
        this.debug(`Delete cmas data success.`);
        resolve();
      };
      request.onerror = () => {
        consoe.error(`Delete cmas data fail with error: ${request.error}`);
        reject();
      };
    });
  };

  DBStorage.prototype.getAllCMASData = async function (dbStore) {
    this.debug(`getAllCMASData dbStore is: ${dbStore}`);
    const targetObjectStore = await this.handleStore('readonly', dbStore);
    return new Promise((resolve) => {
      const request = targetObjectStore.getAll();
      request.onsuccess = (event) => {
        this.debug(
          `Get all cmas data success: ${JSON.stringify(event.target.result)}`
        );
        const results = event.target.result;
        resolve(results || []);
      };
      request.onerror = (event) => {
        consoe.error(
          `Get all cmas data failed with error: ${event.target.error}`
        );
        resolve([]);
      };
    });
  };

  DBStorage.prototype.getAll = async function () {
    const [messages, cacheMessages] = await Promise.all([
      this.getAllCMASData(this.dbStore),
      this.getAllCMASData(this.dbCacheStore)
    ]);
    const currentTime = new Date().getTime();
    const setCacheItem = (item, index) => {
      if (Math.abs(item.timestamp - currentTime) > Utils.expireTime) {
        this.deleteCMASData(+item.id, this.dbCacheStore);
        cacheMessages.splice(index, 1);
      }
    };
    cacheMessages.forEach(setCacheItem);
    return { messages, cacheMessages };
  };

  DBStorage.prototype.getAllActiveMessage = async function () {
    const { messages } = await this.getAll();
    return messages;
  };

  DBStorage.prototype.save = function (message) {
    message.id = new Date().getTime();
    this.setCMASData(message, this.dbStore);
    this.setCMASData(message, this.dbCacheStore);
  };

  DBStorage.prototype.remove = function (ids) {
    ids.forEach((id) => {
      this.deleteCMASData(+id, this.dbStore);
    });
  };

  DBStorage.prototype.getActiveMessages = async function (message) {
    let result = {
      gsmMsgArr: [],
      cdmaMsgArr: []
    };

    const cacheMessageArr = await this.getAllCMASData('cache_cmas_store');
    cacheMessageArr.length > 0 &&
      cacheMessageArr.forEach((item) => {
        if (Math.abs(item.timestamp - message.timestamp) <= Utils.expireTime) {
          if (item.isGSM) {
            result.gsmMsgArr.push(item);
          } else {
            result.cdmaMsgArr.push(item);
          }
        }
      });
    return result;
  };

  exports.DBStorage = new DBStorage();
})(self);
