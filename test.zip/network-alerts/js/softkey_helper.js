'use strict';

(function (exports) {
  const getL10nMothed = window.api.l10n.get;
  let SoftkeyHelper = {
    softkey: null,
    softkeyItems: null,

    init: function () {
      this.softkeyItems = {
        'none': {
          menuClassName: 'menu-button',
          items: [
            {
              name: '',
              priority: 2
            }
          ]
        },
        'option': {
          menuClassName: 'menu-button',
          items: [
            {
              name: getL10nMothed('select'),
              priority: 2,
              method: () => {
                Optionmenu.select();
              }
            }
          ]
        },
        'attention-init': {
          menuClassName: 'menu-button',
          items: [
            {
              name: getL10nMothed('ok'),
              priority: 2,
              method: () => {
                Attention.closeAttentionWindow();
              }
            }
          ]
        },
        'main': {
          menuClassName: 'menu-button',
          items: [
            {
              name: getL10nMothed('ok'),
              priority: 2,
              method: () => {
                Attention.closeAttentionWindow();
              }
            },
            {
              name: getL10nMothed('options'),
              priority: 3,
              method: () => {
                Optionmenu.show('attention');
              }
            }
          ]
        },
        'dialog': {
          menuClassName: 'menu-button',
          items: [
            {
              name: getL10nMothed('cancel'),
              priority: 1,
              method: () => {
                Dialog.cancel();
              }
            },
            {
              name: getL10nMothed('delete'),
              priority: 3,
              method: () => {
                Dialog.confirm();
              }
            }
          ]
        },
        'alert-inbox': {
          menuClassName: 'menu-button',
          items: [
            {
              name: getL10nMothed('select'),
              priority: 2,
              method: () => {
                AlertBox.showDetail();
              }
            },
            {
              name: getL10nMothed('options'),
              priority: 3,
              method: () => {
                AlertBox.focusElement = document.activeElement;
                Optionmenu.show('inbox',
                AlertBox.deleteCB.bind(AlertBox),
                AlertBox.deleteCancelCB.bind(AlertBox));
              }
            }
          ]
        },
        'detail': {
          menuClassName: 'menu-button',
          items: [
            {
              name: getL10nMothed('options'),
              priority: 3,
              method: () => {
                Optionmenu.show('detail',
                AlertDetail.deleteCB.bind(AlertDetail),
                AlertDetail.deleteCancelCB.bind(AlertDetail));
              }
            }
          ]
        },
        'notice-detail': {
          menuClassName: 'menu-button',
          items: [
            {
              name: getL10nMothed('ok'),
              priority: 2,
              method: () => {
                window.close();
              }
            }
          ]
        },
        'edit-inbox': {}
      };
    },

    editSoftKeyItem: function (all, select, del) {
      this.softkeyItems['edit-inbox'] = {
        menuClassName: 'menu-button',
        items: [
          {
            name: all ? getL10nMothed('select-all')
              : getL10nMothed('deselect-all'),
            priority: 1,
            method: () => {
              AlertBox.selectMessages(all);
            }
          },
          {
            name: select ? getL10nMothed('select')
              : getL10nMothed('deselect'),
            priority: 2,
            method: () => {
              AlertBox.selectMessage();
            }
          },
          {
            name: del ? getL10nMothed('delete') : '',
            priority: 3,
            method: () => {
              // eslint-disable-next-line no-unused-expressions
              del ? AlertBox.deleteSelectMessages() : '';
            }
          }
        ]
      };
      this.setSoftKey('edit-inbox');
    },

    // -----------------------------------
    // Softkey Handler
    // -----------------------------------
    setSoftKey: function (type) {
      if (this.softkeyPanel) {
        this.softkeyPanel.initSoftKeyPanel(this.softkeyItems[type]);
      } else {
        this.softkeyPanel = new SoftkeyPanel(this.softkeyItems[type]);
      }
      this.softkeyPanel.show();
    }
  };

  exports.SoftkeyHelper = SoftkeyHelper;
})(window);

