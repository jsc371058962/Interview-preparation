'use strict';

importScripts('%SHARED_APP_ORIGIN%/js/session/lib_session.js');
importScripts('%SHARED_APP_ORIGIN%/js/session/task_scheduler.js');
importScripts('%SHARED_APP_ORIGIN%/js/session/settings/settings_observer.js');
importScripts('%SHARED_APP_ORIGIN%/js/utils/l10n/l10n_sw.js')
importScripts(
  './js/sw/storage.js',
  './js/sw/utils.js',
  './js/sw/alarm.js',
  './js/sw/message_manager.js',
  './js/sw/message_controller.js',
);

Utils.servicesInit();

self.addEventListener('install', (evt) => {
  evt.waitUntil(self.skipWaiting());
});

self.addEventListener('activate', (evt) => {
  evt.waitUntil(self.clients.claim());
});

self.addEventListener('systemmessage', (evt) => {
  const type = evt.name;
  switch (type) {
    case MESSAGE_EVENT_TYPES.ACTIVITY: {
      const activityHandler = evt.data.webActivityRequestHandler();
      const activityName = activityHandler.source.name;
      // Get CMAS messages data.
      evt.waitUntil(new Promise(async (resolve) => {
        const data = await DBStorage.getAllActiveMessage();
        const info = {
          type,
          data,
          url: '/index.html',
          mode: { disposition: 'inline' },
          activityName
        };
        Utils.showClient(info);
        Utils.removeNotices();
        resolve();
      }));
      break;
    }
    case MESSAGE_EVENT_TYPES.ALARM: {
      const {
        data,
        data: { type, alarmType },
      } = evt.data.json();

      evt.waitUntil(new Promise(async (resolve) => {
        if (data && 'remind' === type && 'WEA' === alarmType) {
          await MessageController.setPeriodReminder();
        }
        resolve();
      }));
      break;
    }
    case MESSAGE_EVENT_TYPES.CELLBROADCAST_RECEIVED: {
      const data = evt.data.json();
      evt.waitUntil(new Promise(async (resolve) => {
        await MessageController.startCheckFlow(data);
        resolve();
      }));
      break;
    }
    default:
      break;
  }
});

// Handle delete indexedDB data and multiple attention window.
self.addEventListener('message', (evt) => {
  const { data, data: { type } } = evt;
  console.log(
    `-*- CMAS SW -*- handleEvent message data -> ${JSON.stringify(data)}`
  );
  switch (type) {
    case MESSAGE_EVENT_TYPES.REMOVE_MESSAGE: {
      // Close notice when remove from alert inbox.
      const { ids } = data.data;
      DBStorage.remove(ids);
      Utils.removeNotices(ids);
      break;
    }
    case MESSAGE_EVENT_TYPES.CLOSE_ATTENTION_WINDOW: {
      const { timestamp } = data;
      evt.waitUntil(new Promise(async (resolve) => {
        await MessageController.handleCloseWindowEvent(timestamp);
        resolve();
      }));
      break;
    }
    default:
      break;
  }
});

self.addEventListener('notificationclick', (evt) => {
  evt.notification.close();
  const { data } = evt.notification;
  const info = {
    data,
    type: 'notification',
    url: '/index.html',
    mode: { disposition: 'window' }
  };
  Utils.showClient(info);
});
