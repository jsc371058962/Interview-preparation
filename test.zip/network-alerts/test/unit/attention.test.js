'use strict';

require('../mocks/attentionHTML');
require('../mocks/navigator/l10n');
require('../mocks/utilMock');

document.dir = AttentionHTML.dir;
document.body.innerHTML = AttentionHTML.innerHTML;

require('../../js/attention/attention');
require('../../js/view_utils');
require('../mocks/softHelperMock');

test('attentioninit', () => {
  let input = 'app://network-alerts.gaiamobile.org/attention.html?title=amber-alert&date=1560132828511&body=CMAS_AMBER_ACMAS_AMBER_B&id=1564039170994 ';
  const msg = Attention.parseMessage(input);
  expect(msg.title).toBe('amber-alert');
  expect(msg.body).toBe('CMAS_AMBER_ACMAS_AMBER_B');
  let msgDate = parseInt(msg.date);
  expect(msgDate).toBe(1560132828511);
  let date = ViewUtils.getDate(msgDate);
  let alertContent = document.getElementById('alert-content');
  alertContent.textContent = msg.body;
  ViewUtils.linkingContent(alertContent);
  expect(alertContent.innerHTML).toBe('CMAS_AMBER_ACMAS_AMBER_B');

  let input1 = 'app://network-alerts.gaiamobile.org/attention.html?title=amber-alert&date=1560132828511&body=CMAS_AMBER_ACMAS_AMBER_B www.baidu.com&id=1564039170994 ';
  const msg1 = Attention.parseMessage(input1);
  alertContent.textContent = msg1.body;
  ViewUtils.linkingContent(alertContent);
  expect(alertContent.innerHTML).toBe('CMAS_AMBER_ACMAS_AMBER_B <a class="kai-external-link" ext-tag="url">www.baidu.com</a>');

  let input2 = 'app://network-alerts.gaiamobile.org/attention.html?title=amber-alert&date=1560132828511&body=CMAS_AMBER_ACMAS_AMBER_B 17729111212&id=1564039170994 ';
  const msg2 = Attention.parseMessage(input2);
  alertContent.textContent = msg2.body;
  ViewUtils.linkingContent(alertContent);
  expect(alertContent.innerHTML).toBe('CMAS_AMBER_ACMAS_AMBER_B <a class="kai-external-link" ext-tag="call">17729111212</a>');

  let input3 = 'app://network-alerts.gaiamobile.org/attention.html?title=amber-alert&date=1560132828511&body=CMAS_AMBER_ACMAS_AMBER_B helloworld@163.com&id=1564039170994 ';
  const msg3 = Attention.parseMessage(input3);
  alertContent.textContent = msg3.body;
  ViewUtils.linkingContent(alertContent);
  expect(alertContent.innerHTML).toBe('CMAS_AMBER_ACMAS_AMBER_B <a class="kai-external-link" ext-tag="mail">helloworld@163.com</a>');
});

test('handle up/Down key', () => {
  let input = 'app://network-alerts.gaiamobile.org/attention.html?title=amber-alert&date=1560132828511&body=CMAS_AMBER_ACMAS_AMBER_B www.baidu.com&id=1564039170994 ';
  const msg = Attention.parseMessage(input);
  let alertContent = document.getElementById('alert-content');
  alertContent.textContent = msg.body;
  ViewUtils.linkingContent(alertContent);
  ViewUtils.scrollBar('ArrowUp', false);
  expect(document.querySelector('a').classList.contains('focus')).toBe(true);
});
