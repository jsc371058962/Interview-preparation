'use strict';

require('../mocks/alertHTML');
require('../mocks/softHelperMock');
require('../mocks/navigator/l10n');
require('../mocks/notification');
require('../mocks/utilMock');

document.dir = AlertHTML.dir;
document.body.innerHTML = AlertHTML.innerHTML;

require('../../js/view/alert_inbox');
require('../../js/navigator');
require('../../js/view/store');
require('../../js/view_utils');
require('../../js/view/alert_detail');
require('../../js/dialog');

const scrollIntoViewMock = jest.fn();
window.HTMLElement.prototype.scrollIntoView = scrollIntoViewMock;

AlertDetail.content = document.getElementById('alert-content');
AlertDetail.screen = document.getElementById('alert-detail');


let message = {
  "serviceId": 0,
  "gsmGeographicalScope": "cell",
  "messageCode": 0,
  "messageId": 4379,
  "language": "en",
  "body": "CMAS_AMBER_ACMAS_AMBER_B www.baidu.com",
  "messageClass": "normal",
  "timestamp": 1560132828511,
  "cdmaServiceCategory": 0,
  "etws": null,
  "messageType": "amber-alert",
  "isGSM": true,
  "id": 1586423367704
};

test('detailshow', () => {
  let date = document.getElementById('alert-date');
  AlertDetail.show(message, null);
  expect(AlertDetail.id).toBe(1586423367704);
  expect(AlertDetail.content.innerHTML).toBe('CMAS_AMBER_ACMAS_AMBER_B <a class="kai-external-link focus" ext-tag="url">www.baidu.com</a>');
});
