'use strict';

require('../mocks/alertHTML');
require('../mocks/navigator/l10n');
require('../mocks/softHelperMock');
require('../mocks/utilMock');

document.dir = AlertHTML.dir;
document.body.innerHTML = AlertHTML.innerHTML;

require('../../js/option_menu');
require('../../js/navigator');
require('../../js/view_utils');
require('../../js/view/alert_detail');

const scrollIntoViewMock = jest.fn();
window.HTMLElement.prototype.scrollIntoView = scrollIntoViewMock;

Optionmenu.content = document.querySelector('.option-menu-container .content');
Optionmenu.element = document.querySelector('.option-menu-container');
Optionmenu.options = [];
AlertDetail.content = document.getElementById('alert-content');
AlertDetail.screen = document.getElementById('alert-detail');
ViewUtils.scrollElement = document.getElementById('alert-content');

let message = {
  "serviceId": 0,
  "gsmGeographicalScope": "cell",
  "messageCode": 0,
  "messageId": 4379,
  "language": "en",
  "body": "CMAS_AMBER_ACMAS_AMBER_B www.baidu.com",
  "messageClass": "normal",
  "timestamp": 1560132828511,
  "cdmaServiceCategory": 0,
  "etws": null,
  "messageType": "amber-alert",
  "isGSM": true,
  "id": 1586423367704
};

test('optionmenu inbox show', () => {
  Optionmenu.updateoptionButton('inbox');
  expect(Optionmenu.options.toString()).toBe('delete,multiselect');
  Optionmenu.buildOptions();
  expect(Optionmenu.content.children.length).toBe(2);
  expect(document.getElementsByClassName('content')[1].getAttribute('data-l10n-id')).toBe('delete');
  expect(document.getElementsByClassName('content')[2].getAttribute('data-l10n-id')).toBe('multiselect');
  NavigationHelper.selector = '.menu-item';
  NavigationHelper.element = Optionmenu.element;
  NavigationHelper.updateCandidates();
  expect(Optionmenu.content.children[0].classList.contains('focus')).toBe(true);
});

test('optionmenu alertdetail show', () => {
  AlertDetail.show(message, null);
  Optionmenu.updateoptionButton('alertdetail');
  expect(Optionmenu.options.toString()).toBe('open-web,delete');
  Optionmenu.buildOptions();
  expect(Optionmenu.content.children.length).toBe(2);
  expect(document.getElementsByClassName('content')[1].getAttribute('data-l10n-id')).toBe('open-web');
  expect(document.getElementsByClassName('content')[2].getAttribute('data-l10n-id')).toBe('delete');
  NavigationHelper.selector = '.menu-item';
  NavigationHelper.element = Optionmenu.element;
  NavigationHelper.updateCandidates();
  expect(Optionmenu.content.children[0].classList.contains('focus')).toBe(true);
});

test('optionmenu hide', () => {
  Optionmenu.hide();
  expect(Optionmenu.element.classList.contains('hidden')).toBe(true);
  let active = Optionmenu.isActive();
  expect(active).toBe(false);
});
