'use strict';

require('../mocks/utilMock');
require('../mocks/navigator/wakeLock');

require('../../js/sw/message_controller');
require('../../js/sw/message_manager');
// require('../../js/rings');
require('../../js/sw/utils');

let message = {
  serviceId: 0,
  gsmGeographicalScope: "cell",
  messageCode: 0,
  messageId: 4379,
  language: "en",
  body: "CMAS_AMBER_ACMAS_AMBER_B",
  messageClass: "normal",
  timestamp: 1560132828511,
  cdmaServiceCategory: 0,
  etws: null
};

test('checkMessage', () => {
  MessageController.checkMessage(message).then((value) => {
    expect(value).toBe(true);
  });
  expect(Utils.isEmergencyAlert(message)).toBe(true);

  MessageManager.checkIfMessageCanShow(message).then((value) => {
    expect(value).toBe(true);
  });
});

test('showMessage', () => {
  let win = Utils.sendAlert(message);
  MessageController.windowHashMap.set(message.timestamp, {
    message,
    window: win
  });
  expect(global.open).toBeCalled();
  expect(MessageController.windowHashMap.size).toBe(1);
});
