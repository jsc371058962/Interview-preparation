'use strict';

require('../mocks/alertHTML');
require('../mocks/softHelperMock');
require('../mocks/navigator/l10n');
require('../mocks/notification');

document.dir = AlertHTML.dir;
document.body.innerHTML = AlertHTML.innerHTML;

require('../../js/view/alert_inbox');
require('../../js/navigator');
require('../../js/view/store');
require('../../js/view_utils');
require('../../js/view/alert_detail');
require('../../js/dialog');

const scrollIntoViewMock = jest.fn();
window.HTMLElement.prototype.scrollIntoView = scrollIntoViewMock;
AlertBox.screen = document.getElementById('inbox-screen');
AlertBox.list = document.getElementById('alert-list');
AlertBox.empty = document.getElementById('empty-list');
let item = { "serviceId": 0, "gsmGeographicalScope": "cell", "messageCode": 0, "messageId": 4379, "language": "en", "body": "CMAS_AMBER_ACMAS_AMBER_B www.baidu.com", "messageClass": "normal", "timestamp": 1560132828511, "cdmaServiceCategory": 0, "etws": null, "messageType": "amber-alert", "isGSM": true, "id": 1586422707115 };
let item1 = { "serviceId": 0, "gsmGeographicalScope": "cell", "messageCode": 0, "messageId": 4379, "language": "en", "body": "CMAS_AMBER_ACMAS_AMBER_B 18711001100", "messageClass": "normal", "timestamp": 1560132828511, "cdmaServiceCategory": 0, "etws": null, "messageType": "amber-alert", "isGSM": true, "id": 1586422707116 };
let item2 = { "serviceId": 0, "gsmGeographicalScope": "cell", "messageCode": 0, "messageId": 4379, "language": "en", "body": "CMAS_AMBER_ACMAS_AMBER_B", "messageClass": "normal", "timestamp": 1560132828511, "cdmaServiceCategory": 0, "etws": null, "messageType": "amber-alert", "isGSM": true, "id": 1586422707117 };

test('alertBox empty show', () => {
  AlertBox.show();
  expect(AlertBox.empty.classList.contains('hidden')).toBe(false);
});

test('alertBox list show', () => {
  Store.map.set(item.id, item);
  Store.map.set(item1.id, item1);
  Store.map.set(item2.id, item2);
  AlertBox.show();
  AlertBox.list.children[0].focus();
  AlertBox.list.children[0].classList.add('focus');
  expect(AlertBox.messages.length).toBe(3);
  expect(AlertBox.list.children.length).toBe(3);
  expect(document.activeElement.id).toBe('1586422707117');
  expect(AlertBox.list.children[0].classList.contains('focus')).toBe(true);
});

test('showEditMode', () => {
  AlertBox.showEditMode(true);
  expect(AlertBox.list.children[0].querySelector('.list-item').classList.contains('editMode')).toBe(true);
  expect(AlertBox.list.children[0].querySelector('.pack-checkbox').classList.contains('hidden')).toBe(false);
  expect(AlertBox.list.children[1].querySelector('.list-item').classList.contains('editMode')).toBe(true);
  expect(AlertBox.list.children[1].querySelector('.pack-checkbox').classList.contains('hidden')).toBe(false);
});

test('selectMessage', () => {
  AlertBox.selectedMessages = new Set();
  AlertBox.selectMessage();
  expect(AlertBox.selectedMessages.size).toBe(1);
  AlertBox.list.children[1].focus();
  AlertBox.selectMessage();
  expect(AlertBox.selectedMessages.size).toBe(2);
});

test('deleteSelectMessages', () => {
  let element = document.getElementById('dialog-container');
  let content = document.getElementById('dialog-content');
  Dialog.content = content;
  Dialog.element = element;
  AlertBox.deleteSelectMessages();
  expect(content.getAttribute('data-l10n-id')).toBe('delete-messages');
  expect(element.classList.contains('hidden')).toBe(false);
  Dialog.hide();
});

test('deselectMessage', () => {
  AlertBox.list.children[0].focus();
  AlertBox.selectMessage();
  expect(AlertBox.selectedMessages.size).toBe(1);
  AlertBox.list.children[1].focus();
  AlertBox.selectMessage();
  expect(AlertBox.selectedMessages.size).toBe(0);
});

test('hiddenEditMode', () => {
  AlertBox.showEditMode(false);
  expect(AlertBox.list.children[0].querySelector('.list-item').classList.contains('editMode')).toBe(false);
  expect(AlertBox.list.children[0].querySelector('.pack-checkbox').classList.contains('hidden')).toBe(true);
  expect(AlertBox.list.children[1].querySelector('.list-item').classList.contains('editMode')).toBe(false);
  expect(AlertBox.list.children[1].querySelector('.pack-checkbox').classList.contains('hidden')).toBe(true);
});


