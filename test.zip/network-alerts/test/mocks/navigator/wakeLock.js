window = { navigator: null };

window.navigator = { requestWakeLock: null };

window.navigator.requestWakeLock = function (name) {
  let cPromise = new Promise((resolve) => {
    resolve(true);
  });
  return cPromise;
};
