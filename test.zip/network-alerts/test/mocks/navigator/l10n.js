
window = {
  api: null
};

window.api = {
  hour12: null,
  l10n: null
};

window.api.l10n = {
  get: (name) => {
    return name;
  }, 
  once: () => jest.fn()
};

