'use strict';

(function (exports) {
  let SoftkeyHelper = {
    softkey: null,
    softkeyItems: null,

    init: function () {
    },

    editSoftKeyItem: function (all, select, del) {
    },

    // -----------------------------------
    // Softkey Handler
    // -----------------------------------
    setSoftKey: function (type) {
      this.softkeyPanel = { initSoftKeyPanel: jest.fn(), show: jest.fn() };
      if (this.softkeyPanel) {
        this.softkeyPanel.initSoftKeyPanel();
      } else {
        this.softkeyPanel = new SoftkeyPanel(this.softkeyItems[type]);
      }
      this.softkeyPanel.show();
    }
  };

  exports.SoftkeyHelper = SoftkeyHelper;
})(window);
