(function (exports) {
  let AlertHTML = {
    dir: 'ltr',
    innerHTML:
      '<div class="statusbar-placeholder"></div>\
      <section>\
        <div id="alert-detail" class="hidden">\
          <gaia-header>\
            <h1 class="header" id="alert-title"></h1>\
          </gaia-header>\
          <div id="alert-container">\
            <div id="alert-body" >\
              <div data-icon="alert"></div>\
              <div id="alert-text">\
                <p id="alert-date"></p>\
                <p id="alert-content" class="navigable scrollBar" tabindex="-1"></p>\
              </div>\
            </div>\
          </div>\
        </div>\
        <!-- Alert Inbox screen-->\
        <div id="inbox-screen" class="hidden">\
          <h1 class="alert-inbox h1" data-l10n-id="alert-inbox"></h1>\
          <div id="inbox-container">\
            <ul id="alert-list" class="hidden"  tabindex="-1"></ul>\
          </div>\
          <div id="empty-list" class="hidden" tabIndex="-1" data-l10n-id="no-alert"></div>\
        </div>\
        <div class="option-menu-container hidden" tabindex="-1">\
          <div class="option-menu">\
            <div class="header h1" data-l10n-id="options">\
            </div>\
            <div class="content p-ul">\
            </div>\
          </div>\
        </div>\
        <div id="dialog-container" class="dialog-container hidden" tabindex="-1">\
          <div role="heading" class="dialog">\
            <div id="dialog-header-1" class="header h1" data-l10n-id="confirm" ></div>\
            <div id="dialog-content" class="content p-pri" tabindex="-1"></div>\
          </div>\
        </div>\
      </section>'
  };
  exports.AlertHTML = AlertHTML;
})(window);
