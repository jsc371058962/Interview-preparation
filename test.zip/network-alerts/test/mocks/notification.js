'use strict';

(function (exports) {

  let Notification = function () {};

  Notification.prototype.get = function (tag) {
    return new Promise((resolve) => {
      resolve(tag.id);
    });
  };

  exports.Notification = new Notification();
})(window);
