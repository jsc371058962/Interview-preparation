'use strict';

(function (exports) {
  const GSM_CMAS_LOWER_BOUND = 4370; // 0x1112
  const GSM_CMAS_UPPER_BOUND = 4400; // 0x1130
  const CDMA_CMAS_LOWER_BOUND = 4096; // 0x1000
  const CDMA_CMAS_UPPER_BOUND = 4351; // 0x10FF
  const GSM_CMAS_EXTERNAL_LANGUAGE_SUPPORT_LOWER_BOUND = 4383;
  const GSM_CMAS_EXTERNAL_LANGUAGE_SUPPORT_UPPER_BOUND = 4395;
  const ETWS_WARNINGTYPE_EARTHQUAKE = 4352; // 0x1100 Earthquake warning!
  const ETWS_WARNINGTYPE_TSUNAMI = 4353; // 0x1101 Tsunami waring!
  const ETWS_WARNINGTYPE_EARTHQUAKE_TSUNAMI = 4354;
// 0x1102 Earthquake-tsunami warning!
  const ETWS_WARNINGTYPE_TEST = 4355; // 0x1103 Test emergency warning!
  const ETWS_WARNINGTYPE_OTHER = 4356; // 0x1104 Other emergency warning!
  const ETWS_WARNINGTYPE_EXTENSION_LOWER_BOUND = 4357;
// 0x1105 Future extension warning
  const ETWS_WARNINGTYPE_EXTENSION_UPPER_BOUND = 4359;
// 0x1107 Future extension warning

  const Util = function () {
    this.DEBUG = true;
    this.name = 'utils';
    this.expireTime = 24 * 60 * 60 * 1000;

  // CMAS Type , String Id
    this.preAlert = 'presidential-alert';
    this.extremeAlert = 'extreme-alert';
    this.severeAlert = 'severe-alert';
    this.amberAlert = 'amber-alert';
    this.rmtTestAlert = 'rmt-alert';
    this.exerciseAlert = 'exercise-alert';
    this.operatorAlert = 'operator-alert';
    this.extendedAlert = 'extended-alert';
    this.unknownAlert = 'unknown-alert';

  // Settings value, presidential alert always enabled.
    this.CMAS_ENABLED_KEY = 'cmas.enabled';
    this.CMAS_PRESIDENTIAL_ENABLED_KEY = 'cmas.presidential.enabled';
    this.CMAS_EXTREME_ENABLED_KEY = 'cmas.extreme.enabled';
    this.CMAS_SEVERE_ENABLED_KEY = 'cmas.severe.enabled';
    this.CMAS_AMBER_ENABLED_KEY = 'cmas.amber.enabled';
    this.CMAS_RMT_TEST_ENABLED_KEY = 'cmas.monthlytest.enabled';
    this.CMAS_EXERCISE_ENABLED_KEY = 'cmas.exercise.enabled';
    this.CMAS_OPERATOR_ENABLED_KEY = 'cmas.operator.enabled';
    this.CMAS_EXTENDED_ENABLED_KEY = 'cmas.extended.enabled';
    this.CMAS_MULTI_LANGUAGE_SUPPORT_KEY = 'cmas.multi.language.support';

  // GMS messageId, See GSM[1] section 9.4.1.2.2 Message Identifier
    this.GSM_PRESIDENTIAL_ALERTS = [4370, 4383];
    this.GSM_EXTREME_THREAT_ALERTS = [4371, 4372, 4384, 4385];
    this.GSM_SEVERE_THREAT_ALERTS = [
      4373, 4374, 4375, 4376,
      4377, 4378, 4386, 4387,
      4388, 4389, 4390, 4391
    ];
    this.GSM_CHILD_ABDUCTION_EMERGENCY_ALERTS = [4379, 4392];
    this.GSM_RMT_TEST_ALERTS = [4380, 4393];
    this.GSM_EXERCISE_ALERTS = [4381, 4394];
    this.GSM_OPERATOR_ALERTS = [4382, 4395];
    this.GSM_EXTENDED_ALERTS = [4396, 4397, 4398, 4399];

  // CDMA messageId, CDMA[2] section 9.3.3 Commercial Mobile for CMAS alerts
    this.CDMA_PRESIDENTIAL_ALERTS = 0x1000;
    this.CDMA_EXTREME_THREAT_ALERTS = 0x1001;
    this.CDMA_SEVERE_THREAT_ALERTS = 0x1002;
    this.CDMA_CHILD_ABDUCTION_EMERGENCY_ALERTS = 0x1003;
    this.CDMA_TEST_ALERTS = 0x1004;
  };

  Util.prototype.debug = function (s) {
    if (this.DEBUG) {
      console.log(`-*- CMAS ${this.name} -*- ${s}`);
    }
  };

  Util.prototype.isGSMMsg = function (message) {
    let serviceCategory = message.cdmaServiceCategory;
    return !serviceCategory || (-1 === serviceCategory);
  };

  Util.prototype.isWEAMsg = function (message) { // WEA
    if (message.cdmaServiceCategory) {
      return (message.cdmaServiceCategory >= CDMA_CMAS_LOWER_BOUND &&
              message.cdmaServiceCategory <= CDMA_CMAS_UPPER_BOUND);
    } else {
      return (message.messageId >= GSM_CMAS_LOWER_BOUND &&
              message.messageId < GSM_CMAS_UPPER_BOUND);
    }
  };

  Util.prototype.isETWSAlert = function (message) { // ETWS
    if (message.etws) {
      return (message.messageId === ETWS_WARNINGTYPE_EARTHQUAKE ||
             message.messageId === ETWS_WARNINGTYPE_TSUNAMI ||
             message.messageId === ETWS_WARNINGTYPE_EARTHQUAKE_TSUNAMI ||
             message.messageId === ETWS_WARNINGTYPE_TEST ||
             message.messageId === ETWS_WARNINGTYPE_OTHER ||
             (message.messageId >= ETWS_WARNINGTYPE_EXTENSION_LOWER_BOUND &&
             message.messageId <= ETWS_WARNINGTYPE_EXTENSION_UPPER_BOUND));
    } else {
      return false;
    }
  };

  Util.prototype.isEmergencyAlert = function (message) {
    return this.isWEAMsg(message) || this.isETWSAlert(message);
  };

  Util.prototype.isSupportMultiLanguage = function (message) {
    let supportMultiLanguage = false;
    if (this.isGSMMsg(message)) {
      supportMultiLanguage =
        message.messageId >= GSM_CMAS_EXTERNAL_LANGUAGE_SUPPORT_LOWER_BOUND &&
        message.messageId <= GSM_CMAS_EXTERNAL_LANGUAGE_SUPPORT_UPPER_BOUND;
    }
    return supportMultiLanguage;
  };

  Util.prototype.isPresidentialAlert = function (message) {
    return this.GSM_PRESIDENTIAL_ALERTS.indexOf(message.messageId) !== -1 ||
           message.cdmaServiceCategory === this.CDMA_PRESIDENTIAL_ALERTS;
  };

  Util.prototype.isCmasEnabled = function (message) {
    let cardIndex = message.serviceId || 0;
    return this.getSettingsValue(this.CMAS_ENABLED_KEY).then((result) => {
      return !!(result[cardIndex]);
    });
  };

  Util.prototype.getCmasMessageInfo = function (message, callback) {
    let info = {};
    const messageId = message.messageId;
    const isGSM = this.isGSMMsg(message);
    const cdmaServiceCategory = message.cdmaServiceCategory;

    if (this.isPresidentialAlert(message)) {
      info.type = this.preAlert;
      info.key = this.CMAS_PRESIDENTIAL_ENABLED_KEY;
    } else {
      if (isGSM) {
        if (this.GSM_EXTREME_THREAT_ALERTS.indexOf(messageId) !== -1) {
          info.type = this.extremeAlert;
          info.key = this.CMAS_EXTREME_ENABLED_KEY;
        } else if (this.GSM_SEVERE_THREAT_ALERTS.indexOf(messageId) !== -1) {
          info.type = this.severeAlert;
          info.key = this.CMAS_SEVERE_ENABLED_KEY;
        } else if (
          this.GSM_CHILD_ABDUCTION_EMERGENCY_ALERTS.indexOf(messageId) !== -1) {
          info.type = this.amberAlert;
          info.key = this.CMAS_AMBER_ENABLED_KEY;
        } else if (this.GSM_RMT_TEST_ALERTS.indexOf(messageId) !== -1) {
          info.type = this.rmtTestAlert;
          info.key = this.CMAS_RMT_TEST_ENABLED_KEY;
        } else if (this.GSM_EXERCISE_ALERTS.indexOf(messageId) !== -1) {
          info.type = this.exerciseAlert;
          info.key = this.CMAS_EXERCISE_ENABLED_KEY;
        } else if (this.GSM_OPERATOR_ALERTS.indexOf(messageId) !== -1) {
          info.type = this.operatorAlert;
          info.key = this.CMAS_OPERATOR_ENABLED_KEY;
        } else if (this.GSM_EXTENDED_ALERTS.indexOf(messageId) !== -1) {
          info.type = this.extendedAlert;
          info.key = this.CMAS_EXTENDED_ENABLED_KEY;
        } else {
          info.key = this.unknownAlert;
        }
      } else {
        if (cdmaServiceCategory === this.CDMA_EXTREME_THREAT_ALERTS) {
          info.type = this.extremeAlert;
          info.key = this.CMAS_EXTREME_ENABLED_KEY;
        } else if (cdmaServiceCategory === this.CDMA_SEVERE_THREAT_ALERTS) {
          info.type = this.severeAlert;
          info.key = this.CMAS_SEVERE_ENABLED_KEY;
        } else if (
          cdmaServiceCategory === this.CDMA_CHILD_ABDUCTION_EMERGENCY_ALERTS) {
          info.type = this.amberAlert;
          info.key = this.CMAS_AMBER_ENABLED_KEY;
        } else if (cdmaServiceCategory === this.CDMA_TEST_ALERTS) {
          info.type = this.rmtTestAlert;
          info.key = this.CMAS_RMT_TEST_ENABLED_KEY;
        } else {
          info.key = this.unknownAlert;
        }
      }
    }

    let checkSpecificTypeMessage = (m_info, m_callback) => {
      if (m_info.key !== this.unknownAlert) {
        this.getSettingsValue(m_info.key).then((result) => {
          if (result === undefined) {
            result = m_info.type !== this.rmtTestAlert &&
                     m_info.type !== this.exerciseAlert &&
                     m_info.type !== this.operatorAlert &&
                     m_info.type !== this.extendedAlert;
          }
          m_info.receive = result;
          if (m_callback) {
            m_callback(m_info);
          }
        });
      } else {
        this.debug('cellbroadcast message type is unknown.');
      }
    };

    if (this.isSupportMultiLanguage(message)) { // (GSM, External Language)
      let multiLanguageSupportKey = this.CMAS_MULTI_LANGUAGE_SUPPORT_KEY;
      this.getSettingsValue(multiLanguageSupportKey).then((result) => {
        this.debug(`isSupportExternalLanguage -> ${result}`);
        if (!!result || (result === undefined)) { // True or undefined
          checkSpecificTypeMessage(info, callback);
        } else { // False
          info.receive = false;
          if (callback) {
            callback(info);
          }
        }
      });
    } else { // (CMDA, English) (GSM, English)
      checkSpecificTypeMessage(info, callback);
    }
  };

  Util.prototype.isSameMsgId = function (message_old, message_new) {
    let isSame = false;
    if (message_new.messageId) {
      isSame = (message_old.messageId === message_new.messageId);
    }
    return isSame;
  };

  Util.prototype.isSameMsgSerialNumber = function (message_old, message_new) {
    let isSame = false;
    if (message_new.messageCode) {
      isSame = (message_old.messageCode === message_new.messageCode);
    }
    return isSame;
  };

  Util.prototype.isSameMsg = function (message_old, message_new, bGsm) {
    if (bGsm) {
      return this.isSameMsgId(message_old, message_new) &&
             this.isSameMsgSerialNumber(message_old, message_new);
    } else {
      return this.isSameMsgId(message_old, message_new);
    }
  };

  Util.prototype.sendAlert = function (msg) {
    global.open = jest.fn();
    let url = [
      'attention.html?title=',
      encodeURIComponent(msg.messageType),
      '&date=',
      encodeURIComponent(msg.timestamp),
      '&body=',
      encodeURIComponent(msg.body),
      '&id=',
      encodeURIComponent(msg.id)
    ].join('');
    return window.open(url, '_blank', 'attention');
  };

  Util.prototype.setWakeLock = function (mode) {
    this.debug(`setWakeLock mode -> ${mode}`);
    switch (mode) {
      case 'cpu':
        this.cpuLock = navigator.requestWakeLock('cpu');
        break;
      case 'screen':
        this.screenLock = navigator.requestWakeLock('screen');
        break;
      default:
        this.cpuLock = navigator.requestWakeLock('cpu');
        this.screenLock = navigator.requestWakeLock('screen');
        break;
    }
  };

  Util.prototype.clearWakeLock = function () {
    this.debug('clearWakeLock.');
    if (null !== this.screenLock) {
      this.screenLock.unlock();
      this.screenLock = null;
    }

    if (null !== this.cpuLock) {
      this.cpuLock.unlock();
      this.cpuLock = null;
    }
  };

  Util.prototype.getSettingsValue = function (key) {
    return new Promise((resolve, reject) => {
      let req = navigator.mozSettings.createLock().get(key);
      req.onsuccess = () => {
        resolve(req.result[key]);
      };
      req.onerror = () => {
        reject('Cannot get this settings value');
      };
    });
  };

  Util.prototype.setSettingsValue = function (key, value) {
    let data = {};
    data[key] = value;
    return new Promise((resolve, reject) => {
      let req = navigator.mozSettings.createLock().set(data);
      req.onsuccess = () => {
        resolve(true);
      };
      req.onerror = () => {
        reject('Cannot write this settings value to settings database.');
      };
    });
  };
  let Utils = new Util();
  exports.Utils = Utils;
})(window);
