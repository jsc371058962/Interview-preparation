(function (exports) {
  let AttentionHTML = {
    dir: 'ltr',
    innerHTML:
      '<body role="application" class="theme-communications">\
      <div class="statusbar-placeholder"></div>\
      <div id="alert-detail">\
        <gaia-header>\
          <h1 class="header" id="alert-title"></h1>\
        </gaia-header>\
        <div id="alert-container">\
          <div id="alert-body" >\
            <div data-icon="alert"></div>\
            <div id="alert-text">\
              <p id="alert-date"></p>\
              <p id="alert-content" class="navigable scrollBar" tabindex="-1"></p>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div class="option-menu-container hidden" tabindex="-1">\
        <div class="option-menu">\
          <div class="header h1" data-l10n-id="options">\
          </div>\
          <div class="content p-ul">\
          </div>\
        </div>\
      </div>\
      <div id="dialog" class="dialog-container hidden" tabindex="-1">\
        <div role="heading" class="dialog">\
          <div id="dialog-header-1" class="header h1" data-l10n-id="confirm" ></div>\
          <div class="content p-pri" tabindex="-1"></div>\
        </div>\
      </div>\
    </body>'
  };
  exports.AttentionHTML = AttentionHTML;
})(window);
